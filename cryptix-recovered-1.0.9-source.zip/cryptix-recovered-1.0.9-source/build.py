"""Reproducible Java 25 build against official, unobfuscated Minecraft 26.3.
Downloads build dependencies only; never loads the input client's native DLL.
"""
from pathlib import Path
import concurrent.futures, hashlib, json, os, shutil, subprocess, sys, urllib.request, zipfile

ROOT = Path(__file__).resolve().parent
CACHE = ROOT / '.build-cache'
def get(url, path, sha1=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and (not sha1 or hashlib.sha1(path.read_bytes()).hexdigest() == sha1):
        return path
    for attempt in range(3):
        try:
            data = urllib.request.urlopen(url, timeout=90).read()
            if sha1 and hashlib.sha1(data).hexdigest() != sha1:
                raise ValueError('SHA1 mismatch: ' + url)
            path.write_bytes(data)
            return path
        except Exception:
            if attempt == 2: raise
    return path

def metadata(url, name):
    return json.loads(get(url, CACHE / name).read_text(encoding='utf-8'))

def dependencies():
    manifest = metadata('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json', 'manifest.json')
    version = metadata(next(v['url'] for v in manifest['versions'] if v['id'] == '26.3'), '26.3.json')
    tasks = []
    client = version['downloads']['client']
    tasks.append((client['url'], CACHE / 'minecraft-26.3.jar', client['sha1']))
    for lib in version['libraries']:
        a = lib.get('downloads', {}).get('artifact')
        if a and '-natives-' not in a['path']: tasks.append((a['url'], CACHE / 'libraries' / a['path'], a.get('sha1')))
    loader = metadata('https://meta.fabricmc.net/v2/versions/loader/26.3/0.19.5', 'fabric-loader.json')
    for group in ('common', 'client', 'development'):
        for lib in loader['launcherMeta']['libraries'].get(group, []):
            groupid, artifact, versionid = lib['name'].split(':')[:3]
            rel = groupid.replace('.', '/') + '/' + artifact + '/' + versionid + '/' + artifact + '-' + versionid + '.jar'
            tasks.append((lib['url'].rstrip('/') + '/' + rel, CACHE / 'libraries' / rel, lib.get('sha1')))
    tasks += [('https://maven.fabricmc.net/net/fabricmc/fabric-loader/0.19.5/fabric-loader-0.19.5.jar', CACHE / 'fabric-loader.jar', None)]
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        jars = list(pool.map(lambda t: get(*t), tasks))
    from prepare_access import prepare
    widened = CACHE / 'minecraft-26.3-compile-access.jar'
    if not widened.exists(): prepare(CACHE / 'minecraft-26.3.jar', widened)
    jars[0] = widened
    print('Resolved', len(jars), 'dependency jars.', flush=True)
    return jars

def build():
    jars = dependencies()
    classes = ROOT / 'build/classes'
    if classes.exists():
        assert classes.resolve().parent == (ROOT / 'build').resolve()
        shutil.rmtree(classes)
    classes.mkdir(parents=True, exist_ok=True)
    files = sorted((ROOT / 'src/main/java').rglob('*.java'))
    args = ['--release', '25', '-encoding', 'UTF-8', '-proc:none', '-Xmaxerrs', '1000', '-classpath', os.pathsep.join(map(str, jars)), '-d', str(classes)] + list(map(str, files))
    argfile = ROOT / 'build/javac.args'
    argfile.write_text('\n'.join('"' + a.replace('\\', '/') + '"' for a in args), encoding='utf-8')
    compiler = os.environ.get('JAVA', 'java')
    result = subprocess.run([compiler, '--source', '25', str(ROOT / 'CompileClient.java')] + args, capture_output=True, text=True, encoding='utf-8', errors='replace')
    (ROOT / 'build/compile.log').write_text(result.stdout + result.stderr, encoding='utf-8')
    print((result.stdout + result.stderr)[-12000:])
    if result.returncode: return result.returncode
    out = ROOT / 'build/cryptix-recovered-26.3.jar'
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for base in [classes, ROOT / 'src/main/resources']:
            for p in sorted(base.rglob('*')):
                if p.is_file() and not p.name.endswith(('.SF', '.RSA', '.DSA')):
                    z.write(p, p.relative_to(base).as_posix())
    print('Built', out, flush=True)
    (ROOT / 'build/build-report.json').write_text(json.dumps({
        'minecraft': '26.3', 'fabric_loader': '0.19.5', 'java_release': 25,
        'source_files': len(files), 'class_files': len(list(classes.rglob('*.class'))),
        'compiler_exit_code': result.returncode, 'jar_sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
        'original_native_dll_loaded': False, 'exact_current_dll_bodies_recovered': 0,
        'earlier_version_adapted_methods': 29, 'support_methods_implemented_in_java': 9,
        'in_game_test_performed': False,
    }, indent=2), encoding='utf-8')
    return 0

if __name__ == '__main__': sys.exit(build())
