package a;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.*;
import net.minecraft.world.item.ItemStack;

/** Observes accepted outgoing packets; never cancels or fabricates packets. */
public final class CombatPacketOrder {
   private static final ClientActionTick tick = new ClientActionTick();
   private static LocalPlayer releasePlayer;
   private static ItemStack releaseItem;

   private CombatPacketOrder() {}

   public static boolean canAct() {
      return releasePlayer == null && tick.canAct();
   }

   public static void observe(Packet<?> packet) {
      if (packet instanceof ServerboundClientTickEndPacket) {
         tick.endNetworkTick();
      } else if (packet instanceof ServerboundAttackPacket
            || packet instanceof ServerboundInteractPacket
            || packet instanceof ServerboundUseItemPacket
            || packet instanceof ServerboundUseItemOnPacket
            || packet instanceof ServerboundPickItemFromBlockPacket
            || packet instanceof ServerboundPickItemFromEntityPacket) {
         tick.recordAction();
      } else if (packet instanceof ServerboundPlayerActionPacket action) {
         switch (action.getAction()) {
            case RELEASE_USE_ITEM, START_DESTROY_BLOCK, ABORT_DESTROY_BLOCK, STOP_DESTROY_BLOCK, STAB -> tick.recordAction();
            default -> {}
         }
      }
   }

   public static void requestRelease() {
      Minecraft client = Minecraft.getInstance();
      if (client.player == null || client.gameMode == null || !client.player.isUsingItem()) return;
      releasePlayer = client.player;
      releaseItem = client.player.getUseItem();
      onClientTick();
   }

   /** Runs before vanilla key handling, including while KillAura is disabled. */
   public static void onClientTick() {
      if (releasePlayer == null) return;
      Minecraft client = Minecraft.getInstance();
      if (client.player != releasePlayer || client.gameMode == null
            || !releasePlayer.isUsingItem() || releasePlayer.getUseItem() != releaseItem) {
         releasePlayer = null;
         releaseItem = null;
         return;
      }
      if (!tick.canAct()) return;
      LocalPlayer player = releasePlayer;
      releasePlayer = null;
      releaseItem = null;
      client.gameMode.releaseUsingItem(player);
   }

   public static void resetConnection() {
      tick.endNetworkTick();
      releasePlayer = null;
      releaseItem = null;
   }
}
