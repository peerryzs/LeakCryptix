package a;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class l {
   private static List<m> f57 = new ArrayList();
   

   public static void m8() {
      f57.add(new p());
      f57.add(new z());
      f57.add(new v());
      f57.add(new b());
   }

   public static void m12(String var0) {
      if (var0.startsWith(".")) {
         var0 = var0.substring(1);
         String[] var1 = var0.split(" ");
         if (var1.length > 0) {
            String var2 = var1[0];
            int var3 = 0;

            for (int var4 = f57.size(); var3 < var4; var3++) {
               m var5 = (m)f57.get(var3);

               for (int var6 = 0; var6 < var5.f2.length; var6++) {
                  if (var5.f2[var6].equalsIgnoreCase(var2)) {
                     var5.m0(var1, var0);
                     return;
                  }
               }
            }
         }
      }
   }

   public static m m10(String var0) {
      for (m var2 : f57) {
         if (var2.f0.equalsIgnoreCase(var0)) {
            return var2;
         }

         String[] var3 = var2.f2;
         int var4 = var3.length;

         for (int var5 = 0; var5 < var4; var5++) {
            String var6 = var3[var5];
            if (var6.equalsIgnoreCase(var0)) {
               return var2;
            }
         }
      }

      return null;
   }

   public static List<m> m9() {
      return f57;
   }

   public static List m11() {
      ArrayList var0 = new ArrayList();

      for (m var2 : f57) {
         var0.addAll(Arrays.asList(var2.f2));
      }

      return var0;
   }

   
}
