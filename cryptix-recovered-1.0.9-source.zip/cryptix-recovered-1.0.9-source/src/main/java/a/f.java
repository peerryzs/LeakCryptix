package a;

import com.cryptix.script.ScriptManager;
import com.cryptix.script.impl.packet.PacketManager;
import java.nio.charset.StandardCharsets;
import net.minecraft.network.protocol.Packet;

public class f extends r {
   private Packet f101;
   

   

   public Packet m42() {
      return this.f101;
   }

   public void m43(Packet var1) {
      this.f101 = var1;
   }

   public f m41(Packet var1) {
      this.f101 = var1;
      if (var1.getClass().getSimpleName().startsWith("Client")) {
         ScriptManager.onPacketReceive(PacketManager.getType(var1), this);
      }

      return this;
   }
}
