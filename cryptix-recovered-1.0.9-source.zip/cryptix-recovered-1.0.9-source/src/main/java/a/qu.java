package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.lwjgl.sdl.SDLKeyboard;

public class qu {
   public int f8;
   private static final String f173 = "";
   public int f9;
   private NumberSetting f180;
   public boolean f12;
   private double f181;
   private float f183;
   private long f184;
   private long f182;
   public final Module f7;
   public int f11;
   public int f14;
   public int f10;
   public boolean f13;
   

   public void m101(int var1) {
      if (this.f13) {
         this.f7.setKeyBind(var1 == 41 ? 0 : var1);
         this.f13 = false;
      }
   }

   public void m103() {
      this.f180 = null;
      this.f182 = 0L;
   }

   public void m104(float var1, boolean var2) {
      int var3 = var2 ? 255 : 0;
      float var4 = 1.0F - (float)Math.exp(-15.0F * var1);
      this.f14 = this.f14 + (int)((var3 - this.f14) * var4);
      if (Math.abs(this.f14 - var3) <= 1) {
         this.f14 = var3;
      }
   }

   public int m100() {
      return this.f11 + (this.f12 ? this.f7.f15.size() * 12 + this.f11 : 0);
   }

   public void m98(double var1, double var3, int var5) {
      if (var5 == 1 && this.m99(var1, var3)) {
         this.f7.toggle();
      } else if (var5 == 3 && this.m99(var1, var3)) {
         this.f12 = (!this.f12);
      } else if (this.f12) {
         int var6 = this.f11;

         for (Setting var8 : this.f7.f15) {
            if (var1 >= this.f8 + 5 && var1 <= this.f8 + this.f10 && var3 >= this.f9 + var6 && var3 <= this.f9 + var6 + 12
               )
             {
               if (var8 instanceof ModeSetting var9 && (var5 == 1 || var5 == 3)) {
                  String[] var10 = var9.getModes();
                  int var11 = 0;

                  for (int var12 = 0; var12 < var10.length; var12++) {
                     if (var10[var12].equals(var9.getValue())) {
                        var11 = var12;
                        break;
                     }
                  }

                  int var17 = var5 == 1 ? (var11 + 1) % var10.length : (var11 - 1 + var10.length) % var10.length;
                  var9.setValue(var10[var17]);
               }

               if (var8 instanceof BooleanSetting var14 && var5 == 1) {
                  var14.setValue((!var14.getValue()));
               }

               if (var8 instanceof hk var15 && var5 == 1) {
                  var15.m240();
               }

               if (var8 instanceof NumberSetting var16 && var5 == 1) {
                  this.f180 = var16;
                  this.f181 = var16.getValue();
                  this.f182 = System.nanoTime();
                  this.updateSlider(var16, var1);
               }
            }

            var6 += 12;
         }

         int var13 = this.f9 + this.f11 + this.f7.f15.size() * 12;
         if (var1 >= this.f8 && var1 <= this.f8 + this.f10 && var3 >= var13 && var3 <= var13 + this.f11) {
            if (var5 == 1) {
               this.f13 = true;
            } else if (var5 == 3) {
               this.f7.setHidden((!this.f7.isHidden()));
            }
         }
      }
   }

   public qu(Module var1) {
      this.f11 = 15;
      this.f7 = var1;
   }

   public void m102(double var1, double var3) {
      if (this.f180 != null) {
         this.updateSlider(this.f180, var1);
      }
   }

   private void updateSlider(NumberSetting var1, double var2) {
      double var4 = Math.max(0.0, Math.min(1.0, (var2 - this.f8) / this.f10));
      var1.setValue(var1.getMinimum() + var4 * (var1.getMaximum() - var1.getMinimum()));
   }

   

   public boolean m99(double var1, double var3) {
      return (var1 >= this.f8 && var1 <= this.f8 + this.f10 && var3 >= this.f9 && var3 <= this.f9 + this.f11);
   }

   public void m97(GuiGraphicsExtractor var1, int var2) {
      long var3 = System.nanoTime();
      double var5 = Math.min((var3 - this.f184) * 1.0E-9, 0.05);
      this.f184 = var3;
      float var7 = this.f7.isEnabled() ? 1.0F : 0.0F;
      float var8 = 1.0F - (float)Math.exp(-10.0 * var5);
      this.f183 = this.f183 + (var7 - this.f183) * var8;
      if (Math.abs(this.f183 - var7) < 0.001F) {
         this.f183 = var7;
      }

      int var9 = 128 * this.f14 / 255 << 24 | 1052688;
      int var10 = 170 * this.f14 / 255 << 24 | 16777215;
      int var11 = (int)(this.f183 * 255.0F);
      int var12 = var2 & 16777215 | this.f14 << 24;
      int var13 = var2 & 16777215 | var11 * this.f14 / 255 << 24;
      int var14 = 128 * this.f14 / 255 << 24 | 2105376;
      int var15 = 80 * this.f14 / 255 << 24;
      var1.fill(this.f8, this.f9, this.f8 + this.f10, this.f9 + this.f11, var9);
      var1.text(Minecraft.getInstance().font, this.f7.getName(), this.f8 + 4, this.f9 + 4, var10);
      if (this.f7.isEnabled() || this.f183 > 0.0F) {
         var1.text(Minecraft.getInstance().font, this.f7.getName(), this.f8 + 4, this.f9 + 4, var13);
      }

      if (this.f12) {
         int var16 = this.f11;

         for (Setting var18 : this.f7.f15) {
            var1.fill(this.f8, this.f9 + var16, this.f8 + this.f10, this.f9 + var16 + 12, var14);
            String var19 = f173;
            if (var18 instanceof ModeSetting var20) {
               var19 = var20.getValue();
            } else if (var18 instanceof BooleanSetting var21) {
               var19 = var21.getValue() ? "\u00a7aON" : "\u00a7cOFF";
            } else if (var18 instanceof hk var22) {
               var19 = "\u00a7cOFF";
            } else if (var18 instanceof NumberSetting var23) {
               double var24 = var23.getValue();
               double var26 = var24;
               if (var23 == this.f180) {
                  double var28 = Math.min((var3 - this.f182) * 1.0E-9, 0.05);
                  this.f182 = var3;
                  double var30 = 1.0 - Math.exp(-18.0 * var28);
                  this.f181 = this.f181 + (var24 - this.f181) * var30;
                  var26 = this.f181;
               }

               double var39 = var23.getMaximum() - var23.getMinimum();
               double var40 = var39 == 0.0 ? 0.0 : (var26 - var23.getMinimum()) / var39;
               var40 = Math.max(0.0, Math.min(1.0, var40));
               int var32 = (int)(this.f10 * var40);
               var1.fill(this.f8, this.f9 + var16 + 11, this.f8 + this.f10, this.f9 + var16 + 12, var15);
               var1.fill(this.f8, this.f9 + var16 + 11, this.f8 + var32, this.f9 + var16 + 12, var12);
               var19 = String.valueOf(var24);
            }

            var1.pose().pushMatrix();
            var1.pose().scale(0.8F, 0.8F);
            float var36 = (this.f8 + 4) * 1.25F;
            float var37 = (this.f9 + var16 + 3.5F) * 1.25F;
            String var38 = var18.getName() + ": ";
            var1.text(Minecraft.getInstance().font, var38, (int)var36, (int)var37, var10);
            var1.text(Minecraft.getInstance().font, var19, (int)(var36 + Minecraft.getInstance().font.width(var38)), (int)var37, var12);
            var1.pose().popMatrix();
            var16 += 12;
         }

         var1.fill(this.f8, this.f9 + var16, this.f8 + this.f10, this.f9 + var16 + this.f11, var14);
         String var33 = "Bind: ";
         String var34;
         if (this.f13) {
            var34 = "Press key...";
         } else if (this.f7.getKeyBind() == 0) {
            var34 = "NONE";
         } else {
            String var35 = SDLKeyboard.SDL_GetScancodeName(this.f7.getKeyBind());
            var34 = var35 == null ? "UNKNOWN" : var35.toUpperCase();
         }

         if (this.f7.isHidden()) {
            var34 = var34 + " §c(Hidden)";
         }

         int var10003 = this.f8 + 4;
         int var10004 = this.f9 + var16 + 4;
         var1.text(Minecraft.getInstance().font, var33, var10003, var10004, var10);
         var1.text(
            Minecraft.getInstance().font,
            var34,
            this.f8 + 4 + Minecraft.getInstance().font.width(var33),
            this.f9 + var16 + 4,
            var12
         );
      }
   }
}
