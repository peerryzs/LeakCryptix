package a;

import java.nio.charset.StandardCharsets;

public class NameTagsModule extends Module {
   private NumberSetting f821;
   private NumberSetting f822;
   

   public NameTagsModule() {
      super("NameTags", Category.f24);
      this.f821 = new NumberSetting("Scale", this, 1.0, 0.1, 2.0, 0.1);
      this.f822 = new NumberSetting("Y", this, 0.0, -10.0, 10.0, 0.1);
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f14) {
         u.f14.m36(true);
         u.f14.m35(15728880);
         float var2 = (float)this.f821.getValue();
         u.f14.m29().scale(var2, var2, var2);
         u.f14.m29().translate(0.0, this.f822.getValue(), 0.0);
      }
   }

   
}
