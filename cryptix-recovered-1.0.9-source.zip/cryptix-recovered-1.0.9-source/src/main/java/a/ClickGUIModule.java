package a;

import java.nio.charset.StandardCharsets;

public class ClickGUIModule extends Module {
   public final BooleanSetting f43;
   private ev f778;
   

   @Override
   public void onEnable() {
      if (this.f778 == null) {
         this.f778 = new ev();
      }

      f0.gui.setScreen(this.f778);
      this.setEnabled(false);
   }

   

   public ClickGUIModule() {
      super("ClickGUI", 229, Category.f24);
      this.f43 = new BooleanSetting("Module Sound", this, true);
   }
}
