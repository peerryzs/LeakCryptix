package a;

import net.minecraft.client.Camera;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;
import org.joml.Vector4f;

public class th implements ve {
   private static double f1014;
   private static double f1013;
   private static int f1016;
   private static int f1015;
   private static final Matrix4f f1010 = new Matrix4f();
   private static final Vector4f f1011 = new Vector4f();
   private static double f1012;
   

   public static void m64(GuiGraphicsExtractor var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      var0.guiRenderState
         .addGuiElement(
            new rm(
               RenderPipelines.GUI,
               TextureSetup.noTexture(),
               new Matrix3x2f(var0.pose()),
               var1,
               var2,
               var1 + var3,
               var2 + var4,
               var5,
               var6,
               var0.scissorStack.peek()
            )
         );
   }

   public static void m61() {
      Camera var0 = ve.f0.gameRenderer.mainCamera();
      Vec3 var1 = var0.position();
      f1012 = var1.x;
      f1013 = var1.y;
      f1014 = var1.z;
      f1010.set(var0.getViewRotationProjectionMatrix(f1010));
      f1015 = ve.f0.getWindow().getGuiScaledWidth();
      f1016 = ve.f0.getWindow().getGuiScaledHeight();
   }

   public static fd m62(double var0, double var2, double var4, fd var6) {
      f1011.set((float)(var0 - f1012), (float)(var2 - f1013), (float)(var4 - f1014), 1.0F);
      f1011.mul(f1010);
      if (f1011.w <= 0.0F) {
         return null;
      } else {
         float var7 = 1.0F / f1011.w;
         double var8 = f1011.x * var7;
         double var10 = f1011.y * var7;
         double var12 = f1011.z * var7;
         var6.m247((var8 * 0.5 + 0.5) * f1015, (0.5 - var10 * 0.5) * f1016, var12);
         return var6;
      }
   }

   public static void m66(
      GuiGraphicsExtractor var0,
      Identifier var1,
      int var2,
      int var3,
      int var4,
      int var5,
      int var6,
      int var7,
      int var8,
      int var9,
      int var10,
      int var11,
      int var12,
      int var13
   ) {
      AbstractTexture var14 = ve.f0.getTextureManager().getTexture(var1);
      var0.guiRenderState
         .addGuiElement(
            new rn(
               RenderPipelines.GUI_TEXTURED,
               TextureSetup.singleTexture(var14.getTextureView(), var14.getSampler()),
               new Matrix3x2f(var0.pose()),
               var2,
               var3,
               var2 + var4,
               var3 + var5,
               var6,
               (float)var7 / var11,
               (float)var8 / var12,
               (float)(var7 + var9) / var11,
               (float)(var8 + var10) / var12,
               var13,
               var0.scissorStack.peek()
            )
         );
   }

   public static void m63(j var0, int var1, int var2, int var3, int var4, double var5, int var7, int var8, int var9) {
      var0.m76().fill(var1 - 1, var2 - 1, var1 + var3 + 1, var2 + var4 + 1, var7);
      var0.m76().fill(var1, var2, var1 + var3, var2 + var4, var8);
      var0.m76().fill(var1, var2, (int)(var1 + var3 * var5), var2 + var4, var9);
   }

   public static void m65(GuiGraphicsExtractor var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      var0.guiRenderState
         .addGuiElement(
            new zg(
               RenderPipelines.GUI,
               TextureSetup.noTexture(),
               new Matrix3x2f(var0.pose()),
               var1,
               var2,
               var1 + var3,
               var2 + var4,
               var5,
               var6,
               var7,
               var0.scissorStack.peek()
            )
         );
   }
}
