package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.network.protocol.game.ServerboundPunchPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.component.SwingAnimation;

public class TriggerBotModule extends Module {
   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         Entity var3 = f0.crosshairPickEntity;
         if (var3 instanceof Entity && f0.player != null && f0.player.isAlive() && f0.player.getAttackStrengthScale(0.0F) >= 1.0F) {
            f0.gameMode.attack(f0.player, var3);
            f0.player.swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, false);
            f0.getConnection().send(ServerboundPunchPacket.INSTANCE);
         }
      }
   }

   public TriggerBotModule() {
      super("TriggerBot", Category.f21);
   }

   
}
