package a;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public class g extends r {
   private PoseStack f90;
   private Vec3 f93;
   private Component f91;
   private Entity f97;
   private boolean f96;
   private Component f92;
   private int f94;
   private int f95;
   

   public void m33(Vec3 var1) {
      this.f93 = var1;
   }

   public void m35(int var1) {
      this.f95 = var1;
   }

   public boolean m28() {
      return this.f96;
   }

   public void m32(Component var1) {
      this.f92 = var1;
   }

   public Component m23() {
      return this.f91;
   }

   public Entity m30() {
      return this.f97;
   }

   public g m22(PoseStack var1, Component var2, Vec3 var3, int var4, int var5, boolean var6, Entity var7) {
      this.f91 = var2;
      this.f92 = var2;
      this.f93 = var3;
      this.f94 = var4;
      this.f95 = var5;
      this.f96 = var6;
      this.f90 = var1;
      this.f97 = var7;
      return this;
   }

   public Vec3 m25() {
      return this.f93;
   }

   public void m36(boolean var1) {
      this.f96 = var1;
   }

   public int m26() {
      return this.f94;
   }

   public void m34(int var1) {
      this.f94 = var1;
   }

   public PoseStack m29() {
      return this.f90;
   }

   public Component m24() {
      return this.f92;
   }

   public int m27() {
      return this.f95;
   }

   public void m31(Component var1) {
      this.f91 = var1;
   }
}
