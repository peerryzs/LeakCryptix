package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.NonNullList;
import net.minecraft.core.Registry;
import net.minecraft.core.Holder.Reference;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.item.equipment.Equippable;

public class InvManagerModule extends Module {
   private final NumberSetting f616;
   private final NumberSetting f613;
   private final BooleanSetting f617;
   private final BooleanSetting f619;
   private final NumberSetting f614;
   private final BooleanSetting f618;
   private int f620;
   private final NumberSetting f615;
   

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   private void pm$112() {
      for (int var1 = 0; var1 < 4; var1++) {
         int var2 = -1;
         float var3 = -1.0F;

         EquipmentSlot var4 = switch (var1) {
            case 0 -> EquipmentSlot.HEAD;
            case 1 -> EquipmentSlot.CHEST;
            case 2 -> EquipmentSlot.LEGS;
            case 3 -> EquipmentSlot.FEET;
            default -> throw new IllegalStateException();
         };
         NonNullList var5 = f0.player.getInventory().getNonEquipmentItems();

         for (int var6 = 0; var6 < var5.size(); var6++) {
            ItemStack var7 = (ItemStack)var5.get(var6);
            if (!var7.isEmpty()) {
               Equippable var8 = (Equippable)var7.get(DataComponents.EQUIPPABLE);
               if (var8 != null && var8.slot() == var4) {
                  float var9 = this.pm$113(var7);
                  if (var9 > var3) {
                     var3 = var9;
                     var2 = var6;
                  }
               }
            }
         }

         if (var2 != -1) {
            ItemStack var10 = f0.player.getItemBySlot(var4);
            float var11 = this.pm$113(var10);
            if (var10.isEmpty() || !(var11 >= var3)) {
               if (!var10.isEmpty()) {
                  int var13 = switch (li.$SwitchMap$net$minecraft$world$entity$EquipmentSlot[var4.ordinal()]) {
                     case 1 -> 5;
                     case 2 -> 6;
                     case 3 -> 7;
                     case 4 -> 8;
                     default -> -1;
                  };
                  this.f620 = 0;
                  f0.gameMode.handleContainerInput(f0.player.containerMenu.containerId, var13, 0, ContainerInput.THROW, f0.player);
                  return;
               } else {
                  int var12 = var2 < 9 ? var2 + 36 : var2;
                  this.f620 = 0;
                  f0.gameMode.handleContainerInput(f0.player.containerMenu.containerId, var12, 0, ContainerInput.QUICK_MOVE, f0.player);
                  return;
               }
            }
         }
      }
   }

   private boolean pm$114() {
      NonNullList var1 = f0.player.getInventory().getNonEquipmentItems();

      for (int var2 = 0; var2 < var1.size(); var2++) {
         ItemStack var3 = (ItemStack)var1.get(var2);
         if (!var3.isEmpty() && (var3.is(ItemTags.PICKAXES) || var3.is(ItemTags.AXES) || var3.is(ItemTags.SHOVELS) || var3.is(ItemTags.HOES))) {
            int var4 = var2 < 9 ? var2 + 36 : var2;
            this.f620 = 0;
            f0.gameMode.handleContainerInput(f0.player.containerMenu.containerId, var4, 0, ContainerInput.THROW, f0.player);
            return true;
         }
      }

      return false;
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         if (!(f0.player.containerMenu instanceof ChestMenu)) {
            if (f0.gui.screen() instanceof InventoryScreen) {
               this.pm$107();
            } else if (this.f619.getValue() && !ModuleManager.f31.isEnabled() && f0.gui.screen() == null) {
               this.pm$107();
            } else {
               this.f620 = 0;
            }
         }
      }
   }

   

   private void pm$107() {
      this.f620 = this.f620 + 1;
      if (this.f620 < this.f613.getValue() && this.f619.getValue()) {
         f0.player.closeContainer();
      } else if (!this.f617.getValue() || !this.pm$114()) {
         if (!this.f618.getValue() || !this.pm$115()) {
            this.pm$112();
            this.pm$108();
            this.pm$109();
            this.pm$111();
            System.out.println(this.f620);
         }
      }
   }

   private void pm$108() {
      int var1 = (int)this.f614.getValue() - 1;
      if (var1 >= 0 && var1 <= 8) {
         NonNullList var2 = f0.player.getInventory().getNonEquipmentItems();
         int var3 = -1;
         double var4 = -Double.MAX_VALUE;

         for (int var6 = 0; var6 < 36; var6++) {
            ItemStack var7 = f0.player.getInventory().getItem(var6);
            if (!var7.isEmpty() && var7.is(ItemTags.SWORDS)) {
               double var8 = this.pm$110(var7);
               if (var8 > var4) {
                  var4 = var8;
                  var3 = var6;
               }
            }
         }

         for (int var10 = 0; var10 < 36; var10++) {
            if (var10 != var3) {
               ItemStack var12 = (ItemStack)var2.get(var10);
               if (!var12.isEmpty() && var12.is(ItemTags.SWORDS)) {
                  int var13 = var10 < 9 ? var10 + 36 : var10;
                  this.f620 = 0;
                  f0.gameMode.handleContainerInput(f0.player.containerMenu.containerId, var13, 0, ContainerInput.THROW, f0.player);
                  return;
               }
            }
         }

         if (var3 != -1) {
            int var11 = var3 < 9 ? var3 + 36 : var3;
            if (var3 != var1) {
               this.f620 = 0;
               f0.gameMode.handleContainerInput(f0.player.containerMenu.containerId, var11, var1, ContainerInput.SWAP, f0.player);
            }
         }
      }
   }

   private float pm$113(ItemStack var1) {
      if (var1.isEmpty()) {
         return 0.0F;
      } else {
         double[] var10000 = new double[1];
         var10000[0] = 0.0;
         double[] var2 = var10000;
         Equippable var3 = (Equippable)var1.get(DataComponents.EQUIPPABLE);
         if (var3 == null) {
            return 0.0F;
         } else {
            var1.forEachModifier(var3.slot(), (var1x, var2x) -> {
               if (var1x.equals(Attributes.ARMOR)) {
                  var2[0] = var2[0] + var2x.amount();
               }
            });
            ItemEnchantments var4 = var1.getEnchantments();
            Registry var5 = f0.level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
            Reference var6 = var5.getOrThrow(Enchantments.PROTECTION);
            int var7 = var4.getLevel(var6);
            return (float)(var2[0] + var7);
         }
      }
   }

   private double pm$110(ItemStack var1) {
      double[] var10000 = new double[1];
      var10000[0] = 0.0;
      double[] var2 = var10000;
      var1.forEachModifier(EquipmentSlot.MAINHAND, (var1x, var2x) -> {
         if (var1x.equals(Attributes.ATTACK_DAMAGE)) {
            var2[0] = var2[0] + var2x.amount();
         }
      });
      ItemEnchantments var3 = var1.getEnchantments();
      Registry var4 = f0.level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
      Reference var5 = var4.getOrThrow(Enchantments.SHARPNESS);
      int var6 = var3.getLevel(var5);
      return var2[0] + var6 * 0.5 + (var6 > 0 ? 0.5 : 0.0);
   }

   private boolean pm$115() {
      NonNullList var1 = f0.player.getInventory().getNonEquipmentItems();

      for (int var2 = 0; var2 < var1.size(); var2++) {
         ItemStack var3 = (ItemStack)var1.get(var2);
         if (!var3.isEmpty()
            && (
               var3.is(Items.EGG)
                  || var3.is(Items.SNOWBALL)
                  || var3.is(Items.EXPERIENCE_BOTTLE)
                  || var3.is(Items.FISHING_ROD)
                  || var3.is(Items.LAVA_BUCKET)
                  || var3.is(Items.WATER_BUCKET)
            )) {
            int var4 = var2 < 9 ? var2 + 36 : var2;
            this.f620 = 0;
            f0.gameMode.handleContainerInput(f0.player.containerMenu.containerId, var4, 1, ContainerInput.THROW, f0.player);
            return true;
         }
      }

      return false;
   }

   public InvManagerModule() {
      super("InvManager", Category.f23);
      this.f613 = new NumberSetting("Delay", this, 2.0, 0.0, 4.0, 1.0);
      this.f614 = new NumberSetting("Sword Slot", this, 1.0, 1.0, 9.0, 1.0);
      this.f615 = new NumberSetting("Block Slot", this, 2.0, 1.0, 9.0, 1.0);
      this.f616 = new NumberSetting("Gapple Slot", this, 3.0, 1.0, 9.0, 1.0);
      this.f617 = new BooleanSetting("Drop Tools", this, false);
      this.f618 = new BooleanSetting("Drop Trash", this, false);
      this.f619 = new BooleanSetting("Hypixel", this, false);
   }

   private void pm$109() {
      int var1 = (int)this.f615.getValue() - 1;
      if (var1 >= 0 && var1 <= 8) {
         ItemStack var2 = f0.player.getInventory().getItem(var1);
         if (var2.isEmpty() || !(var2.getItem() instanceof BlockItem)) {
            int var3 = -1;
            int var4 = 0;

            for (int var5 = 0; var5 < 36; var5++) {
               ItemStack var6 = f0.player.getInventory().getItem(var5);
               if (!var6.isEmpty() && var6.getItem() instanceof BlockItem && var6.getCount() > var4) {
                  var4 = var6.getCount();
                  var3 = var5;
               }
            }

            if (var3 != -1) {
               int var7 = var3 < 9 ? var3 + 36 : var3;
               this.f620 = 0;
               f0.gameMode.handleContainerInput(f0.player.containerMenu.containerId, var7, var1, ContainerInput.SWAP, f0.player);
            }
         }
      }
   }

   private void pm$111() {
      int var1 = (int)this.f616.getValue() - 1;
      if (var1 >= 0 && var1 <= 8) {
         NonNullList var2 = f0.player.getInventory().getNonEquipmentItems();

         for (int var3 = 0; var3 < var2.size(); var3++) {
            ItemStack var4 = (ItemStack)var2.get(var3);
            if (!var4.isEmpty() && var4.is(Items.GOLDEN_APPLE) && var3 != var1) {
               int var5 = var3 < 9 ? var3 + 36 : var3;
               this.f620 = 0;
               f0.gameMode.handleContainerInput(f0.player.containerMenu.containerId, var5, var1, ContainerInput.SWAP, f0.player);
               return;
            }
         }
      }
   }
}
