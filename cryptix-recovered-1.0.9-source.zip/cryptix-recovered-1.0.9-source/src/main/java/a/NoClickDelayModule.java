package a;

import java.nio.charset.StandardCharsets;

public class NoClickDelayModule extends Module {
   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         f0.missTime = 0;
      }
   }

   public NoClickDelayModule() {
      super("NoClickDelay", Category.f25);
   }

   
}
