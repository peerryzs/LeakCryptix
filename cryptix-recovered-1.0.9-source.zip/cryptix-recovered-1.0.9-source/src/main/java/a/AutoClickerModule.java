package a;

import com.mojang.blaze3d.platform.InputConstants.Key;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import net.minecraft.client.KeyMapping;
import net.minecraft.world.phys.HitResult.Type;

public class AutoClickerModule extends Module {
   private final BooleanSetting f266;
   private final NumberSetting f265;
   private final BooleanSetting f267;
   private final Random f268;
   private final NumberSetting f264;
   private long f269;
   

   

   public AutoClickerModule() {
      super("AutoClicker", Category.f21);
      this.f264 = new NumberSetting("Min CPS", this, 8.0, 1.0, 20.0, 1.0);
      this.f265 = new NumberSetting("Max CPS", this, 12.0, 1.0, 20.0, 1.0);
      this.f266 = new BooleanSetting("Randomize", this, true);
      this.f267 = new BooleanSetting("Break Blocks", this, false);
      this.f268 = new Random();
   }

   private long pm$59() {
      double var1;
      if (this.f266.getValue()) {
         var1 = this.f264.getValue() + (this.f265.getValue() - this.f264.getValue()) * this.f268.nextDouble();
      } else {
         var1 = this.f264.getValue();
      }

      return (long)(1000.0 / var1);
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         if (f0.gui.screen() != null) {
            return;
         }

         if (!f0.mouseHandler.isLeftPressed()) {
            return;
         }

         if (this.f267.getValue() && f0.hitResult != null && f0.hitResult.getType() == Type.BLOCK) {
            Key var5 = com.mojang.blaze3d.platform.InputConstants.Type.MOUSE.getOrCreate(0);
            KeyMapping.set(var5, true);
            return;
         }

         long var2 = this.pm$59();
         if (System.currentTimeMillis() - this.f269 >= var2) {
            Key var4 = com.mojang.blaze3d.platform.InputConstants.Type.MOUSE.getOrCreate(0);
            KeyMapping.set(var4, true);
            KeyMapping.click(var4);
            KeyMapping.set(var4, false);
            this.f269 = System.currentTimeMillis();
         }
      }
   }

   @Override
   public void onEnable() {
      this.f269 = System.currentTimeMillis();
   }
}
