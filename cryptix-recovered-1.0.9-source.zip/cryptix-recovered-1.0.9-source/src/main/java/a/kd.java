package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class kd extends oc {
   private final TargetHUDModule f195;
   

   public kd(TargetHUDModule var1) {
      super(Component.literal("TargetHUD Position"));
      this.f195 = var1;
   }

   public boolean isPauseScreen() {
      return false;
   }

   public void extractRenderState(GuiGraphicsExtractor var1, int var2, int var3, float var4) {
      var1.fill(0, 0, this.width, this.height, -2147483648);
      this.f195.m218(var1);
      int var5 = ve.f0.getWindow().getGuiScaledWidth();
      int var6 = ve.f0.getWindow().getGuiScaledHeight();
      if (this.isInsideHud(var2, var3)) {
         int var7 = ve.f0.getWindow().getGuiScaledWidth();
         int var8 = ve.f0.getWindow().getGuiScaledHeight();
         int var9 = this.setting.m235() + var7 / 2;
         int var10 = this.setting.m236() + var8 / 2;
         int var11 = this.setting.m237();
         int var12 = this.setting.m238();
         var1.outline(var9, var10, var11, var12, -1);
      }

      String var13 = "Edit the TargetHUD position by dragging.";
      var1.text(
         ve.f0.font, var13, var5 / 2 - ve.f0.font.width(var13) / 2, var6 / 2 - 25, -1
      );
      if (this.getFocused() != null) {
         this.setFocused(null);
      }

      super.extractRenderState(var1, var2, var3, var4);
   }

   public void init() {
      Button var1 = Button.builder(Component.literal("Reset Position"), var1x -> this.setting.m245(0, 0))
         .bounds(this.width - 90, this.height - 25, 85, 20)
         .build();
      this.addRenderableWidget(var1);
   }

   

   public boolean isInsideHud(double var1, double var3) {
      int var5 = ve.f0.getWindow().getGuiScaledWidth();
      int var6 = ve.f0.getWindow().getGuiScaledHeight();
      int var7 = this.setting.m235() + var5 / 2;
      int var8 = this.setting.m236() + var6 / 2;
      int var9 = this.setting.m237();
      int var10 = this.setting.m238();
      return (var1 >= var7 && var1 <= var7 + var9 && var3 >= var8 && var3 <= var8 + var10);
   }
}
