package a;

import net.minecraft.client.Minecraft;

public class hk extends Setting {
   private int f956;
   private int f955;
   private oc f959;
   private int f957;
   private int f958;
   

   public void m241(int var1) {
      this.f955 = var1;
   }

   public void m240() {
      Minecraft.getInstance().gui.setScreen(this.f959);
   }

   public void m244(int var1) {
      this.f958 = var1;
   }

   public int m238() {
      return this.f958;
   }

   public void m242(int var1) {
      this.f956 = var1;
   }

   public void m245(int var1, int var2) {
      this.f955 = var1;
      this.f956 = var2;
   }

   public void m243(int var1) {
      this.f957 = var1;
   }

   public int m236() {
      return this.f956;
   }

   public int m235() {
      return this.f955;
   }

   public hk(String var1, Module var2, int var3, int var4, int var5, int var6, oc var7) {
      super(var1, var2);
      this.f955 = var3;
      this.f956 = var4;
      this.f957 = var5;
      this.f958 = var6;
      this.f959 = var7;
      this.f959.setting = this;
   }

   public int m237() {
      return this.f957;
   }

   public oc m239() {
      return this.f959;
   }
}
