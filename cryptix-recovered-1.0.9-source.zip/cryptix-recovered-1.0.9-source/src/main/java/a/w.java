package a;

import com.cryptix.script.ScriptManager;
import com.cryptix.script.impl.packet.PacketManager;
import java.nio.charset.StandardCharsets;
import net.minecraft.network.protocol.Packet;

public class w extends r {
   private Packet f103;
   

   public Packet m45() {
      return this.f103;
   }

   

   public w m44(Packet var1) {
      this.f103 = var1;
      if (var1.getClass().getSimpleName().startsWith("Server")) {
         ScriptManager.onPacketSend(PacketManager.getType(var1), this);
      }

      return this;
   }
}
