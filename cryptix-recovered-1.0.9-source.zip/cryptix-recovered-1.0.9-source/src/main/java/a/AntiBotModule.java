package a;

import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public class AntiBotModule extends Module {
   private final Set f258 = new HashSet();
   

   public boolean m137(Entity var1) {
      if (!this.isEnabled()) {
         return false;
      } else if (var1 instanceof Player var2) {
         ClientPacketListener var3 = f0.getConnection();
         if (var3 == null) {
            return true;
         } else {
            return (!this.f258.contains(var2.getUUID()));
         }
      } else {
         return true;
      }
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         ClientPacketListener var2 = f0.getConnection();
         Collection<PlayerInfo> var3 = var2.getOnlinePlayers();
         this.f258.clear();

         for (PlayerInfo var5 : var3) {
            this.f258.add(var5.getProfile().id());
         }
      }
   }

   

   public AntiBotModule() {
      super("AntiBot", Category.f21);
   }
}
