package a;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public class jb implements ve {
   

   public static LivingEntity m53(boolean var0) {
      Player var1 = null;
      double var2 = -1.0;

      for (Player var5 : ve.f0.level.players()) {
         if (var5 != ve.f0.player && var5.isAlive() && var5.deathTime <= 0 && !var5.isRemoved() && !ModuleManager.f31.isEnabled()) {
            double var6 = ve.f0.player.distanceTo(var5);
            if (!(var6 < 11.0) && var6 > var2) {
               var2 = var6;
               var1 = var5;
            }
         }
      }

      return var1;
   }

   public static LivingEntity m52(double var0, boolean var2) {
      if (ModuleManager.f31.isEnabled()) {
         return null;
      } else {
         Player var3 = null;
         double var4 = Double.MAX_VALUE;
         double var6 = var0 * var0;
         LocalPlayer var8 = ve.f0.player;
         double var9 = var8.getX();
         double var11 = var8.getY();
         double var13 = var8.getZ();

         for (Player var16 : ve.f0.level.players()) {
            if (var16 != ve.f0.player && !pm$131(var16) && var16.isAlive() && var16.deathTime <= 0 && !var16.isRemoved() && (!ModuleManager.f29.m137(var16) || !var2)) {
               double var17 = var16.getX() - var9;
               double var19 = var16.getY() - var11;
               double var21 = var16.getZ() - var13;
               double var23 = var17 * var17 + var19 * var19 + var21 * var21;
               if (!(var23 > var6) && var23 < var4) {
                  var4 = var23;
                  var3 = var16;
               }
            }
         }

         return var3;
      }
   }

   public static LivingEntity m51(double var0, boolean var2) {
      if (ModuleManager.f31.isEnabled()) {
         return null;
      } else {
         Player var3 = null;
         double var4 = Double.MAX_VALUE;
         double var6 = var0 * var0;
         LocalPlayer var8 = ve.f0.player;
         double var9 = var8.getX();
         double var11 = var8.getY();
         double var13 = var8.getZ();

         for (Player var16 : ve.f0.level.players()) {
            if (var16 != ve.f0.player && var16.isAlive() && var16.deathTime <= 0 && !var16.isRemoved() && (!ModuleManager.f29.m137(var16) || !var2)) {
               double var17 = var16.getX() - var9;
               double var19 = var16.getY() - var11;
               double var21 = var16.getZ() - var13;
               double var23 = var17 * var17 + var19 * var19 + var21 * var21;
               if (!(var23 > var6) && var23 < var4) {
                  var4 = var23;
                  var3 = var16;
               }
            }
         }

         return var3;
      }
   }

   public static Entity m54() {
      Entity var0 = null;
      double var1 = Double.MAX_VALUE;

      for (Entity var4 : ve.f0.level.players()) {
         if (var4 instanceof LivingEntity var5 && var4 != ve.f0.player && var5.isAlive() && !ModuleManager.f29.m137(var4)) {
            double var6 = ve.f0.player.distanceToSqr(var4);
            if (var6 < var1) {
               var1 = var6;
               var0 = var4;
            }
         }
      }

      return var0;
   }

   private static boolean pm$131(Player var0) {
      if (var0 == null || ve.f0.player == null) {
         return false;
      } else if (ve.f0.player.isAlliedTo(var0)) {
         return true;
      } else {
         String var1 = ve.f0.player.getDisplayName().getString();
         String var2 = var0.getDisplayName().getString();
         if (var1.length() >= 2 && var2.length() >= 2) {
            String var3 = var1.substring(0, 2);
            String var4 = var2.substring(0, 2);
            if (var3.equals(var4)) {
               return true;
            }
         }

         return false;
      }
   }
}
