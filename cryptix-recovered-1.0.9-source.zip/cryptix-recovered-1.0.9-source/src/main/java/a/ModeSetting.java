package a;

public class ModeSetting extends Setting {
   private String value;
   private String defaultValue;
   private final String[] modes;
   

   public void setValue(String var1) {
      this.value = var1;
   }

   public ModeSetting(String var1, Module var2, String var3, String[] var4) {
      super(var1, var2);
      this.value = var3;
      this.defaultValue = this.value;
      this.modes = var4;
   }

   public String getValue() {
      return this.value;
   }

   public boolean isMode(String var1) {
      return this.value.equals(var1);
   }

   public String getDefaultValue() {
      return this.defaultValue;
   }

   public String[] getModes() {
      return this.modes;
   }
}
