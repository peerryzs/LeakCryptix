package a;

import java.nio.charset.StandardCharsets;
import mixins.MultiPlayerGameModeMixin_sg;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.InteractionHand;

public class tu implements ve {
   private static int f980;
   private static int f981;
   private static ClientLevel f982;
   

   

   public static void m47(float var0, float var1) {
      ((MultiPlayerGameModeMixin_sg)ve.f0.gameMode).invokeStartPrediction(ve.f0.level, var2 -> new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, var2, var0, var1));
   }

   public static boolean m46(Packet var0) {
      if (ve.f0.level != f982) {
         f982 = ve.f0.level;
         f980 = 0;
         f981 = 0;
      }

      if (var0 instanceof ServerboundSetCarriedItemPacket var1) {
         int var2 = var1.getSlot();
         if (var2 == f980 || Minecraft.getInstance().player.tickCount == f981) {
            System.out.println("bad packet");
            return true;
         }

         f980 = var2;
         f981 = Minecraft.getInstance().player.tickCount;
      }

      return false;
   }
}
