package a;

import java.nio.charset.StandardCharsets;

public class NumberSetting extends Setting {
   private double value;
   private final double maximum;
   private final double step;
   private final double minimum;
   private double defaultValue;
   

   public double getStep() {
      return this.step;
   }

   public double getValue() {
      return this.value;
   }

   public double getMaximum() {
      return this.maximum;
   }

   public void setValue(double var1) {
      var1 = Math.max(this.minimum, Math.min(this.maximum, var1));
      var1 = Math.round(var1 / this.step) * this.step;
      int var3 = String.valueOf(this.step).split("\\.")[1].length();
      var1 = Math.round(var1 * Math.pow(10.0, var3)) / Math.pow(10.0, var3);
      this.value = var1;
   }

   public double getMinimum() {
      return this.minimum;
   }

   public double getDefaultValue() {
      return this.defaultValue;
   }

   

   public NumberSetting(String var1, Module var2, double var3, double var5, double var7, double var9) {
      super(var1, var2);
      this.defaultValue = var3;
      this.value = var3;
      this.minimum = var5;
      this.maximum = var7;
      this.step = var9;
   }
}
