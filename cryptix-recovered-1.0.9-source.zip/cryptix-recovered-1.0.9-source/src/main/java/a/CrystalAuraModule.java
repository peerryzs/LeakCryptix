package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.SwingAnimation;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class CrystalAuraModule extends Module {
   private int f280;
   private Entity f281;
   private final NumberSetting f279;
   

   private void pm$65(BlockPos var1) {
      int var2 = this.pm$67();
      if (var2 != -1) {
         BlockPos[] var10000 = new BlockPos[4];
         var10000[0] = var1.north();
         var10000[1] = var1.south();
         var10000[2] = var1.east();
         var10000[3] = var1.west();
         BlockPos[] var3 = var10000;
         BlockPos[] var4 = var3;
         int var5 = var3.length;

         for (int var6 = 0; var6 < var5; var6++) {
            BlockPos var7 = var4[var6];
            if (f0.level.getBlockState(var7).is(Blocks.OBSIDIAN)) {
               BlockPos var8 = var7.above();
               if (f0.level.getBlockState(var8).isAir()) {
                  f0.player.getInventory().setSelectedSlot(var2);
                  Vec3 var9 = Vec3.atCenterOf(var7).add(0.0, 0.5, 0.0);
                  this.pm$70(var9);
                  BlockHitResult var10 = new BlockHitResult(var9, Direction.UP, var7, false);
                  f0.gameMode.useItemOn(f0.player, InteractionHand.MAIN_HAND, var10);
                  f0.player.swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, false);
                  this.f280 = this.f280 + 1;
                  return;
               }
            }
         }
      }
   }

   private boolean pm$68(BlockPos var1) {
      return (!f0.level.getBlockState(var1.north()).is(Blocks.OBSIDIAN)
            && !f0.level.getBlockState(var1.south()).is(Blocks.OBSIDIAN)
            && !f0.level.getBlockState(var1.east()).is(Blocks.OBSIDIAN)
            && !f0.level.getBlockState(var1.west()).is(Blocks.OBSIDIAN)
         ? false : true);
   }

   private void pm$63() {
      double var1 = this.f279.getValue() * this.f279.getValue();

      for (Entity var4 : f0.level.entitiesForRendering()) {
         if (var4 instanceof EndCrystal var5 && !(f0.player.distanceToSqr(var5) > var1)) {
            this.pm$70(var5.position());
            f0.gameMode.attack(f0.player, var5);
            f0.player.swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, false);
            this.f280 = this.f280 + 1;
            return;
         }
      }
   }

   private int pm$67() {
      for (int var1 = 0; var1 < 9; var1++) {
         if (f0.player.getInventory().getItem(var1).is(Items.END_CRYSTAL)) {
            return var1;
         }
      }

      return -1;
   }

   private void pm$70(Vec3 var1) {
      Vec3 var2 = f0.player.getEyePosition();
      double var3 = var1.x - var2.x;
      double var5 = var1.y - var2.y;
      double var7 = var1.z - var2.z;
      double var9 = Math.sqrt(var3 * var3 + var7 * var7);
      float var11 = (float)(Math.toDegrees(Math.atan2(var7, var3)) - 90.0);
      float var12 = (float)(-Math.toDegrees(Math.atan2(var5, var9)));
      u.f6.m64(var11);
      u.f6.m70(var12);
   }

   private void pm$62() {
      if (this.f281 != null && this.f281.isAlive()) {
         if (!(f0.player.distanceToSqr(this.f281) > 9.0)) {
            this.pm$70(this.f281.getEyePosition());
            f0.gameMode.attack(f0.player, this.f281);
            f0.player.swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, false);
         }
      }
   }

   

   private Entity pm$61() {
      Entity var1 = null;
      double var2 = this.f279.getValue() * this.f279.getValue();

      for (Entity var5 : f0.level.entitiesForRendering()) {
         if (var5 != f0.player && var5.isAlive()) {
            double var6 = f0.player.distanceToSqr(var5);
            if (!(var6 > var2)) {
               var1 = var5;
               var2 = var6;
            }
         }
      }

      return var1;
   }

   @Override
   public void onEnable() {
      this.f281 = null;
   }

   private boolean pm$69(BlockPos var1) {
      if (!f0.level.getBlockState(var1).isAir()) {
         return false;
      } else {
         BlockPos var2 = var1.below();
         return (f0.level.getBlockState(var2).is(Blocks.OBSIDIAN) ? false : f0.level.getBlockState(var2).isSolid());
      }
   }

   private int pm$66() {
      for (int var1 = 0; var1 < 9; var1++) {
         if (f0.player.getInventory().getItem(var1).is(Items.OBSIDIAN)) {
            return var1;
         }
      }

      return -1;
   }

   private void pm$64() {
      int var1 = this.pm$66();
      if (var1 != -1) {
         BlockPos var2 = this.f281.blockPosition();
         BlockPos[] var10000 = new BlockPos[4];
         var10000[0] = var2.north();
         var10000[1] = var2.south();
         var10000[2] = var2.east();
         var10000[3] = var2.west();
         BlockPos[] var3 = var10000;
         BlockPos[] var4 = var3;
         int var5 = var3.length;

         for (int var6 = 0; var6 < var5; var6++) {
            BlockPos var7 = var4[var6];
            if (!f0.level.getBlockState(var7).is(Blocks.OBSIDIAN) && this.pm$69(var7)) {
               f0.player.getInventory().setSelectedSlot(var1);
               BlockPos var8 = var7.below();
               Vec3 var9 = Vec3.atCenterOf(var8).add(0.0, 0.5, 0.0);
               this.pm$70(var9);
               BlockHitResult var10 = new BlockHitResult(var9, Direction.UP, var8, false);
               f0.gameMode.useItemOn(f0.player, f0.player.getUsedItemHand(), var10);
               f0.player.swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, false);
               this.f280 = this.f280 + 1;
               return;
            }
         }
      }
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         this.f281 = this.pm$61();
         if (this.f281 != null) {
            if (f0.gui.screen() == null) {
               this.f280 = 0;
               this.pm$63();
               BlockPos var2 = this.f281.blockPosition();
               if (this.pm$68(var2)) {
                  this.pm$65(var2);
               } else {
                  this.pm$64();
               }

               if (this.f280 == 0) {
                  this.pm$62();
               }
            }
         }
      }
   }

   public CrystalAuraModule() {
      super("CrystalAura", Category.f21);
      this.f279 = new NumberSetting("Range", this, 4.5, 1.0, 6.0, 0.1);
   }
}
