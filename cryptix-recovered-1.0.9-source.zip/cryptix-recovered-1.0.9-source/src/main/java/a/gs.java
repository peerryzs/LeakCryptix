package a;

public record gs(float x, float y, float width, float height, float advance, float u0, float v0, float u1, float v1) {


   

   public gs(float x, float y, float width, float height, float advance, float u0, float v0, float u1, float v1) {
      this.x = x;
      this.y = y;
      this.width = width;
      this.height = height;
      this.advance = advance;
      this.u0 = u0;
      this.v0 = v0;
      this.u1 = u1;
      this.v1 = v1;
   }

   public float advance() {
      return this.advance;
   }

   public float height() {
      return this.height;
   }

   public float u1() {
      return this.u1;
   }

   public float v0() {
      return this.v0;
   }

   public float x() {
      return this.x;
   }

   public float width() {
      return this.width;
   }

   public float y() {
      return this.y;
   }

   public float v1() {
      return this.v1;
   }

   public float u0() {
      return this.u0;
   }
}
