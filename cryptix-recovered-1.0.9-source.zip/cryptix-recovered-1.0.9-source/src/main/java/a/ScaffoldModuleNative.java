package a;
import net.minecraft.world.item.component.SwingAnimation;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.InteractionHand;
import net.minecraft.network.protocol.game.ServerboundPunchPacket;
import net.minecraft.core.Direction;



import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.BlockHitResult;

public class ScaffoldModuleNative extends Module {
   private final BooleanSetting f676;
   private static final String f654;
   private static final float[] f699;
   private static final String f643;
   private final BooleanSetting f670;
   private final MutableBlockPos f702;
   private static final String f663;
   private boolean f701;
   private int f689;
   private int f688;
   private static final String f652;
   private static final String f665;
   private static final float[] f695;
   private int f690;
   private final BooleanSetting f669;
   private final NumberSetting f667;
   private float f682;
   private static final String f664;
   private final BooleanSetting f672;
   private static final String f662;
   private static final String f650;
   private static final float[] f697;
   private static final String f645;
   private static final float[] f694;
   private static final String f651;
   private static final String f644;
   private static final String f658;
   private final ModeSetting f668;
   private static final String f642;
   private float f678;
   private final NumberSetting f674;
   private final be f677;
   private static final String f660;
   private static final String f656;
   public final BooleanSetting f31;
   private final ModeSetting f666;
   private static final String f653;
   private final float[] f693;
   private float f681;
   private final ModeSetting f671;
   private static final float[] f700;
   private static final String f648;
   private static final String f647;
   private static final String f655;
   private static final String f649;
   private static final float[] f698;
   private final BooleanSetting f673;
   private float f680;
   private boolean f684;
   private int f691;
   private static final String f661;
   private boolean f683;
   private boolean f686;
   private boolean f685;
   private static final String f646;
   private static final float f696 = (float) (Math.PI / 180.0);
   private static final String f659;
   private boolean f687;
   private final NumberSetting f675;
   private int f692;
   private float f679;
   private static final String f657;
   private static int f1;

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private void pm$123(BlockHitResult var1, float var2, float basePitch) {
      boolean var3 = this.f668.isMode("Watchdog3");
      if (var3) {
         var2 = xt.m48();
      }

      float var4 = basePitch;
      float var5 = 0.0F;
      float var6 = 0.0F;
      float var7 = 0.0F;
      float[] var8 = this.f694;
      int var9 = var8.length;
      int var10 = 0;

      float var16;
      float var17;
      label46:
      while (true) {
         if (var10 >= var9) {
            if (var3 && var7 != 0.0F) {
               this.f693[0] = var5;
               this.f693[1] = var6;
               return;
            }

            this.f683 = false;
            this.f684 = true;
            this.f693[0] = this.f680;
            this.f693[1] = this.f681;
            return;
         }

         float var11 = var8[var10];
         float[] var12 = this.f695;
         int var13 = var12.length;

         for (int var14 = 0; var14 < var13; var14++) {
            float var15 = var12[var14];
            var16 = var2 + var11;
            var17 = Mth.clamp(var4 + var15, -90.0F, 90.0F);
            BlockHitResult var18 = this.pm$113(var16, var17, 4.5F);
            if (var18.getBlockPos().equals(var1.getBlockPos()) && var18.getDirection() == var1.getDirection()) {
               if (!var3) {
                  break label46;
               }

               float var19 = Math.abs(Mth.wrapDegrees(var16 - xt.m48() + 180.0F));
               if (var19 > var7) {
                  var7 = var19;
                  var5 = var16;
                  var6 = var17;
               }

               if (!(var19 > 90.0F)) {
                  break label46;
               }
            }
         }

         var10++;
      }

      this.f693[0] = var16;
      this.f693[1] = var17;
   }

   @Override
   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   public void onDisable() {
      f0.player.getInventory().setSelectedSlot(this.f689);
      iw.m57(1.0F);
      this.f687 = false;
   }

   public ScaffoldModuleNative() {
      super(f642, Category.f23);
      String var10003 = f643;
      String var10005 = f644;
      String[] var10006 = new String[5 - f1];
      var10006[0 - f1] = f644;
      var10006[1 - f1] = f645;
      var10006[2 - f1] = f646;
      var10006[3 - f1] = f647;
      var10006[4 - f1] = f648;
      this.f666 = new ModeSetting(var10003, this, var10005, var10006);
      this.f667 = new NumberSetting(f649, this, 2.0, 0.5, 10.0, 0.5);
      var10003 = f650;
      var10005 = f651;
      var10006 = new String[5 - f1];
      var10006[0 - f1] = f651;
      var10006[1 - f1] = f652;
      var10006[2 - f1] = f653;
      var10006[3 - f1] = f654;
      var10006[4 - f1] = f655;
      this.f668 = new ModeSetting(var10003, this, var10005, var10006);
      this.f669 = new BooleanSetting(f656, this, false);
      this.f670 = new BooleanSetting(f657, this, false);
      var10003 = f658;
      var10005 = f651;
      var10006 = new String[3 - f1];
      var10006[0 - f1] = f651;
      var10006[1 - f1] = f653;
      var10006[2 - f1] = f659;
      this.f671 = new ModeSetting(var10003, this, var10005, var10006);
      this.f31 = new BooleanSetting(f660, this, true);
      this.f672 = new BooleanSetting(f661, this, false);
      this.f673 = new BooleanSetting(f662, this, false);
      this.f674 = new NumberSetting(f663, this, 0.0, 0.0, 25.0, 1.0);
      this.f675 = new NumberSetting(f664, this, 10.0, 2.0, 15.0, 1.0);
      this.f676 = new BooleanSetting(f665, this, false);
      this.f677 = new be();
      this.f689 = -1 - f1;
      this.f692 = -1 - f1;
      this.f693 = new float[2 - f1];
      this.f702 = new MutableBlockPos();

      for (int var1 = 0 - f1; var1 < f694.length; var1++) {
         float var2 = -f694[var1] * (float) (Math.PI / 180.0);
         f699[var1] = Mth.sin(var2);
         f700[var1] = Mth.cos(var2);
      }

      for (int var3 = 0 - f1; var3 < f695.length; var3++) {
         float var4 = f695[var3];
         f697[var3] = Mth.sin(-var4 * (float) (Math.PI / 180.0));
         f698[var3] = -Mth.cos(-var4 * (float) (Math.PI / 180.0));
      }
   }

   @Override
   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   public void onEnable() {
      this.f688 = (int)(f0.player.getY() - 1.0);
      this.f689 = f0.player.getInventory().getSelectedSlot();
      this.f678 = f0.player.getYRot();
      if (this.f668.isMode("Watchdog3")) {
         this.f678 = f0.player.getYRot();
         this.f682 = this.f678 - 150.0F;
      }

      this.f679 = f0.player.getXRot();
      this.f680 = xt.m48() - 180.0F;
      this.f681 = 83.0F;
      this.f679 = 83.0F;
      this.f685 = false;
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private void pm$119() {
      if (this.f672.getValue()) {
         f0.getConnection().send(ServerboundPunchPacket.INSTANCE);
      } else {
         f0.player.swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, false);
      }
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private int pm$120() {
      int var1 = -1;
      int var2 = 0;

      for (int var3 = 0; var3 < 9; var3++) {
         ItemStack var4 = f0.player.getInventory().getItem(var3);
         if (var4.getItem() instanceof BlockItem && var4.getCount() > var2) {
            var2 = var4.getCount();
            var1 = var3;
         }
      }

      return var1;
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   /* The three added flags have unknown semantics and are not used by this earlier algorithm. */
   private void pm$121(float var1, float var2, boolean unknownFlag1, boolean unknownFlag2, boolean unknownFlag3) {
      if (!this.f684) {
         this.f684 = true;
         float var3 = (float)(this.f667.getValue() * 20.0 - Math.random());
         if (this.f685 && this.f668.isMode("Watchdog")) {
            var3 = (float)(89.0 - Math.random());
         }

         if (this.f701) {
            var3 = (float)(129.0 - Math.random());
            this.f701 = false;
         } else if (this.f668.isMode("Watchdog2")) {
            var3 = 34.0F;
         }

         if (this.f685 && this.f668.isMode("Watchdog2")) {
            this.f701 = true;
         }

         float var4 = Mth.wrapDegrees(var1 - this.f678);
         float var5 = Mth.wrapDegrees(var2 - this.f679);
         var4 = Math.clamp(var4, -var3, var3);
         var5 = Math.clamp(var5, -var3, var3);
         this.f678 += var4;
         float var6 = f0.player.getYRot();
         this.f678 = var6 + Mth.wrapDegrees(this.f678 - var6);
         this.f679 += var5;
         if (!(Math.abs(Mth.wrapDegrees(this.f678 - var1)) > 0.1) && !(Math.abs(Mth.wrapDegrees(this.f679 - var2)) > 0.1)) {
            this.f683 = true;
         } else {
            this.f683 = false;
         }

         if (this.f668.isMode("Watchdog3")) {
            this.f678 = var1;
            this.f683 = true;
         }
      }
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private float pm$124(float movementYaw) {
      float var1 = movementYaw;
      float var2;
      if (var1 % 90.0F <= 45.0F) {
         var2 = var1 + 45.0F;
      } else {
         var2 = var1 - 45.0F;
      }

      return var2 - 180.0F;
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private void pm$122(BlockHitResult var1, float baseYaw) {
      Vec3 var2 = f0.player.getEyePosition();
      Vec3 var3 = var1.getLocation();
      double var4 = var3.x - var2.x;
      double var6 = var3.y - var2.y;
      double var8 = var3.z - var2.z;
      double var10 = Math.sqrt(var4 * var4 + var8 * var8);
      float var12 = (float)(-Math.toDegrees(Math.atan2(var6, var10)));
      String var13 = this.f666.getValue();
      int var14 = -1;
      int var10000 = var13.hashCode();
      if (var10000 == -2133157087) {
         if (var13.equals("HitVec")) {
            var14 = 4;
         }
      } else if (var10000 == -2108346365) {
         if (var13.equals("Backward")) {
            var14 = 0;
         }
      } else if (var10000 == -1935912781) {
         if (var13.equals("Offset")) {
            var14 = 1;
         }
      } else if (var10000 == -1642289591) {
         if (var13.equals("Raycast")) {
            var14 = 2;
         }
      } else if (var10000 == 628630281) {
         if (var13.equals("Raycast2")) {
            var14 = 3;
         }
      }

      switch (var14) {
         case 0:
            this.f693[0] = baseYaw - 180.0F;
            this.f693[1] = var12;
            break;
         case 1:
            this.f693[0] = this.pm$124(xt.m48());
            this.f693[1] = 83.0F;
            break;
         case 2:
            this.pm$123(var1, baseYaw - 180.0F, 0.0F);
            break;
         case 3:
            this.pm$123(var1, this.f680, 0.0F);
            break;
         case 4:
         default:
            float var15 = (float)Math.toDegrees(Math.atan2(var8, var4)) - 90.0F;
            this.f693[0] = var15;
            this.f693[1] = var12;
      }
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private be getPlaceData(BlockPos var1) {
      if (!f0.level.getBlockState(var1).canBeReplaced()) {
         return null;
      } else {
         int var2 = var1.getX();
         int var3 = var1.getY();
         int var4 = var1.getZ();
         double var5 = f0.player.getX();
         double var7 = f0.player.getY();
         double var9 = f0.player.getZ();
         double var11 = Double.MAX_VALUE;
         int var13 = 0;
         int var14 = 0;
         int var15 = 0;
         Direction var16 = null;

         for (int var17 = -4; var17 <= 4; var17++) {
            int var18 = var2 + var17;

            for (int var19 = -2; var19 <= 0; var19++) {
               int var20 = var3 + var19;

               for (int var21 = -4; var21 <= 4; var21++) {
                  int var22 = var4 + var21;
                  this.f702.set(var18, var20, var22);
                  if (!f0.level.isEmptyBlock(this.f702)) {
                     Direction var23;
                     if (Math.abs(var17) >= Math.abs(var19) && Math.abs(var17) >= Math.abs(var21)) {
                        var23 = var17 < 0 ? Direction.EAST : Direction.WEST;
                     } else if (Math.abs(var19) >= Math.abs(var17) && Math.abs(var19) >= Math.abs(var21)) {
                        var23 = var19 < 0 ? Direction.UP : Direction.DOWN;
                     } else {
                        var23 = var21 < 0 ? Direction.SOUTH : Direction.NORTH;
                     }

                     if (var23 != null && var23 != Direction.DOWN) {
                        double var24 = var5 - (var18 + 0.5);
                        double var26 = var7 - (var20 + 0.5);
                        double var28 = var9 - (var22 + 0.5);
                        double var30 = var24 * var24 + var26 * var26 + var28 * var28;
                        if (var30 < var11) {
                           var11 = var30;
                           var13 = this.f702.getX();
                           var14 = this.f702.getY();
                           var15 = this.f702.getZ();
                           var16 = var23;
                        }
                     }
                  }
               }
            }
         }

         if (var16 == null) {
            return null;
         } else {
            this.f677.m199(var13, var14, var15, var16);
            return this.f677;
         }
      }
   }



   @Override
   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   public void onEvent(r var1) {
      if (var1 == u.f16) {
         if (f0.gui.screen() == null) {
            var1.m9(true);
         }

         if (u.f16.m13() == 1) {
            this.f686 = u.f16.m16();
         }
      } else if (var1 != u.f6) {
         if (var1 == u.f5) {
            if (this.f668.isMode("Watchdog3")) {
               f0.player.yHeadRot = this.f682;
               f0.player.yBodyRot = xt.m50(this.f682, f0.player.yBodyRot);
            }
         } else if (var1 == u.f4) {
            if (!f0.options.keyJump.isDown()) {
               if (this.f691 > 0) {
                  this.f691 = this.f691 - 1;
                  iw.m57(0.5F);
                  this.f687 = true;
               } else if (this.f687) {
                  iw.m57(1.0F);
                  this.f687 = false;
               }
            }
         } else if (var1 == u.f7) {
            if (this.f692 != -1 && f0.player.getInventory().getSelectedSlot() != this.f692) {
               f0.player.getInventory().setSelectedSlot(this.f692);
            }
         } else if (var1 == u.f9) {
            if (this.f668.isMode("Watchdog3") && !this.f685 && this.f690 != 10) {
               f0.player.input.makeJump();
               this.f685 = true;
            }

            if ((this.f668.isMode("Telly") || this.f668.isMode("Watchdog") || this.f668.isMode("Watchdog2"))
               && (f0.player.input.getMoveVector().x != 0.0F || f0.player.input.getMoveVector().y != 0.0F)
               && (!this.f669.getValue() || this.f686)) {
               f0.player.input.makeJump();
            }

            if (this.f673.getValue()) {
               Input var7 = f0.player.input.keyPresses;
               if (f0.player.tickCount % (int)(this.f674.getValue() + 1.0) == 0) {
                  f0.player.input.keyPresses = new Input(
                     var7.forward(), var7.backward(), var7.left(), var7.right(), var7.jump(), true, var7.sprint()
                  );
               }
            }
         }
      } else {
            int var2 = 1;
         if (this.f670.getValue() && f0.options.keyJump.isDown()) {
            this.f688 = (int)f0.player.getY() - 1;
         }

         if (this.f690 > 0) {
            this.f690 = this.f690 - 1;
         }

         if ((this.f668.isMode("Watchdog") || this.f668.isMode("Watchdog2") || this.f668.isMode("Telly")) && f0.player.onGround() && (!this.f669.getValue() || this.f686)) {
            float var8 = xt.m48();
            u.f6.m64(var8);
            this.f678 = var8;
            this.f685 = f0.player.onGround();
            return;
         }

         this.f684 = false;
         BlockPos var3 = f0.player.blockPosition().below();
         if (this.f670.getValue()) {
            var3 = var3.atY(this.f688);
         }

         if (f0.level.isEmptyBlock(var3) && var2 != 0) {
            this.f692 = this.pm$120();
            if (this.f692 != -1) {
               be var4 = this.getPlaceData(var3);
               if (var4 != null) {
                  Vec3 var5 = Vec3.atCenterOf(new BlockPos(var4.f27, var4.f28, var4.f29));
                  BlockHitResult var6 = new BlockHitResult(var5, var4.f30, new BlockPos(var4.f27, var4.f28, var4.f29), false);
                  this.pm$122(var6, xt.m48());
                  this.pm$121(this.f693[0], this.f693[1], false, false, false);
                  this.f680 = this.f693[0];
                  this.f681 = this.f693[1];
                  if (!this.f671.isMode("Disabled") && f0.options.keyJump.isDown() && f0.player.onGround()) {
                     this.f683 = false;
                  }

                  if (this.f683) {
                     f0.gameMode.useItemOn(f0.player, InteractionHand.MAIN_HAND, var6);
                     this.pm$119();
                     this.f690 = 10;
                  }
               }
            }
         }

         if (this.f668.isMode("Watchdog3")) {
            float var9 = xt.m48();
            float var11 = var9 + 45.0F;
            float var12 = Math.abs(Mth.wrapDegrees(var11 - this.f678));
            if (this.f690 == 10) {
               this.f682 = this.f678;
            }

            if (this.f690 == (var12 > 60.0F ? 8 : 9) && !f0.options.keyJump.isDown() && this.f685 && f0.player.onGround()) {
               this.f678 = var9 + 45.0F;
            }

            if (f0.player.onGround()) {
               this.f688 = (int)(f0.player.getY() - 1.0);
            }
         } else {
            this.pm$121(this.f680, this.f681, false, false, false);
         }

         if (!this.f671.isMode("Disabled")) {
            float var10 = xt.m48();
            if (f0.player.onGround() && f0.options.keyJump.isDown()) {
               this.f678 = var10;
            }

            if (this.f671.isMode("Watchdog Low")) {
               if (!f0.player.onGround() && f0.player.getDeltaMovement().y < -0.1 && f0.options.keyJump.isDown() && this.f691 < this.f675.getValue()) {
                  iw.m57(2.0F);
                  this.f691 = this.f691 + 1;
                  this.f687 = true;
               } else if (this.f687) {
                  iw.m57(1.0F);
                  this.f687 = false;
               }
            }
         }

         u.f6.m64(this.f678);
         u.f6.m70(this.f679);
         if (!this.f668.isMode("Watchdog3")) {
            this.f685 = f0.player.onGround();
         }
      }
   }
   private BlockHitResult pm$113(float var1, float var2, float var3) {
      Vec3 var4 = f0.getCameraEntity().getEyePosition(1.0F);
      Vec3 var5 = this.pm$114(var1, var2);
      Vec3 var6 = var4.add(var5.x * var3, var5.y * var3, var5.z * var3);
      return f0.level.clip(new ClipContext(var4, var6, Block.OUTLINE, Fluid.NONE, f0.getCameraEntity()));
   }
   private Vec3 pm$114(float var1, float var2) {
      float var3 = Mth.cos(-var1 * (float) (Math.PI / 180.0) - (float) Math.PI);
      float var4 = Mth.sin(-var1 * (float) (Math.PI / 180.0) - (float) Math.PI);
      float var5 = -Mth.cos(-var2 * (float) (Math.PI / 180.0));
      float var6 = Mth.sin(-var2 * (float) (Math.PI / 180.0));
      return new Vec3(var4 * var5, var6, var3 * var5);
   }

   // INFERRED earlier-build labels and raycast search arrays; newer hidden initializer is unavailable.
   static {
      f642 = "Scaffold";
      f643 = "Rotations";
      f644 = "HitVec";
      f645 = "Backward";
      f646 = "Offset";
      f647 = "Raycast";
      f648 = "Raycast2";
      f649 = "Rotation Speed";
      f650 = "Fast Mode";
      f651 = "Disabled";
      f652 = "Telly";
      f653 = "Watchdog";
      f654 = "Watchdog2";
      f655 = "Watchdog3";
      f656 = "Telly RMB";
      f657 = "Keep Y";
      f658 = "Tower";
      f659 = "Watchdog Low";
      f660 = "Block Count";
      f661 = "Silent Swing";
      f662 = "Sneak";
      f663 = "Sneak Delay";
      f664 = "Timer Ticks";
      f665 = "Extra Option";
      f1 = 0;
      f694 = new float[] {0.0F, -1.0F, 1.0F, -2.0F, 2.0F, -3.0F, 3.0F, -4.0F, 4.0F, -5.0F, 5.0F, -6.0F, 6.0F, -7.0F, 7.0F, -8.0F, 8.0F, -9.0F, 9.0F, -10.0F, 10.0F, -11.0F, 11.0F, -12.0F, 12.0F, -13.0F, 13.0F, -14.0F, 14.0F, -15.0F, 15.0F, -16.0F, 16.0F, -17.0F, 17.0F, -18.0F, 18.0F, -19.0F, 19.0F, -20.0F, 20.0F, -22.0F, 22.0F, -24.0F, 24.0F, -26.0F, 26.0F, -28.0F, 28.0F, -30.0F, 30.0F, -32.0F, 32.0F, -34.0F, 34.0F, -36.0F, 36.0F, -38.0F, 38.0F, -40.0F, 40.0F, -42.0F, 42.0F, -44.0F, 44.0F, -46.0F, 46.0F, -48.0F, 48.0F, -50.0F, 50.0F, -52.0F, 52.0F, -54.0F, 54.0F, -56.0F, 56.0F, -58.0F, 58.0F, -60.0F, 60.0F, -62.0F, 62.0F, -64.0F, 64.0F, -66.0F, 66.0F, -68.0F, 68.0F, -70.0F, 70.0F, -72.0F, 72.0F, -74.0F, 74.0F, -76.0F, 76.0F, -78.0F, 78.0F, -80.0F, 80.0F, -82.0F, 82.0F, -84.0F, 84.0F, -86.0F, 86.0F, -88.0F, 88.0F, -90.0F, 90.0F, -92.0F, 92.0F, -94.0F, 94.0F, -96.0F, 96.0F, -98.0F, 98.0F, -100.0F, 100.0F, -102.0F, 102.0F, -104.0F, 104.0F, -106.0F, 106.0F, -108.0F, 108.0F, -110.0F, 110.0F, -112.0F, 112.0F, -114.0F, 114.0F, -116.0F, 116.0F, -118.0F, 118.0F, -120.0F, 120.0F, -122.0F, 122.0F, -124.0F, 124.0F, -126.0F, 126.0F, -128.0F, 128.0F, -130.0F, 130.0F, -132.0F, 132.0F, -134.0F, 134.0F, -136.0F, 136.0F, -138.0F, 138.0F, -140.0F, 140.0F, -142.0F, 142.0F, -144.0F, 144.0F, -146.0F, 146.0F, -148.0F, 148.0F, -150.0F, 150.0F, -152.0F, 152.0F, -154.0F, 154.0F, -156.0F, 156.0F, -158.0F, 158.0F, -160.0F, 160.0F, -162.0F, 162.0F, -164.0F, 164.0F, -166.0F, 166.0F, -168.0F, 168.0F, -170.0F, 170.0F, -172.0F, 172.0F, -174.0F, 174.0F, -176.0F, 176.0F, -178.0F, 178.0F, -180.0F, 180.0F};
      f695 = new float[] {0.0F, -1.0F, 1.0F, -2.0F, 2.0F, -3.0F, 3.0F, -4.0F, 4.0F, -5.0F, 5.0F, -6.0F, 6.0F, -7.0F, 7.0F, -8.0F, 8.0F, -9.0F, 9.0F, -10.0F, 10.0F, -11.0F, 11.0F, -12.0F, 12.0F, -13.0F, 13.0F, -14.0F, 14.0F, -15.0F, 15.0F, -16.0F, 16.0F, -17.0F, 17.0F, -18.0F, 18.0F, -19.0F, 19.0F, -20.0F, 20.0F, -22.0F, 22.0F, -24.0F, 24.0F, -26.0F, 26.0F, -28.0F, 28.0F, -30.0F, 30.0F, -32.0F, 32.0F, -34.0F, 34.0F, -36.0F, 36.0F, -38.0F, 38.0F, -40.0F, 40.0F, -42.0F, 42.0F, -44.0F, 44.0F, -46.0F, 46.0F, -48.0F, 48.0F, -50.0F, 50.0F, -52.0F, 52.0F, -54.0F, 54.0F, -56.0F, 56.0F, -58.0F, 58.0F, -60.0F, 60.0F, -62.0F, 62.0F, -64.0F, 64.0F, -66.0F, 66.0F, -68.0F, 68.0F, -70.0F, 70.0F, -72.0F, 72.0F, -74.0F, 74.0F, -76.0F, 76.0F, -78.0F, 78.0F, -80.0F, 80.0F, -82.0F, 82.0F, -84.0F, 84.0F, -86.0F, 86.0F, -88.0F, 88.0F, -90.0F, 90.0F};
      f697 = new float[f695.length]; f698 = new float[f695.length];
      f699 = new float[f694.length]; f700 = new float[f694.length];
   }
}
