package a;

public class h extends r {
   
}
