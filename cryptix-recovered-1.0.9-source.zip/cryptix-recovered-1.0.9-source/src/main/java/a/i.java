package a;

import net.minecraft.resources.Identifier;

public class i extends r {
   private Identifier f104;
   

   public i m46(Identifier var1) {
      this.f104 = var1;
      return this;
   }

   public Identifier m47() {
      return this.f104;
   }
}
