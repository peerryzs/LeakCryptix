package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.util.Mth;

public class NoFallModule extends Module {
   private boolean f641;
   private final ModeSetting f639;
   private boolean f640;
   

   public NoFallModule() {
      super("NoFall", Category.f23);
      String var10003 = "Mode";
      String var10005 = "Universal";
      String[] var10006 = new String[5];
      var10006[0] = "Universal";
      var10006[1] = "Ground";
      var10006[2] = "NoGround";
      var10006[3] = "Packet";
      var10006[4] = "Clip";
      this.f639 = new ModeSetting(var10003, this, var10005, var10006);
   }

   

   private void pm$118() {
      if (f0.getSingleplayerServer() == null) {
         f0.getConnection().send(new Pos(f0.player.getX(), f0.player.getY(), f0.player.getZ(), true, f0.player.horizontalCollision));
      }
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f4) {
         String var2 = this.f639.getValue();
         int var3 = -1;
         int var10000 = var2.hashCode();
         if (var10000 == 370287304) {
            if (var2.equals("NoGround")) {
               var3 = 1;
            }
         } else if (var10000 == ('ｅ' << 15 | 17831) - 0) {
            if (var2.equals("Ground")) {
               var3 = 0;
            }
         }

         switch (var3) {
            case 0:
               u.f4.m59(true);
               break;
            case 1:
               u.f4.m59(false);
         }

         if (f0.player.fallDistance >= 3.0) {
            this.f641 = true;
         }

         if (f0.player.onGround() && this.f639.isMode("Clip") && this.f641) {
            this.f641 = false;
            u.f4.m53(Mth.floor(u.f4.m52() - 1.0) + 0.42F);
         }
      }

      if (var1 == u.f6) {
         if (f0.player.fallDistance >= 3.0 && this.f639.isMode("Universal")) {
            f0.player.fallDistance = 0.0;
            this.pm$118();
         }

         if (f0.player.fallDistance >= 3.0 && this.f639.isMode("Packet")) {
            this.pm$118();
            iw.m57(0.5F);
            this.f640 = true;
         } else if (this.f640) {
            iw.m57(1.0F);
            this.f640 = false;
         }
      }
   }
}
