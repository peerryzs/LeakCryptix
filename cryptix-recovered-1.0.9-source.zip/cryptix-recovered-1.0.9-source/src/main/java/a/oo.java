package a;

public class oo {
   private static int f963;
   

   public static void m31() {
      f963 = lu.m56(0);
   }

   public static int m29(float var0) {
      return var0 < 0.3 ? -43691 : (var0 < 0.5 ? -22016 : (var0 < 0.7 ? -171 : -11141291));
   }

   public static int m30() {
      return f963;
   }
}
