package a;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.Minecraft;

public abstract class Module {
   private final Category category;
   protected static final Minecraft f0 = Minecraft.getInstance();
   private String suffix;
   private final String name;
   public List<Setting> f15 = new ArrayList();
   private long lastToggleNanos;
   private boolean hidden;
   private static final String f237 = "";
   private int keyBind;
   private int defaultKeyBind;
   private boolean enabled;
   private String displayName;
   private int displayWidth;
   

   public boolean isHidden() {
      return this.hidden;
   }

   public void onEvent(r var1) {
   }

   public String getDisplayName() {
      return this.displayName;
   }

   public void setEnabled(boolean var1) {
      if (this.enabled != var1) {
         this.toggle();
      }
   }

   public String getSuffix() {
      return this.suffix;
   }

   public void onDisable() {
   }

   public Module(String var1, int var2, Category var3) {
      this.displayWidth = -1;
      this.defaultKeyBind = 0;
      this.category = var3;
      this.name = var1;
      this.displayName = var1;
      this.suffix = f237;
      this.keyBind = var2;
      this.defaultKeyBind = var2;
      this.enabled = false;
   }

   public void setKeyBind(int var1) {
      this.keyBind = var1;
   }

   public String getName() {
      return this.name;
   }

   public Category getCategory() {
      return this.category;
   }

   public void setHidden(boolean var1) {
      this.hidden = var1;
   }

   public void onEnable() {
   }

   public void setSuffix(String var1) {
      if (!Objects.equals(this.suffix, var1)) {
         this.suffix = var1;
         this.displayName = var1 == null ? this.name : this.name + "§7 " + var1;
         this.displayWidth = bt.m71(this.displayName);
         ModuleManager.sortModulesByWidth();
      }
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public int getEventPriority(r var1) {
      return 0;
   }

   public long getLastToggleNanos() {
      return this.lastToggleNanos;
   }

   public int getKeyBind() {
      return this.keyBind;
   }

   public int getDefaultKeyBind() {
      return this.defaultKeyBind;
   }

   public void toggle() {
      this.enabled = (!this.enabled);
      if (this.enabled) {
         this.onEnable();
      } else {
         this.onDisable();
      }

      this.lastToggleNanos = System.nanoTime();
      ModuleManager.notifyModuleStateChanged();
      u.m13();
   }

   public int getDisplayWidth() {
      if (this.displayWidth == -1) {
         this.displayWidth = bt.m71(this.displayName);
      }

      return this.displayWidth;
   }

   public void setDisplayWidth(int var1) {
      this.displayWidth = var1;
   }

   public Module(String var1, Category var2) {
      this.displayWidth = -1;
      this.defaultKeyBind = 0;
      this.category = var2;
      this.name = var1;
      this.displayName = var1;
      this.suffix = f237;
      this.keyBind = 0;
      this.enabled = false;
   }
}
