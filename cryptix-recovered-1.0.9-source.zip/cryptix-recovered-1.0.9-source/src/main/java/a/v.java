package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.client.Minecraft;

public class v extends m {
   

   public v() {
      String var10001 = "Say";
      String var10002 = "say <message>";
      String[] var10003 = new String[2];
      var10003[0] = "say";
      var10003[1] = "s";
      super(var10001, var10002, var10003);
   }

   

   @Override
   public void m0(String[] var1, String var2) {
      if (var1.length > 1) {
         String var3 = var2.substring(var2.indexOf(32) + 1);
         Minecraft.getInstance().getConnection().sendChat(var3);
      } else {
         CryptixClient.sendPrefixedMessage("Usage: ." + this.f1);
      }
   }
}
