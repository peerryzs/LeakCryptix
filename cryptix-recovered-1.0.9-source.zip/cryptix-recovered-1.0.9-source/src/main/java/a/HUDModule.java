package a;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class HUDModule extends Module {
   private final BooleanSetting f803;
   public final hk f44;
   private final ModeSetting f798;
   private static final String f805;
   private static final String f794 = "";
   private final BooleanSetting f804;
   private static int f808;
   private final NumberSetting f799;
   private final BooleanSetting f802;
   private final BooleanSetting f800;
   private static int f809;
   private String f811;
   private static final String f807 = null; // Preserved JVM default; no initializer in input bytecode.
   private final BooleanSetting f801;
   private static final String f806;
   private static int f810;
   private int f812;
   private static final long f813 = 150000000L;
   private static final float f814 = 6.6666668E-9F;
   private static final int f815 = 5;
   

   static {
      f805 = "Cryptix".substring(0, 1);
      f806 = "Cryptix".substring(1);
   }

   public void m212(GuiGraphicsExtractor var1) {
      if (!Objects.equals(bt.f46, bt.f47)) {
         f808 = bt.m71(f805);
         f809 = bt.m71(f806);
         f810 = bt.m71("1.0.9");
      }

      boolean var2 = this.f801.getValue();
      boolean var3 = this.f803.getValue();
      boolean var4 = this.f802.getValue();
      int var5 = 5;
      if (var2) {
         bt.m70(var1, f805, var5, 5, oo.m30());
         var5 += f808;
         bt.m70(var1, f806, var5, 5, -1);
         var5 += f809;
      }

      if (var3) {
         if (var2) {
            bt.m70(var1, " | ", var5, 5, -1);
            var5 += bt.m71(" | ");
         }

         bt.m70(var1, "1.0.9", var5, 5, -1);
         var5 += f810;
      }

      if (var4) {
         if (var2 || var3) {
            bt.m70(var1, " | ", var5, 5, -1);
            var5 += bt.m71(" | ");
         }

         int var6 = f0.getFps();
         if (var6 != this.f812) {
            this.f811 = "FPS: " + var6;
            this.f812 = var6;
         }

         bt.m70(var1, this.f811, var5, 5, -1);
      }

      int var44 = this.f44.m235();
      int var7 = this.f44.m236();
      int var8 = var7 + 5;
      int var9 = f0.getWindow().getGuiScaledWidth();
      int var10 = -1;
      int var11 = 0;
      int var12 = 0;
      int var13 = 10;
      int var14 = var9 - 5 + var44;
      String var15 = this.f798.getValue();
      boolean var16 = this.f800.getValue();
      int var17 = !var15.equals("Disabled") ? 1 : 0;
      boolean var18 = var15.equals("Full");
      List var19 = ModuleManager.getSortedModules();
      float var20 = (float)this.f799.getValue();
      boolean var21 = this.f804.getValue();
      int var22 = 0;
      long var23 = System.nanoTime();
      int var25 = 0;

      for (int var26 = var19.size(); var25 < var26; var25++) {
         Module var27 = (Module)var19.get(var25);
         if (!var27.isHidden()) {
            long var28 = var23 - var27.getLastToggleNanos();
            if (!var21) {
               var28 = 150000000L;
            }

            if (var27.isEnabled() || var28 < 150000000L) {
               var11++;
               String var30 = var27.getDisplayName();
               int var31 = var27.getDisplayWidth();
               var12 = var31;
               if (var11 == 1) {
                  this.f44.m243(var31);
               }

               float var32 = (float)var28 * 6.6666668E-9F;
               if (var32 > 1.0F) {
                  var32 = 1.0F;
               }

               if (!var27.isEnabled()) {
                  var32 = 1.0F - var32;
               }

               var32 = 1.0F - (1.0F - var32) * (1.0F - var32);
               int var33 = (int)((1.0F - var32) * (var31 + 5));
               int var34 = (int)((1.0F - var32) * 12.0F);
               if (!var21) {
                  var33 = 0;
                  var34 = 0;
               }

               int var35 = var14 - var31;
               int var36 = var35 + var33;
               var8 -= var34;
               if (var16) {
                  var1.fill(
                     var35 - 3, var8 - 2 + var34, var9 - 2 + var44, var8 + var13, -2147483648
                  );
               }

               int var38 = lu.m56((int)((var11 - 1) * 6 * var20));
               var22 = var38;
               if (var17 != 0) {
                  int var40 = -1;
                  int var10000 = var15.hashCode();
                  if (var10000 == 2201263) {
                     if (var15.equals("Full")) {
                        var40 = 2;
                     }
                  } else if (var10000 == ('遐' << 6 | 39) - 0) {
                     if (var15.equals("Left")) {
                        var40 = 0;
                     }
                  } else if (var10000 == 78959100) {
                     if (var15.equals("Right")) {
                        var40 = 1;
                     }
                  }

                  switch (var40) {
                     case 0:
                        var1.fill(var35 - 4, var8 - 2, var35 - 2, var8 + var13, var38);
                        break;
                     case 1:
                        var1.fill(var9 - 2 + var44, var8 - 2, var9 + var44, var8 + var13, var38);
                        break;
                     case 2:
                        if (var11 == 1) {
                           var1.fill(
                              var36 - 4, var8 - 3, var9 - 2 + var44, var8 - 2, var38
                           );
                        }

                        if (var10 != -1) {
                           int var41 = var31 - var10;
                           var1.fill(
                              var35 - 3,
                              var8 - 3,
                              var35 + var41 - 3,
                              var8 - 2,
                              var38
                           );
                        }

                        var1.fill(var35 - 4, var8 - 2, var35 - 3, var8 + var13, var38);
                        var1.fill(var14 + 2, var8 - 2, var14 + 3, var8 + 10, var38);
                  }
               }

               int var39 = (int)(var32 * 255.0F);
               bt.m70(var1, var30, var36, var8, var39 << 24 | var38 & 16777215);
               var8 += 12;
               var10 = var31;
            }
         }
      }

      this.f44.m244(var8 - var7 - 4);
      if (var18 && var12 != 0) {
         var25 = var9 - var12 - 5 + var44;
         var1.fill(
            var25 - 4, var8 + var13 - 12, var9 - 2 + var44, var8 + var13 - 11, var22
         );
      }
   }

   @Override
   public void onEnable() {
      if (f808 == 0 || f809 == 0 || f810 == 0) {
         f808 = bt.m71(f805);
         f809 = bt.m71(f806);
         f810 = bt.m71("1.0.9");
      }
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f8) {
         if (f0.gui.screen() == this.f44.m239()) {
            return;
         }

         j var2 = u.f8;
         GuiGraphicsExtractor var3 = var2.m76();
         this.m212(var3);
      }
   }

   public HUDModule() {
      super("HUD", Category.f24);
      String var10003 = "Outline";
      String var10005 = "Disabled";
      String[] var10006 = new String[4];
      var10006[0] = "Disabled";
      var10006[1] = "Left";
      var10006[2] = "Right";
      var10006[3] = "Full";
      this.f798 = new ModeSetting(var10003, this, var10005, var10006);
      this.f799 = new NumberSetting("Fade Distance", this, 1.0, 0.2, 2.0, 0.1);
      this.f44 = new hk("Edit Position", this, 0, 0, 0, 0, new ck(this));
      this.f800 = new BooleanSetting("Background", this, false);
      this.f801 = new BooleanSetting("Watermark", this, false);
      this.f802 = new BooleanSetting("Show FPS", this, false);
      this.f803 = new BooleanSetting("Show Version", this, false);
      this.f804 = new BooleanSetting("Animation", this, false);
      this.f811 = f794;
      this.f812 = -1;
   }
}
