package a;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import org.lwjgl.sdl.SDLKeyboard;

public class EagleModule extends Module {
   private final BooleanSetting f588;
   private int f593;
   private final BooleanSetting f587;
   private int f592;
   private boolean f591;
   private final BooleanSetting f586;
   private final NumberSetting f590;
   private final BooleanSetting f589;
   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         if (this.f586.getValue() && !mr.m44()) {
            this.pm$106();
            return;
         }

         if (this.f587.getValue() && f0.player.getXRot() < 70.0F) {
            this.pm$106();
            return;
         }

         if (this.f588.getValue() && !f0.options.keyDown.isDown()) {
            this.pm$106();
            return;
         }

         double var2 = f0.player.getX();
         double var4 = f0.player.getY() - 0.05;
         double var6 = f0.player.getZ();
         BlockState var8 = f0.level.getBlockState(BlockPos.containing(var2, var4, var6));
         if (!this.f589.getValue()) {
            this.pm$105(var8);
         } else {
            this.f592 = this.f592 + 1;
            if (this.f592 >= 4) {
               this.pm$105(var8);
            } else {
               this.pm$106();
            }
         }
      }
   }

   

   private void pm$106() {
      if (this.f591) {
         this.f592 = 0;
         this.f593 = 0;
         ByteBuffer var1 = SDLKeyboard.SDL_GetKeyboardState();
         int var2 = var1 == null || var1.get(225) == 0 && var1.get(229) == 0 ? 0 : 1;
         if (var2 == 0) {
            f0.options.keyShift.setDown(false);
         }

         this.f591 = false;
      }
   }

   public EagleModule() {
      super("Eagle", Category.f23);
      this.f586 = new BooleanSetting("Block Check", this, true);
      this.f587 = new BooleanSetting("Pitch Check", this, true);
      this.f588 = new BooleanSetting("Forward Check", this, true);
      this.f589 = new BooleanSetting("Fix Double Sneak", this, false);
      this.f590 = new NumberSetting("Delay", this, 1.0, 0.0, 4.0, 1.0);
   }

   private void pm$105(BlockState var1) {
      if (var1.isAir() && f0.player.onGround()) {
         f0.options.keyShift.setDown(true);
         this.f591 = true;
      } else if (this.f591) {
         this.f593 = this.f593 + 1;
         if (this.f593 >= this.f590.getValue()) {
            this.pm$106();
         }
      }
   }
}
