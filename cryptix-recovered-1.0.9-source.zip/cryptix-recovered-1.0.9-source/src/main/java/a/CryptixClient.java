package a;

import com.cryptix.script.ScriptManager;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import net.fabricmc.api.ModInitializer;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

public class CryptixClient implements ModInitializer {
   public static ScriptManager f3;
   public static final String f2 = null; // Preserved JVM default; no initializer in input bytecode.
   public static final String f1 = null; // Preserved JVM default; no initializer in input bytecode.
   

   

   public static String sha256(String var0) {
      String var10000;
      try {
         MessageDigest var1 = MessageDigest.getInstance("SHA-256");
         byte[] var2 = var1.digest(var0.getBytes(StandardCharsets.UTF_8));
         StringBuilder var3 = new StringBuilder();
         byte[] var4 = var2;
         int var5 = var2.length;

         for (int var6 = 0; var6 < var5; var6++) {
            byte var7 = var4[var6];
            String var10001 = "%02x";
            Object[] var10002 = new Object[1];
            var10002[0] = var7;
            var3.append(String.format(var10001, var10002));
         }

         var10000 = var3.toString();
      } catch (Exception var8) {
         var8.printStackTrace();
         return "unknown";
      }

      return var10000;
   }

   public void onInitialize() {
      ModuleManager.initialize();
      l.m8();
      ht.m32();
   }

   public static void sendPrefixedMessage(String var0) {
      var0 = "§7[§aC§7] " + var0;
      Minecraft.getInstance().player.sendSystemMessage(Component.literal(var0));
   }

   public static void sendMessage(String var0) {
      if (Minecraft.getInstance().player == null) {
         System.out.println("[Cryptix] " + var0);
      } else {
         Minecraft.getInstance().player.sendSystemMessage(Component.literal(var0));
      }
   }
}
