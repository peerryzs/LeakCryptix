package a;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class kf {
   private long f145;
   public final String f3;
   public boolean f6;
   protected final int width;
   private final int f143;
   public int f4;
   private float f144;
   public int f5;
   private final List<qu> f146;
   

   public kf(String var1, int var2, int var3, List<Module> var4) {
      this.width = 100;
      this.f143 = 15;
      this.f146 = new ArrayList();
      this.f3 = var1;
      this.f4 = var2;
      this.f5 = var3;
      if (var4 != null) {
         for (Module var6 : var4) {
            this.f146.add(new qu(var6));
         }
      }
   }

   public boolean m89(double var1, double var3) {
      return (var1 >= this.f4 && var1 <= this.f4 + 100 && var3 >= this.f5 && var3 <= this.f5 + 15
         );
   }

   public void m87(GuiGraphicsExtractor var1) {
      int var2 = oo.m30();
      long var3 = System.nanoTime();
      if (this.f145 == 0L) {
         this.f145 = var3;
      }

      float var5 = Math.min((float)(var3 - this.f145) * 1.0E-9F, 0.05F);
      this.f145 = var3;
      float var6 = this.f6 ? 1.0F : 0.0F;
      float var7 = 12.0F;
      float var8 = 1.0F - (float)Math.exp(-var7 * var5);
      this.f144 = this.f144 + (var6 - this.f144) * var8;
      if (Math.abs(this.f144 - var6) < 0.001F) {
         this.f144 = var6;
      }

      var1.fill(this.f4, this.f5, this.f4 + 100, this.f5 + 15, var2);
      int var10003 = this.f4 + 4;
      int var10004 = this.f5 + 3;
      var1.text(Minecraft.getInstance().font, this.f3, var10003, var10004, -1);
      int var9 = 15;

      for (qu var11 : this.f146) {
         var9 += var11.m100();
      }

      int var14 = 15;
      int var15 = (int)(var9 * this.f144);

      for (qu var13 : this.f146) {
         if (var14 > var15) {
            var13.m104(var5, false);
            break;
         }

         var13.m104(var5, this.f6);
         var13.f8 = this.f4;
         var13.f9 = this.f5 + var14;
         var13.f10 = 100;
         if (this.f6 || var13.f14 > 5) {
            var13.m97(var1, var2);
         }

         var14 += var13.m100();
      }
   }

   public void m93() {
      if (this.f6) {
         for (qu var2 : this.f146) {
            var2.m103();
         }
      }
   }

   public void m90(double var1, double var3, int var5) {
      if (var5 == 3 && this.m89(var1, var3)) {
         this.f6 = (!this.f6);
      } else if (this.f6) {
         for (qu var7 : this.f146) {
            var7.m98(var1, var3, var5);
         }
      }
   }

   public void m92(double var1, double var3) {
      if (this.f6) {
         for (qu var6 : this.f146) {
            var6.m102(var1, var3);
         }
      }
   }

   public void m91(int var1) {
      for (qu var3 : this.f146) {
         var3.m101(var1);
      }
   }

   public List<qu> m94() {
      return this.f146;
   }

   public boolean m88(double var1, double var3) {
      return (var1 >= this.f4 && var1 <= this.f4 + 100 && var3 >= this.f5 && var3 <= this.f5 + 15
         );
   }
}
