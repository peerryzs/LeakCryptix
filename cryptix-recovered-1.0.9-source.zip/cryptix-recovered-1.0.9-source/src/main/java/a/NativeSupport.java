package a;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;
import java.util.UUID;

/** implemented in Java from callers, not DLL-equivalent: persistent local installation ID
 * replaces the unknown HWID; diagnostics stay local without an inferred server. */
public final class NativeSupport {
   private static final Path DIRECTORY = Path.of("cryptix-recovered");
   private static String installationId;
   private NativeSupport() {}
   public static void m2() {
      throw new IllegalStateException("Original Cryptix authorization is unavailable in the recovered edition.");
   }
   public static synchronized void m3(String value) {
      try {
         Files.createDirectories(DIRECTORY);
         Files.writeString(DIRECTORY.resolve("support-diagnostic.txt"),
            "Cryptix recovered local diagnostic\n" + String.valueOf(value) + "\n", StandardCharsets.UTF_8);
      } catch (IOException e) { throw new IllegalStateException("Cannot save recovered diagnostic", e); }
   }
   public static synchronized String m1() {
      if (installationId != null) return installationId;
      try {
         Files.createDirectories(DIRECTORY);
         Path file = DIRECTORY.resolve("installation-id.txt");
         if (Files.exists(file)) installationId = UUID.fromString(Files.readString(file).trim()).toString();
         else {
            installationId = UUID.randomUUID().toString();
            Files.writeString(file, installationId, StandardCharsets.UTF_8);
         }
         return installationId;
      } catch (IOException | IllegalArgumentException e) {
         throw new IllegalStateException("Cannot read recovered installation ID", e);
      }
   }
}
