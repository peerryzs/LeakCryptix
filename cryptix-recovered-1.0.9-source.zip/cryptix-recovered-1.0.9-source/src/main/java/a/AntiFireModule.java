package a;

import java.nio.charset.StandardCharsets;

public class AntiFireModule extends Module {
   

   

   public AntiFireModule() {
      super("AntiFire", Category.f24);
   }
}
