package a;

public class yi extends r {
   private int f121;
   private boolean f122;
   

   public void m84(int var1) {
      this.f121 = var1;
   }

   public int m83() {
      return this.f121;
   }

   public yi m82(int var1, boolean var2) {
      this.f121 = var1;
      this.f122 = var2;
      return this;
   }

   public void m86(boolean var1) {
      this.f122 = var1;
   }

   public boolean m85() {
      return this.f122;
   }
}
