package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.ItemStack;

public class ChestStealerModule extends Module {
   private int f579;
   private final NumberSetting f577;
   private final BooleanSetting f578;
   private static final String f576 = "";
   

   public ChestStealerModule() {
      super("ChestStealer", Category.f23);
      this.f577 = new NumberSetting("Delay", this, 2.0, 0.0, 5.0, 1.0);
      this.f578 = new BooleanSetting("Hypixel Chest", this, false);
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         if (f0.player.containerMenu instanceof ChestMenu var2) {
            if (this.f578.getValue() && f0.gui.screen() != null) {
               Component var6 = f0.gui.screen().getTitle();
               if (!var6.getString().equals("Chest") && !var6.getString().equals(f576)) {
                  this.f579 = 0;
                  return;
               }
            }

            this.f579 = this.f579 + 1;
            if (this.f579 > this.f577.getValue()) {
               int var7 = 1;

               for (int var4 = 0; var4 < var2.getContainer().getContainerSize(); var4++) {
                  ItemStack var5 = var2.getSlot(var4).getItem();
                  if (!var5.isEmpty()) {
                     f0.gameMode.handleContainerInput(var2.containerId, var4, 0, ContainerInput.QUICK_MOVE, f0.player);
                     this.f579 = 0;
                     var7 = 0;
                     break;
                  }
               }

               if (var7 != 0) {
                  f0.player.closeContainer();
               }
            }
         } else {
            this.f579 = 0;
         }
      }
   }

   
}
