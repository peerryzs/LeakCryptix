package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.InteractionHand;

public class NoSlowModule extends Module {
   private NumberSetting f474;
   private ModeSetting f478;
   private BooleanSetting f475;
   private ModeSetting f479;
   private BooleanSetting f477;
   private BooleanSetting f476;
   private int f480;
   private double f481;
   

   @Override
   public void onEvent(r var1) {
      // Autoblock must preserve vanilla slowdown and its matching server use state.
      if (ModuleManager.f28.isEnabled() && ModuleManager.f28.f17) {
         this.f480 = 0;
         return;
      }
      if (var1 == u.f10) {
         u.f10.m81((float)this.f474.getValue());
      } else if (var1 == u.f13) {
         if (this.f475.getValue()) {
            u.f13.m84(1);
            u.f13.m86(true);
         }
      } else if (var1 == u.f6) {
         double var2 = this.f474.getValue();
         if (var2 != this.f481) {
            this.f481 = var2;
            this.setSuffix(var2 + "");
         }

         if (f0.player.isUsingItem()) {
            int var4 = this.f478.isMode("SecondTick") ? 2 : 1;
            int var5 = this.f479.isMode("SecondTick") ? 2 : 1;
            this.f480 = this.f480 + 1;
            if ((!f0.options.keyJump.isDown() || !f0.player.onGround()) && this.f476.getValue()) {
               u.f6.m64(f0.player.getYRot() + 45.0F);
            }

            if (!this.f478.isMode("Disabled") && (this.f480 == var4 || this.f478.isMode("Always"))) {
               int var6 = f0.player.getInventory().getSelectedSlot();
               f0.player.connection.send(new ServerboundSetCarriedItemPacket(var6 % 8 + 1));
               f0.player.connection.send(new ServerboundSetCarriedItemPacket(var6));
            }

            if (!this.f479.isMode("Disabled") && (this.f480 == var5 || this.f479.isMode("Always"))) {
               f0.getConnection().send(new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, 0, f0.player.getYRot(), f0.player.getXRot()));
            }
         } else {
            this.f480 = 0;
         }
      }

      if (var1 == u.f4 && f0.player.isUsingItem() && this.f477.getValue()) {
         u.f4.m59(false);
      }
   }

   public NoSlowModule() {
      super("NoSlow", Category.f22);
      this.f474 = new NumberSetting("Speed", this, 0.2, 0.2, 1.0, 0.1);
      this.f475 = new BooleanSetting("Force Sprinting", this, false);
      this.f476 = new BooleanSetting("Rotate", this, false);
      this.f477 = new BooleanSetting("NoGround", this, false);
      String var10003 = "Swap";
      String var10005 = "Disabled";
      String[] var10006 = new String[4];
      var10006[0] = "Disabled";
      var10006[1] = "Always";
      var10006[2] = "FirstTick";
      var10006[3] = "SecondTick";
      this.f478 = new ModeSetting(var10003, this, var10005, var10006);
      var10003 = "Block";
      var10005 = "Disabled";
      var10006 = new String[4];
      var10006[0] = "Disabled";
      var10006[1] = "Always";
      var10006[2] = "FirstTick";
      var10006[3] = "SecondTick";
      this.f479 = new ModeSetting(var10003, this, var10005, var10006);
   }

   
}
