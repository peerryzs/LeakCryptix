package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class ck extends oc {
   private final HUDModule f191;
   

   public ck(HUDModule var1) {
      super(Component.literal("HUD Position"));
      this.f191 = var1;
   }

   public void init() {
      Button var1 = Button.builder(Component.literal("Reset Position"), var1x -> this.setting.m245(0, 0))
         .bounds(this.width - 90, this.height - 25, 85, 20)
         .build();
      this.addRenderableWidget(var1);
   }

   public boolean isPauseScreen() {
      return false;
   }

   

   public void extractRenderState(GuiGraphicsExtractor var1, int var2, int var3, float var4) {
      var1.fill(0, 0, this.width, this.height, -2147483648);
      this.f191.m212(var1);
      int var5 = ve.f0.getWindow().getGuiScaledWidth();
      int var6 = ve.f0.getWindow().getGuiScaledHeight();
      if (this.isInsideHud(var2, var3)) {
         int var7 = this.setting.m235() + var5 - this.setting.m237() - 10;
         int var8 = this.setting.m236() + 1;
         int var9 = this.setting.m237() + 9;
         int var10 = this.setting.m238() + 3;
         var1.outline(var7, var8, var9, var10, -1);
      }

      String var11 = "Edit the HUD position by dragging.";
      var1.text(ve.f0.font, var11, var5 / 2 - ve.f0.font.width(var11) / 2, var6 / 2, -1);
      if (this.getFocused() != null) {
         this.setFocused(null);
      }

      super.extractRenderState(var1, var2, var3, var4);
   }

   public boolean isInsideHud(double var1, double var3) {
      int var5 = ve.f0.getWindow().getGuiScaledWidth();
      int var6 = this.setting.m235() + var5 - this.setting.m237() - 10;
      int var7 = this.setting.m236() + 1;
      int var8 = this.setting.m237() + 9;
      int var9 = this.setting.m238() + 3;
      return (var1 >= var6 && var1 <= var6 + var8 && var3 >= var7 && var3 <= var7 + var9);
   }
}
