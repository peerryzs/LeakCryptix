package a;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import mixins.MultiPlayerGameModeMixin_sg;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

public class LongJumpModule extends Module {
   private int f453;
   private boolean f450;
   private int f449;
   private NumberSetting f445;
   private int f448;
   private ModeSetting f444;
   private BooleanSetting f446;
   private int f447;
   private double f451;
   private int f454;
   private double f452;
   public final List<zj> f22;
   

   public LongJumpModule() {
      super("LongJump", Category.f22);
      String var10003 = "Mode";
      String var10005 = "Fireball";
      String[] var10006 = new String[2];
      var10006[0] = "Fireball";
      var10006[1] = "Fireball2";
      this.f444 = new ModeSetting(var10003, this, var10005, var10006);
      this.f445 = new NumberSetting("Fireball Delay", this, 200.0, 100.0, 1000.0, 50.0);
      this.f446 = new BooleanSetting("Show Progress", this, false);
      this.f22 = new ArrayList();
      this.f447 = -1;
   }

   private int pm$93() {
      for (int var1 = 0; var1 < 9; var1++) {
         if (f0.player.getInventory().getItem(var1).is(Items.FIRE_CHARGE)) {
            return var1;
         }
      }

      return -1;
   }

   private void pm$92() {
      this.f452 = this.f451;
      if (this.f450) {
         this.f449 = this.f449 + 1;
         this.f451 = this.f449 * 50.0F / (float)this.f445.getValue();
      }

      if (this.f449 * 50 > this.f445.getValue() || !this.f450) {
         this.f449 = 0;
         this.f451 = 0.0;
         this.f450 = false;
      }

      int var1 = this.f450 ? 255 : 0;
      this.f454 = this.f453;
      this.f453 = (int)Mth.lerp(0.5F, this.f453, var1);
      synchronized (this.f22) {
         Iterator var3 = this.f22.iterator();

         while (var3.hasNext()) {
            zj var4 = (zj)var3.next();
            if (var4.m246() || !this.f450) {
               var3.remove();
               f0.execute(() -> var4.f52.handle(f0.getConnection()));
            }
         }
      }
   }

   

   @Override
   public void onDisable() {
      synchronized (this.f22) {
         for (zj var3 : this.f22) {
            f0.execute(() -> var3.f52.handle(f0.getConnection()));
         }

         this.f22.clear();
         this.f450 = false;
      }

      this.f448 = 0;
      this.f447 = -1;
      this.f449 = 0;
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f8 && this.f446.getValue()) {
         if (!this.f450 && this.f453 <= 5) {
            this.f452 = 0.0;
         } else {
            float var2 = 100.0F;
            float var3 = 4.0F;
            float var4 = f0.getWindow().getGuiScaledWidth() * 0.5F - var2 * 0.5F;
            float var5 = f0.getWindow().getGuiScaledHeight() * 0.5F + 20.0F;
            float var6 = u.f8.m78();
            double var7 = this.f452 + (this.f451 - this.f452) * var6;
            int var9 = (int)(this.f454 + (this.f453 - this.f454) * var6);
            int var10 = oo.m30() & 16777215 | var9 << 24;
            int var11 = var9 << 24;
            int var12 = (int)(var9 * 0.5F) << 24 | 6316128;
            th.m63(u.f8, (int)var4, (int)var5, (int)var2, (int)var3, var7, var11, var12, var10);
         }
      }

      if (var1 == u.f6) {
         this.setSuffix(this.f444.getValue());
         if (ModuleManager.f31.isEnabled()) {
            ModuleManager.f31.toggle();
         }

         int var17 = this.pm$93();
         if (var17 != -1) {
            u.f6.m70(90.0F);
            switch (this.f448) {
               case 0:
                  this.f447 = f0.player.getInventory().getSelectedSlot();
                  f0.player.getInventory().setSelectedSlot(var17);
                  break;
               case 1:
                  ((MultiPlayerGameModeMixin_sg)f0.gameMode)
                     .invokeStartPrediction(f0.level, var0 -> new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, var0, u.f6.m63(), u.f6.m69()));
                  break;
               case 2:
                  if (this.f444.isMode("Fireball")) {
                     f0.player.getInventory().setSelectedSlot(this.f447);
                  }
                  break;
               case 15:
                  if (this.f444.isMode("Fireball2")) {
                     ((MultiPlayerGameModeMixin_sg)f0.gameMode)
                        .invokeStartPrediction(f0.level, var0 -> new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, var0, u.f6.m63(), u.f6.m69()));
                  }
                  break;
               case 16:
                  f0.player.getInventory().setSelectedSlot(this.f447);
            }

            this.f448 = this.f448 + 1;
         } else {
            this.f448 = this.f448 + 1;
         }

         this.pm$92();
         if (f0.player.onGround() && this.f448 > 20) {
            this.toggle();
         }
      }

      if (var1 == u.f9 && this.f448 == (this.f444.isMode("Fireball") ? 4 : 20)) {
         f0.player.input.makeJump();
      }

      if (var1 == u.f12) {
         if (u.f12.m42() instanceof ClientboundSetEntityMotionPacket var18) {
            if (var18.id() == f0.player.getId()) {
               synchronized (this.f22) {
                  this.f22.add(new zj(var18, this.f444.isMode("Fireball") ? (long)this.f445.getValue() : (long)this.f445.getValue() + 800L));
                  var1.m9(true);
               }

               this.f450 = true;
            }
         } else if (this.f450) {
            synchronized (this.f22) {
               this.f22.add(new zj(u.f12.m42(), this.f444.isMode("Fireball") ? (long)this.f445.getValue() : (long)this.f445.getValue() + 800L));
               var1.m9(true);
            }
         }
      }
   }

   @Override
   public void onEnable() {
      this.f448 = 0;
      this.f447 = -1;
      this.f449 = 0;
      this.f450 = false;
      this.f452 = 0.0;
      this.f451 = 0.0;
      this.f454 = 0;
      this.f453 = 0;
   }
}
