package a;

import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.TeamColor;

public class PlayerESPModule extends Module {
   private final NumberSetting f839;
   private boolean f847;
   private final NumberSetting f840;
   private boolean f846;
   private final BooleanSetting f834;
   private int f842;
   private int f843;
   private int f845;
   private final BooleanSetting f835;
   private final ModeSetting f837;
   private final NumberSetting f838;
   private final BooleanSetting f836;
   private int f844;
   private final fd f841;
   

   private int pm$128() {
      int var1 = (int)this.f838.getValue();
      int var2 = (int)this.f839.getValue();
      int var3 = (int)this.f840.getValue();
      if (var1 != this.f843 || var2 != this.f844 || var3 != this.f845) {
         this.f843 = var1;
         this.f844 = var2;
         this.f845 = var3;
         this.f842 = var1 << 16 | var2 << 8 | var3 | -16777216;
      }

      return this.f842;
   }

   public PlayerESPModule() {
      super("PlayerESP", Category.f24);
      this.f834 = new BooleanSetting("2D", this, false);
      this.f835 = new BooleanSetting("Health bar", this, false);
      this.f836 = new BooleanSetting("Outline", this, false);
      String var10003 = "Color";
      String var10005 = "Theme";
      String[] var10006 = new String[3];
      var10006[0] = "Theme";
      var10006[1] = "Team";
      var10006[2] = "Custom";
      this.f837 = new ModeSetting(var10003, this, var10005, var10006);
      this.f838 = new NumberSetting("Red", this, 255.0, 0.0, 255.0, 1.0);
      this.f839 = new NumberSetting("Green", this, 255.0, 0.0, 255.0, 1.0);
      this.f840 = new NumberSetting("Blue", this, 255.0, 0.0, 255.0, 1.0);
      this.f841 = new fd();
      this.f843 = -1;
      this.f844 = -1;
      this.f845 = -1;
   }

   

   private void draw2DBox(GuiGraphicsExtractor var1, Player var2, int var3, float var4, fd var5) {
      if (this.f847) {
         var3 = this.pm$127(var2);
      }

      double var6 = Double.MAX_VALUE;
      double var8 = Double.MAX_VALUE;
      double var10 = -Double.MAX_VALUE;
      double var12 = -Double.MAX_VALUE;
      double var14 = var2.xOld + (var2.getX() - var2.xOld) * var4;
      double var16 = var2.yOld + (var2.getY() - var2.yOld) * var4;
      double var18 = var2.zOld + (var2.getZ() - var2.zOld) * var4;
      double var20 = var2.getBbWidth() * 0.5;
      double var22 = var2.getBbHeight();
      double var24 = var14 - var20;
      double var26 = var14 + var20;
      double var30 = var16 + var22 + 0.15;
      double var32 = var18 - var20;
      double var34 = var18 + var20;
      fd var36 = th.m62(var24, var16, var32, this.f841);
      if (var36 != null) {
         if (var36.f53 < var6) {
            var6 = var36.f53;
         }

         if (var36.f54 < var8) {
            var8 = var36.f54;
         }

         if (var36.f53 > var10) {
            var10 = var36.f53;
         }

         if (var36.f54 > var12) {
            var12 = var36.f54;
         }

         var36 = th.m62(var24, var16, var34, this.f841);
         if (var36 != null) {
            if (var36.f53 < var6) {
               var6 = var36.f53;
            }

            if (var36.f54 < var8) {
               var8 = var36.f54;
            }

            if (var36.f53 > var10) {
               var10 = var36.f53;
            }

            if (var36.f54 > var12) {
               var12 = var36.f54;
            }

            var36 = th.m62(var26, var16, var32, this.f841);
            if (var36 != null) {
               if (var36.f53 < var6) {
                  var6 = var36.f53;
               }

               if (var36.f54 < var8) {
                  var8 = var36.f54;
               }

               if (var36.f53 > var10) {
                  var10 = var36.f53;
               }

               if (var36.f54 > var12) {
                  var12 = var36.f54;
               }

               var36 = th.m62(var26, var16, var34, this.f841);
               if (var36 != null) {
                  if (var36.f53 < var6) {
                     var6 = var36.f53;
                  }

                  if (var36.f54 < var8) {
                     var8 = var36.f54;
                  }

                  if (var36.f53 > var10) {
                     var10 = var36.f53;
                  }

                  if (var36.f54 > var12) {
                     var12 = var36.f54;
                  }

                  var36 = th.m62(var24, var30, var32, this.f841);
                  if (var36 != null) {
                     if (var36.f53 < var6) {
                        var6 = var36.f53;
                     }

                     if (var36.f54 < var8) {
                        var8 = var36.f54;
                     }

                     if (var36.f53 > var10) {
                        var10 = var36.f53;
                     }

                     if (var36.f54 > var12) {
                        var12 = var36.f54;
                     }

                     var36 = th.m62(var24, var30, var34, this.f841);
                     if (var36 != null) {
                        if (var36.f53 < var6) {
                           var6 = var36.f53;
                        }

                        if (var36.f54 < var8) {
                           var8 = var36.f54;
                        }

                        if (var36.f53 > var10) {
                           var10 = var36.f53;
                        }

                        if (var36.f54 > var12) {
                           var12 = var36.f54;
                        }

                        var36 = th.m62(var26, var30, var32, this.f841);
                        if (var36 != null) {
                           if (var36.f53 < var6) {
                              var6 = var36.f53;
                           }

                           if (var36.f54 < var8) {
                              var8 = var36.f54;
                           }

                           if (var36.f53 > var10) {
                              var10 = var36.f53;
                           }

                           if (var36.f54 > var12) {
                              var12 = var36.f54;
                           }

                           var36 = th.m62(var26, var30, var34, this.f841);
                           if (var36 != null) {
                              if (var36.f53 < var6) {
                                 var6 = var36.f53;
                              }

                              if (var36.f54 < var8) {
                                 var8 = var36.f54;
                              }

                              if (var36.f53 > var10) {
                                 var10 = var36.f53;
                              }

                              if (var36.f54 > var12) {
                                 var12 = var36.f54;
                              }

                              int var37 = (int)var6;
                              int var38 = (int)var8;
                              int var39 = (int)var10;
                              int var40 = (int)var12;
                              int var41 = 1;
                              if (this.f834.getValue()) {
                                 int var42 = 1;
                                 var1.fill(var37 - var42, var38 - var42, var39 + var42, var38 + var42 + var41, -16777216);
                                 var1.fill(var37 - var42, var40 - var42 - var41, var39 + var42, var40 + var42, -16777216);
                                 var1.fill(var37 - var42, var38 - var42, var37 + var42 + var41, var40 + var42, -16777216);
                                 var1.fill(var39 - var42 - var41, var38 - var42, var39 + var42, var40 + var42, -16777216);
                                 var1.fill(var37, var38, var39, var38 + var41, var3);
                                 var1.fill(var37, var40 - var41, var39, var40, var3);
                                 var1.fill(var37, var38, var37 + var41, var40, var3);
                                 var1.fill(var39 - var41, var38, var39, var40, var3);
                              }

                              if (this.f835.getValue()) {
                                 double var57 = Math.clamp((double)(var2.getHealth() / var2.getMaxHealth()), 0.0, 1.0);
                                 int var44 = oo.m29((float)var57);
                                 int var45 = Math.max(1, var40 - var38);
                                 int var46 = Math.max(var2.getHealth() > 0.0F ? 1 : 0, (int)Math.ceil(var45 * var57));
                                 int var47 = 4;
                                 int var48 = var37 - var47;
                                 int var49 = var48 + 1;
                                 var1.fill(var48 - 1, var38 - 1, var49 + 1, var38 + var45 + 1, -16777216);
                                 var1.fill(var48, var38, var49, var38 + var45, -11513776);
                                 if (var46 > 0) {
                                    var1.fill(var48, var38 + var45 - var46, var49, var38 + var45, var44);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private int pm$127(Player var1) {
      PlayerTeam var2 = var1.getTeam();
      if (var2 == null) {
         return Color.WHITE.getRGB();
      } else {
         Optional var3 = var2.getColor();
         return var3.isPresent() ? ((TeamColor)var3.get()).rgb() : -1;
      }
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f8 && (this.f834.getValue() || this.f835.getValue())) {
         GuiGraphicsExtractor var2 = u.f8.m76();
         float var3 = u.f8.m78();
         int var4;
         if (this.f846) {
            var4 = oo.m30();
         } else {
            var4 = this.pm$128();
         }

         for (Player var6 : f0.level.players()) {
            if (!ModuleManager.f29.m137(var6) && var6 != f0.player) {
               this.draw2DBox(var2, var6, var4, var3, this.f841);
            }
         }
      }

      if (var1 == u.f15 && this.f836.getValue()) {
         Entity var7 = u.f15.m39();
         if (ModuleManager.f29.m137(u.f15.m39()) || var7 == f0.player || !(var7 instanceof Player)) {
            return;
         }

         int var8;
         if (this.f846) {
            var8 = oo.m30();
         } else if (this.f847) {
            var8 = this.pm$127((Player)var7);
         } else {
            var8 = this.pm$128();
         }

         u.f15.m40(var8);
      }

      if (var1 == u.f6) {
         this.f846 = this.f837.isMode("Theme");
         this.f847 = this.f837.isMode("Team");
      }
   }
}
