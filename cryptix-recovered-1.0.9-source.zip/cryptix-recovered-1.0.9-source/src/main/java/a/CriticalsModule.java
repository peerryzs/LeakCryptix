package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.PosRot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;

public class CriticalsModule extends Module {
   private long f276;
   private double f275;
   private ModeSetting f274;
   

   @Override
   public void onEnable() {
      this.f276 = System.currentTimeMillis();
      this.f275 = 0.0;
   }

   private void pm$60() {
      double var1 = f0.player.getX();
      double var3 = f0.player.getY();
      double var5 = f0.player.getZ();
      f0.getConnection().send(new Pos(var1, var3 + 0.0625, var5, false, f0.player.horizontalCollision));
      f0.getConnection().send(new Pos(var1, var3, var5, false, f0.player.horizontalCollision));
      f0.getConnection().send(new Pos(var1, var3 + 1.0E-6, var5, false, f0.player.horizontalCollision));
   }

   public CriticalsModule() {
      super("Criticals", Category.f21);
      String var10003 = "Mode";
      String var10005 = "Packet";
      String[] var10006 = new String[2];
      var10006[0] = "Packet";
      var10006[1] = "Timer";
      this.f274 = new ModeSetting(var10003, this, var10005, var10006);
   }

   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f11) {
         if (u.f11.m45() instanceof ServerboundAttackPacket var2) {
            if (f0.player == null) {
               return;
            }

            if (!f0.player.onGround()) {
               return;
            }

            if (f0.player.isInWater() || f0.player.isInLava()) {
               return;
            }

            if (this.f274.isMode("Packet")) {
               this.pm$60();
            }
         }

         if (u.f11.m45() instanceof ServerboundMovePlayerPacket || u.f11.m45() instanceof Pos || u.f11.m45() instanceof Rot || u.f11.m45() instanceof PosRot) {
            if (!var1.m8()) {
               this.f275 -= 50.0;
            }

            this.f275 = this.f275 + (System.currentTimeMillis() - this.f276);
            this.f276 = System.currentTimeMillis();
         }
      }

      if (var1 == u.f6) {
         if (System.currentTimeMillis() - this.f276 > 200L) {
            this.f276 = System.currentTimeMillis();
            this.f275 = 0.0;
         }

         double var4 = f0.player.getDeltaMovement().y;
         if (var4 > 0.0) {
            iw.m57(2.5F);
         } else if (this.f275 < 0.0) {
            iw.m57(0.5F);
         } else {
            iw.m57(1.0F);
         }
      }
   }
}
