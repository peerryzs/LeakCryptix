package a;

import java.nio.charset.StandardCharsets;

public class TimerModule extends Module {
   private final NumberSetting f511;
   

   @Override
   public void onDisable() {
      iw.m57(1.0F);
   }

   public TimerModule() {
      super("Timer", Category.f22);
      this.f511 = new NumberSetting("Speed", this, 1.0, 0.1, 5.0, 0.1);
   }

   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         iw.m57((float)this.f511.getValue());
      }
   }
}
