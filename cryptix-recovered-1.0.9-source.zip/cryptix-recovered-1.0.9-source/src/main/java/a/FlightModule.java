package a;

import java.nio.charset.StandardCharsets;

public class FlightModule extends Module {
   private NumberSetting f431;
   

   public FlightModule() {
      super("Flight", Category.f22);
      this.f431 = new NumberSetting("Speed", this, 1.0, 1.0, 10.0, 0.5);
   }

   @Override
   public void onDisable() {
      f0.player.getAbilities().flying = false;
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f4) {
         f0.player.getAbilities().flying = true;
         f0.player.getAbilities().setFlyingSpeed((float)this.f431.getValue() * 0.1F);
      }
   }

   
}
