package a;

import net.minecraft.util.Mth;

public class xt implements ve {
   

   public static float m50(float var0, float var1) {
      float var2 = var1;
      double var3 = ve.f0.player.getX() - ve.f0.player.xOld;
      double var5 = ve.f0.player.getZ() - ve.f0.player.zOld;
      double var7 = var3 * var3 + var5 * var5;
      if (var7 > 0.0025) {
         var2 = (float)Math.toDegrees(Math.atan2(var5, var3)) - 90.0F;
      }

      if (ve.f0.player.isSwinging()) {
         var2 = var0;
      }

      float var9 = Mth.wrapDegrees(var2 - var1);
      float var10 = var1 + var9 * 0.3F;
      float var11 = Mth.wrapDegrees(var0 - var10);
      var11 = Mth.clamp(var11, -75.0F, 75.0F);
      float var12 = var0 - var11;
      if (var11 * var11 > 2500.0F) {
         var12 += var11 * 0.2F;
      }

      return var12;
   }

   public static boolean m49() {
      float var0 = m48() % 90.0F;
      return (var0 > 20.0F && var0 < 70.0F);
   }

   public static float m48() {
      float var0 = ve.f0.player.getYRot();
      boolean var1 = ve.f0.options.keyUp.isDown();
      boolean var2 = ve.f0.options.keyDown.isDown();
      boolean var3 = ve.f0.options.keyLeft.isDown();
      boolean var4 = ve.f0.options.keyRight.isDown();
      if (var1 && !var2) {
         if (var3 && !var4) {
            var0 -= 45.0F;
         } else if (var4 && !var3) {
            var0 += 45.0F;
         }
      } else if (var2 && !var1) {
         var0 += 180.0F;
         if (var3 && !var4) {
            var0 += 45.0F;
         } else if (var4 && !var3) {
            var0 -= 45.0F;
         }
      } else if (var3 && !var4) {
         var0 -= 90.0F;
      } else if (var4 && !var3) {
         var0 += 90.0F;
      }

      var0 %= 360.0F;
      if (var0 < 0.0F) {
         var0 += 360.0F;
      }

      return var0;
   }
}
