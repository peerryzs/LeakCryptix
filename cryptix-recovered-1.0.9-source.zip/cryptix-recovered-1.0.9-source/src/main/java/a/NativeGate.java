package a;

/** implemented in Java licensing boundary; original protocol and keys are unavailable.
 * Recovered edition does not invoke this gate or fabricate license success. */
public final class NativeGate {
   public static volatile boolean f0 = false;
   private NativeGate() {}
   private static boolean pm$1(String value) { return value != null && !value.isBlank(); }
   private static boolean pm$2() { return false; }
   public static boolean m0(String value) { f0 = pm$0(value); return f0; }
   private static void pm$3() { f0 = false; }
   private static boolean pm$0(String value) {
      // Signatures alone cannot establish the unknown authorization protocol.
      if (!pm$1(value) || !pm$2()) return false;
      return false;
   }
   private static void lambda$failClosed$0() { pm$3(); }
}
