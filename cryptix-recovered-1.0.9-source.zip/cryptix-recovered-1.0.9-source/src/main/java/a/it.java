package a;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import org.joml.Matrix3x2fc;
import org.jspecify.annotations.Nullable;

public record it(
   RenderPipeline pipeline,
   TextureSetup textureSetup,
   Matrix3x2fc pose,
   String text,
   gs[] glyphs,
   float x,
   float y,
   int color,
   float size,
   @Nullable ScreenRectangle scissorArea,
   @Nullable ScreenRectangle bounds
) implements GuiElementRenderState {

   private static final int[] f1088;





   

   private static float getWidth(String var0, gs[] var1) {
      float var2 = 0.0F;

      for (int var3 = 0; var3 < var0.length(); var3++) {
         char var4 = var0.charAt(var3);
         if (var4 == 167 && var3 + 1 < var0.length()) {
            var3++;
         } else if (var4 >= 32 && var4 <= 255) {
            gs var5 = var1[var4 - 32];
            if (var5 != null) {
               var2 += var5.advance();
            }
         }
      }

      return var2;
   }

   public Matrix3x2fc pose() {
      return this.pose;
   }

   public float y() {
      return this.y;
   }

   public float size() {
      return this.size;
   }

   public float x() {
      return this.x;
   }

   @Nullable
   public ScreenRectangle scissorArea() {
      return this.scissorArea;
   }

   public TextureSetup textureSetup() {
      return this.textureSetup;
   }

   public it(
      RenderPipeline pipeline,
      TextureSetup textureSetup,
      Matrix3x2fc pose,
      String text,
      gs[] glyphs,
      float x,
      float y,
      int color,
      float size,
      @Nullable ScreenRectangle scissorArea,
      @Nullable ScreenRectangle bounds
   ) {
      this.pipeline = pipeline;
      this.textureSetup = textureSetup;
      this.pose = pose;
      this.text = text;
      this.glyphs = glyphs;
      this.x = x;
      this.y = y;
      this.color = color;
      this.size = size;
      this.scissorArea = scissorArea;
      this.bounds = bounds;
   }

   @Nullable
   public ScreenRectangle bounds() {
      return this.bounds;
   }

   public gs[] glyphs() {
      return this.glyphs;
   }

   public it(
      RenderPipeline var1,
      TextureSetup var2,
      Matrix3x2fc var3,
      String var4,
      gs[] var5,
      float var6,
      float var7,
      int var8,
      float var9,
      @Nullable ScreenRectangle var10
   ) {
      this(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, getBounds(var4, var5, var6, var7, var9, var3, var10));
   }

   private static int pm$140(char var0) {
      var0 = Character.toLowerCase(var0);
      if (var0 >= 48 && var0 <= 57) {
         return f1088[var0 - 48];
      } else {
         return var0 >= 97 && var0 <= 102 ? f1088[var0 - 97 + 10] : -1;
      }
   }

   static {
      int[] var10000 = new int[16];
      var10000[0] = 0;
      var10000[1] = 170;
      var10000[2] = 43520;
      var10000[3] = 43690;
      var10000[4] = 11141120;
      var10000[5] = 11141290;
      var10000[6] = 16755200;
      var10000[7] = 11184810;
      var10000[8] = 5592405;
      var10000[9] = 5592575;
      var10000[10] = 5635925;
      var10000[11] = 5636095;
      var10000[12] = 16733525;
      var10000[13] = 16733695;
      var10000[14] = 16777045;
      var10000[15] = 16777215;
      f1088 = var10000;
   }

   public String text() {
      return this.text;
   }

   public RenderPipeline pipeline() {
      return this.pipeline;
   }

   public int color() {
      return this.color;
   }

   @Nullable
   private static ScreenRectangle getBounds(String var0, gs[] var1, float var2, float var3, float var4, Matrix3x2fc var5, @Nullable ScreenRectangle var6) {
      float var7 = getWidth(var0, var1);
      ScreenRectangle var8 = new ScreenRectangle(
            (int)Math.floor(var2 - var7 * 0.5F), (int)Math.floor(var3 - var4 * 0.5F), (int)Math.ceil(var7), (int)Math.ceil(var4)
         )
         .transformMaxBounds(var5);
      return var6 != null ? var6.intersection(var8) : var8;
   }

   public void buildVertices(VertexConsumer var1) {
      float var2 = this.x() - 3.0F;
      float var3 = this.y() - this.size() * 0.5F + 1.0F;
      int var4 = this.color();
      String var5 = this.text();
      gs[] var6 = this.glyphs();
      Matrix3x2fc var7 = this.pose();
      int var8 = var5.length();

      for (int var9 = 0; var9 < var8; var9++) {
         char var10 = var5.charAt(var9);
         if (var10 == 167 && var9 + 1 < var8) {
            int var16 = pm$140(var5.charAt(++var9));
            if (var16 != -1) {
               var4 = var4 & -16777216 | var16;
            }
         } else if (var10 >= 32 && var10 <= 255) {
            gs var11 = var6[var10 - 32];
            if (var11 != null) {
               float var12 = var2 + var11.x();
               float var13 = var3 + var11.y();
               float var14 = var12 + var11.width();
               float var15 = var13 + var11.height();
               var1.addVertexWith2DPose(var7, var12, var13).setColor(var4).setUv(var11.u0(), var11.v0());
               var1.addVertexWith2DPose(var7, var12, var15).setColor(var4).setUv(var11.u0(), var11.v1());
               var1.addVertexWith2DPose(var7, var14, var15).setColor(var4).setUv(var11.u1(), var11.v1());
               var1.addVertexWith2DPose(var7, var14, var13).setColor(var4).setUv(var11.u1(), var11.v0());
               var2 += var11.advance();
            }
         }
      }
   }
}
