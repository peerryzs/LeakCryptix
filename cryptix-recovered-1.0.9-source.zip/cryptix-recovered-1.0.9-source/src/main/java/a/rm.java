package a;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import org.joml.Matrix3x2fc;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public record rm(
   RenderPipeline pipeline,
   TextureSetup textureSetup,
   Matrix3x2fc pose,
   int x0,
   int y0,
   int x1,
   int y1,
   int radius,
   int color,
   @Nullable ScreenRectangle scissorArea,
   @Nullable ScreenRectangle bounds
) implements GuiElementRenderState {


   

   public RenderPipeline pipeline() {
      return this.pipeline;
   }

   public int color() {
      return this.color;
   }

   public rm(
      RenderPipeline pipeline,
      TextureSetup textureSetup,
      Matrix3x2fc pose,
      int x0,
      int y0,
      int x1,
      int y1,
      int radius,
      int color,
      @Nullable ScreenRectangle scissorArea,
      @Nullable ScreenRectangle bounds
   ) {
      this.pipeline = pipeline;
      this.textureSetup = textureSetup;
      this.pose = pose;
      this.x0 = x0;
      this.y0 = y0;
      this.x1 = x1;
      this.y1 = y1;
      this.radius = radius;
      this.color = color;
      this.scissorArea = scissorArea;
      this.bounds = bounds;
   }

   public int y1() {
      return this.y1;
   }

   public rm(
      RenderPipeline var1, TextureSetup var2, Matrix3x2fc var3, int var4, int var5, int var6, int var7, int var8, int var9, @Nullable ScreenRectangle var10
   ) {
      this(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, pm$138(var4, var5, var6, var7, var3, var10));
   }

   @Nullable
   public ScreenRectangle scissorArea() {
      return this.scissorArea;
   }

   @Nullable
   public ScreenRectangle bounds() {
      return this.bounds;
   }

   public void buildVertices(VertexConsumer var1) {
      int var2 = this.x0();
      int var3 = this.x1();
      int var4 = this.y0();
      int var5 = this.y1();
      int var6 = var3 - var2;
      int var7 = var5 - var4;
      int var8 = (int)Math.min((double)this.radius(), var6 * 0.5);
      if (var8 <= 0) {
         this.pm$137(var1, var2, var4, var3, var5);
      } else {
         this.pm$137(var1, var2 + var8, var4 + var8, var3 - var8, var5 - var8);
         if (var7 > var8 * 2) {
            this.pm$137(var1, var2, var4 + var8, var2 + var8, var5 - var8);
            this.pm$137(var1, var3 - var8, var4 + var8, var3, var5 - var8);
         }

         float var9 = var8;
         float var10 = var9 * var9;

         for (float var11 = 0.0F; var11 < var8; var11 += 0.5F) {
            float var12 = var11 + 0.25F;
            float var13 = var9 - var12;
            float var14 = var9 - (float)Math.sqrt(Math.max(0.0F, var10 - var13 * var13));
            float var15 = var2 + var14;
            float var16 = var3 - var14;
            this.pm$137(var1, var15, var4 + var11, var16, var4 + var11 + 0.5F);
            this.pm$137(var1, var15, var5 - var11 - 0.5F, var16, var5 - var11);
         }
      }
   }

   private void pm$137(VertexConsumer var1, float var2, float var3, float var4, float var5) {
      var1.addVertexWith2DPose(this.pose(), var2, var3).setColor(this.color());
      var1.addVertexWith2DPose(this.pose(), var2, var5).setColor(this.color());
      var1.addVertexWith2DPose(this.pose(), var4, var5).setColor(this.color());
      var1.addVertexWith2DPose(this.pose(), var4, var3).setColor(this.color());
   }

   public int y0() {
      return this.y0;
   }

   public TextureSetup textureSetup() {
      return this.textureSetup;
   }

   @Nullable
   private static ScreenRectangle pm$138(int var0, int var1, int var2, int var3, Matrix3x2fc var4, @Nullable ScreenRectangle var5) {
      ScreenRectangle var6 = new ScreenRectangle(var0, var1, var2 - var0, var3 - var1).transformMaxBounds(var4);
      return var5 != null ? var5.intersection(var6) : var6;
   }

   public int x1() {
      return this.x1;
   }

   public int radius() {
      return this.radius;
   }

   public Matrix3x2fc pose() {
      return this.pose;
   }

   public int x0() {
      return this.x0;
   }
}
