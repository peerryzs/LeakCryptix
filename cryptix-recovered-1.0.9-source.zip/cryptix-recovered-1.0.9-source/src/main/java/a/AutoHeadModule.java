package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

public class AutoHeadModule extends Module {
   private int f522;
   private final NumberSetting f521;
   private boolean f523;
   

   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         if (this.f522 != -1 && !this.f523) {
            f0.player.getInventory().setSelectedSlot(this.f522);
            this.f522 = -1;
            return;
         }

         if (f0.player.getHealth() > this.f521.getValue()) {
            return;
         }

         for (int var2 = 0; var2 < 9; var2++) {
            System.out.println(f0.player.getInventory().getItem(var2));
            if (f0.player.getInventory().getItem(var2).is(Items.HONEY_BOTTLE)) {
               this.f522 = f0.player.getInventory().getSelectedSlot();
               if (!this.f523) {
                  this.f523 = true;
                  return;
               }

               f0.player.getInventory().setSelectedSlot(var2);
               f0.getConnection().send(new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, 0, u.f6.m63(), u.f6.m69()));
               this.f523 = false;
            }
         }
      }
   }

   public AutoHeadModule() {
      super("AutoHead", Category.f23);
      this.f521 = new NumberSetting("Health", this, 4.0, 1.0, 15.0, 1.0);
      this.f522 = -1;
   }
}
