package a;

import java.nio.charset.StandardCharsets;
import mixins.MultiPlayerGameModeMixin_sg;

public class FastMineModule extends Module {
   private final BooleanSetting f598;
   private final NumberSetting f597;
   

   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         if (f0.gameMode == null) {
            return;
         }

         MultiPlayerGameModeMixin_sg var2 = (MultiPlayerGameModeMixin_sg)f0.gameMode;
         if (this.f598.getValue()) {
            var2.setDestroyDelay(0);
         }

         float var3 = var2.getDestroyProgress();
         if (var3 > 0.0F && var3 < 0.99F) {
            var2.setDestroyProgress((float)(var3 * this.f597.getValue()));
         }
      }
   }

   public FastMineModule() {
      super("FastMine", Category.f23);
      this.f597 = new NumberSetting("Speed", this, 1.5, 1.0, 5.0, 0.1);
      this.f598 = new BooleanSetting("Remove Delay", this, true);
   }
}
