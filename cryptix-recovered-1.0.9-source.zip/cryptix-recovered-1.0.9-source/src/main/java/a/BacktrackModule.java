package a;

import java.nio.charset.StandardCharsets;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.common.ClientboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ClientboundPingPacket;
import net.minecraft.network.protocol.common.ServerboundPongPacket;
import net.minecraft.network.protocol.game.ClientboundStartConfigurationPacket;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

public class BacktrackModule extends Module {
   private final NumberSetting f539;
   private int f545;
   private Vec3 f544;
   private final Queue<qq> f541;
   private boolean f543;
   private final NumberSetting f540;
   private final Queue<qq> f542;
   

   private void pm$99() {
      this.f543 = false;

      for (qq var2 : this.f541) {
         var2.packet.handle(f0.getConnection());
      }

      this.f541.clear();

      for (qq var4 : this.f542) {
         f0.getConnection().send(var4.packet);
      }

      this.f542.clear();
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f12) {
         f var2 = (f)var1;
         Packet var3 = var2.m42();
         if (var3 instanceof ClientboundStartConfigurationPacket || var3 instanceof ClientboundDisconnectPacket) {
            this.pm$99();
            return;
         }

         if (this.f543 && (var3 instanceof ClientboundPingPacket || var3 instanceof ClientboundKeepAlivePacket) && f0.level != null) {
            var2.m9(true);
            this.f541.add(new qq(var3, f0.level.getGameTime()));
         }
      }

      if (var1 == u.f11 && this.f543) {
         w var4 = (w)var1;
         Packet var6 = var4.m45();
         if (var6 instanceof ServerboundPongPacket) {
            var4.m9(true);
            this.f542.add(new qq(var6, f0.level.getGameTime()));
         }
      }

      if (var1 == u.f6) {
         LivingEntity var5 = jb.m51(this.f539.getValue(), true);
         if (var5 != null) {
            Vec3 var7 = var5.position();
            if (!this.f543) {
               this.f544 = new Vec3(var7.x, var7.y, var7.z);
            }

            if (this.f544.distanceTo(f0.player.position()) < var5.position().distanceTo(f0.player.position())) {
               this.pm$99();
            }

            if (this.f545 >= this.f540.getValue()) {
               this.pm$99();
               this.f545 = 0;
            }

            this.f543 = true;
            this.f545 = this.f545 + 1;
         } else {
            this.f545 = 0;
            this.f544 = null;
            this.f543 = false;
            this.pm$99();
         }
      }
   }

   public BacktrackModule() {
      super("Backtrack", Category.f23);
      this.f539 = new NumberSetting("Range", this, 6.0, 4.0, 8.0, 0.5);
      this.f540 = new NumberSetting("Ticks", this, 2.0, 1.0, 10.0, 1.0);
      this.f541 = new ConcurrentLinkedQueue();
      this.f542 = new ConcurrentLinkedQueue();
   }

   
}
