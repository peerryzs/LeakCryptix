package a;

import java.nio.charset.StandardCharsets;

public class ThemeModule extends Module {
   public final NumberSetting f50;
   public final ModeSetting f49;
   public final ModeSetting f51;
   

   public ThemeModule() {
      super("Theme", Category.f24);
      String var10003 = "Theme";
      String var10005 = "Default";
      String[] var10006 = new String[11];
      var10006[0] = "Default";
      var10006[1] = "Cherry";
      var10006[2] = "Cotton Candy";
      var10006[3] = "Emerald";
      var10006[4] = "Frost";
      var10006[5] = "Gold";
      var10006[6] = "Inferno";
      var10006[7] = "Nova";
      var10006[8] = "Ocean";
      var10006[9] = "Rainbow";
      var10006[10] = "Sakura";
      this.f49 = new ModeSetting(var10003, this, var10005, var10006);
      this.f50 = new NumberSetting("Speed", this, 1.0, 0.5, 5.0, 0.25);
      var10003 = "Font";
      var10005 = "Minecraft";
      var10006 = new String[2];
      var10006[0] = "Minecraft";
      var10006[1] = "Arial";
      this.f51 = new ModeSetting(var10003, this, var10005, var10006);
   }

   
}
