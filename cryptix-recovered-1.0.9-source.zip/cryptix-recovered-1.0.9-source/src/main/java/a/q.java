package a;

public class q extends r {
   
}
