package a;

import java.nio.charset.StandardCharsets;
import mixins.MultiPlayerGameModeMixin_sg;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

public class WindChargeModule extends Module {
   private final NumberSetting f418;
   private final BooleanSetting f419;
   private float f420;
   private int f421;
   private boolean f422;
   

   @Override
   public void onEnable() {
      this.f420 = f0.player.getXRot();
      this.f420 = -1.0F;
   }

   @Override
   public void onDisable() {
      if (this.f421 != -1) {
         f0.player.getInventory().setSelectedSlot(this.f421);
         this.f421 = -1;
      }
   }

   public WindChargeModule() {
      super("WindCharge", Category.f25);
      this.f418 = new NumberSetting("RotationSpeed", this, 5.0, 1.0, 10.0, 0.1);
      this.f419 = new BooleanSetting("Jump", this, true);
      this.f421 = -1;
   }

   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f9 && this.f422) {
         f0.player.input.makeJump();
         this.f422 = false;
         this.toggle();
      }

      if (var1 == u.f6) {
         int var2 = 0;

         for (int var3 = 0; var3 < 9; var3++) {
            if (f0.player.getInventory().getItem(var3).is(Items.WIND_CHARGE)) {
               if (this.f421 == -1) {
                  this.f421 = f0.player.getInventory().getSelectedSlot();
                  f0.player.getInventory().setSelectedSlot(var3);
               }

               var2 = 1;
               break;
            }
         }

         if (var2 == 0) {
            return;
         }

         float var5 = (float)this.f418.getValue() * 10.0F;
         float var4 = 90.0F - this.f420;
         this.f420 = this.f420 + Math.copySign(Math.min(Math.abs(var4), var5), var4);
         u.f6.m70(this.f420);
         if (this.f420 >= 90.0F && f0.player.getMainHandItem().is(Items.WIND_CHARGE)) {
            ((MultiPlayerGameModeMixin_sg)f0.gameMode).invokeStartPrediction(f0.level, var0 -> new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, var0, u.f6.m63(), u.f6.m69()));
            this.f422 = true;
         }
      }
   }
}
