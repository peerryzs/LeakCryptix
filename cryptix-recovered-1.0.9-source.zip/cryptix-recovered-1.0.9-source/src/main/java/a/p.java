package a;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.InputConstants.Key;
import com.mojang.blaze3d.platform.InputConstants.Type;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class p extends m {
   private static final List f66 = pm$4();
   

   @Override
   public void m0(String[] var1, String var2) {
      if (var1.length <= 2) {
         CryptixClient.sendPrefixedMessage("Usage: ." + this.f1);
      } else {
         String var3 = var1[1];
         String var4 = var1[2];
         Module var5 = null;
         Iterator var6 = ModuleManager.getModules().iterator();

         while (true) {
            if (var6.hasNext()) {
               Module var7 = (Module)var6.next();
               if (!var7.getName().equalsIgnoreCase(var3)) {
                  continue;
               }

               var5 = var7;
            }

            if (var5 == null) {
               CryptixClient.sendPrefixedMessage("Invalid module: " + var3);
               return;
            }

            if (var4.equalsIgnoreCase("none") || var4.equalsIgnoreCase("unbind")) {
               var5.setKeyBind(InputConstants.UNKNOWN.getValue());
               CryptixClient.sendPrefixedMessage("Unbound " + var5.getName());
               return;
            }

            Key var8 = pm$5(var4);
            if (var8 == InputConstants.UNKNOWN) {
               CryptixClient.sendPrefixedMessage("Invalid key: " + var4);
               return;
            }

            var5.setKeyBind(var8.getValue());
            CryptixClient.sendPrefixedMessage("Bound " + var5.getName() + " to " + var4.toUpperCase());
            break;
         }
      }
   }

   

   private static List pm$4() {
      ArrayList var0 = new ArrayList();
      Field[] var1 = InputConstants.class.getDeclaredFields();
      int var2 = var1.length;

      for (int var3 = 0; var3 < var2; var3++) {
         Field var4 = var1[var3];
         if (var4.getName().startsWith("KEY_") && var4.getType() == int.class) {
            String var5 = var4.getName().substring(4);
            var0.add(var5);
         }
      }

      var0.add("NONE");
      return var0;
   }

   public p() {
      String var10001 = "Bind";
      String var10002 = "bind <name> <key>";
      String[] var10003 = new String[2];
      var10003[0] = "bind";
      var10003[1] = "b";
      super(var10001, var10002, var10003);
   }

   private static Key pm$5(String var0) {
      String var1 = var0.toUpperCase();

      Key var10000;
      try {
         Field var2 = InputConstants.class.getDeclaredField("KEY_" + var1);
         if (var2.getType() != int.class) {
            return InputConstants.UNKNOWN;
         }

         int var3 = var2.getInt(null);
         var10000 = Type.KEYBOARD.getOrCreate(var3);
      } catch (ReflectiveOperationException var4) {
         return InputConstants.UNKNOWN;
      }

      return var10000;
   }

   @Override
   public Collection m1(String[] var1) {
      if (var1.length <= 1) {
         return ModuleManager.getModules().stream().map(Module::getName).toList();
      } else {
         return var1.length == 2 ? f66 : List.of();
      }
   }
}
