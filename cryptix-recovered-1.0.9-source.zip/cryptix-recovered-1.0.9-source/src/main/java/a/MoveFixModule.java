package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.Vec2;

public class MoveFixModule extends Module {
   private boolean f462;
   private final BooleanSetting f461;
   private final ModeSetting f460;
   

   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f12) {
         f var2 = (f)var1;
         if (var2.m42() instanceof ClientboundPlayerPositionPacket) {
            this.f462 = true;
         }
      }

      if (var1 == u.f6) {
         this.setSuffix(this.f460.getValue());
         u.f6.m72(true);
         u.f6.m74(this.f461.getValue());
         if (this.f462) {
            this.f462 = false;
            float var30 = f0.player.getYRot();
            float var3 = f0.player.getXRot();
            u.f6.m64(var30);
            u.f6.m70(var3);
         }
      } else if (var1 == u.f9 && this.f460.isMode("Silent")) {
         mixins.ClientInputMixin_rn var31 = (mixins.ClientInputMixin_rn)f0.player.input;
         float var32 = var31.getMoveVector().y;
         float var4 = var31.getMoveVector().x;
         if (var32 == 0.0F && var4 == 0.0F) {
            return;
         }

         float[] corrected = ClientRotationMath.correctMovement(var32, var4, f0.player.getYRot(), u.f6.m63());
         float var19 = corrected[0];
         float var20 = corrected[1];
         Vec2 var33 = new Vec2(var20, var19);

         var31.setMoveVector(var33);
         Input var34 = f0.player.input.keyPresses;
         f0.player.input.keyPresses = new Input(
            (var19 > 0.0F),
            (var19 < 0.0F),
            (var20 > 0.0F),
            (var20 < 0.0F),
            var34.jump(),
            var34.shift(),
            var34.sprint()
         );
      }
   }

   public MoveFixModule() {
      super("MoveFix", Category.f22);
      String var10003 = "Mode";
      String var10005 = "Silent";
      String[] var10006 = new String[2];
      var10006[0] = "Silent";
      var10006[1] = "Strict";
      this.f460 = new ModeSetting(var10003, this, var10005, var10006);
      this.f461 = new BooleanSetting("Use PrevYaw", this, true);
      this.f462 = false;
   }
}
