package a;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.protocol.Packet;

public class xb implements ve {
   private static boolean f961;
   private static final List<Packet<?>> f960 = new ArrayList();
   private static boolean f962;
   

   public static boolean m27() {
      return f961;
   }

   public static boolean m28(Packet var0) {
      if (f961 && !f962) {
         int var10000;
         synchronized (f960) {
            f960.add(var0);
            var10000 = 1;
         }

         return var10000 != 0;
      } else {
         return false;
      }
   }

   private static void pm$130() {
      f962 = true;
      synchronized (f960) {
         for (Packet var2 : f960) {
            ve.f0.getConnection().send(var2);
         }

         f960.clear();
      }

      f962 = false;
   }

   public static void m25() {
      if (!f961) {
         f960.clear();
      }

      f961 = true;
   }

   public static void m26() {
      f961 = false;
      pm$130();
   }
}
