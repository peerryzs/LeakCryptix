package a;
import net.minecraft.world.item.component.SwingAnimation;
import org.lwjgl.sdl.SDLMouse;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.item.Items;
import net.minecraft.world.entity.projectile.hurtingprojectile.SmallFireball;
import net.minecraft.world.entity.projectile.hurtingprojectile.LargeFireball;
import net.minecraft.world.entity.projectile.hurtingprojectile.Fireball;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundPunchPacket;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import java.util.Optional;



import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public class CombatModuleNative extends Module {
   private static final String f293;
   private final BooleanSetting f314;
   private boolean f324;
   private final ModeSetting f308;
   private boolean f325;
   private static final String f299;
   private static final String f284;
   private int f328;
   private final NumberSetting f310;
   private float f334;
   private static final String f298;
   private static final String f294;
   private final NumberSetting f312;
   private final BooleanSetting f315;
   private static final String f306;
   private final NumberSetting f311;
   private final BooleanSetting f317;
   private boolean f323;
   private static final String f302;
   private int f327;
   private static final String f305;
   private final BooleanSetting f318;
   private static final String f289;
   private int f331;
   private boolean f322;
   private static final String f291;
   private static final String f297;
   private static final String f288;
   private float f333;
   private static final String f290;
   private int f321;
   private static final String f286;
   private final NumberSetting f313;
   private static final String f304;
   private static final String f307;
   private final BooleanSetting f320;
   private static final String f300;
   private int f330;
   public boolean f17;
   private final ModeSetting f309;
   private boolean f326;
   private boolean f329;
   public boolean f16;
   private final BooleanSetting f316;
   private static final String f303;
   private static final String f295;
   private static final String f292;
   public Entity f18;
   private static final String f287;
   private static final String f285;
   private static final String f301;
   private float f336 = -1.0F;
   private float f335;
   private static final String f296;
   private final BooleanSetting f319;
   private boolean f332;
   private static final String f283;
   private static final String f282;
   private static int f1;

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private void pm$71() {
      this.f16 = true;
      // Old packet/slot tricks do not represent item use in Minecraft 26.3.
      if (!this.f309.isMode("Fake") && !this.f17 && !f0.player.isUsingItem()) {
         this.pm$77();
      }
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private Vec3 pm$81(float var1, float var2) {
      float var3 = Mth.cos(-var2 * (float) (Math.PI / 180.0) - (float) Math.PI);
      float var4 = Mth.sin(-var2 * (float) (Math.PI / 180.0) - (float) Math.PI);
      float var5 = -Mth.cos(-var1 * (float) (Math.PI / 180.0));
      float var6 = Mth.sin(-var1 * (float) (Math.PI / 180.0));
      return new Vec3(var4 * var5, var6, var3 * var5);
   }

   @Override
   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   public int getEventPriority(r var1) {
      return var1 == u.f6 ? -2 : 0;
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private void pm$77() {
      if (!CombatPacketOrder.canAct() || f0.gameMode.isDestroying()) return;
      // Unsupported swords get the visual pose only, never a fabricated use state.
      if (f0.player.getMainHandItem().getUseAnimation() != net.minecraft.world.item.ItemUseAnimation.BLOCK) {
         return;
      }
      f0.gameMode.useItem(f0.player, InteractionHand.MAIN_HAND);
      this.f17 = f0.player.isUsingItem() && f0.player.getUsedItemHand() == InteractionHand.MAIN_HAND;
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private Entity pm$80(double var1) {
      AABB var3 = f0.player.getBoundingBox().inflate(var1);
      Entity var4 = null;
      double var5 = Double.MAX_VALUE;

      for (Entity var8 : f0.level.getEntities(f0.player, var3)) {
         if ((var8 instanceof Fireball || var8 instanceof SmallFireball || var8 instanceof LargeFireball) && ((Fireball)var8).getOwner() != f0.player) {
            double var9 = this.pm$79(var8, this.f333, this.f334, 10.0);
            if (var9 <= var1 && var9 < var5) {
               var4 = var8;
               var5 = var9;
            }
         }
      }

      return var4;
   }

   @Override
   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   public void onEvent(r var1) {
      if (var1 == u.f16 && f0.gui.screen() == null && this.f18 != null) {
         var1.m9(true);
      }

      if (var1 == u.f6) {
         this.f16 = false;
         if (this.f17 && !f0.player.isUsingItem()) {
            this.f17 = false;
         }
         if (f0.gui.screen() != null) {
            this.pm$85();
            return;
         }

         int var2 = this.f315.getValue() && !(f0.player.getAttackStrengthScale(0.0F) >= 1.0F) ? 0 : 1;
         if (var2 != 0) {
            this.f321 = this.f321 + 1;
         }

         if (this.f320.getValue()) {
            Entity var3 = this.pm$80(3.0);
            if (var3 != null && !f0.player.isUsingItem() && CombatPacketOrder.canAct() && !f0.gameMode.isDestroying()) {
               this.pm$82(var3);
               u.f6.m64(this.f333);
               u.f6.m70(this.f334);
               this.pm$85();
               f0.gameMode.attack(f0.player, var3);
               f0.player.swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, false);
               // Minecraft 26.3 sends the network animation separately from the local swing.
               f0.getConnection().send(ServerboundPunchPacket.INSTANCE);
               this.f18 = var3;
               return;
            }
         }

         double var10 = this.f312.getValue();
         if (!this.f319.getValue()) {
            this.f18 = jb.m52(var10, true);
         } else {
            this.f18 = jb.m51(var10, true);
         }

         if (this.f317.getValue() && !mr.m43()) {
            this.f18 = null;
         }

         if (this.f18 != null) {
            this.pm$82(this.f18);
            u.f6.m64(this.f333);
            u.f6.m70(this.f334);
            boolean var5 = this.pm$86();
            if (this.f17 && (!var5 || this.f309.isMode("Disabled") || this.f309.isMode("Fake")
                  || !f0.player.getMainHandItem().is(ItemTags.SWORDS))) {
               this.pm$78();
               return;
            }
            double var6 = this.f323 ? this.f311.getValue() : this.f310.getValue();
            boolean attackedThisTick = false;
            if (ModuleManager.f30.f19.isEmpty() && this.f321 > var6 && var2 != 0) {
               if (this.f17) {
                  // Release on its own tick; movement then sees the real unblocked state.
                  this.pm$78();
                  return;
               }
               if (f0.player.isUsingItem() || !CombatPacketOrder.canAct() || f0.gameMode.isDestroying()) {
                  return;
               }
               if (this.f316.getValue() && this.f18 instanceof Player var8 && var8.isUsingItem() && var8.getUseItem().is(Items.SHIELD)) {
                  System.out.println("shield");
                  return;
               }

               this.f321 = 0;
               this.pm$76(this.f333, this.f334, false);
               attackedThisTick = true;

               this.f323 = (!this.f323);
            }

            if (!attackedThisTick && !this.f309.isMode("Disabled") && f0.player.getMainHandItem().is(ItemTags.SWORDS)) {
               if (var5) {
                  this.pm$71();
               } else {
                  if (this.f17) {
                     this.pm$78();
                  }

               }
            }
         } else {
            this.pm$85();
         }
      }

   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private void pm$75() {
      if (this.f324) {
         f0.getConnection().send(new ServerboundSetCarriedItemPacket(f0.player.getInventory().getSelectedSlot()));
         this.f324 = false;
      }
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private float pm$83() {
      float var1 = ((Double)f0.options.sensitivity().get()).floatValue();
      if (var1 != this.f336) {
         float var2 = var1 * 0.6F + 0.2F;
         this.f336 = var1;
         this.f335 = var2 * var2 * var2 * 8.0F * 0.15F;
      }

      return this.f335;
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private boolean pm$86() {
      long var1 = f0.getWindow().handle();
      int var3 = (SDLMouse.SDL_GetMouseState(null, null) & 4) != 0 ? 1 : 0;
      return !(this.f318.getValue() && var3 == 0);
   }

   @Override
   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   public void onDisable() {
      this.pm$85();
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private void pm$78() {
      this.f322 = false;
      if (f0.player != null && f0.gameMode != null && f0.player.isUsingItem()) {
         CombatPacketOrder.requestRelease();
      }
      this.f17 = false;
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private boolean pm$72(Entity var1, double var2) {
      Vec3 var4 = var1.getEyePosition(1.0F);
      Vec3 var5 = var1.getViewVector(1.0F).normalize();
      Vec3 var6 = f0.player.getEyePosition(1.0F).subtract(var4).normalize();
      double var7 = var5.dot(var6);
      return (var7 >= Math.cos(Math.toRadians(var2)));
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private float pm$84(float var1, float var2, float var3) {
      float var4 = var1 - var2;
      var4 -= var4 % var3;
      return var2 + var4;
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private double pm$79(Entity var1, float var2, float var3, double var4) {
      Vec3 var6 = f0.player.getEyePosition(1.0F);
      AABB var7 = var1.getBoundingBox();
      if (var7.contains(var6)) {
         return 0.0;
      } else {
         Vec3 var8 = this.pm$81(var3, var2);
         Vec3 var9 = new Vec3(var6.x + var8.x * var4, var6.y + var8.y * var4, var6.z + var8.z * var4);
         Optional var10 = var7.clip(var6, var9);
         return var10.isPresent() ? var6.distanceTo((Vec3)var10.get()) : -0.1;
      }
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private void pm$76(float var1, float var2, boolean var3) {
      if (!ModuleManager.f35.f25 && !f0.player.isUsingItem() && CombatPacketOrder.canAct() && !f0.gameMode.isDestroying()) {
         if (!this.f314.getValue() || !(f0.player.getDeltaMovement().y > 0.0)) {
            double var4 = this.pm$79(this.f18, var1, var2, 10.0);
            if (var4 <= 3.0 && var4 >= 0.0) {
               f0.gameMode.attack(f0.player, this.f18);
               f0.player.swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, false);
               // Keep attack and punch together before any blocking or interaction packets.
               f0.getConnection().send(ServerboundPunchPacket.INSTANCE);
               if (var3) {
                  Vec3 var6 = f0.player.getEyePosition();
                  float var7 = var1 * (float) (Math.PI / 180.0);
                  float var8 = var2 * (float) (Math.PI / 180.0);
                  double var9 = -Math.sin(var7) * Math.cos(var8);
                  double var11 = -Math.sin(var8);
                  double var13 = Math.cos(var7) * Math.cos(var8);
                  Vec3 var15 = new Vec3(var9, var11, var13);
                  Vec3 var16 = var6.add(var15.scale(var4));
                  EntityHitResult var17 = new EntityHitResult(this.f18, var16);
                  Vec3 var18 = var17.getLocation().subtract(this.f18.getX(), this.f18.getY(), this.f18.getZ());
                  f0.getConnection().send(new ServerboundInteractPacket(this.f18.getId(), InteractionHand.MAIN_HAND, var18, f0.player.isShiftKeyDown()));
               }
            }
         }
      }
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private void pm$74(int var1) {
      f0.getConnection().send(new ServerboundSetCarriedItemPacket(var1));
      this.f324 = true;
      if (var1 == f0.player.getInventory().getSelectedSlot()) {
         this.f324 = false;
      }
   }

   public CombatModuleNative() {
      super(f282, Category.f21);
      String var10003 = f283;
      String var10005 = f284;
      String[] var10006 = new String[2 - f1];
      var10006[0 - f1] = f284;
      var10006[1 - f1] = f285;
      this.f308 = new ModeSetting(var10003, this, var10005, var10006);
      var10003 = f286;
      var10005 = f287;
      var10006 = new String[9 - f1];
      var10006[0 - f1] = f287;
      var10006[1 - f1] = f288;
      var10006[2 - f1] = f289;
      var10006[3 - f1] = f290;
      var10006[4 - f1] = f291;
      var10006[5 - f1] = f292;
      var10006[6 - f1] = f293;
      var10006[7 - f1] = f294;
      var10006[8 - f1] = f295;
      this.f309 = new ModeSetting(var10003, this, var10005, var10006);
      this.f310 = new NumberSetting(f296, this, 3.0, 0.0, 10.0, 1.0);
      this.f311 = new NumberSetting(f297, this, 3.0, 0.0, 10.0, 1.0);
      this.f312 = new NumberSetting(f298, this, 5.0, 3.0, 10.0, 0.5);
      this.f313 = new NumberSetting(f299, this, 3.0, 3.0, 10.0, 0.5);
      this.f314 = new BooleanSetting(f300, this, true);
      this.f315 = new BooleanSetting(f301, this, true);
      this.f316 = new BooleanSetting(f302, this, false);
      this.f317 = new BooleanSetting(f303, this, false);
      this.f318 = new BooleanSetting(f304, this, false);
      this.f319 = new BooleanSetting(f305, this, true);
      this.f320 = new BooleanSetting(f306, this, false);
      this.f330 = -1 - f1;
      this.f331 = -1 - f1;
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private void pm$73() {
      this.f330 = -1;
      this.f331 = -1;

      for (int var1 = 0; var1 < 9; var1++) {
         if (f0.player.getInventory().getItem(var1).is(ItemTags.SWORDS)) {
            if (this.f330 != -1) {
               this.f331 = var1;
               break;
            }

            this.f330 = var1;
         }
      }
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private void pm$82(Entity var1) {
      double var2;
      double var4;
      double var6;
      if (this.f308.isMode("Optimal")) {
         AABB var8 = var1.getBoundingBox();
         var2 = Mth.clamp(f0.player.getX(), var8.minX, var8.maxX);
         var4 = Mth.clamp(f0.player.getEyeY(), var8.minY, var8.maxY);
         var6 = Mth.clamp(f0.player.getZ(), var8.minZ, var8.maxZ);
      } else {
         var2 = var1.getX();
         var4 = var1.getEyeY();
         var6 = var1.getZ();
      }

      double var19 = var2 - f0.player.getX();
      double var10 = var4 - f0.player.getEyeY();
      double var12 = var6 - f0.player.getZ();
      double var14 = Math.sqrt(var19 * var19 + var12 * var12);
      float var16 = (float)Math.toDegrees(Math.atan2(var12, var19)) - 90.0F;
      float var17 = (float)(-Math.toDegrees(Math.atan2(var10, var14)));
      float previousYaw = u.f6.m65();
      var16 = ClientRotationMath.continuousYaw(var16, previousYaw);
      float var18 = this.pm$83();
      this.f333 = this.pm$84(var16, previousYaw, var18);
      this.f334 = Mth.clamp(this.pm$84(var17, u.f6.m66(), var18), -90.0F, 90.0F);
   }

   /** adapted from earlier Minecraft 26.2 Cryptix Java code; not recovered from the current DLL. */
   private void pm$85() {
      this.f16 = false;
      this.f322 = false;
      this.f18 = null;
      if (this.f324) {
         this.pm$75();
      }

      if (this.f17) {
         this.pm$78();
      }

      if (this.f329) {
         xb.m26();
         this.f329 = false;
      }

      this.f327 = 0;
      this.f328 = 0;
   }

   // INFERRED defaults from the earlier build; the extra mode/range label is unknown.
   static {
      f282 = "KillAura";
      f283 = "Rotations";
      f284 = "Head";
      f285 = "Optimal";
      f286 = "AutoBlock";
      f287 = "Disabled";
      f288 = "Fake";
      f289 = "Vanilla";
      f290 = "Watchdog";
      f291 = "Watchdog2";
      f292 = "Swap";
      f293 = "Swap2";
      f294 = "Cycle";
      f295 = "Additional";
      f296 = "Attack Delay";
      f297 = "Attack Delay2";
      f298 = "Rotation Range";
      f299 = "Range";
      f300 = "Attack Crits";
      f301 = "Attack Cooldown";
      f302 = "Ignore Shield";
      f303 = "Require Sword";
      f304 = "AutoBlock RMB";
      f305 = "Attack Teammates";
      f306 = "Attack Fireballs";
      f307 = "shield";
      f1 = 0;
   }
}
