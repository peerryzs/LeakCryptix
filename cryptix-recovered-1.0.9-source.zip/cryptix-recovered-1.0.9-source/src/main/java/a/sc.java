package a;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class sc extends kf {
   private final Map<String,Boolean> f172;
   private int f171;
   

   

   public sc(String var1, int var2, int var3) {
      super(var1, var2, var3, null);
      this.f171 = 1;
      this.f172 = new HashMap();
   }

   @Override
   public void m87(GuiGraphicsExtractor var1) {
      int var2 = oo.m30();
      Minecraft var3 = Minecraft.getInstance();
      var1.fill(this.f4, this.f5, this.f4 + 100, this.f5 + 15, var2);
      var1.text(var3.font, this.f3, this.f4 + 4, this.f5 + 3, -1);
      int var4 = this.f5 + 17;
      String[] var5 = ht.m41();
      int var6 = var5.length;

      for (int var7 = 0; var7 < var6; var7++) {
         String var8 = var5[var7];
         var1.fill(this.f4, var4 - 2, this.f4 + 100, var4 + 10, -2146430960);
         var1.text(var3.font, var8, this.f4 + 4, var4, -1426063361);
         var4 += 12;
         if (this.f172.getOrDefault(var8, Boolean.valueOf(false))) {
            var1.fill(this.f4, var4 - 2, this.f4 + 100, var4 + 46, -2145378272);
            var1.text(var3.font, "Load", this.f4 + 4, var4, -11141291);
            var4 += 12;
            var1.text(var3.font, "Save", this.f4 + 4, var4, -171);
            var4 += 12;
            var1.text(var3.font, "Remove", this.f4 + 4, var4, -43691);
            var4 += 12;
            var1.text(var3.font, "Reset", this.f4 + 4, var4, -11162881);
            var4 += 12;
         }
      }

      var1.fill(this.f4, var4 - 2, this.f4 + 100, var4 + 10, -1440590558);
      var1.text(var3.font, "Create Config", this.f4 + 4, var4, -11141291);
      var4 += 12;
      var1.fill(this.f4, var4 - 2, this.f4 + 100, var4 + 10, -1440590558);
      var1.text(var3.font, "Open Folder", this.f4 + 4, var4, -11141291);
   }

   @Override
   public void m90(double var1, double var3, int var5) {
      int var6 = this.f5 + 17;
      String[] var7 = ht.m41();
      String[] var8 = var7;
      int var9 = var7.length;

      for (int var10 = 0; var10 < var9; var10++) {
         String var11 = var8[var10];
         if (var1 >= this.f4 && var1 <= this.f4 + 100 && var3 >= var6 - 2 && var3 <= var6 + 10) {
            if (var5 == 3) {
               this.f172.put(var11, Boolean.valueOf((!this.f172.getOrDefault(var11, Boolean.valueOf(false)))));
            } else if (var5 == 1) {
               ht.m37(var11);
            }

            return;
         }

         var6 += 12;
         if (this.f172.getOrDefault(var11, Boolean.valueOf(false))) {
            if (var1 >= this.f4 && var1 <= this.f4 + 100 && var3 >= var6 - 2 && var3 <= var6 + 10) {
               if (var5 == 1) {
                  ht.m37(var11);
               }

               return;
            }

            var6 += 12;
            if (var1 >= this.f4 && var1 <= this.f4 + 100 && var3 >= var6 - 2 && var3 <= var6 + 10) {
               if (var5 == 1) {
                  ht.m36(var11);
               }

               return;
            }

            var6 += 12;
            if (var1 >= this.f4 && var1 <= this.f4 + 100 && var3 >= var6 - 2 && var3 <= var6 + 10) {
               if (var5 == 1) {
                  ht.m40(var11);
                  this.f172.remove(var11);
               }

               return;
            }

            var6 += 12;
            if (var1 >= this.f4 && var1 <= this.f4 + 100 && var3 >= var6 - 2 && var3 <= var6 + 10) {
               if (var5 == 1) {
                  ht.m35(var11);
               }

               return;
            }

            var6 += 12;
         }
      }

      if (var1 >= this.f4 && var1 <= this.f4 + 100 && var3 >= var6 - 2 && var3 <= var6 + 10) {
         if (var5 == 1) {
            int var10000 = this.f171;
            this.f171 = this.f171 + 1;
            String var18 = "Config" + var10000;
            ht.m36(var18);
         }
      } else {
         var6 += 12;
         if (var1 >= this.f4 && var1 <= this.f4 + 100 && var3 >= var6 - 2 && var3 <= var6 + 10) {
            if (var5 == 1) {
               try {
                  File var17 = ht.m34();
                  if (!var17.exists()) {
                     var17.mkdirs();
                  }

                  String var19 = System.getProperty("os.name").toLowerCase();
                  if (var19.contains("win")) {
                     String[] var10002 = new String[2];
                     var10002[0] = "explorer.exe";
                     var10002[1] = var17.getAbsolutePath();
                     new ProcessBuilder(var10002).start();
                  } else if (var19.contains("mac")) {
                     String[] var20 = new String[2];
                     var20[0] = "open";
                     var20[1] = var17.getAbsolutePath();
                     new ProcessBuilder(var20).start();
                  } else {
                     String[] var21 = new String[2];
                     var21[0] = "xdg-open";
                     var21[1] = var17.getAbsolutePath();
                     new ProcessBuilder(var21).start();
                  }
               } catch (IOException var12) {
                  var12.printStackTrace();
               }
            }
         }
      }
   }
}
