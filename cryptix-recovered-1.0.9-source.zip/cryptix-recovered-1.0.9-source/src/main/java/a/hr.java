package a;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.platform.NativeImage.Format;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.font.GlyphVector;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import org.joml.Matrix3x2f;

public final class hr {
   private final Identifier f1075;
   private static final int f1066 = 32;
   private static final int f1067 = 255;
   private static final int f1068 = 4;
   private static final int f1069 = 16;
   private static final int f1070 = 14;
   private static final int f1071 = 8;
   private final Minecraft f1072 = Minecraft.getInstance();
   private final DynamicTexture f1074;
   private final float f1076;
   private final gs[] f1073;
   

   

   public void m251(GuiGraphicsExtractor var1, String var2, float var3, float var4, int var5) {
      if (var2 != null && !var2.isEmpty()) {
         var1.guiRenderState
            .addGuiElement(
               new it(
                  RenderPipelines.GUI_TEXTURED,
                  TextureSetup.singleTexture(this.f1074.getTextureView(), this.f1074.getSampler()),
                  new Matrix3x2f(var1.pose()),
                  var2,
                  this.f1073,
                  var3,
                  var4,
                  var5,
                  this.f1076,
                  var1.scissorStack.peek()
               )
            );
      }
   }

   public hr(String var1, float var2) {
      this.f1073 = new gs[224];
      this.f1076 = var2;

      try {
         try (InputStream var3 = hr.class.getClassLoader().getResourceAsStream(var1)) {
            if (var3 == null) {
               throw new IllegalArgumentException("Font not found: " + var1);
            }

            Font var4 = Font.createFont(0, var3);
            Font var5 = var4.deriveFont(0, var2 * 4.0F);
            int var6 = (int)Math.ceil(var2 * 4.0F * 1.5F);
            int var7 = var6 * 16;
            int var8 = var6 * 14;
            BufferedImage var9 = new BufferedImage(var7, var8, 2);
            Graphics2D var10 = var9.createGraphics();
            var10.setFont(var5);
            var10.setColor(Color.WHITE);
            var10.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            var10.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
            var10.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            FontMetrics var11 = var10.getFontMetrics();

            for (int var12 = 0; var12 < this.f1073.length; var12++) {
               char var13 = (char)(32 + var12);
               int var14 = var12 % 16 * var6;
               int var15 = var12 / 16 * var6;
               String var16 = String.valueOf(var13);
               GlyphVector var17 = var5.createGlyphVector(var10.getFontRenderContext(), var16);
               float var18 = var17.getGlyphMetrics(0).getAdvanceX() * 0.25F;
               int var19 = var14 + 8;
               int var20 = var15 + 8 + var11.getAscent();
               var10.drawString(var16, var19, var20);
               Rectangle var21 = var17.getPixelBounds(var10.getFontRenderContext(), var19, var20);
               float var22 = (var21.x - var14) * 0.25F;
               float var23 = (var21.y - var15) * 0.25F;
               float var24 = var21.width * 0.25F;
               float var25 = var21.height * 0.25F;
               float var26 = (float)var21.x / var7;
               float var27 = (float)var21.y / var8;
               float var28 = (float)(var21.x + var21.width) / var7;
               float var29 = (float)(var21.y + var21.height) / var8;
               this.f1073[var12] = new gs(var22, var23, var24, var25, var18, var26, var27, var28, var29);
            }

            var10.dispose();
            NativeImage var33 = new NativeImage(Format.RGBA, var7, var8, false);
            int[] var34 = var9.getRGB(0, 0, var7, var8, null, 0, var7);

            for (int var35 = 0; var35 < var8; var35++) {
               for (int var36 = 0; var36 < var7; var36++) {
                  int var37 = var34[var35 * var7 + var36];
                  int var38 = var37 & -16777216
                     | (var37 & ('\uff00' << '\b') - 0) >>> 16
                     | var37 & 65280
                     | (var37 & 255) << 16;
                  var33.setPixel(var36, var35, var38);
               }
            }

            this.f1075 = Identifier.fromNamespaceAndPath("cryptix", "font/" + Integer.toHexString(System.identityHashCode(this)));
            this.f1074 = new DynamicTexture(() -> "Cryptix Font", var33);
            this.f1072.getTextureManager().register(this.f1075, this.f1074);
         }
      } catch (Exception var32) {
         throw new RuntimeException("Failed to load font: " + var1, var32);
      }
   }

   public void m254() {
      this.f1072.getTextureManager().release(this.f1075);
   }

   public float m252(String var1) {
      if (var1 != null && !var1.isEmpty()) {
         float var2 = 0.0F;

         for (int var3 = 0; var3 < var1.length(); var3++) {
            char var4 = var1.charAt(var3);
            if (var4 == 167 && var3 + 1 < var1.length()) {
               var3++;
            } else if (var4 >= 32 && var4 <= 255) {
               gs var5 = this.f1073[var4 - 32];
               if (var5 != null) {
                  var2 += var5.advance();
               }
            }
         }

         return var2;
      } else {
         return 0.0F;
      }
   }

   public float m253() {
      return this.f1076;
   }
}
