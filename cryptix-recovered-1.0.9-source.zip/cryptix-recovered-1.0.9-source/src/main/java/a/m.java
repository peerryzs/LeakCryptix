package a;

import java.util.Collection;
import java.util.List;

public abstract class m {
   public String[] f2;
   public String f0;
   public String f1;
   

   public abstract void m0(String[] var1, String var2);

   public Collection m1(String[] var1) {
      return List.of();
   }

   public m(String var1, String var2, String[] var3) {
      this.f0 = var1;
      this.f1 = var2;
      this.f2 = var3;
   }
}
