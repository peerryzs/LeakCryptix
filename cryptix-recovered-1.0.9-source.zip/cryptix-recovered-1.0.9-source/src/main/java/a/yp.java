package a;

import com.mojang.blaze3d.platform.Window;
import java.nio.charset.StandardCharsets;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.Mth;

public class yp implements ve {
   private static int f709;
   private static String f707;
   private static int f710;
   private static int f706;
   private static int f705;
   private static int f708 = -1;
   private static int f704;
   

   public static void m23() {
      boolean var0 = ModuleManager.f31.isEnabled();
      float var1 = var0 ? 255.0F : 0.0F;
      f705 = f704;
      f704 = (int)Mth.lerp(0.5F, f704, var1);
      if (var0) {
         Window var2 = ve.f0.getWindow();
         f709 = (var2.getGuiScaledWidth() >> 1) + 5;
         f710 = (var2.getGuiScaledHeight() >> 1) + 5;
         int var3 = mr.m45();
         if (var3 != f706) {
            f706 = var3;
            f707 = var3 + " §fBlocks";
            if (f706 <= 10) {
               f708 = -43691;
            } else if (f706 <= 20) {
               f708 = -22016;
            } else if (f706 <= 30) {
               f708 = -171;
            } else {
               f708 = -1;
            }
         }
      }
   }

   public static void m24(float var0) {
      int var1 = (int)(f705 + (f704 - f705) * var0);
      if (var1 > 0 && ModuleManager.f31.f31.getValue()) {
         GuiGraphicsExtractor var2 = u.f8.m76();
         int var3 = f708 & 16777215 | var1 << 24;
         bt.m70(var2, f707, f709, f710, var3);
      }
   }

   static {
      f707 = "0 \u00a7fBlocks";
   }
}
