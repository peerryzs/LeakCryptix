package a;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;

public class BedPlatesModule extends Module {
   private final List<aa> f756;
   private MutableBlockPos f755;
   private NumberSetting f754;
   

   public BedPlatesModule() {
      super("BedPlates", Category.f24);
      this.f754 = new NumberSetting("Range", this, 16.0, 8.0, 32.0, 1.0);
      this.f755 = new MutableBlockPos();
      this.f756 = new ArrayList();
   }

   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         this.f756.clear();
         BlockPos var2 = f0.player.blockPosition();
         int var3 = var2.getX();
         int var4 = var2.getY();
         int var5 = var2.getZ();
         int var6 = (int)this.f754.getValue();
         int var7 = var6 * var6;

         for (int var8 = -var6; var8 <= var6; var8++) {
            if (var8 * var8 <= var7) {
               int var9 = var3 + var8;

               for (int var10 = -var6; var10 <= var6; var10++) {
                  if (var8 * var8 + var10 * var10 <= var7) {
                     int var11 = var5 + var10;

                     for (int var12 = -4; var12 <= 4; var12++) {
                        int var13 = var4 + var12;
                        this.f755.set(var9, var13, var11);
                        BlockState var14 = f0.level.getBlockState(this.f755);
                        if (var14.getBlock() instanceof BedBlock && var14.getValue(BedBlock.PART) == BedPart.FOOT) {
                           this.f755.set(var9, var13 + 1, var11);
                           BlockState var15 = f0.level.getBlockState(this.f755);
                           if (!var15.isAir()) {
                              ItemStack var16 = new ItemStack(var15.getBlock().asItem());
                              if (!var16.isEmpty()) {
                                 this.f756.add(new aa(var9, var13, var11, var16));
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      if (var1 == u.f8) {
         j var17 = (j)var1;
         fd var18 = new fd();

         for (aa var20 : this.f756) {
            fd var21 = th.m62(var20.x() + 0.5, var20.y() + 1.5, var20.z() + 0.5, var18);
            if (var21 != null) {
               int var22 = (int)var21.f53;
               int var23 = (int)var21.f54;
               int var24 = 10;
               var17.m76().fill(var22 - var24, var23 - var24, var22 + var24, var23 + var24, -2147483648);
               var17.m76().item(var20.stack(), var22 - var24 + 2, var23 - var24 + 2);
            }
         }
      }
   }
}
