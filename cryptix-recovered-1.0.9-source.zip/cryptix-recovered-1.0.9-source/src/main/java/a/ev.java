package a;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.sdl.SDLMouse;

public class ev extends Screen {
   private List<kf> f155 = new ArrayList();
   private int f157;
   private int f158;
   private kf f156;
   

   public void extractRenderState(GuiGraphicsExtractor var1, int var2, int var3, float var4) {
      super.extractRenderState(var1, var2, var3, var4);
      if (this.f156 != null) {
         int var5 = SDLMouse.SDL_GetMouseState(null, null);
         if ((var5 & SDLMouse.SDL_BUTTON_LMASK) != 0) {
            this.f156.f4 = var2 - this.f157;
            this.f156.f5 = var3 - this.f158;
         } else {
            this.f156 = null;
         }
      }

      for (kf var6 : this.f155) {
         var6.m87(var1);
      }
   }

   public boolean mouseClicked(MouseButtonEvent var1, boolean var2) {
      double var3 = var1.x();
      double var5 = var1.y();
      int var7 = var1.button();
      int var8 = SDLMouse.SDL_GetMouseState(null, null);
      if ((var8 & SDLMouse.SDL_BUTTON_LMASK) != 0) {
         for (kf var10 : this.f155) {
            if (var10.m88(var3, var5)) {
               this.startDrag(var10, var3, var5);
            }
         }
      }

      for (kf var12 : this.f155) {
         var12.m90(var3, var5, var7);
      }

      return super.mouseClicked(var1, var2);
   }

   private void startDrag(kf var1, double var2, double var4) {
      this.f156 = var1;
      this.f157 = (int)var2 - var1.f4;
      this.f158 = (int)var4 - var1.f5;
   }

   public boolean keyPressed(KeyEvent var1) {
      for (kf var3 : this.f155) {
         int var4 = 0;

         for (qu var6 : var3.m94()) {
            if (var6.f13) {
               var4 = 1;
            }
         }

         var3.m91(var1.key());
         if (var4 != 0) {
            return false;
         }
      }

      return super.keyPressed(var1);
   }

   public boolean mouseDragged(MouseButtonEvent var1, double var2, double var4) {
      double var6 = var1.x();
      double var8 = var1.y();

      for (kf var11 : this.f155) {
         var11.m92(var6, var8);
      }

      if (this.f156 != null) {
         this.f156.f4 = (int)var6 - this.f157;
         this.f156.f5 = (int)var8 - this.f158;
      }

      return super.mouseDragged(var1, var2, var4);
   }

   public boolean mouseReleased(MouseButtonEvent var1) {
      if (var1.button() == 1) {
         this.f156 = null;

         for (kf var3 : this.f155) {
            var3.m93();
         }
      }

      return super.mouseReleased(var1);
   }

   public ev() {
      super(Component.literal("ClickGUI"));
      this.f155.add(new kf("Combat", 50, 50, ModuleManager.getModulesByCategory(Category.f21)));
      this.f155.add(new kf("Movement", 160, 50, ModuleManager.getModulesByCategory(Category.f22)));
      this.f155.add(new kf("Player", 270, 50, ModuleManager.getModulesByCategory(Category.f23)));
      this.f155.add(new kf("Visual", 380, 50, ModuleManager.getModulesByCategory(Category.f24)));
      this.f155.add(new kf("Misc", 490, 50, ModuleManager.getModulesByCategory(Category.f25)));
      this.f155.add(new sc("Configs", 600, 50));
      this.f155.add(new ho("Scripts", 710, 50));
   }

   
}
