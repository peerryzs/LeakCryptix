package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;

public class StasisModule extends Module {
   private final BooleanSetting f505;
   private float f508;
   private final NumberSetting f504;
   private float f507;
   private int f506;
   

   @Override
   public void onEnable() {
      this.f506 = 0;
      this.f507 = f0.player.getYRot();
      this.f508 = f0.player.getXRot();
   }

   

   @Override
   public int getEventPriority(r var1) {
      return var1 == u.f6 ? 1 : 0;
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         this.f506 = this.f506 + 1;
         if (this.f506 >= this.f504.getValue()) {
            this.f506 = 0;
            return;
         }

         var1.m9(true);
         u.f4.m49(f0.player.getX(), f0.player.getY(), f0.player.getZ(), f0.player.horizontalCollision, f0.player.onGround());
         u.f4.m10();
         float var2 = u.f6.m63();
         float var3 = u.f6.m69();
         int var4 = var2 != this.f507 ? 1 : 0;
         int var5 = var3 != this.f508 ? 1 : 0;
         int var6 = var5 == 0 && var4 == 0 ? 0 : 1;
         if (this.f505.getValue()) {
            if (var6 != 0) {
               f0.getConnection().send(new Rot(var2, var3, f0.player.onGround(), f0.player.horizontalCollision));
            }

            f0.player.yBodyRot = var2;
            f0.player.yBodyRotO = this.f507;
            mixins.LocalPlayerMixin_bl var7 = (mixins.LocalPlayerMixin_bl)f0.player;
            var7.setXRotLast(var3);
            var7.setYRotLast(var2);
            f0.player.yHeadRot = var2;
            f0.player.yHeadRotO = this.f507;
         }

         this.f507 = var2;
         this.f508 = var3;
      }
   }

   public StasisModule() {
      super("Stasis", Category.f22);
      this.f504 = new NumberSetting("Delay", this, 15.0, 10.0, 50.0, 1.0);
      this.f505 = new BooleanSetting("Rotate", this, false);
   }
}
