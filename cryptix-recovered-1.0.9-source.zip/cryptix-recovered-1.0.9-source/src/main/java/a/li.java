package a;
import net.minecraft.world.entity.EquipmentSlot;
/** Synthetic enum-switch helper implemented in Java directly from the original bytecode. */
class li {
    static final int[] $SwitchMap$net$minecraft$world$entity$EquipmentSlot = new int[EquipmentSlot.values().length];
    static {
        try { $SwitchMap$net$minecraft$world$entity$EquipmentSlot[EquipmentSlot.HEAD.ordinal()] = 1; } catch (NoSuchFieldError ignored) {}
        try { $SwitchMap$net$minecraft$world$entity$EquipmentSlot[EquipmentSlot.CHEST.ordinal()] = 2; } catch (NoSuchFieldError ignored) {}
        try { $SwitchMap$net$minecraft$world$entity$EquipmentSlot[EquipmentSlot.LEGS.ordinal()] = 3; } catch (NoSuchFieldError ignored) {}
        try { $SwitchMap$net$minecraft$world$entity$EquipmentSlot[EquipmentSlot.FEET.ordinal()] = 4; } catch (NoSuchFieldError ignored) {}
    }
}
