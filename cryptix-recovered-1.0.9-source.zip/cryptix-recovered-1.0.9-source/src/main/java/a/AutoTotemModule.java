package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Items;

public class AutoTotemModule extends Module {
   private boolean f535;
   private int f534;
   

   

   private int pm$98() {
      for (int var1 = 0; var1 < 36; var1++) {
         if (f0.player.getInventory().getItem(var1).is(Items.TOTEM_OF_UNDYING)) {
            return var1;
         }
      }

      return -1;
   }

   public AutoTotemModule() {
      super("AutoTotem", Category.f23);
   }

   @Override
   public void onEnable() {
      this.f535 = false;
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         if (f0.player != null && f0.gameMode != null) {
            if (f0.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
               this.f535 = false;
            } else {
               int var2 = this.pm$98();
               if (var2 != -1) {
                  if (!this.f535) {
                     f0.player.sendOpenInventory();
                     f0.gui.setScreen(new InventoryScreen(f0.player));
                     this.f535 = true;
                  } else if (f0.gui.screen() instanceof InventoryScreen) {
                     int var3 = var2 < 9 ? var2 + 36 : var2;
                     int var4 = f0.player.inventoryMenu.containerId;
                     if (this.f534 == 1) {
                        this.f534 = 0;
                        f0.gameMode.handleContainerInput(var4, 45, 0, ContainerInput.PICKUP, f0.player);
                        f0.gui.setScreen(null);
                        f0.player.closeContainer();
                        this.f535 = false;
                     }

                     f0.gameMode.handleContainerInput(var4, var3, 0, ContainerInput.PICKUP, f0.player);
                     this.f534 = 1;
                  }
               }
            }
         }
      }
   }
}
