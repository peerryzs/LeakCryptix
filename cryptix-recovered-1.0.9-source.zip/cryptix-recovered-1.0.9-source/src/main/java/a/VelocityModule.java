package a;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ClientboundStartConfigurationPacket;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundPunchPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class VelocityModule extends Module {
   private final NumberSetting f378;
   private final BooleanSetting f381;
   private final ModeSetting f375;
   private int f382;
   public final List<Packet<?>> f19;
   private boolean f385;
   private final NumberSetting f374;
   private final BooleanSetting f376;
   private final NumberSetting f371;
   private final BooleanSetting f380;
   private final NumberSetting f373;
   private int f386;
   private boolean f384;
   private final NumberSetting f372;
   private final NumberSetting f379;
   private final BooleanSetting f377;
   private int f383;
   

   public VelocityModule() {
      super("Velocity", Category.f21);
      this.f371 = new NumberSetting("Horizontal", this, 100.0, 0.0, 100.0, 5.0);
      this.f372 = new NumberSetting("Vertical", this, 100.0, 0.0, 100.0, 5.0);
      this.f373 = new NumberSetting("Reduce Motion", this, 1.0, 0.0, 1.0, 0.1);
      this.f374 = new NumberSetting("Reduce Ticks", this, 0.0, 0.0, 5.0, 1.0);
      String var10003 = "Reduce";
      String var10005 = "Disabled";
      String[] var10006 = new String[3];
      var10006[0] = "Disabled";
      var10006[1] = "Normal";
      var10006[2] = "AirPush";
      this.f375 = new ModeSetting(var10003, this, var10005, var10006);
      this.f376 = new BooleanSetting("Jump Reset", this, false);
      this.f377 = new BooleanSetting("Delay", this, false);
      this.f378 = new NumberSetting("Delay Ticks", this, 4.0, 1.0, 15.0, 1.0);
      this.f379 = new NumberSetting("Delay Range", this, 3.0, 1.0, 4.0, 0.5);
      this.f380 = new BooleanSetting("Delay Until Ground", this, false);
      this.f381 = new BooleanSetting("Reverse", this, false);
      this.f19 = new ArrayList();
      this.f382 = -1;
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f9) {
         if (f0.player.onGround() && f0.player.hurtTime == 9) {
            f0.player.input.makeJump();
            this.f384 = false;
         }
      } else if (var1 == u.f6) {
         if (!this.f375.isMode("Disabled")) {
            this.setSuffix(this.f375.getValue());
         } else {
            this.setSuffix((int)this.f371.getValue() + "% " + (int)this.f372.getValue() + "%");
         }

         if (!this.f19.isEmpty()) {
            this.f383 = this.f383 + 1;
            if (this.f383 > this.f378.getValue() || this.f380.getValue() && f0.player.onGround()) {
               this.pm$89();
            }
         }

         if (this.f382 >= 0 && this.f382 < this.f374.getValue() && f0.gui.screen() == null) {
            this.f382 = this.f382 + 1;
            Vec3 var2 = f0.player.getDeltaMovement();
            double var3 = this.f373.getValue();
            if (this.f375.isMode("Normal")) {
               LivingEntity var5 = jb.m51(3.0, false);
               if (var5 != null && var5 instanceof Player && this.f386 != f0.player.tickCount && this.f19.isEmpty() && var5.isAlive()) {
                  Vec3 var6 = f0.player.getEyePosition();
                  Vec3 var7 = var5.getEyePosition();
                  double var8 = var7.x - var6.x;
                  double var10 = var7.y - var6.y;
                  double var12 = var7.z - var6.z;
                  double var14 = Math.sqrt(var8 * var8 + var12 * var12);
                  float var16 = (float)(Math.toDegrees(Math.atan2(var12, var8)) - 90.0);
                  float var17 = (float)(-Math.toDegrees(Math.atan2(var10, var14)));
                  u.f6.m64(var16);
                  u.f6.m70(var17);
                  this.pm$87(var5);
               }
            } else if (this.f375.isMode("AirPush")) {
               LivingEntity var23 = jb.m53(false);
               if (var23 != null && this.f382 < 3) {
                  this.pm$87(var23);
               } else {
                  var23 = jb.m51(3.0, false);
                  if (var23 instanceof Player && this.f386 != f0.player.tickCount && this.f19.isEmpty() && var23.isAlive()) {
                     Vec3 var26 = f0.player.getEyePosition();
                     Vec3 var27 = var23.getEyePosition();
                     double var29 = var27.x - var26.x;
                     double var30 = var27.y - var26.y;
                     double var31 = var27.z - var26.z;
                     double var32 = Math.sqrt(var29 * var29 + var31 * var31);
                     float var33 = (float)(Math.toDegrees(Math.atan2(var31, var29)) - 90.0);
                     float var34 = (float)(-Math.toDegrees(Math.atan2(var30, var32)));
                     u.f6.m64(var33);
                     u.f6.m70(var34);
                     this.pm$87(var23);
                  }
               }
            } else {
               f0.player.setDeltaMovement(var2.x * var3, var2.y, var2.z * var3);
            }
         }
      } else if (var1 == u.f11) {
         if (u.f11.m45() instanceof ServerboundAttackPacket) {
            this.f386 = f0.player.tickCount;
         }

         if (u.f11.m45() instanceof ServerboundPlayerActionPacket && this.f385) {
            var1.m9(true);
         }
      } else if (var1 == u.f12) {
         Packet var20 = u.f12.m42();
         if (var20 instanceof ClientboundSetEntityMotionPacket var21) {
            if (f0.player == null) {
               return;
            }

            if (var21.id() == f0.player.getId()) {
               Vec3 var4 = var21.movement();
               if (var4.y > 0.0 && !ModuleManager.f37.isEnabled()) {
                  double var25 = this.f381.getValue() ? -this.f371.getValue() * 0.01 : this.f371.getValue() * 0.01;
                  double var28 = var4.x * var25;
                  double var9 = var4.y * (this.f372.getValue() * 0.01);
                  double var11 = var4.z * var25;
                  if (this.f371.getValue() != 100.0 || this.f381.getValue()) {
                     var1.m9(true);
                  }

                  if (this.f374.getValue() != 0.0) {
                     this.f382 = 0;
                  }

                  if (this.f377.getValue() && this.pm$88()) {
                     this.f19.add(var21);
                     var1.m9(true);
                  } else {
                     if (this.f371.getValue() != 100.0 || this.f381.getValue()) {
                        if (this.f371.getValue() == 0.0) {
                           var28 = f0.player.getDeltaMovement().x;
                           var11 = f0.player.getDeltaMovement().z;
                        }

                        if (this.f372.getValue() == 0.0) {
                           var9 = f0.player.getDeltaMovement().y;
                        }

                        f0.player.setDeltaMovement(new Vec3(var28, var9, var11));
                     }

                     if (this.f376.getValue() && f0.player.onGround() && f0.player.isSprinting()) {
                        this.f384 = true;
                     }
                  }
               }
            }
         } else if (this.f377.getValue() && !this.f19.isEmpty()) {
            if (var20 instanceof ClientboundStartConfigurationPacket || var20 instanceof ClientboundDisconnectPacket) {
               this.pm$89();
               return;
            }

            synchronized (this.f19) {
               this.f19.add(var20);
               var1.m9(true);
            }
         }
      }
   }

   private boolean pm$88() {
      LivingEntity var1 = jb.m51(6.0, false);
      LivingEntity var2 = jb.m53(false);
      return (f0.player.onGround() && this.f380.getValue()
            || var1 != null && !(f0.player.distanceTo(var1) > this.f379.getValue())
            || this.f375.isMode("AirPush") && (f0.player.isSprinting() || var2 != null && f0.player.distanceTo(var2) > 11.0F)
         ? false : true);
   }

   private void pm$89() {
      if (!this.f19.isEmpty()) {
         synchronized (this.f19) {
            for (Packet var3 : this.f19) {
               f0.execute(() -> var3.handle(f0.getConnection()));
            }

            this.f19.clear();
         }

         this.f383 = 0;
      }
   }

   private void pm$87(Entity var1) {
      if (!ModuleManager.f35.isEnabled() || !ModuleManager.f35.f25) {
         this.f385 = true;
         f0.gameMode.attack(f0.player, var1);
         f0.getConnection().send(ServerboundPunchPacket.INSTANCE);
         this.f385 = false;
      }
   }

   
}
