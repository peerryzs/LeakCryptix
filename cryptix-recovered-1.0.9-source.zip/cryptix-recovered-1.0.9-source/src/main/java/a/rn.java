package a;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import org.jspecify.annotations.Nullable;
import org.joml.Matrix3x2fc;

public record rn(
   RenderPipeline pipeline,
   TextureSetup textureSetup,
   Matrix3x2fc pose,
   int x0,
   int y0,
   int x1,
   int y1,
   int radius,
   float u0,
   float v0,
   float u1,
   float v1,
   int color,
   @Nullable ScreenRectangle scissorArea,
   @Nullable ScreenRectangle bounds
) implements GuiElementRenderState {



   

   @Nullable
   public ScreenRectangle bounds() {
      return this.bounds;
   }

   public TextureSetup textureSetup() {
      return this.textureSetup;
   }

   public int y1() {
      return this.y1;
   }

   public int y0() {
      return this.y0;
   }

   public Matrix3x2fc pose() {
      return this.pose;
   }

   public rn(
      RenderPipeline var1,
      TextureSetup var2,
      Matrix3x2fc var3,
      int var4,
      int var5,
      int var6,
      int var7,
      int var8,
      float var9,
      float var10,
      float var11,
      float var12,
      int var13,
      @Nullable ScreenRectangle var14
   ) {
      this(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, pm$139(var4, var5, var6, var7, var3, var14));
   }

   public int radius() {
      return this.radius;
   }

   public int color() {
      return this.color;
   }

   public int x0() {
      return this.x0;
   }

   public int x1() {
      return this.x1;
   }

   public rn(
      RenderPipeline pipeline,
      TextureSetup textureSetup,
      Matrix3x2fc pose,
      int x0,
      int y0,
      int x1,
      int y1,
      int radius,
      float u0,
      float v0,
      float u1,
      float v1,
      int color,
      @Nullable ScreenRectangle scissorArea,
      @Nullable ScreenRectangle bounds
   ) {
      this.pipeline = pipeline;
      this.textureSetup = textureSetup;
      this.pose = pose;
      this.x0 = x0;
      this.y0 = y0;
      this.x1 = x1;
      this.y1 = y1;
      this.radius = radius;
      this.u0 = u0;
      this.v0 = v0;
      this.u1 = u1;
      this.v1 = v1;
      this.color = color;
      this.scissorArea = scissorArea;
      this.bounds = bounds;
   }

   public float v1() {
      return this.v1;
   }

   public float v0() {
      return this.v0;
   }

   public float u0() {
      return this.u0;
   }

   @Nullable
   public ScreenRectangle scissorArea() {
      return this.scissorArea;
   }

   public RenderPipeline pipeline() {
      return this.pipeline;
   }

   public float u1() {
      return this.u1;
   }

   public void buildVertices(VertexConsumer var1) {
      int var2 = this.x0();
      int var3 = this.y0();
      int var4 = this.x1();
      int var5 = this.y1();
      int var6 = var4 - var2;
      int var7 = var5 - var3;
      float var8 = Math.min((float)this.radius(), Math.min(var6, var7) * 0.5F);
      float var9 = var8 * var8;
      float var10 = this.u0();
      float var11 = this.v0();
      float var12 = (this.u1() - var10) / var6;
      float var13 = (this.v1() - var11) / var7;
      int var14 = this.color();
      Matrix3x2fc var15 = this.pose();

      for (float var16 = 0.0F; var16 < var7; var16 += 0.5F) {
         float var17 = var16 + 0.25F;
         float var18 = 0.0F;
         if (var17 < var8) {
            float var19 = var8 - var17;
            var18 = var8 - (float)Math.sqrt(var9 - var19 * var19);
         } else if (var17 >= var7 - var8) {
            float var27 = var17 - (var7 - var8);
            var18 = var8 - (float)Math.sqrt(var9 - var27 * var27);
         }

         float var28 = var2 + var18;
         float var20 = var4 - var18;
         float var21 = var10 + var18 * var12;
         float var22 = var10 + (var6 - var18) * var12;
         float var23 = var3 + var16;
         float var24 = var23 + 0.5F;
         float var25 = var11 + var16 * var13;
         float var26 = var25 + 0.5F * var13;
         var1.addVertexWith2DPose(var15, var28, var23).setUv(var21, var25).setColor(var14);
         var1.addVertexWith2DPose(var15, var28, var24).setUv(var21, var26).setColor(var14);
         var1.addVertexWith2DPose(var15, var20, var24).setUv(var22, var26).setColor(var14);
         var1.addVertexWith2DPose(var15, var20, var23).setUv(var22, var25).setColor(var14);
      }
   }

   @Nullable
   private static ScreenRectangle pm$139(int var0, int var1, int var2, int var3, Matrix3x2fc var4, @Nullable ScreenRectangle var5) {
      ScreenRectangle var6 = new ScreenRectangle(var0, var1, var2 - var0, var3 - var1).transformMaxBounds(var4);
      return var5 != null ? var5.intersection(var6) : var6;
   }
}
