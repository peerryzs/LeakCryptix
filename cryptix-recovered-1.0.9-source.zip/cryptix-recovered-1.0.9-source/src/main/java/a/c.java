package a;

import com.cryptix.script.ScriptManager;
import net.minecraft.client.Minecraft;

public class c extends r {
   

   public c m48() {
      ScriptManager.onInput(Minecraft.getInstance().player.input);
      return this;
   }
}
