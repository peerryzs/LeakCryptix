package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class bt implements ve {
   private static boolean f1091;
   public static String f46;
   public static String f47;
   

   public static void m69(String var0) {
      f1091 = false;
      f47 = f46;
      int var2 = -1;
      if (var0.hashCode() == 63529059) {
         if (var0.equals("Arial")) {
            var2 = 0;
         }
      }

      switch (var2) {
         case 0:
            f1091 = true;
      }

      f46 = var0;
      if (!f46.equals(f47)) {
         for (Module var4 : ModuleManager.getModules()) {
            var4.setDisplayWidth(m71(var4.getDisplayName()));
         }

         ModuleManager.sortModulesByWidth();
      }
   }

   public static int m71(String var0) {
      return f1091 ? (int)bl.f44.m252(var0) : ve.f0.font.width(var0);
   }

   public static void m70(GuiGraphicsExtractor var0, String var1, int var2, int var3, int var4) {
      if (f1091) {
         bl.f44.m251(var0, var1, var2, var3, var4);
      } else {
         var0.text(ve.f0.font, var1, var2, var3, var4);
      }
   }

   
}
