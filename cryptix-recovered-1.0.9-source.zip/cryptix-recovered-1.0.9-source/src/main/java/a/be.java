package a;

import net.minecraft.core.Direction;

class be {
   public int f27;
   public int f29;
   public int f28;
   public Direction f30;
   

   public void m199(int var1, int var2, int var3, Direction var4) {
      this.f27 = var1;
      this.f28 = var2;
      this.f29 = var3;
      this.f30 = var4;
   }

   be() {
   }
}
