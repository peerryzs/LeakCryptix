package a;

import java.nio.charset.StandardCharsets;

public class KeepSprintModule extends Module {
   private NumberSetting f437;
   

   public double m165() {
      return !this.isEnabled() ? 0.6 : this.f437.getValue();
   }

   public KeepSprintModule() {
      super("KeepSprint", Category.f22);
      this.f437 = new NumberSetting("Speed", this, 0.6, 0.6, 1.0, 0.05);
   }

   
}
