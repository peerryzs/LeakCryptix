package a;

public final class ClientRotationMath {
   private ClientRotationMath() {}

   public static float continuousYaw(float target, float previous) {
      double delta = (double)target - previous;
      delta = ((delta + 180.0) % 360.0 + 360.0) % 360.0 - 180.0;
      return previous + (float)delta;
   }

   public static double angularDistance(double first, double second) {
      double delta = ((first - second + 180.0) % 360.0 + 360.0) % 360.0 - 180.0;
      return Math.abs(delta);
   }

   public static float[] correctMovement(float forward, float strafe, float cameraYaw, float movementYaw) {
      if (forward == 0.0F && strafe == 0.0F) return new float[]{0.0F, 0.0F};
      double desired = cameraYaw + Math.toDegrees(Math.atan2(-strafe, forward));
      double best = Double.POSITIVE_INFINITY;
      float bestForward = 0.0F, bestStrafe = 0.0F;
      for (int candidateForward = -1; candidateForward <= 1; candidateForward++) {
         for (int candidateStrafe = -1; candidateStrafe <= 1; candidateStrafe++) {
            if (candidateForward == 0 && candidateStrafe == 0) continue;
            double heading = movementYaw + Math.toDegrees(Math.atan2(-candidateStrafe, candidateForward));
            double distance = angularDistance(desired, heading);
            if (distance < best) {
               best = distance;
               bestForward = candidateForward;
               bestStrafe = candidateStrafe;
            }
         }
      }
      float length = (float)Math.sqrt(bestForward * bestForward + bestStrafe * bestStrafe);
      float magnitude = Math.min(1.0F, (float)Math.sqrt(forward * forward + strafe * strafe));
      return new float[]{bestForward / length * magnitude, bestStrafe / length * magnitude};
   }
}
