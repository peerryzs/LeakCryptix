package a;

import java.nio.charset.StandardCharsets;

public class ScoreboardModule extends Module {
   public final NumberSetting f46;
   public final NumberSetting f47;
   

   public ScoreboardModule() {
      super("Scoreboard", Category.f24);
      this.f46 = new NumberSetting("X", this, 0.0, 0.0, 1000.0, 1.0);
      this.f47 = new NumberSetting("Y", this, 0.0, -500.0, 500.0, 1.0);
   }

   
}
