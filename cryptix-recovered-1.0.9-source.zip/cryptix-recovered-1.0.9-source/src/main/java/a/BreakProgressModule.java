package a;

import java.nio.charset.StandardCharsets;
import mixins.MultiPlayerGameModeMixin_sg;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;

public class BreakProgressModule extends Module {
   private String f765;
   private BlockPos f770;
   private BlockPos f769;
   private final BooleanSetting f762;
   private float f767;
   private final fd f763;
   private int f766;
   private final BooleanSetting f761;
   private int f764;
   private float f768;
   

   public BreakProgressModule() {
      super("BreakProgress", Category.f24);
      this.f761 = new BooleanSetting("BedAura Only", this, false);
      this.f762 = new BooleanSetting("Fade", this, true);
      this.f763 = new fd();
      this.f764 = -1;
      this.f765 = "0%";
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         int var2 = this.f769 != null ? 255 : 0;
         this.f768 = this.f767;
         this.f767 = Mth.lerp(0.5F, this.f767, var2);
         if (!this.f762.getValue()) {
            this.f767 = var2;
            this.f768 = this.f767;
         }

         if (this.f769 != null) {
            this.f770 = this.f769;
         }
      }

      if (var1 == u.f8) {
         j var14 = u.f8;
         GuiGraphicsExtractor var3 = var14.m76();
         MultiPlayerGameModeMixin_sg var4 = (MultiPlayerGameModeMixin_sg)f0.gameMode;
         BedAuraModule var5 = ModuleManager.f35;
         BlockPos var6 = var5.f24;
         if (var6 != null) {
            this.f769 = var6;
         } else {
            if (this.f761.getValue()) {
               return;
            }

            this.f769 = var4.isDestroying() ? var4.getDestroyBlockPos() : null;
         }

         float var7 = var14.m77().getGameTimeDeltaPartialTick(false);
         float var8 = Mth.lerp(var7, this.f768, this.f767);
         BlockPos var9 = this.f769;
         if (var9 == null) {
            if (var8 < 5.0F) {
               return;
            }

            var9 = this.f770;
         }

         float var10 = var4.getDestroyProgress();
         if (var9 == var6 && var6 != null) {
            var10 = var5.f23;
            var10 = Mth.clamp(var10, 0.0F, 1.0F);
         }

         if (var10 != 0.0F || !(var8 < 5.0F)) {
            fd var11 = th.m62(var9.getX() + 0.5, var9.getY() + 0.5, var9.getZ() + 0.5, this.f763);
            if (var11 != null) {
               int var12 = (int)(var10 * 100.0F);
               if (var12 != this.f764) {
                  this.f764 = var12;
                  this.f765 = var12 + "%";
                  this.f766 = bt.m71(this.f765) >> 1;
               }

               int var13 = (int)var8 << 24 | 16777215;
               bt.m70(var3, this.f765, (int)var11.f53 - this.f766, (int)var11.f54, var13);
            }
         }
      }
   }

   
}
