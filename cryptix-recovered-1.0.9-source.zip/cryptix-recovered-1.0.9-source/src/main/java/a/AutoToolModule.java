package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public class AutoToolModule extends Module {
   private int f532;
   private final BooleanSetting f531;
   

   public AutoToolModule() {
      super("AutoTool", Category.f23);
      this.f531 = new BooleanSetting("Swap Back", this, true);
      this.f532 = -1;
   }

   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         if (!f0.gameMode.isDestroying()) {
            if (this.f531.getValue() && this.f532 != -1) {
               f0.player.getInventory().setSelectedSlot(this.f532);
               this.f532 = -1;
            }

            return;
         }

         if (!(f0.hitResult instanceof BlockHitResult var2)) {
            return;
         }

         BlockPos var10 = var2.getBlockPos();
         BlockState var4 = f0.level.getBlockState(var10);
         if (var4.isAir()) {
            return;
         }

         int var5 = -1;
         float var6 = 1.0F;

         for (int var7 = 0; var7 < 9; var7++) {
            ItemStack var8 = f0.player.getInventory().getItem(var7);
            if (!var8.isEmpty()) {
               float var9 = var8.getDestroySpeed(var4);
               if (var9 > var6) {
                  var6 = var9;
                  var5 = var7;
               }
            }
         }

         if (var5 != -1 && var5 != f0.player.getInventory().getSelectedSlot()) {
            if (this.f532 == -1) {
               this.f532 = f0.player.getInventory().getSelectedSlot();
            }

            f0.player.getInventory().setSelectedSlot(var5);
         }
      }
   }
}
