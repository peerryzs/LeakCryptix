package a;

import java.nio.charset.StandardCharsets;

public enum Category {
   f25,
   f22,
   f21,
   f24,
   f23;

   // $VF: synthetic field
   private static final Category[] f236 = values();
   

   public static Category[] m14() {
      return (Category[])f236.clone();
   }

   public static Category m15(String var0) {
      return Enum.valueOf(Category.class, var0);
   }

   
}
