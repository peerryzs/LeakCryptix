package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class AutoPlayModule extends Module {
   private long f401;
   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6 && ModuleManager.f28.f18 == null) {
         for (int var2 = 0; var2 < 9; var2++) {
            ItemStack var3 = f0.player.getInventory().getItem(var2);
            if (var3.is(Items.PAPER)) {
               if (var3.getHoverName().getString().contains("Play Again") && System.currentTimeMillis() - this.f401 > 1000L) {
                  f0.player.getInventory().setSelectedSlot(var2);
                  f0.gameMode.useItem(f0.player, InteractionHand.MAIN_HAND);
                  this.f401 = System.currentTimeMillis();
               }
               break;
            }
         }
      }
   }

   public AutoPlayModule() {
      super("AutoPlay", Category.f25);
   }

   
}
