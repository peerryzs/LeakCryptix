package a;

import net.minecraft.world.entity.Entity;

public class k extends r {
   private Entity f98;
   private int f99;
   

   public int m38() {
      return this.f99;
   }

   public void m40(int var1) {
      this.f99 = var1;
   }

   public k m37(int var1, Entity var2) {
      this.f99 = var1;
      this.f98 = var2;
      return this;
   }

   public Entity m39() {
      return this.f98;
   }
}
