package a;

import net.minecraft.world.phys.Vec3;

public final class fd {
   public double f55;
   public double f54;
   public double f53;
   

   public fd m247(double var1, double var3, double var5) {
      this.f53 = var1;
      this.f54 = var3;
      this.f55 = var5;
      return this;
   }

   public fd() {
   }

   public fd m248(fd var1) {
      return this.m247(var1.f53, var1.f54, var1.f55);
   }

   public Vec3 m250() {
      return new Vec3(this.f53, this.f54, this.f55);
   }

   public fd m249(Vec3 var1) {
      return this.m247(var1.x, var1.y, var1.z);
   }

   public fd(double var1, double var3, double var5) {
      this.m247(var1, var3, var5);
   }
}
