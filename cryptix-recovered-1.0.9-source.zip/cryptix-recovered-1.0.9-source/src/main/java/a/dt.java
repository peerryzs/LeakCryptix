package a;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class dt extends Screen {
   private final File f131;
   public static String f20;
   private EditBox f129;
   private boolean f130;
   

   private void pm$7() {
      f20 = this.f129.getValue();
      if (!f20.isEmpty()) {
         if (!this.f130) {
            this.f130 = true;
            new Thread(() -> {
               boolean var1 = NativeGate.m0(f20 + "|" + NativeSupport.m1());
               Minecraft.getInstance().execute(() -> {
                  if (var1) {
                     try {
                        this.f131.getParentFile().mkdirs();
                        Files.writeString(this.f131.toPath(), f20);
                     } catch (IOException var3) {
                     }

                     Minecraft.getInstance().gui.setScreen(null);
                  } else {
                     System.exit(0);
                  }
               });
            }).start();
         }
      }
   }

   private void pm$6() {
      String var1 = NativeSupport.m1();
      Minecraft.getInstance().keyboardHandler.setClipboard(var1);
   }

   public void extractRenderState(GuiGraphicsExtractor var1, int var2, int var3, float var4) {
      super.extractRenderState(var1, var2, var3, var4);
      String var5 = "Cryptix License Key";
      var1.text(
         this.font,
         Component.literal(var5),
         this.width / 2 - this.font.width(var5) / 2,
         this.height / 2 - 60,
         -1
      );
   }

   public boolean shouldCloseOnEsc() {
      return false;
   }

   public dt() {
      super(Component.literal("Cryptix Login"));
      this.f130 = false;
      this.f131 = new File(Minecraft.getInstance().gameDirectory, "cryptix/license.txt");
   }

   

   protected void init() {
      this.f129 = new EditBox(
         this.font,
         this.width / 2 - 100,
         this.height / 2 - 20,
         200,
         20,
         Component.literal("License")
      );
      this.f129.setMaxLength(64);
      if (this.f131.exists()) {
         try {
            this.f129.setValue(Files.readString(this.f131.toPath()));
         } catch (IOException var2) {
         }
      }

      this.addRenderableWidget(this.f129);
      this.addRenderableWidget(
         Button.builder(Component.literal("Login"), var1 -> this.pm$7())
            .bounds(
               this.width / 2 - 50,
               this.height / 2 + 20,
               100,
               20
            )
            .build()
      );
      this.addRenderableWidget(
         Button.builder(Component.literal("Copy HWID"), var1 -> this.pm$6())
            .bounds(
               this.width / 2 - 50,
               this.height / 2 + 50,
               100,
               20
            )
            .build()
      );
      this.setInitialFocus(this.f129);
   }
}
