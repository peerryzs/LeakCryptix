package a;

import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public abstract class oc extends Screen implements ve {
   public hk setting;
   protected double dragOffsetY;
   protected double dragOffsetX;
   protected boolean dragging;
   

   public boolean mouseDragged(MouseButtonEvent var1, double var2, double var4) {
      double var6 = var1.x();
      double var8 = var1.y();
      int var10 = var1.button();
      if (this.dragging && var10 == 1) {
         int var11 = ve.f0.getWindow().getGuiScaledWidth();
         int var12 = 150;
         double var13 = var6 - this.dragOffsetX;
         double var15 = var8 - this.dragOffsetY;
         int var17 = (int)(var13 + var12 - var11);
         int var18 = (int)var15;
         this.setting.m245(var17, var18);
         return true;
      } else {
         return super.mouseDragged(var1, var2, var4);
      }
   }

   public boolean mouseReleased(MouseButtonEvent var1) {
      if (var1.button() == 1 && this.dragging) {
         this.dragging = false;
         return true;
      } else {
         return super.mouseReleased(var1);
      }
   }

   public boolean mouseClicked(MouseButtonEvent var1, boolean var2) {
      double var3 = var1.x();
      double var5 = var1.y();
      int var7 = var1.button();
      if (var7 == 1 && this.isInsideHud(var3, var5)) {
         this.dragging = true;
         int var8 = ve.f0.getWindow().getGuiScaledWidth();
         int var9 = 150;
         double var10 = var8 + this.setting.m235() - var9;
         this.dragOffsetX = var1.x() - var10;
         this.dragOffsetY = var1.y() - this.setting.m236();
         return true;
      } else {
         return super.mouseClicked(var1, var2);
      }
   }

   protected oc(Component var1) {
      super(var1);
   }

   public abstract boolean isInsideHud(double var1, double var3);
}
