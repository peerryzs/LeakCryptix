package a;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import net.minecraft.util.Mth;
import org.joml.Matrix3x2fc;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
public record zg(
   RenderPipeline pipeline,
   TextureSetup textureSetup,
   Matrix3x2fc pose,
   int x0,
   int y0,
   int x1,
   int y1,
   int radius,
   int thickness,
   int color,
   @Nullable ScreenRectangle scissorArea,
   @Nullable ScreenRectangle bounds
) implements GuiElementRenderState {





   

   public int thickness() {
      return this.thickness;
   }

   public int x0() {
      return this.x0;
   }

   private void pm$135(VertexConsumer var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9) {
      var1.addVertexWith2DPose(this.pose(), var2, var3).setColor(this.color());
      var1.addVertexWith2DPose(this.pose(), var4, var5).setColor(this.color());
      var1.addVertexWith2DPose(this.pose(), var6, var7).setColor(this.color());
      var1.addVertexWith2DPose(this.pose(), var8, var9).setColor(this.color());
   }

   public TextureSetup textureSetup() {
      return this.textureSetup;
   }

   @Nullable
   private static ScreenRectangle pm$136(int var0, int var1, int var2, int var3, Matrix3x2fc var4, @Nullable ScreenRectangle var5) {
      ScreenRectangle var6 = new ScreenRectangle(var0, var1, var2 - var0, var3 - var1).transformMaxBounds(var4);
      return var5 != null ? var5.intersection(var6) : var6;
   }

   private void pm$133(VertexConsumer var1, float var2, float var3, float var4, float var5, float var6, float var7, int var8) {
      double var9 = Math.toRadians(var6);
      float var11 = 0.09817477F;
      float var12 = Mth.sin(var9);
      float var13 = Mth.cos(var9);
      float var14 = var2 + var13 * var4;
      float var15 = var3 + var12 * var4;
      float var16 = var2 + var13 * var5;
      float var17 = var3 + var12 * var5;

      for (int var18 = 1; var18 <= var8; var18++) {
         double var19 = var9 + var11 * var18;
         float var21 = Mth.cos(var19);
         float var22 = Mth.sin(var19);
         float var23 = var2 + var21 * var4;
         float var24 = var3 + var22 * var4;
         float var25 = var2 + var21 * var5;
         float var26 = var3 + var22 * var5;
         this.pm$135(var1, var14, var15, var16, var17, var25, var26, var23, var24);
         var14 = var23;
         var15 = var24;
         var16 = var25;
         var17 = var26;
      }
   }

   public int radius() {
      return this.radius;
   }

   public Matrix3x2fc pose() {
      return this.pose;
   }

   public int y0() {
      return this.y0;
   }

   public RenderPipeline pipeline() {
      return this.pipeline;
   }

   public int color() {
      return this.color;
   }

   public int x1() {
      return this.x1;
   }

   public zg(
      RenderPipeline var1,
      TextureSetup var2,
      Matrix3x2fc var3,
      int var4,
      int var5,
      int var6,
      int var7,
      int var8,
      int var9,
      int var10,
      @Nullable ScreenRectangle var11
   ) {
      this(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, pm$136(var4, var5, var6, var7, var3, var11));
   }

   private void pm$134(VertexConsumer var1, float var2, float var3, float var4, float var5) {
      var1.addVertexWith2DPose(this.pose(), var2, var3).setColor(this.color());
      var1.addVertexWith2DPose(this.pose(), var2, var5).setColor(this.color());
      var1.addVertexWith2DPose(this.pose(), var4, var5).setColor(this.color());
      var1.addVertexWith2DPose(this.pose(), var4, var3).setColor(this.color());
   }

   @Nullable
   public ScreenRectangle scissorArea() {
      return this.scissorArea;
   }

   @Nullable
   public ScreenRectangle bounds() {
      return this.bounds;
   }

   public int y1() {
      return this.y1;
   }

   public void buildVertices(VertexConsumer var1) {
      int var2 = this.x1() - this.x0();
      int var3 = this.y1() - this.y0();
      int var4 = (int)Math.min((double)this.radius(), var2 * 0.5);
      int var5 = Math.min(this.thickness(), Math.min(var2, var3) / 2);
      if (var4 > 0 && var5 > 0) {
         int var6 = Math.max(0, var4 - var5);
         this.pm$134(var1, this.x0() + var4, this.y0(), this.x1() - var4, this.y0() + var5);
         this.pm$134(var1, this.x0() + var4, this.y1() - var5, this.x1() - var4, this.y1());
         this.pm$134(var1, this.x0(), this.y0() + var4, this.x0() + var5, this.y1() - var4);
         this.pm$134(var1, this.x1() - var5, this.y0() + var4, this.x1(), this.y1() - var4);
         int var7 = Math.min(32, Math.max(4, var4 * 4));
         this.pm$133(var1, this.x0() + var4, this.y0() + var4, var4, var6, 180.0F, 270.0F, var7);
         this.pm$133(var1, this.x1() - var4, this.y0() + var4, var4, var6, 270.0F, 360.0F, var7);
         this.pm$133(var1, this.x1() - var4, this.y1() - var4, var4, var6, 0.0F, 90.0F, var7);
         this.pm$133(var1, this.x0() + var4, this.y1() - var4, var4, var6, 90.0F, 180.0F, var7);
      }
   }

   public zg(
      RenderPipeline pipeline,
      TextureSetup textureSetup,
      Matrix3x2fc pose,
      int x0,
      int y0,
      int x1,
      int y1,
      int radius,
      int thickness,
      int color,
      @Nullable ScreenRectangle scissorArea,
      @Nullable ScreenRectangle bounds
   ) {
      this.pipeline = pipeline;
      this.textureSetup = textureSetup;
      this.pose = pose;
      this.x0 = x0;
      this.y0 = y0;
      this.x1 = x1;
      this.y1 = y1;
      this.radius = radius;
      this.thickness = thickness;
      this.color = color;
      this.scissorArea = scissorArea;
      this.bounds = bounds;
   }
}
