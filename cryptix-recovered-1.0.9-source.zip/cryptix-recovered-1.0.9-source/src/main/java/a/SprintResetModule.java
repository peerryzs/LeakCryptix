package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.Vec2;

public class SprintResetModule extends Module {
   private int f354;
   private final BooleanSetting f351;
   private int f353;
   private final ModeSetting f349;
   private final NumberSetting f348;
   private int f352;
   private final NumberSetting f347;
   private final BooleanSetting f350;
   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         this.setSuffix(this.f349.getValue());
      } else if (var1 == u.f11) {
         if (u.f11.m45() instanceof ServerboundAttackPacket var2) {
            Entity var9 = f0.level.getEntity(var2.entityId());
            if (var9 != null && f0.player.isSprinting() && this.f353 <= 0) {
               this.f352 = (int)this.f347.getValue();
               this.f353 = (int)this.f348.getValue();
            }
         }
      } else if (var1 == u.f12) {
         if (u.f12.m42() instanceof ClientboundSetEntityMotionPacket var7 && var7.id() == f0.player.getId()) {
            this.f354 = 5;
         }
      } else if (var1 == u.f9) {
         if (this.f353 > 0) {
            this.f353 = this.f353 - 1;
         }

         if (this.f354 > 0) {
            this.f354 = this.f354 - 1;
         }

         if (this.f352 > 0) {
            this.f352 = this.f352 - 1;
            if (this.f354 > 0 && this.f350.getValue()) {
               return;
            }

            LivingEntity var8 = jb.m51(5.0, false);
            if (this.f351.getValue() && var8 != null && f0.player.distanceTo(var8) > 3.5) {
               System.out.println("dist:");
               return;
            }

            Input var11 = f0.player.input.keyPresses;
            mixins.ClientInputMixin_rn var4 = (mixins.ClientInputMixin_rn)f0.player.input;
            boolean var5 = this.f349.isMode("STap");
            Vec2 var6 = new Vec2(0.0F, var5 ? -1.0F : 0.0F);
            if (var6.length() > 1.0F) {
               var6 = var6.normalized();
            }

            var4.setMoveVector(var6);
            f0.player.input.keyPresses = new Input(
               false, (var5), false, false, var11.jump(), var11.shift(), var11.sprint()
            );
         } else if (this.f352 == 0) {
            this.f352 = this.f352 - 1;
         }
      }
   }

   

   public SprintResetModule() {
      super("SprintReset", Category.f21);
      this.f347 = new NumberSetting("Release Delay", this, 2.0, 1.0, 5.0, 1.0);
      this.f348 = new NumberSetting("Reset Delay", this, 0.0, 0.0, 10.0, 1.0);
      String var10003 = "Mode";
      String var10005 = "WTap";
      String[] var10006 = new String[2];
      var10006[0] = "Wtap";
      var10006[1] = "STap";
      this.f349 = new ModeSetting(var10003, this, var10005, var10006);
      this.f350 = new BooleanSetting("Cancel on Velo", this, false);
      this.f351 = new BooleanSetting("Cancel Far", this, false);
   }
}
