package a;

import java.nio.charset.StandardCharsets;

public final class bl {
   public static hr f44;
   public static hr f45;
   

   public static void m67() {
      f44 = new hr("font/ARIAL.TTF", 10.5F);
      f45 = new hr("font/ARIAL.TTF", 18.0F);
   }

   

   private bl() {
   }

   public static void m68() {
      f44.m254();
      f45.m254();
   }
}
