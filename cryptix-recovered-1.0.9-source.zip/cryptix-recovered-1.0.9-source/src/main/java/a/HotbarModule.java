package a;

import java.nio.charset.StandardCharsets;

public class HotbarModule extends Module {
   public final NumberSetting f45;
   

   

   public HotbarModule() {
      super("Hotbar", Category.f24);
      this.f45 = new NumberSetting("Animation Time", this, 100.0, 50.0, 200.0, 25.0);
   }
}
