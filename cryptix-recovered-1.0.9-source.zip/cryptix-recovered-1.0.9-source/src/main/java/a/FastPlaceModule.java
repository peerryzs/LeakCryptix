package a;

import java.nio.charset.StandardCharsets;
import mixins.MinecraftMixin_ea;

public class FastPlaceModule extends Module {
   private NumberSetting f602;
   private int f604;
   private BooleanSetting f603;
   

   public FastPlaceModule() {
      super("FastPlace", Category.f23);
      this.f602 = new NumberSetting("Delay", this, 1.0, 0.0, 3.0, 1.0);
      this.f603 = new BooleanSetting("Blocks Only", this, true);
   }

   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         if (this.f603.getValue() && !mr.m44()) {
            return;
         }

         int var2 = (int)this.f602.getValue();
         if (var2 == 0) {
            ((MinecraftMixin_ea)f0).setRightClickDelay(0);
         } else {
            if (this.f604 >= var2) {
               ((MinecraftMixin_ea)f0).setRightClickDelay(0);
               this.f604 = 0;
            }

            this.f604 = this.f604 + 1;
         }
      }
   }
}
