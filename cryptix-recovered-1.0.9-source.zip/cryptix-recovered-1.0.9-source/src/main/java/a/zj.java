package a;

import net.minecraft.network.protocol.Packet;

public class zj {
   private final long f977;
   public final Packet f52;
   

   public zj(Packet var1, long var2) {
      this.f52 = var1;
      this.f977 = System.currentTimeMillis() + var2;
   }

   public boolean m246() {
      return (System.currentTimeMillis() >= this.f977);
   }
}
