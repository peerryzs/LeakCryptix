package a;

import com.mojang.blaze3d.platform.Window;
import java.nio.charset.StandardCharsets;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

public class TargetHUDModule extends Module {
   private final BooleanSetting f910;
   private static final String f882 = "";
   private int f923;
   private float f914;
   public final hk f48;
   private Player f918;
   private int f917;
   private final BooleanSetting f907;
   private float f912;
   private Player f920;
   private final BooleanSetting f908;
   private final BooleanSetting f911;
   private static final String[] f925;
   private final BooleanSetting f909;
   private Identifier f919;
   private float f915;
   private int f916;
   private int f922;
   private String f921;
   private kd f924;
   private float f913;
   

   private void render(j var1) {
      CombatModuleNative var2 = ModuleManager.f28;
      if (var2 != null) {
         int var3 = !(var2.f18 instanceof Player) && (this.f918 == null || this.f916 <= 10) ? 0 : 1;
         if (var3 != 0) {
            Player var4 = var2.f18 instanceof Player ? (Player)var2.f18 : this.f918;
            if (this.f920 != var4) {
               this.f920 = var4;
               this.f919 = null;
               this.f921 = var4.getDisplayName().getString();
               this.f922 = bt.m71(this.f921);
               this.f923 = Math.max(50, 50 + this.f922);
               f0.getSkinManager().get(var4.getGameProfile()).thenAccept(var1x -> var1x.ifPresent(var1xx -> this.f919 = var1xx.body().id()));
            }

            Window var5 = f0.getWindow();
            int var6 = var5.getGuiScaledWidth();
            int var7 = var5.getGuiScaledHeight();
            int var8 = (var6 >> 1) + this.f48.m235();
            int var9 = (var7 >> 1) + this.f48.m236();
            int var10 = this.f923;
            float var11 = Mth.lerp(var1.m78(), this.f914, this.f913);
            float var12 = Mth.lerp(var1.m78(), this.f912, this.f915);
            float var13 = var4.getMaxHealth();
            float var14 = var12 / var13;
            float var15 = var11 / var13;
            GuiGraphicsExtractor var16 = var1.m76();
            int var17 = oo.m30();
            boolean var18 = this.f907.getValue();
            int var19 = var18 ? var17 : oo.m29(var14);
            int var20 = var19 & 16777215 | 1677721600;
            int var21 = (int)(this.f917 + (this.f916 - this.f917) * var1.m78());
            var19 = var21 << 24 | var19 & 16777215;
            int var22 = var21 * 128 / 254 << 24;
            int var23 = Math.round(var12);
            if (var23 < 0) {
               var23 = 0;
            } else if (var23 > 20) {
               var23 = 20;
            }

            String var24 = f925[var23];
            if (this.f911.getValue()) {
               th.m64(var16, var8, var9, var10, 42, 6, var22);
            } else {
               var16.fill(var8, var9, var8 + var10, var9 + 42, var22);
            }

            if (this.f908.getValue()) {
               if (this.f911.getValue()) {
                  th.m65(
                     var16, var8, var9, var10, 42, 5, 1, var21 << 24 | var17 & 16777215
                  );
               } else {
                  var16.fill(var8, var9, var8 + 1, var9 + 42, var21 << 24 | var17 & 16777215);
                  var16.fill(
                     var8 + var10 - 1, var9, var8 + var10, var9 + 42, var21 << 24 | var17 & 16777215
                  );
                  var16.fill(var8, var9, var8 + var10, var9 + 1, var21 << 24 | var17 & 16777215);
                  var16.fill(
                     var8, var9 + 41, var8 + var10, var9 + 42, var21 << 24 | var17 & 16777215
                  );
               }
            }

            if (this.f910.getValue() && this.f916 > 200) {
               var16.fill(
                  var8 + 4,
                  var9 + 34,
                  var8 + 8 + (int)((var10 - 12) * var15),
                  var9 + 38,
                  var20
               );
            }

            if (this.f911.getValue()) {
               th.m64(
                  var16,
                  var8 + 4,
                  var9 + 34,
                  4 + (int)((var10 - 12) * var14),
                  4,
                  2,
                  var19
               );
            } else {
               var16.fill(
                  var8 + 4,
                  var9 + 34,
                  var8 + 8 + (int)((var10 - 12) * var14),
                  var9 + 38,
                  var19
               );
            }

            if (this.f909.getValue()) {
               String var25 = var4.getHealth() <= f0.player.getHealth() ? "\u00a7aW" : "\u00a7cL";
               bt.m70(
                  var16,
                  var25,
                  var8 + var10 - bt.m71(var25) - 5,
                  var9 + 5,
                  var21 << 24 | 16777215
               );
            }

            bt.m70(var16, this.f921, var8 + 34, var9 + 5, var21 << 24 | 16777215);
            bt.m70(var16, var24, var8 + var10 - 35, var9 + 22, var19);
            if (this.f919 != null) {
               if (this.f911.getValue()) {
                  th.m66(
                     var16,
                     this.f919,
                     var8 + 4,
                     var9 + 4,
                     26,
                     26,
                     5,
                     8,
                     8,
                     8,
                     8,
                     64,
                     64,
                     var21 << 24 | 16777215
                  );
               } else {
                  var16.blit(
                     RenderPipelines.GUI_TEXTURED,
                     this.f919,
                     var8 + 4,
                     var9 + 4,
                     8.0F,
                     8.0F,
                     26,
                     26,
                     8,
                     8,
                     64,
                     64,
                     var21 << 24 | 16777215
                  );
               }
            }

            this.f918 = var4;
         }
      }
   }

   static {
      String[] var10000 = new String[21];
      var10000[0] = "HP: 0";
      var10000[1] = "HP: 1";
      var10000[2] = "HP: 2";
      var10000[3] = "HP: 3";
      var10000[4] = "HP: 4";
      var10000[5] = "HP: 5";
      var10000[6] = "HP: 6";
      var10000[7] = "HP: 7";
      var10000[8] = "HP: 8";
      var10000[9] = "HP: 9";
      var10000[10] = "HP: 10";
      var10000[11] = "HP: 11";
      var10000[12] = "HP: 12";
      var10000[13] = "HP: 13";
      var10000[14] = "HP: 14";
      var10000[15] = "HP: 15";
      var10000[16] = "HP: 16";
      var10000[17] = "HP: 17";
      var10000[18] = "HP: 18";
      var10000[19] = "HP: 19";
      var10000[20] = "HP: 20";
      f925 = var10000;
   }

   public TargetHUDModule() {
      super("TargetHUD", Category.f24);
      this.f907 = new BooleanSetting("Theme Color", this, false);
      this.f908 = new BooleanSetting("Outline", this, false);
      this.f48 = new hk("Edit Position", this, 0, 0, 0, 0, new kd(this));
      this.f909 = new BooleanSetting("Show Win or Loss", this, false);
      this.f910 = new BooleanSetting("Health Animation", this, false);
      this.f911 = new BooleanSetting("Round", this, false);
      this.f921 = f882;
      this.f923 = 80;
      this.f924 = new kd(this);
   }

   public void m218(GuiGraphicsExtractor var1) {
      int var2 = f0.getWindow().getGuiScaledWidth();
      int var3 = f0.getWindow().getGuiScaledHeight();
      int var4 = (var2 >> 1) + this.f48.m235();
      int var5 = (var3 >> 1) + this.f48.m236();
      String var6 = "Player";
      int var7 = bt.m71(var6);
      int var8 = Math.max(80, 38 + var7);
      this.f48.m243(var8);
      this.f48.m244(42);
      int var9 = -1;
      var1.fill(var4, var5, var4 + var8, var5 + 42, -1442840576);
      bt.m70(var1, var6, var4 + 34, var5 + 5, -1);
      bt.m70(var1, "HP: 20", var4 + var8 - 35, var5 + 22, var9);
      var1.fill(var4 + 4, var5 + 34, var4 + 8 + var8 - 12, var5 + 38, var9);
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f8) {
         if (f0.gui.screen() == this.f924) {
            return;
         }

         this.render(u.f8);
      }

      if (var1 == u.f6) {
         CombatModuleNative var2 = ModuleManager.f28;
         int var3 = var2 != null && var2.f18 instanceof Player ? 1 : 0;
         float var4 = var3 != 0 ? 255.0F : 0.0F;
         this.f917 = this.f916;
         this.f916 = (int)Mth.lerp(0.5F, this.f916, var4);
         if (var3 == 0) {
            return;
         }

         Player var5 = (Player)var2.f18;
         this.f914 = this.f913;
         this.f913 = this.f912;
         this.f912 = this.f915;
         this.f915 = var5.getHealth();
      }
   }
}
