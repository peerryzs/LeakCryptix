package a;

import net.minecraft.client.Minecraft;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class mr {
   private static final Minecraft f978 = Minecraft.getInstance();
   

   public static boolean m43() {
      return (f978.player == null ? false : f978.player.getMainHandItem().is(ItemTags.SWORDS));
   }

   public static int m45() {
      int var0 = 0;
      Inventory var1 = f978.player.getInventory();

      for (int var2 = 0; var2 < 9; var2++) {
         ItemStack var3 = var1.getItem(var2);
         if (var3.getItem() instanceof BlockItem) {
            var0 += var3.getCount();
         }
      }

      return var0;
   }

   public static boolean m44() {
      if (f978.player == null) {
         return false;
      } else {
         Item var0 = f978.player.getMainHandItem().getItem();
         return var0 instanceof BlockItem;
      }
   }
}
