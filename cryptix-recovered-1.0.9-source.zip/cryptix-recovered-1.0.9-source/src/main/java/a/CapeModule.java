package a;

import java.nio.charset.StandardCharsets;

public class CapeModule extends Module {
   public final ModeSetting f42;
   

   public CapeModule() {
      super("Cape", Category.f24);
      String var10003 = "Cape";
      String var10005 = "Cryptix";
      String[] var10006 = new String[4];
      var10006[0] = "Cryptix";
      var10006[1] = "Cat";
      var10006[2] = "Pushy";
      var10006[3] = "Sky";
      this.f42 = new ModeSetting(var10003, this, var10005, var10006);
   }

   
}
