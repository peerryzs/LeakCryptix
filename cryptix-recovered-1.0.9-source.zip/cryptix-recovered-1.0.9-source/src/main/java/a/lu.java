package a;

import java.awt.Color;
import java.nio.charset.StandardCharsets;
import net.minecraft.util.Mth;

public class lu {
   private static int f1000;
   private static int f996 = -1;
   private static int f1002;
   private static int f998;
   private static boolean f1008;
   private static float f1007;
   private static final float f993 = 0.0027777778F;
   private static final double f994 = 1.6666666666666666E-4;
   private static final double f995 = 0.001;
   private static int f1003;
   private static int f999;
   private static long f1005;
   private static int f1001;
   private static double f1006;
   private static String f1004;
   private static int f997 = -1;
   

   

   public static int m56(int var0) {
      if (f1008) {
         return pm$132(var0);
      } else {
         double var1 = (Mth.sin(f1006 + var0) + 1.0F) * 0.5;
         int var3 = (int)(f998 + (f1001 - f998) * var1);
         int var4 = (int)(f999 + (f1002 - f999) * var1);
         int var5 = (int)(f1000 + (f1003 - f1000) * var1);
         return -16777216 | var3 << 16 | var4 << 8 | var5;
      }
   }

   private static int pm$132(int var0) {
      float var1 = (f1007 + var0 * 0.0027777778F) % 1.0F;
      return Color.HSBtoRGB(var1, 1.0F, 1.0F) | -16777216;
   }

   public static void m55() {
      String var0 = ModuleManager.f26.f49.getValue();
      double var1 = ModuleManager.f26.f50.getValue();
      f1005 = System.currentTimeMillis();
      f1007 = (float)(f1005 * var1 % 6000.0 * 1.6666666666666666E-4);
      f1006 = f1005 * 0.001 * var1;
      f1008 = "Rainbow".equals(var0);
      if (!var0.equals(f1004)) {
         f1004 = var0;
         int var4 = -1;
         int var10000 = var0.hashCode();
         if (var10000 == -1825862521) {
            if (var0.equals("Sakura")) {
               var4 = 5;
            }
         } else if (var10000 == -685180305) {
            if (var0.equals("Inferno")) {
               var4 = 4;
            }
         } else if (var10000 == 2225280) {
            if (var0.equals("Gold")) {
               var4 = 0;
            }
         } else if (var10000 == 2434124) {
            if (var0.equals("Nova")) {
               var4 = 2;
            }
         } else if (var10000 == 30590468) {
            if (var0.equals("Emerald")) {
               var4 = 3;
            }
         } else if (var10000 == 68152996) {
            if (var0.equals("Frost")) {
               var4 = 7;
            }
         } else if (var10000 == 76007646) {
            if (var0.equals("Ocean")) {
               var4 = 1;
            }
         } else if (var10000 == 1929002704) {
            if (var0.equals("Cotton Candy")) {
               var4 = 8;
            }
         } else if (var10000 == ('\uf07b' << 15 | 25017) - 0) {
            if (var0.equals("Cherry")) {
               var4 = 6;
            }
         }

         switch (var4) {
            case 0:
               f996 = -23296;
               f997 = -256;
               break;
            case 1:
               f996 = -16726273;
               f997 = -16747777;
               break;
            case 2:
               f996 = -39736;
               f997 = -15100161;
               break;
            case 3:
               f996 = -16718218;
               f997 = -15315669;
               break;
            case 4:
               f996 = -43230;
               f997 = -8768993;
               break;
            case 5:
               f996 = -32597;
               f997 = -2080517;
               break;
            case 6:
               f996 = -2278039;
               f997 = -2051145;
               break;
            case 7:
               f996 = -2104349;
               f997 = -4405814;
               break;
            case 8:
               f996 = -10225153;
               f997 = -38708;
               break;
            default:
               f996 = -1;
               f997 = -1;
         }

         f998 = f996 >> 16 & 255;
         f999 = f996 >> 8 & 255;
         f1000 = f996 & 255;
         f1001 = f997 >> 16 & 255;
         f1002 = f997 >> 8 & 255;
         f1003 = f997 & 255;
      }
   }
}
