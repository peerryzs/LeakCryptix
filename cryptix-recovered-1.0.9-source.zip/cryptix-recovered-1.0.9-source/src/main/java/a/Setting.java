package a;

public abstract class Setting {
   private final Module owner;
   private final String name;
   

   public Module getOwner() {
      return this.owner;
   }

   public String getName() {
      return this.name;
   }

   public Setting(String var1, Module var2) {
      this.name = var1;
      this.owner = var2;
      this.owner.f15.add(this);
   }
}
