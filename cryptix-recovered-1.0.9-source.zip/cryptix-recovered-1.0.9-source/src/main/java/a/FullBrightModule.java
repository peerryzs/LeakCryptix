package a;

import java.nio.charset.StandardCharsets;
import mixins.OptionInstanceMixin_pw;

public class FullBrightModule extends Module {
   private double f780;
   

   @Override
   public void onEnable() {
      this.f780 = (Double)f0.options.gamma().get();
      ((OptionInstanceMixin_pw)(Object)f0.options.gamma()).setValue(100.0);
   }

   public FullBrightModule() {
      super("FullBright", Category.f24);
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         ((OptionInstanceMixin_pw)(Object)f0.options.gamma()).setValue(100.0);
      }
   }

   @Override
   public void onDisable() {
      f0.options.gamma().set(this.f780);
   }

   
}
