package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

public class AimAssistModule extends Module {
   private NumberSetting f255;
   private BooleanSetting f256;
   private NumberSetting f254;
   

   public AimAssistModule() {
      super("AimAssist", Category.f21);
      this.f254 = new NumberSetting("Range", this, 6.0, 3.0, 8.0, 0.5);
      this.f255 = new NumberSetting("Speed", this, 5.0, 1.0, 10.0, 0.5);
      this.f256 = new BooleanSetting("Require Mouse Down", this, false);
   }

   private float pm$57() {
      float var1 = ((Double)f0.options.sensitivity().get()).floatValue();
      float var2 = var1 * 0.6F + 0.2F;
      return var2 * var2 * var2 * 8.0F * 0.15F;
   }

   

   private float pm$58(float var1, float var2) {
      float var3 = this.pm$57();
      float var4 = var1 - var2;
      var4 -= var4 % var3;
      return var2 + var4;
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f4) {
         if (this.f256.getValue() && !f0.mouseHandler.isLeftPressed()) {
            return;
         }

         LivingEntity var2 = jb.m51(this.f254.getValue(), true);
         if (var2 != null) {
            AABB var3 = var2.getBoundingBox();
            double var4 = Mth.clamp(f0.player.getX(), var3.minX, var3.maxX) - f0.player.getX();
            double var6 = Mth.clamp(f0.player.getEyeY(), var3.minY, var3.maxY) - f0.player.getEyeY();
            double var8 = Mth.clamp(f0.player.getZ(), var3.minZ, var3.maxZ) - f0.player.getZ();
            double var10 = Math.sqrt(var4 * var4 + var8 * var8);
            float var12 = (float)(Math.toDegrees(Math.atan2(var8, var4)) - 90.0);
            float var13 = (float)(-Math.toDegrees(Math.atan2(var6, var10)));
            float var14 = Mth.wrapDegrees(var12 - f0.player.getYRot());
            float var15 = var13 - f0.player.getXRot();
            float var16 = (float)Math.min((double)Math.abs(var14), this.f255.getValue());
            float var17 = (float)Math.min((double)Math.abs(var15), this.f255.getValue());
            float var18 = this.pm$58(Math.copySign(var16, var14), f0.player.getYRot());
            float var19 = this.pm$58(Math.copySign(var17, var15), f0.player.getXRot());
            f0.player.setYRot(f0.player.getYRot() + var18);
            f0.player.setXRot(f0.player.getXRot() + var19);
         }
      }
   }
}
