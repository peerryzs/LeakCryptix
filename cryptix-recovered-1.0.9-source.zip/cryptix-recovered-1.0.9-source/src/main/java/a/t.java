package a;

public class t extends r {
   private float f120;
   

   public void m81(float var1) {
      this.f120 = var1;
   }

   public t m79(float var1) {
      this.f120 = var1;
      return this;
   }

   public float m80() {
      return this.f120;
   }
}
