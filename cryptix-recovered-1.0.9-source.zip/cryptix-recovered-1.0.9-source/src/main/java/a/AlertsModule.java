package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class AlertsModule extends Module {
   private final BooleanSetting f389;
   private long f390;
   

   public AlertsModule() {
      super("Alerts", Category.f25);
      this.f389 = new BooleanSetting("Fireball", this, false);
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         long var2 = System.currentTimeMillis();
         if (var2 - this.f390 < 2000L) {
            return;
         }

         for (Player var5 : f0.level.players()) {
            if (var5 != f0.player && !ModuleManager.f29.m137(var5)) {
               String var6 = var5.getName().getString();
               ItemStack var7 = var5.getMainHandItem();
               if (this.f389.getValue() && var7.is(Items.FIRE_CHARGE)) {
                  CryptixClient.sendPrefixedMessage("§a" + var6 + " §7has a fireball");
                  this.f390 = var2;
                  break;
               }
            }
         }
      }
   }

   
}
