package a;

import java.util.List;
import net.minecraft.client.Minecraft;

public class u {
   public static final a f18 = new a();
   public static final f f12 = new f();
   public static final e f4 = new e();
   public static final List<r> f19;
   public static final i f17 = new i();
   public static final o f16 = new o();
   public static final g f14 = new g();
   public static final k f15 = new k();
   public static final c f9 = new c();
   public static final j f8 = new j();
   public static final t f10 = new t();
   public static final yi f13 = new yi();
   public static final w f11 = new w();
   public static final h f7 = new h();
   public static final d f6 = new d();
   public static final q f5 = new q();
   

   static {
      r[] var10000 = new r[15];
      var10000[0] = f4;
      var10000[1] = f5;
      var10000[2] = f6;
      var10000[3] = f7;
      var10000[4] = f8;
      var10000[5] = f9;
      var10000[6] = f10;
      var10000[7] = f11;
      var10000[8] = f12;
      var10000[9] = f13;
      var10000[10] = f14;
      var10000[11] = f15;
      var10000[12] = f16;
      var10000[13] = f17;
      var10000[14] = f18;
      f19 = List.of(var10000);
   }

   public static void m13() {
      if (Minecraft.getInstance().player != null) {
         for (r var1 : f19) {
            var1.m11();
         }
      }
   }
}
