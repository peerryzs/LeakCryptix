package a;

import java.nio.charset.StandardCharsets;
import java.util.Objects;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

public class LagRangeModule extends Module {
   private final BooleanSetting f627;
   private final NumberSetting f625;
   private boolean f628;
   private final NumberSetting f626;
   private double f631;
   private int f629;
   private Vec3 f630;
   

   @Override
   public void onEnable() {
   }

   

   private void pm$117() {
      double var1 = this.f626.getValue();
      if (var1 != this.f631) {
         this.f631 = var1;
         this.setSuffix((int)(var1 * 50.0) + " ms");
      }
   }

   @Override
   public void onDisable() {
      this.pm$116();
   }

   public LagRangeModule() {
      super("LagRange", Category.f23);
      this.f625 = new NumberSetting("Range", this, 6.0, 4.0, 8.0, 0.5);
      this.f626 = new NumberSetting("Blink Ticks", this, 5.0, 2.0, 10.0, 1.0);
      this.f627 = new BooleanSetting("Lag When Close", this, false);
      this.f631 = Double.NaN;
   }

   private void pm$116() {
      if (this.f628) {
         this.f628 = false;
         xb.m26();
      }

      this.f630 = null;
      this.f629 = 0;
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f11 && u.f11.m45() instanceof ServerboundAttackPacket var2) {
         if (this.f627.getValue() && f0.player.distanceTo(Objects.requireNonNull(f0.level.getEntity(var2.entityId()))) < 2.0F) {
            return;
         }

         this.pm$116();
      }

      if (var1 == u.f6) {
         this.pm$117();
         LivingEntity var5 = jb.m51(this.f625.getValue(), true);
         if (var5 != null) {
            xb.m25();
            this.f628 = true;
            this.f629 = this.f629 + 1;
            Vec3 var6 = var5.position();
            if (this.f630 != null && this.f630.distanceTo(var6) <= f0.player.position().distanceTo(var6)) {
               this.pm$116();
            } else if (this.f629 > this.f626.getValue()) {
               this.pm$116();
            }

            Vec3 var4 = f0.player.position();
            this.f630 = new Vec3(var4.x, var4.y, var4.z);
         } else {
            this.pm$116();
         }
      }
   }
}
