package a;

import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.List;

public class b extends m {
   

   

   @Override
   public void m0(String[] var1, String var2) {
      if (var1.length > 1) {
         String var3 = var1[1];
         int var4 = 0;

         for (Module var6 : ModuleManager.getModules()) {
            if (var6.getName().equalsIgnoreCase(var3)) {
               var6.toggle();
               CryptixClient.sendPrefixedMessage((var6.isEnabled() ? "Enabled" : "Disabled") + " " + var3);
               var4 = 1;
               break;
            }
         }

         if (var4 == 0) {
            CryptixClient.sendPrefixedMessage("Invalid module");
         }
      } else {
         CryptixClient.sendPrefixedMessage("Usage: ." + this.f1);
      }
   }

   @Override
   public Collection m1(String[] var1) {
      return var1.length <= 1 ? ModuleManager.getModules().stream().map(Module::getName).toList() : List.of();
   }

   public b() {
      String var10001 = "Toggle";
      String var10002 = "toggle <name>";
      String[] var10003 = new String[2];
      var10003[0] = "toggle";
      var10003[1] = "t";
      super(var10001, var10002, var10003);
   }
}
