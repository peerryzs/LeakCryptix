package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.world.entity.Entity;

public class AutoWalkModule extends Module {
   private BooleanSetting f428;
   private BooleanSetting f427;
   

   private void pm$90(Entity var1) {
      double var2 = var1.getX() - f0.player.getX();
      double var4 = var1.getZ() - f0.player.getZ();
      float var6 = (float)Math.toDegrees(Math.atan2(var4, var2)) - 90.0F;
      f0.player.setYRot(var6);
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6 && f0.gui.screen() == null) {
         f0.options.keyUp.setDown(true);
         if (this.f427.getValue()) {
            Entity var2 = jb.m54();
            if (var2 != null) {
               this.pm$90(var2);
            }
         }
      }

      if (var1 == u.f9 && f0.player.horizontalCollision && this.f428.getValue()) {
         f0.player.input.makeJump();
      }
   }

   

   @Override
   public void onDisable() {
      f0.options.keyUp.setDown(false);
   }

   public AutoWalkModule() {
      super("AutoWalk", Category.f22);
      this.f427 = new BooleanSetting("Rotate to Entity", this, false);
      this.f428 = new BooleanSetting("Jump When Collided", this, false);
   }
}
