package a;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import net.minecraft.client.Minecraft;

public class ht {
   private static final String f973 = "";
   private static final File f976;
   private static final Gson f975 = new GsonBuilder().setPrettyPrinting().create();
   

   public static void m36(String var0) {
      JsonObject var1 = new JsonObject();

      for (Module var3 : ModuleManager.getModules()) {
         JsonObject var4 = new JsonObject();
         var4.addProperty("enabled", var3.isEnabled());
         var4.addProperty("hidden", var3.isHidden());
         var4.addProperty("key", var3.getKeyBind());
         JsonObject var5 = new JsonObject();

         for (Setting var7 : var3.f15) {
            if (var7 instanceof BooleanSetting var8) {
               var5.addProperty(var7.getName(), var8.getValue());
            } else if (var7 instanceof NumberSetting var9) {
               var5.addProperty(var7.getName(), var9.getValue());
            } else if (var7 instanceof ModeSetting var10) {
               var5.addProperty(var7.getName(), var10.getValue());
            } else if (var7 instanceof hk var11) {
               JsonObject var12 = new JsonObject();
               var12.addProperty("x", var11.m235());
               var12.addProperty("y", var11.m236());
               var12.addProperty("width", var11.m237());
               var12.addProperty("height", var11.m238());
               var5.add(var7.getName(), var12);
            }
         }

         var4.add("settings", var5);
         var1.add(var3.getName(), var4);
      }

      m38(var0, var1);
   }

   public static String[] m41() {
      File[] var0 = f976.listFiles((var0x, var1x) -> var1x.endsWith(".json"));
      if (var0 == null) {
         return new String[0];
      } else {
         String[] var1 = new String[var0.length];

         for (int var2 = 0; var2 < var0.length; var2++) {
            var1[var2] = var0[var2].getName().replace(".json", f973);
         }

         return var1;
      }
   }

   public static JsonObject m39(String var0) {
      File var1 = m33(var0);
      if (!var1.exists()) {
         return new JsonObject();
      } else {
         JsonObject var3;
         try (FileReader var2 = new FileReader(var1)) {
            var3 = JsonParser.parseReader(var2).getAsJsonObject();
         } catch (Exception var7) {
            var7.printStackTrace();
            return new JsonObject();
         }

         return var3;
      }
   }

   public static void m38(String var0, JsonObject var1) {
      try (FileWriter var2 = new FileWriter(m33(var0))) {
         f975.toJson(var1, var2);
      } catch (IOException var7) {
         var7.printStackTrace();
      }
   }

   public static boolean m42(String var0) {
      return m33(var0).exists();
   }

   public static void m35(String var0) {
      for (Module var2 : ModuleManager.getModules()) {
         var2.setEnabled(false);
         var2.setHidden(false);
         var2.setKeyBind(var2.getDefaultKeyBind());

         for (Setting var4 : var2.f15) {
            if (var4 instanceof BooleanSetting var5) {
               ((BooleanSetting)var4).setValue(var5.getDefaultValue());
            } else if (var4 instanceof NumberSetting var6) {
               ((NumberSetting)var4).setValue(var6.getDefaultValue());
            } else if (var4 instanceof ModeSetting var7) {
               ((ModeSetting)var4).setValue(var7.getDefaultValue());
            } else if (var4 instanceof hk) {
               ((hk)var4).m245(0, 0);
            }
         }
      }

      m36(var0);
   }

   public static File m34() {
      return f976;
   }

   static {
      f976 = new File(Minecraft.getInstance().gameDirectory, "cryptix/configs");
   }

   public static boolean m40(String var0) {
      return m33(var0).delete();
   }

   public static File m33(String var0) {
      return new File(f976, var0 + ".json");
   }

   public static void m32() {
      if (!f976.exists()) {
         f976.mkdirs();
      }
   }

   public static void m37(String var0) {
      try {
         JsonObject var1 = m39(var0);

         for (Module var3 : ModuleManager.getModules()) {
            if (var1.has(var3.getName())) {
               JsonObject var4 = var1.getAsJsonObject(var3.getName());
               var3.setEnabled(var4.get("enabled").getAsBoolean());
               var3.setHidden(var4.get("hidden").getAsBoolean());
               var3.setKeyBind(var4.get("key").getAsInt());
               JsonObject var5 = var4.getAsJsonObject("settings");

               for (Setting var7 : var3.f15) {
                  if (var5.has(var7.getName())) {
                     if (var7 instanceof BooleanSetting var8) {
                        var8.setValue(var5.get(var7.getName()).getAsBoolean());
                     } else if (var7 instanceof NumberSetting var9) {
                        var9.setValue(var5.get(var7.getName()).getAsDouble());
                     } else if (var7 instanceof ModeSetting var10) {
                        var10.setValue(var5.get(var7.getName()).getAsString());
                     } else if (var7 instanceof hk var11) {
                        JsonObject var12 = var5.getAsJsonObject(var7.getName());
                        var11.m245(var12.get("x").getAsInt(), var12.get("y").getAsInt());
                        var11.m243(var12.get("width").getAsInt());
                        var11.m244(var12.get("height").getAsInt());
                     }
                  }
               }
            }
         }
      } catch (Exception var13) {
         var13.printStackTrace();
      }
   }
}
