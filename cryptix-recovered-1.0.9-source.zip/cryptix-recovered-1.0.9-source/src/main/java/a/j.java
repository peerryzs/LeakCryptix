package a;

import com.cryptix.script.ScriptManager;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class j extends r {
   private GuiGraphicsExtractor f118;
   private DeltaTracker f119;
   

   public float m78() {
      return this.f119.getGameTimeDeltaPartialTick(false);
   }

   public DeltaTracker m77() {
      return this.f119;
   }

   public j m75(GuiGraphicsExtractor var1, DeltaTracker var2) {
      this.f118 = var1;
      this.f119 = var2;
      th.m61();
      lu.m55();
      oo.m31();
      ScriptManager.onRender(Minecraft.getInstance().getWindow(), Minecraft.getInstance().gameRenderer.mainCamera(), var1);
      yp.m24(this.m78());
      return this;
   }

   public GuiGraphicsExtractor m76() {
      return this.f118;
   }
}
