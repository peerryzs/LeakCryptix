package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.world.phys.Vec3;

public class InvMoveModule extends Module {
   private NumberSetting f434;
   

   

   private void pm$91() {
      Vec3 var1 = f0.player.getDeltaMovement();
      f0.player.setDeltaMovement(var1.x * this.f434.getValue(), var1.y, var1.z * this.f434.getValue());
   }

   public InvMoveModule() {
      super("InvMove", Category.f22);
      this.f434 = new NumberSetting("Motion", this, 1.0, 0.1, 1.0, 0.1);
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6 && f0.gui.screen() != null && !(f0.gui.screen() instanceof ChatScreen)) {
         KeyMapping.setAll();
         this.pm$91();
      }
   }
}
