package a;

import java.nio.charset.StandardCharsets;
import mixins.fg;
import mixins.ClientClockManagerMixin_vg;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import net.minecraft.resources.Identifier;
import net.minecraft.world.clock.WorldClocks;

public class AmbienceModule extends Module {
   private static final Identifier f729;
   private int f726;
   private static final Identifier f732;
   private static final Identifier f731;
   private static final Identifier f733;
   private ClientLevel f727;
   private final ModeSetting f724;
   public final NumberSetting f32;
   private static final Identifier f730;
   private final BooleanSetting f725;
   private static final Identifier f728;
   

   static {
      f728 = Identifier.parse("minecraft:entity.player.attack.nodamage");
      f729 = Identifier.parse("minecraft:entity.player.attack.weak");
      f730 = Identifier.parse("minecraft:entity.player.attack.crit");
      f731 = Identifier.parse("minecraft:entity.player.attack.strong");
      f732 = Identifier.parse("minecraft:entity.player.attack.knockback");
      f733 = Identifier.parse("minecraft:entity.player.attack.sweep");
   }

   public AmbienceModule() {
      super("Ambience", Category.f24);
      String var10003 = "Weather";
      String var10005 = "Clear";
      String[] var10006 = new String[3];
      var10006[0] = "Clear";
      var10006[1] = "Rain";
      var10006[2] = "Thunder";
      this.f724 = new ModeSetting(var10003, this, var10005, var10006);
      this.f725 = new BooleanSetting("Cancel Hit Sound", this, false);
      this.f32 = new NumberSetting("Time", this, 6000.0, 0.0, 24000.0, 100.0);
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         int var2 = (int)this.f32.getValue();
         ClientLevel var3 = f0.level;
         String var4 = this.f724.getValue();
         if (var2 != this.f726 || var3 != this.f727) {
            ClientClockManagerMixin_vg var5 = (ClientClockManagerMixin_vg)var3.clockManager();
            var3.registryAccess().get(WorldClocks.OVERWORLD).ifPresent(var2x -> {
               Object var3x = var5.getClocks().get(var2x);
               if (var3x != null) {
                  ((fg)var3x).setTotalTicks(var2);
               }
            });
         }

         if (var4.equals("Rain")) {
            var3.setRainLevel(1.0F);
            var3.setThunderLevel(0.0F);
         } else if (var4.equals("Thunder")) {
            var3.setRainLevel(1.0F);
            var3.setThunderLevel(1.0F);
         } else {
            var3.setRainLevel(0.0F);
            var3.setThunderLevel(0.0F);
         }

         this.f726 = var2;
         this.f727 = var3;
      }

      if (var1 == u.f12 && u.f12.m42() instanceof ClientboundSetTimePacket) {
         var1.m9(true);
      }

      if (var1 == u.f17 && this.f725.getValue()) {
         Identifier var6 = u.f17.m47();
         if (var6.equals(f728) || var6.equals(f729) || var6.equals(f730) || var6.equals(f731) || var6.equals(f732) || var6.equals(f733)) {
            var1.m9(true);
         }
      }
   }
}
