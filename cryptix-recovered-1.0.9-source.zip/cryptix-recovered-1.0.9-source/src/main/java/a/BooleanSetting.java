package a;

public class BooleanSetting extends Setting {
   private boolean value;
   private boolean defaultValue;
   

   public boolean getValue() {
      return this.value;
   }

   public void setValue(boolean var1) {
      this.value = var1;
   }

   public BooleanSetting(String var1, Module var2, boolean var3) {
      super(var1, var2);
      this.defaultValue = var3;
      this.value = var3;
   }

   public boolean getDefaultValue() {
      return this.defaultValue;
   }
}
