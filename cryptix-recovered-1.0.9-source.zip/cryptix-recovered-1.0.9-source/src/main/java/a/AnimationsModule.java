package a;

import java.nio.charset.StandardCharsets;

public class AnimationsModule extends Module {
   public BooleanSetting f41;
   public NumberSetting f38;
   public NumberSetting f36;
   public NumberSetting f34;
   public NumberSetting f35;
   public BooleanSetting f39;
   public ModeSetting f33;
   public NumberSetting f37;
   public BooleanSetting f40;
   

   public AnimationsModule() {
      super("Animations", Category.f24);
      String var10003 = "Mode";
      String var10005 = "None";
      String[] var10006 = new String[3];
      var10006[0] = "None";
      var10006[1] = "1.7";
      var10006[2] = "Exhibition";
      this.f33 = new ModeSetting(var10003, this, var10005, var10006);
      this.f34 = new NumberSetting("Scale", this, 1.0, 0.1, 2.0, 0.1);
      this.f35 = new NumberSetting("X", this, 0.0, -2.0, 2.0, 0.05);
      this.f36 = new NumberSetting("Y", this, 0.0, -2.0, 2.0, 0.05);
      this.f37 = new NumberSetting("Z", this, 0.0, -2.0, 2.0, 0.05);
      this.f38 = new NumberSetting("Swing Time", this, 1.0, 0.5, 5.0, 0.1);
      this.f39 = new BooleanSetting("Only While Blocking", this, false);
      this.f40 = new BooleanSetting("Remove Sneak Anim", this, false);
      this.f41 = new BooleanSetting("Old Body Yaw", this, false);
   }

   
}
