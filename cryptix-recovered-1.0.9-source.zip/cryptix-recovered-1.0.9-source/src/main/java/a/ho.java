package a;

import com.cryptix.script.Script;
import com.cryptix.script.ScriptManager;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class ho extends kf implements ve {
   private final Map<String,Boolean> f187 = new HashMap<>();
   

   @Override
   public void m87(GuiGraphicsExtractor var1) {
      int var2 = oo.m30();
      var1.fill(this.f4, this.f5, this.f4 + 100, this.f5 + 15, var2);
      var1.text(ve.f0.font, this.f3, this.f4 + 4, this.f5 + 3, -1);
      int var3 = this.f5 + 17;
      String[] var4 = ScriptManager.list();
      int var5 = var4.length;

      for (int var6 = 0; var6 < var5; var6++) {
         String var7 = var4[var6];
         Script var8 = ScriptManager.get(var7);
         int var9 = var8 != null && var8.isEnabled() ? 1 : 0;
         var1.fill(this.f4, var3 - 2, this.f4 + 100, var3 + 10, -2146430960);
         var1.text(ve.f0.font, var7, this.f4 + 4, var3, var9 != 0 ? var2 : -1426063361);
         var3 += 12;
         if (this.f187.getOrDefault(var7, Boolean.valueOf(false))) {
            var1.fill(this.f4, var3 - 2, this.f4 + 100, var3 + 10, -2145378272);
            var1.text(ve.f0.font, "Load", this.f4 + 8, var3, -1426063361);
            var3 += 12;
         }
      }

      var1.fill(this.f4, var3 - 2, this.f4 + 100, var3 + 10, -1440590558);
      var1.text(ve.f0.font, "Open Folder", this.f4 + 4, var3, -11141291);
   }

   

   @Override
   public void m90(double var1, double var3, int var5) {
      int var6 = this.f5 + 17;
      String[] var7 = ScriptManager.list();
      int var8 = var7.length;

      for (int var9 = 0; var9 < var8; var9++) {
         String var10 = var7[var9];
         if (var1 >= this.f4 && var1 <= this.f4 + 100 && var3 >= var6 && var3 <= var6 + 12) {
            if (var5 == 1) {
               ScriptManager.toggle(var10);
               CryptixClient.sendPrefixedMessage("Toggled Script: §a" + var10);
               return;
            }

            if (var5 == 3) {
               this.f187.put(var10, Boolean.valueOf((!this.f187.getOrDefault(var10, Boolean.valueOf(false)))));
            }
         }

         var6 += 12;
         if (this.f187.getOrDefault(var10, Boolean.valueOf(false))) {
            if (var1 >= this.f4 && var1 <= this.f4 + 100 && var3 >= var6 && var3 <= var6 + 12 && var5 == 1) {
               ScriptManager.reload(var10);
               CryptixClient.sendPrefixedMessage("Reloaded Script: §a" + var10);
               return;
            }

            var6 += 12;
         }
      }

      if (var1 >= this.f4
         && var1 <= this.f4 + 100
         && var3 >= var6 - 2
         && var3 <= var6 + 10
         && var5 == 1) {
         ScriptManager.openFolder();
      }
   }

   public ho(String var1, int var2, int var3) {
      super(var1, var2, var3, null);
   }
}
