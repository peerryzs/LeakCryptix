package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.client.User;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;

public class SessionInfoModule extends Module {
   private String f873;
   private int f871;
   private String f864;
   private final StringBuilder f861;
   private int f870;
   private int f868;
   private long f867;
   private int f869;
   private String f874;
   private long f860 = 0L;
   private int f872;
   private String f862;
   private User f866;
   private String f865;
   private String f863;
   

   @Override
   public void onEnable() {
      if (this.f870 == -1 || this.f871 == -1) {
         this.f870 = bt.m71(this.f865);
         this.f871 = (int)(this.f870 * 0.5);
         this.f872 = bt.m71(this.f862);
      }
   }

   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         long var2 = System.currentTimeMillis();
         if (f0.getUser() != this.f866) {
            this.f867 = var2;
            this.f868 = 0;
            this.f869 = 0;
            this.f863 = "Kills: 0";
            this.f864 = "Wins: 0";
            this.f866 = f0.getUser();
            if (this.f866 != null) {
               String var4 = this.f866.getName();
               this.f873 = "void by " + var4;
               this.f874 = "killed by " + var4;
            }
         }

         if (var2 >= this.f860) {
            this.f860 = var2 + 1000L;
            long var18 = (var2 - this.f867) / 1000L;
            long var6 = var18 / 3600L;
            long var8 = var18 - var6 * 3600L;
            long var10 = var8 / 60L;
            long var12 = var8 - var10 * 60L;
            this.f861.setLength(0);
            this.f861.append("Time: ");
            if (var6 < 10L) {
               this.f861.append((char)48);
            }

            this.f861.append(var6).append((char)58);
            if (var10 < 10L) {
               this.f861.append((char)48);
            }

            this.f861.append(var10).append((char)58);
            if (var12 < 10L) {
               this.f861.append((char)48);
            }

            this.f861.append(var12);
            this.f862 = this.f861.toString();
            this.f870 = bt.m71(this.f865);
            this.f871 = (int)(this.f870 * 0.5);
            this.f872 = bt.m71(this.f862) + 10;
         }
      }

      if (var1 == u.f12) {
         Packet var14 = u.f12.m42();
         if (var14 instanceof ClientboundSystemChatPacket var3) {
            String var19 = var3.content().getString();
            if (var19.contains(this.f873) || var19.contains(this.f874)) {
               this.f868 = this.f868 + 1;
               this.f863 = "Kills: " + this.f868;
            }
         }

         if (var14 instanceof ClientboundSetTitleTextPacket var16) {
            String var20 = var16.text().getString();
            if (var20.contains("Victory!") || var20.contains("Victory") || var20.equals("\u00a76\u00a7lVICTORY!")) {
               this.f869 = this.f869 + 1;
               this.f864 = "Wins: " + this.f869;
            }
         }
      }

      if (var1 == u.f8) {
         GuiGraphicsExtractor var15 = u.f8.m76();
         int var17 = oo.m30();
         int var21 = 20;
         int var5 = 53;
         int var22 = 5;
         int var7 = (int)(this.f872 * 0.5);
         var15.fill(var22, var21, var22 + this.f872, var21 + var5, -2147483648);
         var15.outline(var22, var21, this.f872, var5, var17);
         bt.m70(var15, this.f865, var22 + var7 - this.f871, 25, var17);
         bt.m70(var15, this.f862, 10, 37, -1);
         bt.m70(var15, this.f863, 10, 49, -1);
         bt.m70(var15, this.f864, 10, 61, -1);
      }
   }

   public SessionInfoModule() {
      super("SessionInfo", Category.f24);
      this.f861 = new StringBuilder(14);
      this.f862 = "00:00:00";
      this.f863 = "Kills: 0";
      this.f864 = "Wins: 0";
      this.f865 = "Session";
      this.f867 = 0L;
      this.f870 = -1;
      this.f871 = -1;
      this.f872 = 0;
   }
}
