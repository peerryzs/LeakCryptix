package a;

import java.nio.charset.StandardCharsets;
import mixins.LivingEntityMixin_pz;

public class NoJumpDelayModule extends Module {
   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         ((LivingEntityMixin_pz)f0.player).setNoJumpDelay(0);
      }
   }

   

   public NoJumpDelayModule() {
      super("NoJumpDelay", Category.f25);
   }
}
