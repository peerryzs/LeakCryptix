package a;

import java.nio.ByteBuffer;
import java.util.HashSet;
import java.util.Set;
import org.lwjgl.sdl.SDLKeyboard;

public class x implements ve {
   private static final Set f53 = new HashSet();
   private static ByteBuffer f54;
   

   public static void m7() {
      if (ve.f0.gui.screen() == null) {
         f54 = SDLKeyboard.SDL_GetKeyboardState();

         for (Module var1 : ModuleManager.getModules()) {
            int var2 = var1.getKeyBind();
            if (var2 > 0) {
               int var3 = var2 < f54.limit() && f54.get(var2) != 0 ? 1 : 0;
               if (var3 == 0) {
                  f53.remove(var2);
               } else if (f53.add(var2)) {
                  for (Module var5 : ModuleManager.getModules()) {
                     if (var5.getKeyBind() == var2) {
                        var5.toggle();
                     }
                  }
               }
            }
         }
      }
   }
}
