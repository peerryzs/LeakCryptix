package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;

public class AutoGGModule extends Module {
   private static final String f393 = "";
   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f12 && u.f12.m42() instanceof ClientboundSetTitleTextPacket var3) {
         String var4 = var3.text().getString().replace("!", f393).toLowerCase();
         if (var4.contains("defeat") || var4.contains("game over")) {
            f0.getConnection().sendChat("gg");
         } else if (var4.contains("victory")) {
            f0.getConnection().sendChat("cryptix on top");
         }
      }
   }

   public AutoGGModule() {
      super("AutoGG", Category.f25);
   }

   
}
