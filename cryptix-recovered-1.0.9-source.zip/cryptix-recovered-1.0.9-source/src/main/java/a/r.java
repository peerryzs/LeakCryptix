package a;

import java.util.List;

public abstract class r {
   private Module[] f84 = new Module[ModuleManager.getModules().size()];
   private int f86;
   private boolean f85;
   

   public void m9(boolean var1) {
      this.f85 = var1;
   }

   public boolean m8() {
      return this.f85;
   }

   public void m11() {
      List var1 = ModuleManager.getModules();
      this.f86 = 0;
      int var2 = 0;

      for (int var3 = var1.size(); var2 < var3; var2++) {
         Module var4 = (Module)var1.get(var2);
         if (var4.isEnabled()) {
            int var5 = var4.getEventPriority(this);

            int var6;
            for (var6 = this.f86 - 1; var6 >= 0 && this.f84[var6].getEventPriority(this) > var5; var6--) {
               this.f84[var6 + 1] = this.f84[var6];
            }

            this.f84[var6 + 1] = var4;
            this.f86 = this.f86 + 1;
         }
      }
   }

   public void m10() {
      this.f85 = false;

      for (int var1 = 0; var1 < this.f86; var1++) {
         this.f84[var1].onEvent(this);
      }
   }
}
