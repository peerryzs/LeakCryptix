package a;

public class iw {
   private static float f1009 = 1.0F;
   

   public static float m58() {
      return f1009;
   }

   public static void m57(float var0) {
      f1009 = var0;
   }

   public static boolean m60() {
      return (f1009 == 1.0F);
   }

   public static void m59() {
      f1009 = 1.0F;
   }
}
