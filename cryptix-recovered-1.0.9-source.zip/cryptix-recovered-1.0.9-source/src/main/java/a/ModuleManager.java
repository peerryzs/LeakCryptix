package a;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;

public class ModuleManager {
   public static BedAuraModule f35;
   public static LongJumpModule f37;
   public static ScoreboardModule f34;
   public static AntiFireModule f33;
   private static List<Module> f248;
   public static WhitelistModule f32;
   public static KeepSprintModule f38;
   public static AntiSwimModule f39;
   public static HotbarModule f42;
   public static ThemeModule f26;
   private static List<Module> f249;
   public static CombatModuleNative f28;
   public static AnimationsModule f36;
   public static CapeModule f40;
   public static VelocityModule f30;
   public static ScaffoldModuleNative f31;
   public static ClickGUIModule f41;
   public static HUDModule f27;
   public static AntiBotModule f29;
   

   public static void initializeSortedModules() {
      f249 = new ArrayList(f248);
      sortModulesByWidth();
   }

   public static List<Module> getModulesByCategory(Category var0) {
      ArrayList var1 = new ArrayList();

      for (Module var3 : f248) {
         if (var3.getCategory() == var0) {
            var1.add(var3);
         }
      }

      return var1;
   }

   public static void sortModulesByWidth() {
      f249.sort((var0, var1) -> Integer.compare(bt.m71(var1.getDisplayName()), bt.m71(var0.getDisplayName())));
   }

   public static List<Module> getSortedModules() {
      return f249;
   }

   public static void initialize() {
      f248 = new ArrayList();
      f248.add(new AimAssistModule());
      f248.add(f29 = new AntiBotModule());
      f248.add(new AutoClickerModule());
      f248.add(new CriticalsModule());
      f248.add(new CrystalAuraModule());
      f248.add(f28 = new CombatModuleNative());
      f248.add(new SprintResetModule());
      f248.add(new TriggerBotModule());
      f248.add(f30 = new VelocityModule());
      f248.add(f39 = new AntiSwimModule());
      f248.add(new AutoWalkModule());
      f248.add(new FlightModule());
      f248.add(new InvMoveModule());
      f248.add(f38 = new KeepSprintModule());
      f248.add(f37 = new LongJumpModule());
      f248.add(new MoveFixModule());
      f248.add(new NoSlowModule());
      f248.add(new SpeedModule());
      f248.add(new SprintModule());
      f248.add(new StasisModule());
      f248.add(new TimerModule());
      f248.add(new AutoBlockInModule());
      f248.add(new AutoHeadModule());
      f248.add(new AutoRodModule());
      f248.add(new AutoToolModule());
      f248.add(new AutoTotemModule());
      f248.add(new BacktrackModule());
      f248.add(f35 = new BedAuraModule());
      f248.add(new ChestStealerModule());
      f248.add(new EagleModule());
      f248.add(new FastMineModule());
      f248.add(new FastPlaceModule());
      f248.add(new InvManagerModule());
      f248.add(new LagRangeModule());
      f248.add(new NoFallModule());
      f248.add(f31 = new ScaffoldModuleNative());
      f248.add(new AmbienceModule());
      f248.add(f36 = new AnimationsModule());
      f248.add(f33 = new AntiFireModule());
      f248.add(new BedPlatesModule());
      f248.add(new BreakProgressModule());
      f248.add(f40 = new CapeModule());
      f248.add(f41 = new ClickGUIModule());
      f248.add(new FullBrightModule());
      f248.add(f42 = new HotbarModule());
      f248.add(f27 = new HUDModule());
      f248.add(new NameTagsModule());
      f248.add(new PlayerESPModule());
      f248.add(f34 = new ScoreboardModule());
      f248.add(new SessionInfoModule());
      f248.add(new TargetHUDModule());
      f248.add(f26 = new ThemeModule());
      f248.add(new AlertsModule());
      f248.add(new AutoGGModule());
      f248.add(new AutoPlayModule());
      f248.add(new DisablerModule());
      f248.add(new NoClickDelayModule());
      f248.add(new NoJumpDelayModule());
      f248.add(f32 = new WhitelistModule());
      f248.add(new WindChargeModule());
   }

   public static void notifyModuleStateChanged() {
      if (f41.f43.getValue()) {
         Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
      }
   }

   public static List<Module> getModules() {
      return f248;
   }
}
