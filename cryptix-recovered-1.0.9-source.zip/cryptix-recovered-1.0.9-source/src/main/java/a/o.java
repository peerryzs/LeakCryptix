package a;

public class o extends r {
   private int f89;
   private int f88;
   private int f87;
   

   public o m12(int var1, int var2, int var3) {
      this.f87 = var1;
      this.f88 = var2;
      this.f89 = var3;
      return this;
   }

   public boolean m16() {
      return (this.f88 == 1);
   }

   public int m15() {
      return this.f89;
   }

   public boolean m21() {
      return (this.f87 == 2);
   }

   public int m13() {
      return this.f87;
   }

   public boolean m17() {
      return (this.f88 == 0);
   }

   public boolean m18() {
      return (this.f88 == 2);
   }

   public boolean m19() {
      return (this.f87 == 0);
   }

   public boolean m20() {
      return (this.f87 == 1);
   }

   public int m14() {
      return this.f88;
   }
}
