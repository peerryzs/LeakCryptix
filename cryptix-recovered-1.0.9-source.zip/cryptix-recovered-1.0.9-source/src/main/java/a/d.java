package a;

import com.cryptix.script.ScriptManager;

public class d extends r {
   private float f113;
   private boolean f116;
   private boolean f117;
   private float f112;
   private float f115;
   private float f114;
   private boolean rotationInitialized;
   

   public void m68(float var1) {
      this.f114 = var1;
   }

   public float m69() {
      return this.f113;
   }

   public float m66() {
      return this.f115;
   }

   public void m67(float var1) {
      this.f115 = var1;
   }

   public void m72(boolean var1) {
      this.f116 = var1;
   }

   public void m70(float var1) {
      this.f113 = var1;
   }

   public boolean m73() {
      return this.f117;
   }

   public void m74(boolean var1) {
      this.f117 = var1;
   }

   public d m62(float var1, float var2) {
      x.m7();
      yp.m23();
      ScriptManager.onUpdate();
      bt.m69(ModuleManager.f26.f51.getValue());
      this.f114 = this.f112;
      this.f115 = this.f113;
      this.f112 = this.rotationInitialized ? ClientRotationMath.continuousYaw(var1, this.f114) : var1;
      this.rotationInitialized = true;
      this.f113 = var2;
      this.f116 = false;
      this.f117 = true;
      return this;
   }

   public boolean m71() {
      return this.f116;
   }

   public void m64(float var1) {
      this.f112 = var1;
   }

   public float m63() {
      return this.f112;
   }

   public float m65() {
      return this.f114;
   }
}
