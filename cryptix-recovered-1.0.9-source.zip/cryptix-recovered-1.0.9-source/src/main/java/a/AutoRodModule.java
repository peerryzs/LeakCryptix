package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

public class AutoRodModule extends Module {
   private int f526;
   private boolean f528;
   private int f527;
   private int f525;
   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         if (this.f528) {
            if ((this.f526 = this.f526 + 1) >= 5) {
               f0.player.getInventory().setSelectedSlot(this.f527);
               this.f527 = -1;
               this.f526 = 0;
               this.f528 = false;
            }

            return;
         }

         if ((this.f525 = this.f525 + 1) < 5) {
            return;
         }

         this.f525 = 0;
         if (!(ModuleManager.f28.f18 instanceof Player var2)) {
            return;
         }

         if (f0.player.distanceToSqr(var2) <= 12.25) {
            return;
         }

         int var16 = -1;

         for (int var4 = 0; var4 < 9; var4++) {
            if (f0.player.getInventory().getItem(var4).is(Items.FISHING_ROD)) {
               var16 = var4;
               break;
            }
         }

         if (var16 == -1) {
            return;
         }

         this.f527 = f0.player.getInventory().getSelectedSlot();
         Vec3 var17 = f0.player.getEyePosition();
         Vec3 var5 = var2.getEyePosition();
         double var6 = var5.x - var17.x;
         double var8 = var5.y - var17.y;
         double var10 = var5.z - var17.z;
         double var12 = Math.sqrt(var6 * var6 + var10 * var10);
         float var14 = (float)(Math.toDegrees(Math.atan2(var10, var6)) - 90.0);
         float var15 = (float)(-Math.toDegrees(Math.atan2(var8, var12)));
         u.f6.m64(var14);
         u.f6.m70(var15);
         if (f0.player.getInventory().getSelectedSlot() != var16) {
            f0.player.getInventory().setSelectedSlot(var16);
         }

         f0.gameMode.useItem(f0.player, InteractionHand.MAIN_HAND);
         this.f526 = 0;
         this.f528 = true;
      }
   }

   public AutoRodModule() {
      super("AutoRod", Category.f23);
      this.f527 = -1;
   }

   
}
