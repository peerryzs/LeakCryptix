package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.network.protocol.common.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.world.phys.Vec3;

public class WhitelistModule extends Module {
   private boolean f414;
   public boolean f20;
   public Vec3 f21;
   

   public WhitelistModule() {
      super("Whitelist", Category.f25);
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f12) {
         if (u.f12.m42() instanceof ClientboundDisconnectPacket) {
            this.f20 = false;
            this.f21 = null;
         }

         if (u.f12.m42() instanceof ClientboundSystemChatPacket var2) {
            String var5 = var2.content().getString();
            if (var5.contains("Protect your bed and destroy the enemy")) {
               this.f414 = true;
            }
         }

         if (u.f12.m42() instanceof ClientboundPlayerPositionPacket var4 && this.f414) {
            this.f20 = true;
            this.f414 = false;
            System.out.println("whitelist");
            this.f21 = var4.change().position();
         }
      }
   }

   
}
