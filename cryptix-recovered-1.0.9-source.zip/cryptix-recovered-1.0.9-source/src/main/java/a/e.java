package a;

import net.minecraft.client.Minecraft;

public class e extends r {
   private double f106;
   private boolean f110;
   private float f108;
   private double f105;
   private double f107;
   private float f109;
   private boolean f111;
   

   public double m50() {
      return this.f105;
   }

   public double m52() {
      return this.f106;
   }

   public float m57() {
      return this.f109;
   }

   public void m53(double var1) {
      this.f106 = var1;
   }

   public boolean m60() {
      return this.f111;
   }

   public void m61(boolean var1) {
      this.f111 = var1;
   }

   public void m51(double var1) {
      this.f105 = var1;
   }

   public e m49(double var1, double var3, double var5, boolean var7, boolean var8) {
      if (!u.f6.m73()) {
         this.f108 = u.f6.m63();
         this.f109 = u.f6.m69();
      }

      if (u.f6.m63() != Minecraft.getInstance().player.getYRot()) {
         Minecraft.getInstance().player.yBodyRot = u.f6.m63();
      }

      if (ModuleManager.f36.isEnabled() && ModuleManager.f36.f41.getValue()) {
         Minecraft.getInstance().player.yBodyRot = xt.m50(u.f6.m63(), Minecraft.getInstance().player.yBodyRot);
      }

      this.f105 = var1;
      this.f106 = var3;
      this.f107 = var5;
      this.f110 = var7;
      this.f111 = var8;
      Minecraft.getInstance().player.yHeadRot = u.f6.m63();
      return this;
   }

   public float m56() {
      return this.f108;
   }

   public boolean m58() {
      return this.f110;
   }

   public void m59(boolean var1) {
      this.f110 = var1;
   }

   public void m55(double var1) {
      this.f107 = var1;
   }

   public double m54() {
      return this.f107;
   }
}
