package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ServerboundKeepAlivePacket;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.phys.Vec2;

public class DisablerModule extends Module {
   private final BooleanSetting f408;
   private final BooleanSetting f407;
   private final BooleanSetting f406;
   int ticks;
   

   public DisablerModule() {
      super("Disabler", Category.f25);
      this.f406 = new BooleanSetting("KeepAlive Packet", this, false);
      this.f407 = new BooleanSetting("Sprint Packet", this, false);
      this.f408 = new BooleanSetting("Watchdog InvMove", this, false);
      this.ticks = -1;
   }

   

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f9) {
         if (this.ticks > 0) {
            f0.player.input.keyPresses = new Input(
               false, false, false, false, false, false, false
            );
            mixins.ClientInputMixin_rn var2 = (mixins.ClientInputMixin_rn)f0.player.input;
            var2.setMoveVector(new Vec2(0.0F, 0.0F));
            this.ticks = this.ticks - 1;
         }
      } else if (var1 == u.f11) {
         Packet var5 = u.f11.m45();
         if (this.f406.getValue() && var5 instanceof ServerboundKeepAlivePacket) {
            var1.m9(true);
         }

         if (this.f407.getValue()
            && var5 instanceof ServerboundPlayerCommandPacket var3
            && (var3.getAction() == Action.START_SPRINTING || var3.getAction() == Action.STOP_SPRINTING)) {
            var1.m9(true);
         }

         if (this.f408.getValue() && u.f11.m45() instanceof ServerboundPlayerCommandPacket var6 && var6.getAction() == Action.OPEN_INVENTORY) {
            var1.m9(true);
         }

         if (this.f408.getValue() && var5 instanceof ServerboundContainerClickPacket var7) {
            Minecraft var8 = Minecraft.getInstance();
            if (var7.containerInput() == ContainerInput.PICKUP && var8.getConnection() != null && var8.player.containerMenu instanceof InventoryMenu) {
               this.ticks = 5;
            }
         }
      }
   }
}
