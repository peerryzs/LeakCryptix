package a;

import java.nio.charset.StandardCharsets;
import mixins.MultiPlayerGameModeMixin_sg;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.Direction.Plane;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundPunchPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.SwingAnimation;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.phys.Vec3;

public class BedAuraModule extends Module {
   private final NumberSetting f557;
   private int f570;
   private BlockPos f567;
   private final BooleanSetting f563;
   private int f569;
   private final NumberSetting f556;
   private float f565;
   private int f566;
   public int f26;
   public boolean f25;
   private final NumberSetting f558;
   private final BooleanSetting f564;
   private final BooleanSetting f561;
   private final MutableBlockPos f571;
   public BlockPos f24;
   private final BooleanSetting f559;
   private final BooleanSetting f560;
   public float f23;
   private final BooleanSetting f562;
   private int f568;
   

   private Direction pm$103(float var1, float var2) {
      Vec3 var3 = Vec3.directionFromRotation(var2, var1);
      double var4 = Math.abs(var3.x);
      double var6 = Math.abs(var3.y);
      double var8 = Math.abs(var3.z);
      if (var6 > var4 && var6 > var8) {
         return var3.y > 0.0 ? Direction.DOWN : Direction.UP;
      } else if (var4 > var8) {
         return var3.x > 0.0 ? Direction.WEST : Direction.EAST;
      } else {
         return var3.z > 0.0 ? Direction.NORTH : Direction.SOUTH;
      }
   }

   public BedAuraModule() {
      super("BedAura", Category.f23);
      this.f556 = new NumberSetting("Range", this, 5.0, 1.0, 8.0, 0.5);
      this.f557 = new NumberSetting("Speed", this, 1.0, 1.0, 2.0, 0.05);
      this.f558 = new NumberSetting("Break Delay", this, 2.0, 1.0, 4.0, 1.0);
      this.f559 = new BooleanSetting("Surrounding", this, false);
      this.f560 = new BooleanSetting("Allow KillAura", this, false);
      this.f561 = new BooleanSetting("Only S/S Rotate", this, false);
      this.f562 = new BooleanSetting("Watchdog Mode", this, false);
      this.f563 = new BooleanSetting("Silent Swing", this, false);
      this.f564 = new BooleanSetting("Ground Spoof", this, false);
      this.f566 = -1;
      this.f571 = new MutableBlockPos();
   }

   @Override
   public void onDisable() {
      this.f25 = false;
   }

   private void pm$102() {
      if (this.f23 > 0.0F && this.f24 != null) {
         Direction var1 = this.pm$103(u.f6.m63(), u.f6.m69());
         ((MultiPlayerGameModeMixin_sg)f0.gameMode).invokeStartPrediction(f0.level, var2 -> new ServerboundPlayerActionPacket(Action.ABORT_DESTROY_BLOCK, this.f24, var1, var2));
         f0.level.destroyBlockProgress(f0.player.getId(), this.f24, -1);
         this.f24 = null;
      }

      this.f565 = this.f23;
      this.f23 = 0.0F;
      if (this.f566 != -1) {
         f0.player.getInventory().setSelectedSlot(this.f566);
         this.f566 = -1;
      }

      if (this.f568 < 0) {
         this.f568 = this.f568 + 1;
      }

      this.f26 = 0;
      this.f567 = null;
      this.f24 = null;
   }

   private void pm$104() {
      if (!this.f563.getValue()) {
         f0.player.swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, false);
      }

      f0.getConnection().send(ServerboundPunchPacket.INSTANCE);
   }

   private BlockPos pm$100() {
      if (f0.player.isUsingItem()) {
         return null;
      } else {
         Vec3 var1 = ModuleManager.f32.f21;
         if (var1 != null && ModuleManager.f32.f20 && f0.player.distanceToSqr(var1) < 600.0) {
            return null;
         } else if (this.f567 != null && f0.level.getBlockState(this.f567).getBlock() instanceof BedBlock) {
            return this.f567;
         } else {
            BlockPos var2 = f0.player.blockPosition();
            int var3 = var2.getX();
            int var4 = var2.getY();
            int var5 = var2.getZ();
            int var6 = (int)this.f556.getValue();

            for (int var7 = var3 - var6; var7 <= var3 + var6; var7++) {
               for (int var8 = var4 - var6; var8 <= var4 + var6; var8++) {
                  for (int var9 = var5 - var6; var9 <= var5 + var6; var9++) {
                     this.f571.set(var7, var8, var9);
                     BlockState var10 = f0.level.getBlockState(this.f571);
                     if (var10.getBlock() instanceof BedBlock) {
                        return new BlockPos(this.f571.getX(), this.f571.getY(), this.f571.getZ());
                     }
                  }
               }
            }

            return null;
         }
      }
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f16 && f0.gui.screen() == null && this.f567 != null) {
         var1.m9(true);
      }

      if (var1 == u.f4 && this.f564.getValue() && this.f567 != null) {
         u.f4.m59(true);
      }

      if (var1 == u.f6) {
         this.f25 = false;
         float var2 = this.f567 == null && this.f568 >= 0 ? 0.0F : 255.0F;
         this.f570 = this.f569;
         this.f569 = (int)Mth.lerp(0.5F, this.f569, var2);
         if (f0.gui.screen() != null) {
            this.pm$102();
            return;
         }

         if ((ModuleManager.f28.f18 != null || ModuleManager.f28.f17) && !this.f560.getValue() || ModuleManager.f31.isEnabled()) {
            this.pm$102();
            return;
         }

         if (this.f568 < 0) {
            this.pm$102();
            return;
         }

         BlockPos var3 = this.pm$100();
         if (var3 != null && this.f567 != null) {
            BlockState var4 = f0.level.getBlockState(var3);
            BlockState var5 = f0.level.getBlockState(this.f567);
            if (var4 != var5) {
               this.pm$102();
               return;
            }
         }

         if (var3 != null) {
            if (f0.player.distanceToSqr(var3.getX() + 0.5, var3.getY() + 0.5, var3.getZ() + 0.5) > this.f556.getValue() * this.f556.getValue()) {
               this.pm$102();
               return;
            }

            BlockState var16 = f0.level.getBlockState(var3);
            if (var16.getBlock() == Blocks.AIR) {
               this.pm$102();
               return;
            }

            this.pm$101(var3, var16);
         } else {
            this.pm$102();
         }

         this.f567 = var3;
      }

      if (var1 == u.f8 && (this.f23 > 0.0F || this.f569 > 5)) {
         float var14 = 100.0F;
         float var15 = 4.0F;
         float var17 = f0.getWindow().getGuiScaledWidth() * 0.5F - var14 * 0.5F;
         float var18 = f0.getWindow().getGuiScaledHeight() * 0.5F + 20.0F;
         float var6 = !f0.player.onGround() && this.f562.getValue() ? 5.0F : 1.0F;
         float var7 = u.f8.m78();
         float var8 = this.f565 + (this.f23 - this.f565) * var7;
         float var9 = (float)Math.min((double)(var8 / var6), 1.0);
         int var10 = (int)(this.f570 + (this.f569 - this.f570) * var7);
         int var11 = oo.m30() & 16777215 | var10 << 24;
         int var12 = var10 << 24;
         int var13 = (int)(var10 * 0.5F) << 24 | 6316128;
         th.m63(u.f8, (int)var17, (int)var18, (int)var14, (int)var15, var9, var12, var13, var11);
      }
   }

   

   private void pm$101(BlockPos var1, BlockState var2) {
      if (this.f559.getValue()) {
         BlockPos var3 = var1.above();
         Direction var4 = (Direction)var2.getValue(BedBlock.FACING);
         BedPart var5 = (BedPart)var2.getValue(BedBlock.PART);
         BlockPos var6 = var5 == BedPart.HEAD ? var1.relative(var4.getOpposite()) : var1.relative(var4);
         int var7 = 0;

         for (Direction var9 : Plane.HORIZONTAL) {
            BlockPos var10 = var1.relative(var9);
            BlockPos var11 = var6.relative(var9);
            BlockState var12 = f0.level.getBlockState(var10);
            BlockState var13 = f0.level.getBlockState(var11);
            if (var12.getBlock() == Blocks.AIR) {
               var7 = 1;
               break;
            }

            if (var13.getBlock() == Blocks.AIR) {
               var7 = 1;
               break;
            }
         }

         if (var7 == 0) {
            BlockState var27 = f0.level.getBlockState(var3);
            if (!var27.isAir()) {
               var1 = var3;
               var2 = var27;
               int var28 = -1;
               float var30 = 1.0F;

               for (int var31 = 0; var31 < 9; var31++) {
                  ItemStack var33 = f0.player.getInventory().getItem(var31);
                  float var34 = var33.getDestroySpeed(var2);
                  if (var34 > var30) {
                     var30 = var34;
                     var28 = var31;
                  }
               }

               if (var28 != -1 && f0.player.getInventory().getSelectedSlot() != var28) {
                  this.f566 = f0.player.getInventory().getSelectedSlot();
                  f0.player.getInventory().setSelectedSlot(var28);
               }
            }
         }
      }

      if (this.f24 != null && !this.f24.equals(var1)) {
         if (this.f23 > 0.0F) {
            Direction var24 = this.pm$103(u.f6.m63(), u.f6.m69());
            ((MultiPlayerGameModeMixin_sg)f0.gameMode).invokeStartPrediction(f0.level, var2x -> new ServerboundPlayerActionPacket(Action.ABORT_DESTROY_BLOCK, this.f24, var24, var2x));
            f0.level.destroyBlockProgress(f0.player.getId(), this.f24, -1);
         }

         this.f24 = null;
         this.f565 = this.f23;
         this.f23 = 0.0F;
      } else {
         double var23 = var1.getX() + 0.5;
         double var25 = var1.getY() + 0.5;
         double var26 = var1.getZ() + 0.5;
         double var29 = var23 - f0.player.getX();
         double var32 = var25 - f0.player.getEyeY();
         double var35 = var26 - f0.player.getZ();
         double var15 = Math.sqrt(var29 * var29 + var35 * var35);
         float var17 = (float)Math.toDegrees(Math.atan2(var35, var29)) - 90.0F;
         float var18 = (float)(-Math.toDegrees(Math.atan2(var32, var15)));
         if (!this.f561.getValue() || this.f23 == 0.0F || this.f23 >= 1.0F) {
            u.f6.m64(var17);
            u.f6.m70(var18);
            this.f25 = true;
         }

         float var19 = (float)(var2.getDestroyProgress(f0.player, f0.player.level(), var1) * this.f557.getValue());
         if (u.f4.m58() && !f0.player.onGround()) {
            var19 *= 5.0F;
         }

         if (f0.player.isEyeInFluid(FluidTags.WATER) && this.f562.getValue()) {
            var19 *= 5.0F;
         }

         float var20 = 1.0F;
         if (!f0.player.onGround() && this.f562.getValue()) {
            var19 *= 5.0F;
            var20 = 5.0F;
         }

         if (!(var19 < 0.0F)) {
            if (f0.player.tickCount % 4 == 0) {
               SoundType var21 = var2.getSoundType();
               f0.getSoundManager()
                  .play(
                     new SimpleSoundInstance(
                        var21.getHitSound(),
                        SoundSource.BLOCKS,
                        (var21.getVolume() + 1.0F) * 0.125F,
                        var21.getPitch() * 0.5F,
                        SoundInstance.createUnseededRandom(),
                        var1
                     )
                  );
            }

            BlockPos var36 = var1;
            Direction var22 = this.pm$103(var17, var18);
            if (this.f23 == 0.0F) {
               ((MultiPlayerGameModeMixin_sg)f0.gameMode).invokeStartPrediction(f0.level, var2x -> new ServerboundPlayerActionPacket(Action.START_DESTROY_BLOCK, var36, var22, var2x));
            }

            if (this.f23 >= var20 + var19) {
               ((MultiPlayerGameModeMixin_sg)f0.gameMode).invokeStartPrediction(f0.level, var2x -> new ServerboundPlayerActionPacket(Action.STOP_DESTROY_BLOCK, var36, var22, var2x));
               this.pm$104();
               this.f23 = 0.0F;
               f0.gameMode.destroyBlock(var1);
               f0.level.destroyBlockProgress(f0.player.getId(), var1, -1);
               this.pm$102();
               this.f568 = (int)this.f558.getValue();
            } else {
               f0.level.destroyBlockProgress(f0.player.getId(), var1, Math.min(9, (int)(this.f23 * 10.0F / var20)));
               this.f565 = this.f23;
               this.f23 += var19;
               this.pm$104();
               this.f24 = var1;
            }
         }
      }
   }
}
