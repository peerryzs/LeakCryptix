package a;

import java.nio.charset.StandardCharsets;

public class SprintModule extends Module {
   

   public SprintModule() {
      super("Sprint", Category.f22);
   }

   @Override
   public void onDisable() {
      f0.options.keySprint.setDown(false);
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         f0.options.keySprint.setDown(true);
      }
   }

   
}
