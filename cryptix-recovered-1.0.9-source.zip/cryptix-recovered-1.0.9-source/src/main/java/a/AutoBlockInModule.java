package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class AutoBlockInModule extends Module {
   private final BooleanSetting f516;
   private final Direction[] f517;
   private int f518;
   private final NumberSetting f515;
   

   

   public AutoBlockInModule() {
      super("AutoBlockIn", Category.f24);
      this.f515 = new NumberSetting("Delay", this, 1.0, 0.0, 4.0, 1.0);
      this.f516 = new BooleanSetting("Only While Sneaking", this, false);
      Direction[] var10001 = new Direction[6];
      var10001[0] = Direction.DOWN;
      var10001[1] = Direction.UP;
      var10001[2] = Direction.NORTH;
      var10001[3] = Direction.SOUTH;
      var10001[4] = Direction.WEST;
      var10001[5] = Direction.EAST;
      this.f517 = var10001;
   }

   private void pm$97(BlockPos var1) {
      if (f0.level.getBlockState(var1).canBeReplaced()) {
         if (!(this.f518 < this.f515.getValue())) {
            Vec3 var2 = f0.player.getEyePosition();
            Direction[] var3 = this.f517;
            int var4 = var3.length;

            for (int var5 = 0; var5 < var4; var5++) {
               Direction var6 = var3[var5];
               BlockPos var7 = var1.relative(var6.getOpposite());
               if (f0.level.getBlockState(var7).isFaceSturdy(f0.level, var7, var6)) {
                  Vec3 var8 = Vec3.atCenterOf(var7).add(var6.getStepX() * 0.499, var6.getStepY() * 0.499, var6.getStepZ() * 0.499);
                  double var9 = var8.x - var2.x;
                  double var11 = var8.y - var2.y;
                  double var13 = var8.z - var2.z;
                  double var15 = Math.sqrt(var9 * var9 + var13 * var13);
                  float var17 = (float)Math.toDegrees(Math.atan2(var13, var9)) - 90.0F;
                  float var18 = (float)(-Math.toDegrees(Math.atan2(var11, var15)));
                  Vec3 var19 = Vec3.directionFromRotation(var18, var17).scale(4.5);
                  BlockHitResult var20 = f0.level.clip(new ClipContext(var2, var2.add(var19), Block.COLLIDER, Fluid.NONE, f0.player));
                  if (var20.getBlockPos().equals(var7) && var20.getDirection() == var6) {
                     f0.player.setYRot(var17);
                     f0.player.setXRot(var18);
                     f0.gameMode.useItemOn(f0.player, InteractionHand.MAIN_HAND, var20);
                     this.f518 = 0;
                     return;
                  }
               }
            }
         }
      }
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         if (this.f516.getValue() && !f0.options.keyShift.isDown()) {
            this.f518 = 0;
            return;
         }

         this.f518 = this.f518 + 1;
         BlockPos var2 = f0.player.blockPosition();
         this.pm$97(var2.relative(Direction.NORTH));
         this.pm$97(var2.relative(Direction.NORTH).relative(Direction.UP));
         this.pm$97(var2.relative(Direction.SOUTH));
         this.pm$97(var2.relative(Direction.SOUTH).relative(Direction.UP));
         this.pm$97(var2.relative(Direction.EAST));
         this.pm$97(var2.relative(Direction.EAST).relative(Direction.UP));
         this.pm$97(var2.relative(Direction.WEST));
         this.pm$97(var2.relative(Direction.WEST).relative(Direction.UP));
      }
   }
}
