package a;

import java.nio.charset.StandardCharsets;

public class z extends m {
   

   @Override
   public void m0(String[] var1, String var2) {
      CryptixClient.sendPrefixedMessage("Available Commands:");

      for (m var4 : l.m9()) {
         String var5 = String.join(", ", var4.f2);
         CryptixClient.sendPrefixedMessage("." + var4.f1 + " §7[" + var5 + "]");
      }
   }

   

   public z() {
      String var10001 = "Help";
      String var10002 = "help";
      String[] var10003 = new String[3];
      var10003[0] = "help";
      var10003[1] = "h";
      var10003[2] = "?";
      super(var10001, var10002, var10003);
   }
}
