package a;

import net.minecraft.client.Minecraft;

public interface ve {
   Minecraft f0 = Minecraft.getInstance();
}
