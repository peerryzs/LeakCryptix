package a;

import java.nio.charset.StandardCharsets;

public class AntiSwimModule extends Module {
   

   public AntiSwimModule() {
      super("AntiSwim", Category.f22);
   }

   
}
