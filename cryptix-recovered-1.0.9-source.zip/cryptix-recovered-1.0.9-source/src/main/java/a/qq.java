package a;

import net.minecraft.network.protocol.Packet;

class qq {
   Packet packet;
   long time;
   

   qq(Packet var1, long var2) {
      this.packet = var1;
      this.time = var2;
   }
}
