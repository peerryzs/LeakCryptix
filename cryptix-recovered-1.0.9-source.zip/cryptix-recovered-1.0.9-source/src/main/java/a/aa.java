package a;

import net.minecraft.world.item.ItemStack;

record aa(int x, int y, int z, ItemStack stack) {


   

   aa(int x, int y, int z, ItemStack stack) {
      this.x = x;
      this.y = y;
      this.z = z;
      this.stack = stack;
   }

   public int z() {
      return this.z;
   }

   public ItemStack stack() {
      return this.stack;
   }

   public int x() {
      return this.x;
   }

   public int y() {
      return this.y;
   }
}
