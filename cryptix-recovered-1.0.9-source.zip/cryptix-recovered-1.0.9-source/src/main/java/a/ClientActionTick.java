package a;

/** Tracks actions within the network tick, independently of player update events. */
public final class ClientActionTick {
   private boolean acted;

   public synchronized boolean canAct() {
      return !this.acted;
   }

   public synchronized void recordAction() {
      this.acted = true;
   }

   public synchronized void endNetworkTick() {
      this.acted = false;
   }
}
