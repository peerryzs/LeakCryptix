package a;

import java.nio.charset.StandardCharsets;
import net.minecraft.world.phys.Vec3;

public class SpeedModule extends Module {
   private BooleanSetting f495;
   private int f499;
   private BooleanSetting f496;
   private ModeSetting f497;
   private ModeSetting f498;
   private BooleanSetting f494;
   

   private void pm$95() {
      this.pm$94(this.pm$96());
   }

   private double pm$96() {
      return Math.sqrt(f0.player.getDeltaMovement().x * f0.player.getDeltaMovement().x + f0.player.getDeltaMovement().z * f0.player.getDeltaMovement().z);
   }

   @Override
   public void onEvent(r var1) {
      if (var1 == u.f6) {
         if (this.f494.getValue()
            && !f0.options.keyRight.isDown()
            && !f0.options.keyLeft.isDown()
            && (!f0.player.onGround() || !f0.options.keyJump.isDown() && !this.f495.getValue())) {
            u.f6.m64(f0.player.getYRot() + 45.0F);
         }

         if (this.f496.getValue()) {
            this.pm$95();
         }

         if (f0.player.onGround()) {
            this.f499 = 0;
            String var2 = this.f497.getValue();
            int var3 = -1;
            int var10000 = var2.hashCode();
            if (var10000 == -1955878649) {
               if (var2.equals("Normal")) {
                  var3 = 0;
               }
            } else if (var10000 == 2182268) {
               if (var2.equals("Fast")) {
                  var3 = 1;
               }
            }

            switch (var3) {
               case 0:
                  f0.player.jumpFromGround();
                  f0.player.input.makeJump();
                  this.pm$94(0.29);
                  break;
               case 1:
                  f0.player.jumpFromGround();
                  f0.player.input.makeJump();
                  this.pm$94(0.48);
            }
         } else {
            this.f499 = this.f499 + 1;
            Vec3 var9 = f0.player.getDeltaMovement();
            double var11 = var9.y;
            String var5 = this.f498.getValue();
            int var6 = -1;
            int var12 = var5.hashCode();
            if (var12 == 1607715814) {
               if (var5.equals("7 tick")) {
                  var6 = 2;
               }
            } else if (var12 == 1636344965) {
               if (var5.equals("8 tick")) {
                  var6 = 1;
               }
            } else if (var12 == 1664974116) {
               if (var5.equals("9 tick")) {
                  var6 = 0;
               }
            }

            switch (var6) {
               case 0:
                  if (this.f499 == 5) {
                     var11 -= 0.16;
                  }
                  break;
               case 1:
                  if (this.f499 == 3) {
                     var11 -= 0.03;
                  }

                  if (this.f499 == 5) {
                     var11 -= 0.19;
                  }
                  break;
               case 2:
                  if (this.f499 == 4) {
                     var11 -= 0.15;
                  } else if (this.f499 == 3) {
                     var11 -= 0.04;
                  } else if (this.f499 == 5) {
                     var11 -= 0.12;
                  }
            }

            var9 = f0.player.getDeltaMovement();
            f0.player.setDeltaMovement(var9.x, var11, var9.z);
         }
      }

      if (var1 == u.f9 && this.f495.getValue() && this.f497.isMode("Disabled")) {
         f0.player.input.makeJump();
      }
   }

   @Override
   public void onEnable() {
      this.f499 = 100;
   }

   private void pm$94(double var1) {
      if (f0.player != null && !f0.player.isSpectator()) {
         float var3 = f0.player.zza;
         float var4 = f0.player.xxa;
         if (var3 != 0.0F || var4 != 0.0F) {
            float var5 = f0.player.getYRot();
            if (var3 != 0.0F) {
               if (var4 > 0.0F) {
                  var5 += var3 > 0.0F ? -45.0F : 45.0F;
               } else if (var4 < 0.0F) {
                  var5 += var3 > 0.0F ? 45.0F : -45.0F;
               }

               var4 = 0.0F;
               var3 = var3 > 0.0F ? 1.0F : -1.0F;
            }

            double var6 = Math.toRadians(var5);
            double var8 = Math.sin(var6);
            double var10 = Math.cos(var6);
            double var12 = var3 * -var8 + var4 * var10;
            double var14 = var3 * var10 + var4 * var8;
            f0.player.setDeltaMovement(var12 * var1, f0.player.getDeltaMovement().y, var14 * var1);
         }
      }
   }

   public SpeedModule() {
      super("Speed", Category.f22);
      this.f494 = new BooleanSetting("Rotate", this, false);
      this.f495 = new BooleanSetting("Jump", this, false);
      this.f496 = new BooleanSetting("Strafe", this, false);
      String var10003 = "Ground Strafe";
      String var10005 = "Disabled";
      String[] var10006 = new String[3];
      var10006[0] = "Disabled";
      var10006[1] = "Normal";
      var10006[2] = "Fast";
      this.f497 = new ModeSetting(var10003, this, var10005, var10006);
      var10003 = "FastFall";
      var10005 = "Disabled";
      var10006 = new String[4];
      var10006[0] = "Disabled";
      var10006[1] = "9 tick";
      var10006[2] = "8 tick";
      var10006[3] = "7 tick";
      this.f498 = new ModeSetting(var10003, this, var10005, var10006);
   }

   

   @Override
   public int getEventPriority(r var1) {
      return var1 == u.f6 ? -3 : 0;
   }
}
