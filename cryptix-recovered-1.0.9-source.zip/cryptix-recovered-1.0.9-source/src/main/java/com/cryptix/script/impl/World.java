package com.cryptix.script.impl;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;

public class World {
   private final ClientLevel world;
   

   public List<Entity> getEntities() {
      ArrayList var1 = new ArrayList();

      for (net.minecraft.world.entity.Entity var3 : this.world.entitiesForRendering()) {
         var1.add(new Entity(var3));
      }

      return var1;
   }

   public World(ClientLevel var1) {
      this.world = var1;
   }

   public boolean exists() {
      return (this.world != null);
   }

   public List<Entity> getPlayers() {
      ArrayList var1 = new ArrayList();

      for (Player var3 : this.world.players()) {
         var1.add(new Entity(var3));
      }

      return var1;
   }

   public Block getBlock(Vec3 var1) {
      return this.getBlock((int)var1.x, (int)var1.y, (int)var1.z);
   }

   public Block getBlock(int var1, int var2, int var3) {
      return new Block(this.world.getBlockState(new BlockPos(var1, var2, var3)));
   }

   public Entity getEntityById(int var1) {
      net.minecraft.world.entity.Entity var2 = this.world.getEntity(var1);
      return var2 == null ? null : new Entity(this.world.getEntity(var1));
   }
}
