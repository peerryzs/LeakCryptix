package com.cryptix.script.impl.packet.outgoing;

import com.cryptix.script.impl.packet.Packet;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action;

public class C0B extends Packet {
   public int data;
   public String action;
   

   public C0B(String var1) {
      this(var1, 0);
   }

   public C0B(ServerboundPlayerCommandPacket var1) {
      super(var1);
      this.action = var1.getAction().name();
      this.data = var1.getData();
   }

   public C0B(String var1, int var2) {
      Action var3 = Action.valueOf(var1.toUpperCase());
      super(new ServerboundPlayerCommandPacket(Minecraft.getInstance().player, var3, var2));
      this.action = var1;
      this.data = var2;
   }
}
