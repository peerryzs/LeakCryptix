package com.cryptix.script.impl.packet.outgoing;

import com.cryptix.script.impl.Vec3;
import com.cryptix.script.impl.packet.Packet;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.PosRot;

public class C06 extends Packet {
   public float pitch;
   public double z;
   public double x;
   public boolean onGround;
   public boolean horizontalCollision;
   public float yaw;
   public double y;
   

   public C06(PosRot var1) {
      super(var1);
      this.x = var1.getX(0.0);
      this.y = var1.getY(0.0);
      this.z = var1.getZ(0.0);
      this.yaw = var1.getYRot(0.0F);
      this.pitch = var1.getXRot(0.0F);
      this.onGround = var1.isOnGround();
      this.horizontalCollision = var1.horizontalCollision();
   }

   public C06(Vec3 var1, float var2, float var3, boolean var4, boolean var5) {
      this(new PosRot(var1.x, var1.y, var1.z, var2, var3, var4, var5));
   }

   public C06(double var1, double var3, double var5, float var7, float var8, boolean var9, boolean var10) {
      this(new PosRot(var1, var3, var5, var7, var8, var9, var10));
   }
}
