package com.cryptix.script;

import a.iw;
import a.mr;
import a.ve;
import a.CryptixClient;
import com.cryptix.script.impl.Entity;
import com.cryptix.script.impl.Vec3;
import com.cryptix.script.impl.World;
import com.cryptix.script.impl.packet.Packet;
import net.minecraft.network.protocol.game.ServerboundPunchPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.component.SwingAnimation;

public class ScriptDefaults implements ve {
   

   public void setSprinting(boolean var1) {
      ve.f0.player.setSprinting(var1);
   }

   public void sendPacket(Packet var1) {
      ve.f0.getConnection().send(var1.get());
   }

   public void setTimer(float var1) {
      iw.m57(var1);
   }

   public boolean isHoldingBlock() {
      return mr.m44();
   }

   public double getSpeed() {
      return Math.hypot(ve.f0.player.getDeltaMovement().x, ve.f0.player.getDeltaMovement().z);
   }

   public boolean isHoldingSword() {
      return mr.m43();
   }

   public long nanoTime() {
      return System.nanoTime();
   }

   public void print(String var1) {
      CryptixClient.sendMessage(var1);
   }

   public void jump() {
      ve.f0.player.jumpFromGround();
   }

   public long time() {
      return System.currentTimeMillis();
   }

   public World getWorld() {
      return new World(ve.f0.level);
   }

   public Vec3 getMotion() {
      return new Vec3(ve.f0.player.getDeltaMovement());
   }

   public void attack(Entity var1) {
      ve.f0.gameMode.attack(ve.f0.player, var1.getEntity());
   }

   public void setMotion(Vec3 var1) {
      this.setMotion(var1.x, var1.y, var1.z);
   }

   public void setMotion(double var1, double var3, double var5) {
      ve.f0.player.setDeltaMovement(var1, var3, var5);
   }

   public void swing(boolean var1) {
      ve.f0.player.swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, false);
      if (var1) {
         ve.f0.getConnection().send(ServerboundPunchPacket.INSTANCE);
      }
   }

   public void strafe() {
      this.strafe(this.getSpeed());
   }

   public void strafe(double var1) {
      float var3 = ve.f0.player.zza;
      float var4 = ve.f0.player.xxa;
      if (var3 != 0.0F || var4 != 0.0F) {
         float var5 = ve.f0.player.getYRot();
         if (var3 != 0.0F) {
            if (var4 > 0.0F) {
               var5 += var3 > 0.0F ? -45.0F : 45.0F;
            } else if (var4 < 0.0F) {
               var5 += var3 > 0.0F ? 45.0F : -45.0F;
            }

            var4 = 0.0F;
            var3 = var3 > 0.0F ? 1.0F : -1.0F;
         }

         double var6 = Math.toRadians(var5);
         double var8 = Math.sin(var6);
         double var10 = Math.cos(var6);
         double var12 = var3 * -var8 + var4 * var10;
         double var14 = var3 * var10 + var4 * var8;
         ve.f0.player.setDeltaMovement(var12 * var1, ve.f0.player.getDeltaMovement().y, var14 * var1);
      }
   }

   public Entity getPlayer() {
      return new Entity(ve.f0.player);
   }
}
