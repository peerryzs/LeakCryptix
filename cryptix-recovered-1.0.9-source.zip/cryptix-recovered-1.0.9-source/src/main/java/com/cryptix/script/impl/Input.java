package com.cryptix.script.impl;

import mixins.ClientInputMixin_rn;
import net.minecraft.client.player.ClientInput;
import net.minecraft.world.phys.Vec2;

public class Input {
   private final float y;
   private final ClientInput input;
   private final float x;
   

   public float getMoveY() {
      return this.y;
   }

   public void setLeft(boolean var1) {
      boolean var2 = this.input.keyPresses.forward();
      boolean var3 = this.input.keyPresses.backward();
      boolean var4 = this.input.keyPresses.right();
      boolean var5 = this.input.keyPresses.jump();
      boolean var6 = this.input.keyPresses.shift();
      boolean var7 = this.input.keyPresses.sprint();
      this.input.keyPresses = new net.minecraft.world.entity.player.Input(var2, var3, var1, var4, var5, var6, var7);
   }

   public void setSprint(boolean var1) {
      boolean var2 = this.input.keyPresses.forward();
      boolean var3 = this.input.keyPresses.backward();
      boolean var4 = this.input.keyPresses.left();
      boolean var5 = this.input.keyPresses.right();
      boolean var6 = this.input.keyPresses.jump();
      boolean var7 = this.input.keyPresses.shift();
      this.input.keyPresses = new net.minecraft.world.entity.player.Input(var2, var3, var4, var5, var6, var7, var1);
   }

   public void setBackward(boolean var1) {
      boolean var2 = this.input.keyPresses.forward();
      boolean var3 = this.input.keyPresses.left();
      boolean var4 = this.input.keyPresses.right();
      boolean var5 = this.input.keyPresses.jump();
      boolean var6 = this.input.keyPresses.shift();
      boolean var7 = this.input.keyPresses.sprint();
      this.input.keyPresses = new net.minecraft.world.entity.player.Input(var2, var1, var3, var4, var5, var6, var7);
   }

   public void setMove(float var1, float var2) {
      ((ClientInputMixin_rn)this.input).setMoveVector(new Vec2(var1, var2));
   }

   public boolean forward() {
      return this.input.keyPresses.forward();
   }

   public boolean jump() {
      return this.input.keyPresses.jump();
   }

   public boolean right() {
      return this.input.keyPresses.right();
   }

   public boolean backward() {
      return this.input.keyPresses.backward();
   }

   public void setForward(boolean var1) {
      boolean var2 = this.input.keyPresses.backward();
      boolean var3 = this.input.keyPresses.left();
      boolean var4 = this.input.keyPresses.right();
      boolean var5 = this.input.keyPresses.jump();
      boolean var6 = this.input.keyPresses.shift();
      boolean var7 = this.input.keyPresses.sprint();
      this.input.keyPresses = new net.minecraft.world.entity.player.Input(var1, var2, var3, var4, var5, var6, var7);
   }

   private void setKeys(boolean var1, boolean var2, boolean var3, boolean var4, boolean var5, boolean var6, boolean var7) {
      this.input.keyPresses = new net.minecraft.world.entity.player.Input(var1, var2, var3, var4, var5, var6, var7);
   }

   public boolean left() {
      return this.input.keyPresses.left();
   }

   public void setRight(boolean var1) {
      boolean var2 = this.input.keyPresses.forward();
      boolean var3 = this.input.keyPresses.backward();
      boolean var4 = this.input.keyPresses.left();
      boolean var5 = this.input.keyPresses.jump();
      boolean var6 = this.input.keyPresses.shift();
      boolean var7 = this.input.keyPresses.sprint();
      this.input.keyPresses = new net.minecraft.world.entity.player.Input(var2, var3, var4, var1, var5, var6, var7);
   }

   public Input(ClientInput var1) {
      this.input = var1;
      this.x = var1.getMoveVector().x;
      this.y = var1.getMoveVector().y;
   }

   public void setJump(boolean var1) {
      boolean var2 = this.input.keyPresses.forward();
      boolean var3 = this.input.keyPresses.backward();
      boolean var4 = this.input.keyPresses.left();
      boolean var5 = this.input.keyPresses.right();
      boolean var6 = this.input.keyPresses.shift();
      boolean var7 = this.input.keyPresses.sprint();
      this.input.keyPresses = new net.minecraft.world.entity.player.Input(var2, var3, var4, var5, var1, var6, var7);
   }

   public float getMoveX() {
      return this.x;
   }

   public void setShift(boolean var1) {
      boolean var2 = this.input.keyPresses.forward();
      boolean var3 = this.input.keyPresses.backward();
      boolean var4 = this.input.keyPresses.left();
      boolean var5 = this.input.keyPresses.right();
      boolean var6 = this.input.keyPresses.jump();
      boolean var7 = this.input.keyPresses.sprint();
      this.input.keyPresses = new net.minecraft.world.entity.player.Input(var2, var3, var4, var5, var6, var1, var7);
   }

   public boolean sprint() {
      return this.input.keyPresses.sprint();
   }

   public boolean shift() {
      return this.input.keyPresses.shift();
   }
}
