package com.cryptix.script.impl.packet;

import com.cryptix.script.impl.packet.outgoing.C00;
import com.cryptix.script.impl.packet.outgoing.C01;
import com.cryptix.script.impl.packet.outgoing.C02;
import com.cryptix.script.impl.packet.outgoing.C03;
import com.cryptix.script.impl.packet.outgoing.C04;
import com.cryptix.script.impl.packet.outgoing.C05;
import com.cryptix.script.impl.packet.outgoing.C06;
import com.cryptix.script.impl.packet.outgoing.C07;
import com.cryptix.script.impl.packet.outgoing.C08;
import com.cryptix.script.impl.packet.outgoing.C09;
import com.cryptix.script.impl.packet.outgoing.C0A;
import com.cryptix.script.impl.packet.outgoing.C0B;
import java.lang.reflect.Constructor;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.network.protocol.common.ServerboundKeepAlivePacket;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundChatPacket;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPunchPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.PosRot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.StatusOnly;

public class PacketManager {
   public static final Map<Class<? extends net.minecraft.network.protocol.Packet<?>>, Class<? extends Packet>> packets = new LinkedHashMap<>();
   

   static {
      packets.put(ServerboundPunchPacket.class, C0A.class);
      packets.put(ServerboundPlayerCommandPacket.class, C0B.class);
      packets.put(ServerboundKeepAlivePacket.class, C00.class);
      packets.put(ServerboundChatPacket.class, C01.class);
      packets.put(ServerboundInteractPacket.class, C02.class);
      packets.put(ServerboundAttackPacket.class, C02.class);
      packets.put(StatusOnly.class, C03.class);
      packets.put(Pos.class, C04.class);
      packets.put(Rot.class, C05.class);
      packets.put(PosRot.class, C06.class);
      packets.put(ServerboundPlayerActionPacket.class, C07.class);
      packets.put(ServerboundUseItemPacket.class, C08.class);
      packets.put(ServerboundUseItemOnPacket.class, C08.class);
      packets.put(ServerboundSetCarriedItemPacket.class, C09.class);
   }

   public static Packet getType(net.minecraft.network.protocol.Packet var0) {
      Class var1 = packets.get(var0.getClass());
      if (var1 == null) {
         return new Packet(var0);
      } else {
         Packet var4;
         try {
            Class[] var10001 = new Class[1];
            var10001[0] = var0.getClass();
            Constructor var10000 = var1.getDeclaredConstructor(var10001);
            Object[] var5 = new Object[1];
            var5[0] = var0;
            var4 = (Packet)var10000.newInstance(var5);
         } catch (ReflectiveOperationException var3) {
            var3.printStackTrace();
            return new Packet(var0);
         }

         return var4;
      }
   }
}
