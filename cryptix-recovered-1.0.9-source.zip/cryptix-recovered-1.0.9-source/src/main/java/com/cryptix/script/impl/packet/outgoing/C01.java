package com.cryptix.script.impl.packet.outgoing;

import com.cryptix.script.impl.packet.Packet;
import java.time.Instant;
import java.util.BitSet;
import java.util.Optional;
import net.minecraft.network.chat.LastSeenMessages.Update;
import net.minecraft.network.protocol.game.ServerboundChatPacket;

public class C01 extends Packet {
   public String message;
   

   public C01(ServerboundChatPacket var1) {
      super(var1);
      this.message = var1.message();
   }

   public C01(String var1) {
      super(new ServerboundChatPacket(var1, Instant.now(), 0L, Optional.empty(), new Update(0, new BitSet(20), (byte)0)));
      this.message = var1;
   }
}
