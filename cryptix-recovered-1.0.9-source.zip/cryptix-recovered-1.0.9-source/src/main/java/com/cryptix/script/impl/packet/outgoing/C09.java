package com.cryptix.script.impl.packet.outgoing;

import com.cryptix.script.impl.packet.Packet;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;

public class C09 extends Packet {
   public int slot;
   

   public C09(int var1) {
      this(new ServerboundSetCarriedItemPacket(var1));
   }

   public C09(ServerboundSetCarriedItemPacket var1) {
      super(var1);
      this.slot = var1.getSlot();
   }
}
