package com.cryptix.script.impl;

import a.bt;
import a.th;
import com.mojang.blaze3d.platform.Window;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class Render {
   private final Window window;
   private final Camera camera;
   private final GuiGraphicsExtractor graphics;
   

   public Render(Window var1, Camera var2, GuiGraphicsExtractor var3) {
      this.window = var1;
      this.camera = var2;
      this.graphics = var3;
   }

   public int[] getDisplaySize() {
      int var1 = this.window.getGuiScaledWidth();
      int var2 = this.window.getGuiScaledHeight();
      int[] var10000 = new int[2];
      var10000[0] = var1;
      var10000[1] = var2;
      return var10000;
   }

   public double getX() {
      return this.camera.position().x;
   }

   public void text(String var1, int var2, int var3, int var4) {
      bt.m70(this.graphics, var1, var2, var3, var4);
   }

   public double getZ() {
      return this.camera.position().z;
   }

   public void roundedRect(int var1, int var2, int var3, int var4, int var5, int var6) {
      th.m64(this.graphics, var1, var2, var3, var4, var5, var6);
   }

   public void rect(int var1, int var2, int var3, int var4, int var5) {
      this.graphics.fill(var1, var2, var1 + var3, var2 + var4, var5);
   }

   public double getY() {
      return this.camera.position().y;
   }

   public void textMc(String var1, int var2, int var3, int var4) {
      this.graphics.text(Minecraft.getInstance().font, var1, var2, var3, var4);
   }
}
