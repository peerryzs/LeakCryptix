package com.cryptix.script.impl;

import net.minecraft.world.entity.LivingEntity;

public class Entity {
   private final LivingEntity living;
   private final net.minecraft.world.entity.Entity entity;
   

   public double getLastX() {
      return this.entity.xOld;
   }

   public double distanceTo(Entity var1) {
      return this.entity.distanceTo(var1.entity);
   }

   public boolean isHorizontalCollision() {
      return this.entity.horizontalCollision;
   }

   public boolean isAlive() {
      return this.entity.isAlive();
   }

   public float getMaxHealth() {
      return this.living != null ? this.living.getMaxHealth() : -1.0F;
   }

   public boolean isSwinging() {
      return (this.living != null ? this.living.isSwinging() : false);
   }

   public boolean isSneaking() {
      return this.entity.isCrouching();
   }

   public float getEyeHeight() {
      return this.entity.getEyeHeight();
   }

   public net.minecraft.world.entity.Entity getEntity() {
      return this.entity;
   }

   public boolean isVerticalCollision() {
      return this.entity.verticalCollision;
   }

   public boolean isSleeping() {
      return (this.living != null ? this.living.isSleeping() : false);
   }

   public boolean isSprinting() {
      return this.entity.isSprinting();
   }

   public float getYaw() {
      return this.entity.getYRot();
   }

   public double getLastY() {
      return this.entity.yOld;
   }

   public int getTicksExisted() {
      return this.entity.tickCount;
   }

   public double getY() {
      return this.entity.getY();
   }

   public float getHeight() {
      return this.entity.getBbHeight();
   }

   public String getUUID() {
      return this.entity.getUUID().toString();
   }

   public void setYaw(float var1) {
      this.entity.setYRot(var1);
   }

   public Entity(net.minecraft.world.entity.Entity var1) {
      this.entity = var1;
      this.living = var1 instanceof LivingEntity var2 ? var2 : null;
   }

   public void setPrevPitch(float var1) {
      this.entity.xRotO = var1;
   }

   public String getName() {
      return this.entity.getName().getString();
   }

   public String getDisplayName() {
      return this.entity.getDisplayName().getString();
   }

   public double getZ() {
      return this.entity.getZ();
   }

   public boolean onGround() {
      return this.entity.onGround();
   }

   public boolean isInLiquid() {
      return this.entity.isInLiquid();
   }

   public float getHealth() {
      return this.living != null ? this.living.getHealth() : -1.0F;
   }

   public boolean isOnFire() {
      return this.entity.isOnFire();
   }

   public int getId() {
      return this.entity.getId();
   }

   public double getLastZ() {
      return this.entity.zOld;
   }

   public boolean isCollision() {
      return !(!this.entity.horizontalCollision && !this.entity.verticalCollision);
   }

   public float getWidth() {
      return this.entity.getBbWidth();
   }

   public float getPitch() {
      return this.entity.getXRot();
   }

   public double getX() {
      return this.entity.getX();
   }

   public void setPosition(double var1, double var3, double var5) {
      this.entity.setPos(var1, var3, var5);
   }

   public boolean isUsingItem() {
      return (this.living != null ? this.living.isUsingItem() : false);
   }

   public void setPosition(Vec3 var1) {
      this.entity.setPos(var1.x, var1.y, var1.z);
   }

   public boolean isRemoved() {
      return this.entity.isRemoved();
   }

   public int getMaxHurtTime() {
      return this.living != null ? this.living.hurtDuration : -1;
   }

   public int getHurtTime() {
      return this.living != null ? this.living.hurtTime : -1;
   }

   public void setPitch(float var1) {
      this.entity.setXRot(var1);
   }

   public boolean isInvisible() {
      return this.entity.isInvisible();
   }

   public boolean isInLava() {
      return this.entity.isInLava();
   }

   public double getFallDistance() {
      return this.entity.fallDistance;
   }

   public boolean isInWater() {
      return this.entity.isInWater();
   }

   public void setPrevYaw(float var1) {
      this.entity.yRotO = var1;
   }
}
