package com.cryptix.script.impl.packet.outgoing;

import com.cryptix.script.impl.packet.Packet;
import net.minecraft.network.protocol.game.ServerboundPunchPacket;

public class C0A extends Packet {
   

   public C0A() {
      super(ServerboundPunchPacket.INSTANCE);
   }

   public C0A(ServerboundPunchPacket var1) {
      super(var1);
   }
}
