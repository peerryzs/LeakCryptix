package com.cryptix.script.impl.packet.outgoing;

import com.cryptix.script.impl.packet.Packet;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;

public class C05 extends Packet {
   public float pitch;
   public boolean horizontalCollision;
   public float yaw;
   public boolean onGround;
   

   public C05(float var1, float var2, boolean var3, boolean var4) {
      this(new Rot(var1, var2, var3, var4));
   }

   public C05(Rot var1) {
      super(var1);
      this.yaw = var1.getYRot(0.0F);
      this.pitch = var1.getXRot(0.0F);
      this.onGround = var1.isOnGround();
      this.horizontalCollision = var1.horizontalCollision();
   }
}
