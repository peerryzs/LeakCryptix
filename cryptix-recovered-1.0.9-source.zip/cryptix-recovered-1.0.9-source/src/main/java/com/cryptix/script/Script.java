package com.cryptix.script;

import com.cryptix.script.impl.Input;
import com.cryptix.script.impl.Render;
import com.cryptix.script.impl.packet.Packet;

public abstract class Script extends ScriptDefaults {
   private boolean enabled;
   

   public void onInput(Input var1) {
   }

   public void onEnable() {
   }

   public boolean onPacketSend(Packet var1) {
      return false;
   }

   public void onRender(Render var1) {
   }

   public void onDisable() {
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public boolean onPacketReceive(Packet var1) {
      return false;
   }

   public String getScriptName() {
      return this.getClass().getSimpleName();
   }

   public void setEnabled(boolean var1) {
      if (var1 != this.enabled) {
         if (var1) {
            this.enabled = true;
            this.onEnable();
         } else {
            this.enabled = false;
            this.onDisable();
         }
      }
   }

   public void onUpdate() {
   }
}
