package com.cryptix.script.impl;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;

public class Block {
   public boolean interactable;
   public double height;
   public double width;
   public double length;
   public String name;
   public String type;
   

   public Block(BlockState var1) {
      this.type = var1.getBlock().getDescriptionId();
      this.name = var1.getBlock().getName().getString();
      this.interactable = (!var1.getShape(null, null).isEmpty());
      VoxelShape var2 = var1.getShape(null, null);
      AABB var3 = var2.isEmpty() ? new AABB(0.0, 0.0, 0.0, 0.0, 0.0, 0.0) : var2.bounds();
      this.width = var3.getXsize();
      this.height = var3.getYsize();
      this.length = var3.getZsize();
   }
}
