package com.cryptix.script.impl.packet.outgoing;

import com.cryptix.script.impl.packet.Packet;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.StatusOnly;

public class C03 extends Packet {
   public boolean horizontalCollision;
   public boolean onGround;
   

   public C03(boolean var1, boolean var2) {
      this(new StatusOnly(var1, var2));
   }

   public C03(StatusOnly var1) {
      super(var1);
      this.onGround = var1.isOnGround();
      this.horizontalCollision = var1.horizontalCollision();
   }
}
