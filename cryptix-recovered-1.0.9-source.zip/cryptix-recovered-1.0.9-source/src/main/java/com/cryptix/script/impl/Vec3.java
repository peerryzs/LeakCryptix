package com.cryptix.script.impl;

public class Vec3 {
   public double y;
   public double x;
   public double z;
   

   public Vec3 translate(Vec3 var1) {
      return this.offset(var1.x, var1.y, var1.z);
   }

   public double distanceTo(Vec3 var1) {
      double var2 = this.x - var1.x;
      double var4 = this.y - var1.y;
      double var6 = this.z - var1.z;
      return Math.sqrt(var2 * var2 + var4 * var4 + var6 * var6);
   }

   public Vec3 inverse() {
      return new Vec3(-this.x, -this.y, -this.z);
   }

   public Vec3(net.minecraft.world.phys.Vec3 var1) {
      this.x = var1.x;
      this.y = var1.y;
      this.z = var1.z;
   }

   public Vec3 ceil() {
      return new Vec3(Math.ceil(this.x), Math.ceil(this.y), Math.ceil(this.z));
   }

   public Vec3 floor() {
      return new Vec3(Math.floor(this.x), Math.floor(this.y), Math.floor(this.z));
   }

   public Vec3(double var1, double var3, double var5) {
      this.x = var1;
      this.y = var3;
      this.z = var5;
   }

   public Vec3 translate(double var1, double var3, double var5) {
      return this.offset(var1, var3, var5);
   }

   public boolean equals(Vec3 var1) {
      return !((var1.x != this.x || var1.y != this.y || var1.z != this.z) && this != var1);
   }

   public Vec3 offset(double var1, double var3, double var5) {
      return new Vec3(this.x + var1, this.y + var3, this.z + var5);
   }

   public Vec3 offset(Vec3 var1) {
      return new Vec3(this.x + var1.x, this.y + var1.y, this.z + var1.z);
   }

   public double distanceToSq(Vec3 var1) {
      double var2 = this.x - var1.x;
      double var4 = this.y - var1.y;
      double var6 = this.z - var1.z;
      return var2 * var2 + var4 * var4 + var6 * var6;
   }
}
