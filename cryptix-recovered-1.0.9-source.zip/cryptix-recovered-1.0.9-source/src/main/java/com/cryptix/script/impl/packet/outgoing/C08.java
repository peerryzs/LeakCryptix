package com.cryptix.script.impl.packet.outgoing;

import com.cryptix.script.impl.Vec3;
import com.cryptix.script.impl.packet.Packet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;

public class C08 extends Packet {
   public int sequence;
   public int y;
   public float pitch;
   public float yaw;
   public String direction;
   public int z;
   public int x;
   

   public C08(ServerboundUseItemOnPacket var1) {
      super(var1);
      this.sequence = var1.sequence();
      this.yaw = -1.0F;
      this.pitch = -1.0F;
      BlockHitResult var2 = var1.hitResult();
      this.direction = var2.getDirection().getName();
      this.x = var2.getBlockPos().getX();
      this.y = var2.getBlockPos().getY();
      this.z = var2.getBlockPos().getZ();
   }

   public C08(ServerboundUseItemPacket var1) {
      super(var1);
      this.sequence = var1.sequence();
      this.yaw = var1.yRot();
      this.pitch = var1.xRot();
      this.direction = "";
      this.x = -1;
      this.y = -1;
      this.z = -1;
   }

   public C08(Vec3 var1, String var2, int var3) {
      this(
         new ServerboundUseItemOnPacket(
            InteractionHand.MAIN_HAND,
            new BlockHitResult(
               new net.minecraft.world.phys.Vec3(var1.x, var1.y, var1.z),
               Direction.byName(var2.toLowerCase()),
               new BlockPos((int)var1.x, (int)var1.y, (int)var1.z),
               false
            ),
            var3
         )
      );
   }

   public C08(int var1, float var2, float var3) {
      this(new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, var1, var2, var3));
   }
}
