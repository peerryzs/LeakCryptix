package com.cryptix.script;

import a.r;
import a.CryptixClient;
import com.cryptix.script.impl.Block;
import com.cryptix.script.impl.Entity;
import com.cryptix.script.impl.Input;
import com.cryptix.script.impl.Render;
import com.cryptix.script.impl.Vec3;
import com.cryptix.script.impl.World;
import com.cryptix.script.impl.packet.Packet;
import com.cryptix.script.impl.packet.PacketManager;
import com.mojang.blaze3d.platform.Window;
import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.FileObject;
import javax.tools.ForwardingJavaFileManager;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.SimpleJavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import javax.tools.JavaCompiler.CompilationTask;
import javax.tools.JavaFileManager.Location;
import javax.tools.JavaFileObject.Kind;
import net.minecraft.client.Camera;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.ClientInput;

public class ScriptManager {
   private static final Map<String, Class<?>> SCRIPT_CLASSES = new HashMap<>();
   private static Path directory;
   private static final Map<String, ScriptManager.LoadedScript> scripts;
   

   public static boolean unload(String var0) {
      ScriptManager.LoadedScript var1 = scripts.remove(var0);
      if (var1 == null) {
         return false;
      } else {
         try {
            var1.script.setEnabled(false);
         } catch (Exception var3) {
            var3.printStackTrace();
         }

         System.out.println("[Cryptix] Unloaded script: " + var0);
         return true;
      }
   }

   public static void onRender(Window var0, Camera var1, GuiGraphicsExtractor var2) {
      for (ScriptManager.LoadedScript var4 : scripts.values()) {
         if (var4.script.isEnabled()) {
            try {
               var4.script.onRender(new Render(var0, var1, var2));
            } catch (Throwable var7) {
               String var6 = var7.getMessage();
               CryptixClient.sendMessage("[Cryptix] Error in script " + var4.script.getClass().getSimpleName() + ": " + (var6 != null ? var6 : var7.getClass().getSimpleName()));
               var7.printStackTrace();
            }
         }
      }
   }

   public static boolean reload(String var0) {
      Path var1 = directory.resolve(var0 + ".java");
      if (!Files.exists(var1)) {
         return false;
      } else {
         if (scripts.containsKey(var0)) {
            unload(var0);
         }

         return load(var1);
      }
   }

   public static void onPacketSend(Packet var0, r var1) {
      for (ScriptManager.LoadedScript var3 : scripts.values()) {
         if (var3.script.isEnabled()) {
            try {
               if (var3.script.onPacketSend(var0)) {
                  var1.m9(true);
               }
            } catch (Throwable var6) {
               String var5 = var6.getMessage();
               CryptixClient.sendMessage("[Cryptix] Error in script " + var3.script.getClass().getSimpleName() + ": " + (var5 != null ? var5 : var6.getClass().getSimpleName()));
               var6.printStackTrace();
            }
         }
      }
   }

   public static boolean load(Path var0) {
      String var1 = var0.getFileName().toString();
      if (!var1.endsWith(".java")) {
         return false;
      } else {
         String var2 = var1.substring(0, var1.length() - 5);
         if (scripts.containsKey(var2)) {
            unload(var2);
         }

         JavaCompiler var3 = ToolProvider.getSystemJavaCompiler();
         if (var3 == null) {
            System.err.println("[Cryptix] Java compiler unavailable.");
            System.err.println("[Cryptix] A JDK is required to load scripts.");
            return false;
         } else {
            String var4;
            try {
               var4 = Files.readString(var0);
            } catch (IOException var18) {
               var18.printStackTrace();
               return false;
            }

            var4 = var4.replaceAll("\\bvoid\\s+(\\w+)\\s*\\(", "public void $1(");
            var4 = var4.replaceAll("\\bboolean\\s+(\\w+)\\s*\\(", "public boolean $1(");
            String generatedSource = "public class " + var2 + " extends Script {\n" + var4.replaceAll("(?m)^\\s*import\\s+[^;]+;\\s*$", "") + "\n}";

            for (Entry var7 : SCRIPT_CLASSES.entrySet()) {
               generatedSource = generatedSource.replaceAll("\\b" + (String)var7.getKey() + "\\b", ((Class)var7.getValue()).getName());
            }

            final String var5 = generatedSource;
            final HashMap<String, byte[]> var22 = new HashMap<>();
            System.out.println(var5);
            SimpleJavaFileObject var8 = new SimpleJavaFileObject(URI.create("string:///" + var1), Kind.SOURCE) {
               

               @Override
               public CharSequence getCharContent(boolean var1) {
                  return var5;
               }
            };

            int var10000;
            try {
               StandardJavaFileManager var9 = var3.getStandardFileManager(null, null, null);
               ForwardingJavaFileManager var10 = new ForwardingJavaFileManager<StandardJavaFileManager>(var9) {
                  

                  @Override
                  public JavaFileObject getJavaFileForOutput(Location var1, final String var2x, Kind var3x, FileObject var4x) {
                     return new SimpleJavaFileObject(
                        URI.create("memory:///" + var2x.replace((char)46, (char)47) + var3x.extension), var3x
                     ) {
                        


                        @Override
                        public OutputStream openOutputStream() {
                           return new ByteArrayOutputStream() {
                              

                              @Override
                              public void close() throws IOException {
                                 var22.put(var2x, this.toByteArray());
                                 super.close();
                              }

                           };
                        }
                     };
                  }
               };
               DiagnosticCollector<JavaFileObject> var11 = new DiagnosticCollector();
               String var12 = System.getProperty("java.class.path");

               try {
                  String var13 = new File(ScriptManager.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getAbsolutePath();
                  var12 = var12 + File.pathSeparator + var13;
               } catch (Exception var17) {
                  var17.printStackTrace();
               }

               CompilationTask var23 = var3.getTask(null, var10, var11, List.of("-classpath", var12), null, List.of(var8));
               if (!var23.call()) {
                  for (Diagnostic var25 : var11.getDiagnostics()) {
                     CryptixClient.sendMessage("§c" + var25.getMessage(null));
                  }

                  var10.close();
                  return false;
               }

               var10.close();
               ClassLoader var14 = new ClassLoader(ScriptManager.class.getClassLoader()) {
                  

                  @Override
                  protected Class<?> loadClass(String var1, boolean var2x) throws ClassNotFoundException {
                     if (var1.startsWith("java.lang.")) {
                        return super.loadClass(var1, var2x);
                     } else {
                        for (Class var4x : ScriptManager.SCRIPT_CLASSES.values()) {
                           if (var4x.getName().equals(var1)) {
                              return var4x;
                           }
                        }

                        byte[] var5x = (byte[])var22.get(var1);
                        if (var5x != null) {
                           Class var6 = this.findClass(var1);
                           if (var2x) {
                              this.resolveClass(var6);
                           }

                           return var6;
                        } else {
                           throw new ClassNotFoundException("Access denied: " + var1);
                        }
                     }
                  }

                  @Override
                  protected Class<?> findClass(String var1) throws ClassNotFoundException {
                     byte[] var2x = (byte[])var22.get(var1);
                     if (var2x == null) {
                        throw new ClassNotFoundException(var1);
                     } else {
                        return this.defineClass(var1, var2x, 0, var2x.length);
                     }
                  }
               };
               Class var15 = Class.forName(var2, true, var14);
               if (!Script.class.isAssignableFrom(var15)) {
                  System.err.println("[Cryptix] " + var2 + " must extend Script.");
                  return false;
               }

               Script var16 = (Script)var15.getDeclaredConstructor().newInstance();
               scripts.put(var2, new ScriptManager.LoadedScript(var16, var14));
               System.out.println("[Cryptix] Loaded script: " + var2);
               var10000 = 1;
            } catch (Throwable var19) {
               System.err.println("[Cryptix] Failed to load " + var2);
               var19.printStackTrace();
               return false;
            }

            return var10000 != 0;
         }
      }
   }

   public static void innit(Path var0) {
      directory = var0;

      try {
         Files.createDirectories(directory);
      } catch (IOException var2) {
         var2.printStackTrace();
      }
   }

   public static void openFolder() {
      try {
         File var0 = directory.toFile();
         if (!var0.exists()) {
            var0.mkdirs();
         }

         String var1 = System.getProperty("os.name").toLowerCase();
         if (var1.contains("win")) {
            String[] var10002 = new String[2];
            var10002[0] = "explorer.exe";
            var10002[1] = var0.getAbsolutePath();
            new ProcessBuilder(var10002).start();
         } else if (var1.contains("mac")) {
            String[] var3 = new String[2];
            var3[0] = "open";
            var3[1] = var0.getAbsolutePath();
            new ProcessBuilder(var3).start();
         } else {
            String[] var4 = new String[2];
            var4[0] = "xdg-open";
            var4[1] = var0.getAbsolutePath();
            new ProcessBuilder(var4).start();
         }
      } catch (IOException var2) {
         var2.printStackTrace();
      }
   }

   public static void onUpdate() {
      for (ScriptManager.LoadedScript var1 : scripts.values()) {
         if (var1.script.isEnabled()) {
            try {
               var1.script.onUpdate();
            } catch (Throwable var4) {
               String var3 = var4.getMessage();
               CryptixClient.sendMessage("[Cryptix] Error in script " + var1.script.getClass().getSimpleName() + ": " + (var3 != null ? var3 : var4.getClass().getSimpleName()));
               var4.printStackTrace();
            }
         }
      }
   }

   public static void onPacketReceive(Packet var0, r var1) {
      for (ScriptManager.LoadedScript var3 : scripts.values()) {
         if (var3.script.isEnabled()) {
            try {
               if (var3.script.onPacketReceive(var0)) {
                  var1.m9(true);
               }
            } catch (Throwable var6) {
               String var5 = var6.getMessage();
               CryptixClient.sendMessage("[Cryptix] Error in script " + var3.script.getClass().getSimpleName() + ": " + (var5 != null ? var5 : var6.getClass().getSimpleName()));
               var6.printStackTrace();
            }
         }
      }
   }

   public static void onInput(ClientInput var0) {
      for (ScriptManager.LoadedScript var2 : scripts.values()) {
         if (var2.script.isEnabled()) {
            try {
               var2.script.onInput(new Input(var0));
            } catch (Throwable var5) {
               String var4 = var5.getMessage();
               CryptixClient.sendMessage("[Cryptix] Error in script " + var2.script.getClass().getSimpleName() + ": " + (var4 != null ? var4 : var5.getClass().getSimpleName()));
               var5.printStackTrace();
            }
         }
      }
   }

   public static boolean toggle(String var0) {
      Script var1 = get(var0);
      if (var1 == null) {
         return false;
      } else {
         var1.setEnabled((!var1.isEnabled()));
         return true;
      }
   }

   public static Script get(String var0) {
      ScriptManager.LoadedScript var1 = scripts.get(var0);
      return var1 == null ? null : var1.script;
   }

   public static void loadAll() {
      if (directory != null) {
         try (Stream<Path> var0 = Files.list(directory)) {
            var0.filter(var0x -> var0x.toString().endsWith(".java")).forEach(ScriptManager::load);
         } catch (IOException var5) {
            var5.printStackTrace();
         }
      }
   }

   static {
      SCRIPT_CLASSES.put("Script", Script.class);
      SCRIPT_CLASSES.put("Entity", Entity.class);
      SCRIPT_CLASSES.put("Vec3", Vec3.class);
      SCRIPT_CLASSES.put("World", World.class);
      SCRIPT_CLASSES.put("Block", Block.class);
      SCRIPT_CLASSES.put("Input", Input.class);
      SCRIPT_CLASSES.put("Packet", Packet.class);
      SCRIPT_CLASSES.put("ArrayList", ArrayList.class);
      SCRIPT_CLASSES.put("Arrays", Arrays.class);
      SCRIPT_CLASSES.put("AtomicBoolean", AtomicBoolean.class);
      SCRIPT_CLASSES.put("AtomicInteger", AtomicInteger.class);
      SCRIPT_CLASSES.put("AtomicLong", AtomicLong.class);
      SCRIPT_CLASSES.put("Color", Color.class);
      SCRIPT_CLASSES.put("Collections", Collections.class);
      SCRIPT_CLASSES.put("Comparator", Comparator.class);
      SCRIPT_CLASSES.put("ConcurrentHashMap", ConcurrentHashMap.class);
      SCRIPT_CLASSES.put("HashMap", HashMap.class);
      SCRIPT_CLASSES.put("HashSet", HashSet.class);
      SCRIPT_CLASSES.put("Iterator", Iterator.class);
      SCRIPT_CLASSES.put("LinkedHashMap", LinkedHashMap.class);
      SCRIPT_CLASSES.put("LinkedList", LinkedList.class);
      SCRIPT_CLASSES.put("List", List.class);
      SCRIPT_CLASSES.put("Matcher", Matcher.class);
      SCRIPT_CLASSES.put("Pattern", Pattern.class);
      SCRIPT_CLASSES.put("Random", Random.class);

      for (Class var1 : PacketManager.packets.values()) {
         SCRIPT_CLASSES.put(var1.getSimpleName(), var1);
      }

      scripts = new HashMap<>();
   }

   public static String[] list() {
      if (directory == null) {
         return new String[0];
      } else {
         String[] var1;
         try (Stream<Path> var0 = Files.list(directory)) {
            var1 = var0.filter(var0x -> var0x.toString().endsWith(".java")).map(var0x -> {
               String var1x = var0x.getFileName().toString();
               return var1x.substring(0, var1x.length() - 5);
            }).toArray(String[]::new);
         } catch (IOException var5) {
            var5.printStackTrace();
            return new String[0];
         }

         return var1;
      }
   }

   private record LoadedScript(Script script, ClassLoader loader) {
      
   }
}
