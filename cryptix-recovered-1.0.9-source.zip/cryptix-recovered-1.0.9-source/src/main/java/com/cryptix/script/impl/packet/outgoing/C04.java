package com.cryptix.script.impl.packet.outgoing;

import com.cryptix.script.impl.Vec3;
import com.cryptix.script.impl.packet.Packet;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;

public class C04 extends Packet {
   public boolean horizontalCollision;
   public double z;
   public double y;
   public boolean onGround;
   public double x;
   

   public C04(double var1, double var3, double var5, boolean var7, boolean var8) {
      this(new Pos(var1, var3, var5, var7, var8));
   }

   public C04(Pos var1) {
      super(var1);
      this.x = var1.getX(0.0);
      this.y = var1.getY(0.0);
      this.z = var1.getZ(0.0);
      this.onGround = var1.isOnGround();
      this.horizontalCollision = var1.horizontalCollision();
   }

   public C04(Vec3 var1, boolean var2, boolean var3) {
      this(new Pos(var1.x, var1.y, var1.z, var2, var3));
   }
}
