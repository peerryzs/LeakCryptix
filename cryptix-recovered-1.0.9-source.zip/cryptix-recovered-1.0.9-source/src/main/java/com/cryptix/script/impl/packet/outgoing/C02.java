package com.cryptix.script.impl.packet.outgoing;

import com.cryptix.script.impl.Entity;
import com.cryptix.script.impl.packet.Packet;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.Vec3;

public class C02 extends Packet {
   public int entityId;
   public String action;
   

   public C02(Entity var1) {
      this(new ServerboundAttackPacket(var1.getId()));
   }

   public C02(Entity var1, double var2, double var4, double var6, boolean var8) {
      this(new ServerboundInteractPacket(var1.getId(), InteractionHand.MAIN_HAND, new Vec3(var2, var4, var6), var8));
   }

   public C02(ServerboundAttackPacket var1) {
      super(var1);
      this.entityId = var1.entityId();
      this.action = "ATTACK";
   }

   public C02(ServerboundInteractPacket var1) {
      super(var1);
      this.entityId = var1.entityId();
      this.action = "INTERACT";
   }

   public C02(Entity var1, boolean var2) {
      this(var1, 0.0, 0.0, 0.0, var2);
   }
}
