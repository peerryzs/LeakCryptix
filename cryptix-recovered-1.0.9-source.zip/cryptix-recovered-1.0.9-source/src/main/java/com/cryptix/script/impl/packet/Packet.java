package com.cryptix.script.impl.packet;

public class Packet {
   public final String name;
   public final net.minecraft.network.protocol.Packet packet;
   

   public Packet(net.minecraft.network.protocol.Packet var1) {
      this.packet = var1;
      this.name = var1.getClass().getSimpleName();
   }

   public net.minecraft.network.protocol.Packet get() {
      return this.packet;
   }
}
