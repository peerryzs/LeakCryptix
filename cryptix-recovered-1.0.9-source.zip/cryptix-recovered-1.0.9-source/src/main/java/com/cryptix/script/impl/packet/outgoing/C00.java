package com.cryptix.script.impl.packet.outgoing;

import com.cryptix.script.impl.packet.Packet;
import net.minecraft.network.protocol.common.ServerboundKeepAlivePacket;

public class C00 extends Packet {
   public long id;
   

   public C00(long var1) {
      super(new ServerboundKeepAlivePacket(var1));
      this.id = var1;
   }

   public C00(ServerboundKeepAlivePacket var1) {
      super(var1);
      this.id = var1.getId();
   }
}
