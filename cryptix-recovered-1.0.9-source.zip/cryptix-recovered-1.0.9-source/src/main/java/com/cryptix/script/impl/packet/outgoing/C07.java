package com.cryptix.script.impl.packet.outgoing;

import com.cryptix.script.impl.Vec3;
import com.cryptix.script.impl.packet.Packet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action;

public class C07 extends Packet {
   public String direction;
   public int z;
   public int x;
   public String action;
   public int y;
   

   public C07(ServerboundPlayerActionPacket var1) {
      super(var1);
      this.action = var1.getAction().name();
      this.x = var1.getPos().getX();
      this.y = var1.getPos().getY();
      this.z = var1.getPos().getZ();
      this.direction = var1.getDirection().name();
   }

   public C07(Vec3 var1, String var2, String var3) {
      this(
         new ServerboundPlayerActionPacket(
            Action.valueOf(var2.toUpperCase()), new BlockPos((int)var1.x, (int)var1.y, (int)var1.z), Direction.byName(var3.toLowerCase())
         )
      );
   }
}
