package mixins;

import a.iw;
import it.unimi.dsi.fastutil.floats.FloatUnaryOperator;
import net.minecraft.client.DeltaTracker.Timer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({Timer.class})
public class TimerMixin_nk {
   @Shadow
   private long lastMs;
   @Shadow
   private float deltaTickResidual;
   @Shadow
   private float deltaTicks;
   @Shadow
   private FloatUnaryOperator targetMsptProvider;
   @Shadow
   private float msPerTick;
   

   @Overwrite
   public int advanceGameTime(long var1) {
      this.deltaTicks = (float)(var1 - this.lastMs) / (iw.m60() ? this.targetMsptProvider.apply(this.msPerTick) : this.msPerTick / iw.m58());
      this.lastMs = var1;
      this.deltaTickResidual = this.deltaTickResidual + this.deltaTicks;
      int var3 = (int)this.deltaTickResidual;
      this.deltaTickResidual -= var3;
      return var3;
   }
}
