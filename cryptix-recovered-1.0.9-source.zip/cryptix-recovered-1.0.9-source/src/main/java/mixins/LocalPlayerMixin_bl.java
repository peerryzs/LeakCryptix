package mixins;

import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({LocalPlayer.class})
public interface LocalPlayerMixin_bl {
   @Accessor("zLast")
   void setZLast(double var1);

   @Accessor("yRotLast")
   void setYRotLast(float var1);

   @Accessor("xRotLast")
   void setXRotLast(float var1);

   @Accessor("xLast")
   void setXLast(double var1);
}
