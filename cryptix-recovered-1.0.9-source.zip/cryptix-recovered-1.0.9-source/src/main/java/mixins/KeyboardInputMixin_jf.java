package mixins;

import a.c;
import a.u;
import net.minecraft.client.player.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({KeyboardInput.class})
public class KeyboardInputMixin_jf {
   

   @Inject(
      method = {"tick"},
      at = {@At("TAIL")}
   )
   private void pm$37(CallbackInfo var1) {
      c var2 = u.f9.m48();
      var2.m10();
   }
}
