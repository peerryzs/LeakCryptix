package mixins;

import a.ModuleManager;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin({Hud.class})
public class HudMixin_br {
   @Unique
   private long f221;
   @Shadow
   private Minecraft minecraft;
   @Unique
   private int f219;
   @Unique
   private float f217;
   @Unique
   private long f220;
   @Unique
   private float f218;
   

   private int pm$25() {
      return ModuleManager.f34.isEnabled() ? (int)ModuleManager.f34.f46.getValue() : 0;
   }

   @Inject(
      method = {"extractItemHotbar"},
      at = {@At("HEAD")}
   )
   private void pm$23(GuiGraphicsExtractor var1, DeltaTracker var2, CallbackInfo var3) {
      if (ModuleManager.f42.isEnabled()) {
         this.f221 = (long)(ModuleManager.f42.f45.getValue() * 1000000.0);
         this.pm$22(var1, var2);
      }
   }

   @ModifyArgs(
      method = {"extractItemHotbar"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;blitSprite(Lcom/mojang/renderpearl/api/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIII)V",
         ordinal = 1
      )}
   )
   private void pm$24(Args var1) {
      int var2 = (Integer)var1.get(2);
      float var3 = this.f217 * 20.0F;
      float var4 = this.f219 * 20.0F;
      if (ModuleManager.f42.isEnabled()) {
         var1.set(2, Math.round(var2 + var3 - var4));
      }
   }

   @ModifyArg(
      method = {"displayScoreboardSidebar"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;fill(IIIII)V"
      )},
      index = 0
   )
   private int pm$29(int var1) {
      return var1 - this.pm$25();
   }

   @ModifyArg(
      method = {"displayScoreboardSidebar"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;fill(IIIII)V"
      )},
      index = 2
   )
   private int pm$30(int var1) {
      return var1 - this.pm$25();
   }

   @ModifyArg(
      method = {"displayScoreboardSidebar"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIIZ)V"
      )},
      index = 2
   )
   private int pm$27(int var1) {
      return var1 - this.pm$25();
   }

   public HudMixin_br() {
      this.f219 = -1;
      this.f221 = 100000000L;
   }

   @ModifyArg(
      method = {"displayScoreboardSidebar"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;fill(IIIII)V"
      )},
      index = 1
   )
   private int pm$31(int var1) {
      return var1 - this.pm$26();
   }

   @Unique
   private void pm$22(GuiGraphicsExtractor var1, DeltaTracker var2) {
      LocalPlayer var3 = this.minecraft.player;
      if (var3 == null) {
         this.f219 = -1;
      } else {
         int var4 = var3.getInventory().getSelectedSlot();
         if (this.f219 == -1) {
            this.f219 = var4;
            this.f217 = var4;
            this.f218 = var4;
         } else {
            if (var4 != this.f219) {
               this.f218 = this.f217;
               this.f220 = System.nanoTime();
               this.f219 = var4;
            }

            long var5 = this.f221;
            if (var5 <= 0L) {
               this.f217 = var4;
            } else {
               long var7 = System.nanoTime() - this.f220;
               if (var7 >= var5) {
                  this.f217 = var4;
               } else {
                  float var9 = (float)var7 / (float)var5;
                  var9 *= var9 * (3.0F - 2.0F * var9);
                  this.f217 = Mth.lerp(var9, this.f218, var4);
               }
            }
         }
      }
   }

   @ModifyArg(
      method = {"displayScoreboardSidebar"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;fill(IIIII)V"
      )},
      index = 3
   )
   private int pm$32(int var1) {
      return var1 - this.pm$26();
   }

   @ModifyArg(
      method = {"displayScoreboardSidebar"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIIZ)V"
      )},
      index = 3
   )
   private int pm$28(int var1) {
      return var1 - this.pm$26();
   }

   private int pm$26() {
      return ModuleManager.f34.isEnabled() ? (int)ModuleManager.f34.f47.getValue() : 0;
   }
}
