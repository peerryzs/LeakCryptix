package mixins;

import a.o;
import a.u;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.input.MouseButtonInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MouseHandler.class})
public class MouseHandlerMixin_yd {
   

   @Inject(
      method = {"onButton"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pm$41(long var1, MouseButtonInfo var3, int var4, CallbackInfo var5) {
      o var6 = u.f16.m12(var3.button(), var4, var3.modifiers());
      var6.m10();
      if (var6.m8()) {
         var5.cancel();
      }
   }
}
