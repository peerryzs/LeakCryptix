package mixins;

import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({LivingEntity.class})
public interface LivingEntityMixin_pz {
   @Accessor("noJumpDelay")
   void setNoJumpDelay(int var1);
}
