package mixins;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.multiplayer.prediction.PredictiveAction;
import net.minecraft.core.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({MultiPlayerGameMode.class})
public interface MultiPlayerGameModeMixin_sg {
   @Accessor("destroyDelay")
   void setDestroyDelay(int var1);

   @Invoker("startPrediction")
   void invokeStartPrediction(ClientLevel var1, PredictiveAction var2);

   @Accessor("isDestroying")
   boolean isDestroying();

   @Accessor("destroyBlockPos")
   BlockPos getDestroyBlockPos();

   @Accessor("destroyProgress")
   void setDestroyProgress(float var1);

   @Accessor("destroyProgress")
   float getDestroyProgress();
}
