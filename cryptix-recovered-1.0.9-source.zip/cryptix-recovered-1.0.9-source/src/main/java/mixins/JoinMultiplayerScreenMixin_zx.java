package mixins;

import a.dp;
import java.nio.charset.StandardCharsets;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({JoinMultiplayerScreen.class})
public class JoinMultiplayerScreenMixin_zx {
   

   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void pm$36(CallbackInfo var1) {
      JoinMultiplayerScreen var2 = (JoinMultiplayerScreen)(Object)this;
      ((ScreenMixin_ar)var2)
         .invokeAddRenderableWidget(
            Button.builder(Component.literal("Token Login"), var1x -> ((ScreenMixin_ar)var2).getMinecraft().gui.setScreen(new dp()))
               .bounds(var2.width - 110, 5, 105, 20)
               .build()
         );
   }

   
}
