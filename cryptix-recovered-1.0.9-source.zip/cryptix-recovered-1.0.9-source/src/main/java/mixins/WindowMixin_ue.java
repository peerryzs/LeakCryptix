package mixins;

import a.NativeSupport;
import a.NativeGate;
import com.mojang.blaze3d.platform.Window;
import java.nio.charset.StandardCharsets;
import net.minecraft.client.Minecraft;
import org.lwjgl.sdl.SDLVideo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Window.class})
public class WindowMixin_ue {
   @Shadow
   private long handle;
   

   

   @Inject(
      method = {"setTitle"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pm$43(String var1, CallbackInfo var2) {
      // Recovered edition has no dependency on the unavailable native license service.

      var2.cancel();
      SDLVideo.SDL_SetWindowTitle(this.handle, "Cryptix Recovered");
   }
}
