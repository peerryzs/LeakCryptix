package mixins;

import a.dt;
import a.ModuleManager;
import a.u;
import a.CombatPacketOrder;
import com.cryptix.script.ScriptManager;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Minecraft.class})
public class MinecraftMixin_sv {
   @Inject(method = {"tick"}, at = {@At("HEAD")})
   private void serviceCombatRelease(CallbackInfo info) {
      CombatPacketOrder.onClientTick();
   }
   private boolean f228;
   private dt f227;
   

   @Inject(
      method = {"handleKeybinds"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/Gui;handleKeybinds()V",
         shift = Shift.AFTER
      )}
   )
   private void pm$40(CallbackInfo var1) {
      u.f7.m10();
   }

   

   // Recovered edition: native license protocol and its exit monitor are unavailable.

   public MinecraftMixin_sv() {
      this.f228 = false;
   }

   @Inject(
      method = {"onResourceLoadFinished"},
      at = {@At("TAIL")}
   )
   private void pm$38(CallbackInfo var1) {
      if (!this.f228) {
         ModuleManager.initializeSortedModules();
         String var10000 = "cryptix";
         String[] var10001 = new String[1];
         var10001[0] = "scripts";
         ScriptManager.innit(Path.of(var10000, var10001));
         ScriptManager.loadAll();
         a.bl.m67();
         this.f228 = true;
      }
   }
}
