package mixins;

import a.e;
import a.q;
import a.t;
import a.u;
import a.yi;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.PosRot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.StatusOnly;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LocalPlayer.class})
public abstract class LocalPlayerMixin_ag extends AbstractClientPlayer {
   @Shadow
   private float xRotLast;
   @Shadow
   private double zLast;
   @Shadow
   @Final
   protected Minecraft minecraft;
   @Shadow
   private int positionReminder;
   @Shadow
   private boolean autoJumpEnabled;
   @Shadow
   private float yRotLast;
   @Shadow
   private boolean lastHorizontalCollision;
   @Shadow
   @Final
   public ClientPacketListener connection;
   @Shadow
   private double yLast;
   @Shadow
   private boolean lastOnGround;
   @Shadow
   private int sprintTriggerTime;
   @Shadow
   private double xLast;
   

   @Inject(
      method = {"aiStep"},
      at = {@At(
         value = "FIELD",
         target = "Lnet/minecraft/world/entity/player/Abilities;mayfly:Z",
         opcode = 180
      )}
   )
   private void pm$50(CallbackInfo var1) {
      u.f18.m10();
   }

   @Shadow
   protected abstract void sendIsSprintingIfNeeded();

   @Overwrite
   private void sendPosition() {
      e var1 = u.f4.m49(this.getX(), this.getY(), this.getZ(), this.onGround(), this.horizontalCollision);
      var1.m10();
      this.sendIsSprintingIfNeeded();
      if (this.isControlledCamera()) {
         float var3 = u.f6.m63();
         float var4 = u.f6.m69();
         double var5 = var1.m50() - this.xLast;
         double var7 = var1.m52() - this.yLast;
         double var9 = var1.m54() - this.zLast;
         double var11 = var3 - this.yRotLast;
         double var13 = var4 - this.xRotLast;
         this.positionReminder = this.positionReminder + 1;
         int var15 = !(Mth.lengthSquared(var5, var7, var9) > Mth.square(2.0E-4)) && this.positionReminder < 20 ? 0 : 1;
         int var2 = var11 == 0.0 && var13 == 0.0 ? 0 : 1;
         if (var15 != 0 && var2 != 0) {
            this.connection.send(new PosRot(var1.m50(), var1.m52(), var1.m54(), var3, var4, var1.m58(), var1.m60()));
         } else if (var15 != 0) {
            this.connection.send(new Pos(var1.m50(), var1.m52(), var1.m54(), var1.m58(), var1.m60()));
         } else if (var2 != 0) {
            this.connection.send(new Rot(var3, var4, var1.m58(), var1.m60()));
         } else if (this.lastOnGround != var1.m58() || this.lastHorizontalCollision != var1.m60()) {
            this.connection.send(new StatusOnly(var1.m58(), var1.m60()));
         }

         if (var15 != 0) {
            this.xLast = var1.m50();
            this.yLast = var1.m52();
            this.zLast = var1.m54();
            this.positionReminder = 0;
         }

         if (var2 != 0) {
            this.yRotLast = var3;
            this.xRotLast = var4;
         }

         this.lastOnGround = var1.m58();
         this.lastHorizontalCollision = var1.m60();
         this.autoJumpEnabled = this.minecraft.options.autoJump().get();
      }

      q var17 = u.f5;
      var17.m10();
   }

   @Shadow
   protected abstract boolean canStartSprinting();

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pm$47(CallbackInfo var1) {
      u.f6.m62(this.getYRot(), this.getXRot()).m10();
      if (u.f6.m8()) {
         var1.cancel();
      }
   }

   public LocalPlayerMixin_ag(ClientLevel var1, GameProfile var2) {
      super(var1, var2);
   }

   @Redirect(
      method = {"modifyInput"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/player/LocalPlayer;itemUseSpeedMultiplier()F"
      )}
   )
   private float pm$48(LocalPlayer var1) {
      t var2 = u.f10.m79(this.itemUseSpeedMultiplier());
      var2.m10();
      return var2.m80();
   }

   @Redirect(
      method = {"aiStep"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/player/LocalPlayer;canStartSprinting()Z"
      )}
   )
   private boolean pm$49(LocalPlayer var1) {
      yi var2 = u.f13.m82(this.sprintTriggerTime, this.canStartSprinting());
      var2.m10();
      return var2.m85();
   }

   @Shadow
   protected abstract boolean isControlledCamera();

   @Shadow
   protected abstract float itemUseSpeedMultiplier();
}
