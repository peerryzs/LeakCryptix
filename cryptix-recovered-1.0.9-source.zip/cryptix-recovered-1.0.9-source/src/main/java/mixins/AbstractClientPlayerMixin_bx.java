package mixins;

import a.ModuleManager;
import java.nio.charset.StandardCharsets;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.ClientAsset.ResourceTexture;
import net.minecraft.core.ClientAsset.Texture;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({AbstractClientPlayer.class})
public class AbstractClientPlayerMixin_bx {
   @Unique
   private static final Texture f210;
   @Unique
   private static final Texture f209;
   @Unique
   private static final Texture f212;
   @Unique
   private static final Texture f211;
   

   @Inject(
      method = {"getSkin"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void pm$12(CallbackInfoReturnable var1) {
      AbstractClientPlayer var2 = (AbstractClientPlayer)(Object)this;
      if (var2 == Minecraft.getInstance().player) {
         if (ModuleManager.f40.isEnabled()) {
            PlayerSkin var3 = (PlayerSkin)var1.getReturnValue();
            String var4 = ModuleManager.f40.f42.getValue();
            int var5 = -1;
            int var10000 = var4.hashCode();
            if (var10000 == -1582842115) {
               if (var4.equals("Cryptix")) {
                  var5 = 0;
               }
            } else if (var10000 == 67510) {
               if (var4.equals("Cat")) {
                  var5 = 1;
               }
            } else if (var10000 == 83201) {
               if (var4.equals("Sky")) {
                  var5 = 3;
               }
            } else if (var10000 == ('鏈' << 11 | 1151) - 0) {
               if (var4.equals("Pushy")) {
                  var5 = 2;
               }
            }

            switch (var5) {
               case 0:
                  var1.setReturnValue(PlayerSkin.insecure(var3.body(), f209, var3.elytra(), var3.model()));
                  break;
               case 1:
                  var1.setReturnValue(PlayerSkin.insecure(var3.body(), f210, var3.elytra(), var3.model()));
                  break;
               case 2:
                  var1.setReturnValue(PlayerSkin.insecure(var3.body(), f211, var3.elytra(), var3.model()));
                  break;
               case 3:
                  var1.setReturnValue(PlayerSkin.insecure(var3.body(), f212, var3.elytra(), var3.model()));
            }
         }
      }
   }

   static {
      f209 = new ResourceTexture(Identifier.fromNamespaceAndPath("cryptix", "cape"), Identifier.fromNamespaceAndPath("cryptix", "cape.png"));
      f210 = new ResourceTexture(Identifier.fromNamespaceAndPath("cryptix", "cape2"), Identifier.fromNamespaceAndPath("cryptix", "cape2.png"));
      f211 = new ResourceTexture(Identifier.fromNamespaceAndPath("cryptix", "cape3"), Identifier.fromNamespaceAndPath("cryptix", "cape3.png"));
      f212 = new ResourceTexture(Identifier.fromNamespaceAndPath("cryptix", "cape4"), Identifier.fromNamespaceAndPath("cryptix", "cape4.png"));
   }
}
