package mixins;

import a.f;
import a.tu;
import a.u;
import a.w;
import a.xb;
import a.CombatPacketOrder;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.game.ClientboundStartConfigurationPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Connection.class})
public class ConnectionMixin_hs {
   

   @Inject(
      method = {"send(Lnet/minecraft/network/protocol/Packet;Lio/netty/channel/ChannelFutureListener;Z)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pm$19(Packet var1, ChannelFutureListener var2, boolean var3, CallbackInfo var4) {
      w var5 = u.f11.m44(var1);
      var5.m10();
      if (var5.m8()) {
         var4.cancel();
      } else {
         if (xb.m28(var5.m45())) {
            var4.cancel();
         }

         if (tu.m46(var5.m45())) {
            var4.cancel();
         }
         if (!var4.isCancelled()) {
            CombatPacketOrder.observe(var1);
         }
      }
   }

   @Inject(
      method = {"channelRead0"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pm$20(ChannelHandlerContext var1, Packet var2, CallbackInfo var3) {
      f var4 = u.f12.m41(var2);
      var4.m10();
      if (var2 instanceof ClientboundDisconnectPacket || var2 instanceof ClientboundStartConfigurationPacket) {
         xb.m26();
         CombatPacketOrder.resetConnection();
      }

      if (var4.m8()) {
         var3.cancel();
      }
   }
}
