package mixins;

import a.ModuleManager;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({ScreenEffectRenderer.class})
public class ScreenEffectRendererMixin_yg {
   

   @ModifyExpressionValue(
      method = {"submit"},
      at = {@At(
         value = "FIELD",
         target = "Lnet/minecraft/client/renderer/state/level/PlayerRenderState;isOnFire:Z"
      )}
   )
   private boolean pm$56(boolean var1) {
      return (ModuleManager.f33.isEnabled() ? false : var1);
   }
}
