package mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.client.User;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({Minecraft.class})
public interface MinecraftMixin_ea {
   @Accessor("user")
   @Mutable
   void setUser(User var1);

   @Accessor("user")
   User getUser();

   @Accessor("rightClickDelay")
   void setRightClickDelay(int var1);

   @Invoker("startUseItem")
   void invokeStartUseItem();

   @Accessor("rightClickDelay")
   int getRightClickDelay();
}
