package mixins;

import a.i;
import a.u;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundEngine;
import net.minecraft.client.sounds.SoundEngine.PlayResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({SoundEngine.class})
public class SoundEngineMixin_qd {
   

   @Inject(
      method = {"play"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pm$42(SoundInstance var1, CallbackInfoReturnable var2) {
      i var3 = u.f17.m46(var1.getIdentifier());
      var3.m10();
      if (var3.m8()) {
         var2.setReturnValue(PlayResult.NOT_STARTED);
      }
   }
}
