package mixins;

import a.CombatModuleNative;
import a.ModuleManager;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.nio.charset.StandardCharsets;
import net.minecraft.client.renderer.FirstPersonHandsAndItemsRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.state.level.FirstPersonHandsAndItemsRenderState;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({FirstPersonHandsAndItemsRenderer.class})
public class FirstPersonHandsAndItemsRendererMixin_mr {
   

   @Inject(
      method = {"submitArmWithItem"},
      slice = {@Slice(
         from = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/item/ItemStack;getUseAnimation()Lnet/minecraft/world/item/ItemUseAnimation;"
         )
      )},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/renderer/FirstPersonHandsAndItemsRenderer;applyItemArmTransform(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/entity/HumanoidArm;F)V",
         shift = Shift.AFTER
      )}
   )
   private void pm$35(
      PlayerRenderState var1,
      FirstPersonHandsAndItemsRenderState var2,
      float var3,
      float var4,
      InteractionHand var5,
      float var6,
      ItemStack var7,
      float var8,
      PoseStack var9,
      SubmitNodeCollector var10,
      int var11,
      CallbackInfo var12
   ) {
      if (ModuleManager.f36.isEnabled()) {
         CombatModuleNative var13 = ModuleManager.f28;
         AvatarRenderState var14 = var1.avatarRenderState;
         int var15 = var14.isUsingItem && var2.useItemRemainingTicks > 0 && var14.useItemHand == var5 && var7.getUseAnimation() == ItemUseAnimation.BLOCK
            ? 1
            : 0;
         if (var13 != null && var13.f16 && var7.getUseAnimation() == ItemUseAnimation.BLOCK && var14.useItemHand == var5) {
            var15 = 1;
         }

         if (!ModuleManager.f36.f39.getValue() || var15 != 0) {
            float var16 = Mth.sin(var6 * var6 * (float) Math.PI);
            float var17 = Mth.sin(Mth.sqrt(var6) * (float) Math.PI);
            float var18 = (float)ModuleManager.f36.f34.getValue();
            float var19 = (float)ModuleManager.f36.f35.getValue();
            float var20 = (float)ModuleManager.f36.f36.getValue();
            float var21 = (float)ModuleManager.f36.f37.getValue();
            HumanoidArm var22 = var5 == InteractionHand.MAIN_HAND ? var14.mainArm : var14.mainArm.getOpposite();
            float var23 = var22 == HumanoidArm.RIGHT ? 1.0F : -1.0F;
            var9.translate(var19, var20, var21);
            if (var15 != 0) {
               String var24 = ModuleManager.f36.f33.getValue();
               int var25 = -1;
               int var10000 = var24.hashCode();
               if (var10000 == -352259601) {
                  if (var24.equals("Exhibition")) {
                     var25 = 1;
                  }
               } else if (var10000 == 48570) {
                  if (var24.equals("1.7")) {
                     var25 = 0;
                  }
               }

               switch (var25) {
                  case 0:
                     var9.rotateDegrees(Axis.YP, 45.0F * var23);
                     var9.rotateDegrees(Axis.YP, -10.0F * var23);
                     var9.rotateDegrees(Axis.YP, var16 * -20.0F * var23);
                     var9.rotateDegrees(Axis.ZP, var17 * -20.0F * var23);
                     var9.rotateDegrees(Axis.XP, var17 * -80.0F);
                     var9.rotateDegrees(Axis.YP, -45.0F * var23);
                     break;
                  case 1:
                     var9.rotateDegrees(Axis.XP, -var17 * 50.0F);
                     var9.rotateDegrees(Axis.YP, -var17 * 30.0F);
               }

               var9.translate(0.0F, 0.06F, 0.0F);
            }

            var9.scale(0.95F * var18, 0.95F * var18, 0.95F * var18);
         }
      }
   }

   @ModifyExpressionValue(
      method = {"submitArmWithItem"},
      at = {@At(
         value = "FIELD",
         target = "Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;isUsingItem:Z"
      )}
   )
   private boolean pm$33(boolean var1) {
      CombatModuleNative var2 = ModuleManager.f28;
      return (var2 != null && var2.f16 ? true : var1);
   }

   @ModifyExpressionValue(
      method = {"submitArmWithItem"},
      at = {@At(
         value = "FIELD",
         target = "Lnet/minecraft/client/renderer/state/level/FirstPersonHandsAndItemsRenderState;useItemRemainingTicks:I"
      )}
   )
   private int pm$34(int var1) {
      CombatModuleNative var2 = ModuleManager.f28;
      return var2 != null && var2.f16 ? 20 : var1;
   }

   
}
