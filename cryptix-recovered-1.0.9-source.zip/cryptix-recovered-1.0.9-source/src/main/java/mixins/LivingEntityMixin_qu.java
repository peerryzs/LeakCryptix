package mixins;

import a.ModuleManager;
import a.u;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({LivingEntity.class})
public abstract class LivingEntityMixin_qu {
   

   @ModifyReturnValue(
      method = {"getModifiedSwingDuration"},
      at = {@At("RETURN")}
   )
   private int pm$45(int var1) {
      return ModuleManager.f36.isEnabled() ? (int)(var1 * ModuleManager.f36.f38.getValue()) : var1;
   }

   @ModifyExpressionValue(
      method = {"jumpFromGround"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/entity/LivingEntity;getYRot()F"
      )}
   )
   private float pm$46(float var1) {
      if (u.f6.m71()) {
         return u.f6.m73() ? u.f6.m63() : u.f4.m56();
      } else {
         return var1;
      }
   }
}
