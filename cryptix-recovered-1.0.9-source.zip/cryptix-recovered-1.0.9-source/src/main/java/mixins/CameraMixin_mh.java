package mixins;

import a.ModuleManager;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Pose;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({Camera.class})
public class CameraMixin_mh {
   

   @Redirect(
      method = {"tick"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/entity/Entity;getEyeHeight()F"
      )}
   )
   private float pm$13(Entity var1) {
      return ModuleManager.f36.f40.getValue() && ModuleManager.f36.isEnabled() ? var1.getEyeHeight(Pose.STANDING) : var1.getEyeHeight();
   }
}
