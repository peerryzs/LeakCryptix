# Source provenance

The input is `cryptix(1)(1).jar`; its SHA256 is recorded in
`analysis/binary-report.json`. Recoverable Java code was decompiled, renamed and
repaired to compile against the official Minecraft 26.3 classes.

No exact protected native method bodies were extracted from the newer DLL.
The 29 combat/scaffold counterparts use the earlier Minecraft 26.2 Cryptix Java
implementation, with changes for newer signatures and SDL mouse input. Source
comments and `analysis/native-adaptation-map.json` identify their basis.

Version 1.0.6 changes combat behavior further: legacy autoblock packet, slot and
buffer sequences use a shared vanilla item-use lifecycle instead. Unsupported
swords show a visual blocking pose only. Attacks wait for item use to end, and
NoSlow preserves normal slowdown during module-owned blocking. MoveFix direction
conversion, correction handling and continuous yaw calculations are repaired.
These changes are compatibility fixes, not recovered original DLL behavior.

Version 1.0.7 gates combat and autoblock against accepted outgoing input actions
until the real Minecraft 26.3 client tick-end packet. It also defers conflicting
release requests to a free tick, including cleanup after the module is disabled.
This addresses vanilla key handling issuing a release before the player's update
event; separating module updates alone did not separate those network actions.

The nine authentication/support signatures have Java replacements. These provide
a local installation UUID, local diagnostics and explicit authorization rejection;
they do not duplicate the original HWID algorithm, server protocol or secret keys.
The recovered edition uses a startup flow without the original native licensing
screen, exit monitor or window-title authorization check. It never reports a
fabricated original license success.

The newer combat module's additional autoblock mode/range, Scaffold's additional
boolean and extra rotation flags remain uncertain. Earlier-version behavior is
used where evidence is unavailable; unknown labels remain visible in the source.

The original DLL was not executed on the host. CPU emulation reached the packer's
integrity-error path without unpacking original code. See `analysis/native-retry.json`.

Build and verification results are supplied in `validation/`. They establish
compilation, the tested timer/support behavior and static structural checks, not
complete equivalence to the original client or a successful in-game launch.
