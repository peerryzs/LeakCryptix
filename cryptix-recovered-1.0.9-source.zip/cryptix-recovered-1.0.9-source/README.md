# Cryptix Recovered

This source matches the 1.0.7 JAR renamed to `cryptix-recovered-1.0.9-mc26.3.jar`.
The internal mod version remains 1.0.7-recovered, matching that unchanged JAR.

Recovered source and build scripts for Minecraft 26.3, Fabric Loader 0.19.5 or
later, and Java 25 or later. This source includes the latest timer-crash and
access-widener fixes and builds the accompanying 1.0.7-recovered JAR.

KillAura includes Minecraft 26.3 attack-animation packets and uses vanilla item
use and release for autoblock. Attacks and blocking start on separate ticks;
normal item-use slowdown is preserved even with NoSlow enabled. Legacy autoblock
mode names remain for saved configurations, but their old packet/slot tricks are
replaced by this shared behavior. Fake is visual only. Swords without a blocking
use animation also display the pose only; they do not gain server-side blocking.
Silent MoveFix preserves the intended world direction, and rotations keep a
continuous yaw across angle boundaries. These changes have not been tested on a
live multiplayer server and do not guarantee acceptance by an anticheat.

Version 1.0.7 tracks accepted outgoing input-action packets through the actual
client tick-end packet. KillAura waits if vanilla input or another module has
already released, attacked, used, picked or dug during that network tick.
Pending autoblock releases run before key handling on a subsequent free tick,
including after KillAura is disabled. Movement packets do not reset this state.

## Build

Install Python 3 and a Java 25+ JDK, then run from this directory:

```powershell
python build.py
python verify.py
```

Dependencies download into `.build-cache`. The output is
`build/cryptix-recovered-26.3.jar`. Set the `JAVA` environment variable to a
specific `java.exe` path if needed.

Replace the previous Cryptix JAR in your Fabric profile's `mods` directory with
this JAR. Keep only one Cryptix version installed. The mod ID remains `cryptix`.

## Checks

The verification suite checks the packaged timer hook, Fabric's access-widener
parser, mixin targets, compiled bytecode, attack packets, autoblock structure, network-tick packet traces,
rotation/movement math and Java support methods. The source
package includes their results under `validation/`. An automated check is not a
full game-launch or multiplayer test.

## Source provenance

The Java portion was decompiled and deobfuscated from the supplied JAR. For
native methods whose DLL bodies could not be extracted, 29 combat/scaffold
methods use earlier-version Java adaptations and nine support/authentication
methods use Java replacements. This is not an exact deobfuscation of every
original method. See [PROVENANCE.md](PROVENANCE.md) for the remaining differences.

The original All Rights Reserved declaration is preserved.
