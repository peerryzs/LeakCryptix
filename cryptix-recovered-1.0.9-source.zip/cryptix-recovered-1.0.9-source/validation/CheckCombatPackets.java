import java.nio.file.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Ensures each KillAura attack includes its separate 26.3 network animation. */
public class CheckCombatPackets {
    public static void main(String[] args) throws Exception {
        ClassNode c = new ClassNode();
        new ClassReader(Files.readAllBytes(Path.of(args[0]))).accept(c, 0);
        int attacks = 0;
        for (MethodNode method : c.methods) {
            for (AbstractInsnNode insn : method.instructions) {
                if (!(insn instanceof MethodInsnNode call)
                        || !call.owner.equals("net/minecraft/client/multiplayer/MultiPlayerGameMode")
                        || !call.name.equals("attack")) continue;
                attacks++;
                boolean swing = false, punch = false, sent = false;
                for (AbstractInsnNode next = insn.getNext(); next != null; next = next.getNext()) {
                    if (next instanceof JumpInsnNode || next.getOpcode() == Opcodes.RETURN) break;
                    if (next instanceof FieldInsnNode field
                            && field.owner.equals("net/minecraft/network/protocol/game/ServerboundPunchPacket")
                            && field.name.equals("INSTANCE")) punch = true;
                    if (next instanceof MethodInsnNode action) {
                        if (action.name.equals("attack")) break;
                        if (action.name.equals("swing")) swing = true;
                        if (action.name.equals("send")) {
                            if (!swing || !punch) throw new AssertionError(method.name + ": packet before punch");
                            sent = true;
                            break;
                        }
                    }
                }
                if (!sent) throw new AssertionError(method.name + ": missing attack animation packet");
            }
        }
        if (attacks != 2) throw new AssertionError("Expected both KillAura attack paths, got " + attacks);
        System.out.println("PASS: both KillAura attack paths send attack, local swing, then punch before further packets");
    }
}
