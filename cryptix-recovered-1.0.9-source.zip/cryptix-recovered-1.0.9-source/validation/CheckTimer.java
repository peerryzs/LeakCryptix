import a.iw;
import mixins.TimerMixin_nk;
import it.unimi.dsi.fastutil.floats.FloatUnaryOperator;
import java.lang.reflect.Field;

/** Executes the packaged timer hook without starting the game. */
public class CheckTimer {
    static void set(TimerMixin_nk timer, String name, Object value) throws Exception {
        Field f=TimerMixin_nk.class.getDeclaredField(name);f.setAccessible(true);f.set(timer,value);
    }
    static float residual(TimerMixin_nk timer) throws Exception {
        Field f=TimerMixin_nk.class.getDeclaredField("deltaTickResidual");f.setAccessible(true);return f.getFloat(timer);
    }
    static TimerMixin_nk timer(float providerMspt) throws Exception {
        TimerMixin_nk t=new TimerMixin_nk();
        set(t,"lastMs",1000L);set(t,"msPerTick",50f);
        set(t,"targetMsptProvider",(FloatUnaryOperator)(value->providerMspt));
        return t;
    }
    static void check(TimerMixin_nk t,long time,int ticks,float remainder) throws Exception {
        int actual=t.advanceGameTime(time);
        if(actual!=ticks||Math.abs(residual(t)-remainder)>0.00001f)
            throw new AssertionError("At "+time+": ticks="+actual+", residual="+residual(t));
    }
    public static void main(String[] args) throws Exception {
        try {
            iw.m59();
            TimerMixin_nk normal=timer(50f);
            check(normal,1000L,0,0f);
            check(normal,1030L,0,.6f);
            check(normal,1060L,1,.2f);
            check(normal,1310L,5,.2f);
            TimerMixin_nk dynamic=timer(100f);
            check(dynamic,1050L,0,.5f);check(dynamic,1100L,1,0f);
            iw.m57(2f);check(timer(100f),1025L,1,0f);
            iw.m57(.5f);TimerMixin_nk slow=timer(100f);
            check(slow,1050L,0,.5f);check(slow,1100L,1,0f);
            System.out.println("PASS: packaged timer hook executes startup, fractional, multi-tick, dynamic-provider, fast and slow tick cases without boxing casts");
        } finally {iw.m59();}
    }
}
