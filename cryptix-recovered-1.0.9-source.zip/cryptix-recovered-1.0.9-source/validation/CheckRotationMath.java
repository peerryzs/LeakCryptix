import a.ClientRotationMath;

public class CheckRotationMath {
    public static void main(String[] args) {
        int cases = 0;
        for (int previous = -1080; previous <= 1080; previous += 17) {
            for (int target = -180; target <= 180; target += 11) {
                float yaw = ClientRotationMath.continuousYaw(target, previous);
                if (Math.abs(yaw - previous) > 180.001 || ClientRotationMath.angularDistance(yaw, target) > 0.001)
                    throw new AssertionError("Yaw discontinuity");
                cases++;
            }
        }
        for (int camera = -540; camera <= 540; camera += 19) {
            for (int silent = -540; silent <= 540; silent += 23) {
                for (int forward = -1; forward <= 1; forward++) {
                    for (int strafe = -1; strafe <= 1; strafe++) {
                        float[] out = ClientRotationMath.correctMovement(forward, strafe, camera, silent);
                        double magnitude = Math.hypot(out[0], out[1]);
                        if (forward == 0 && strafe == 0) {
                            if (magnitude != 0) throw new AssertionError("Unexpected movement");
                        } else {
                            // Compare actual Minecraft world vectors: x = strafe*cos - forward*sin.
                            double c = Math.toRadians(camera), s = Math.toRadians(silent);
                            double desired = Math.toDegrees(Math.atan2(strafe*Math.cos(c)-forward*Math.sin(c), forward*Math.cos(c)+strafe*Math.sin(c)));
                            double actual = Math.toDegrees(Math.atan2(out[1]*Math.cos(s)-out[0]*Math.sin(s), out[0]*Math.cos(s)+out[1]*Math.sin(s)));
                            if (ClientRotationMath.angularDistance(desired, actual) > 22.501 || Math.abs(magnitude - 1) > 0.001)
                                throw new AssertionError("Movement direction or magnitude mismatch");
                        }
                        cases++;
                    }
                }
            }
        }
        System.out.println("PASS: " + cases + " yaw and movement cases, including wrap boundaries and multiple turns");
    }
}
