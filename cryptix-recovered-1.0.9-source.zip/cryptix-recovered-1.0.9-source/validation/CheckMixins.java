import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;

/** Checks annotation target names against the exact official 26.3 client.
 * Does not substitute for applying mixins in a running game.
 */
public class CheckMixins {
    static Map<String,ClassNode> game=new HashMap<>();
    static Object value(AnnotationNode a,String key) {
        if(a.values!=null)for(int i=0;i<a.values.size();i+=2)if(a.values.get(i).equals(key))return a.values.get(i+1);
        return null;
    }
    static boolean field(String owner,String name) {
        ClassNode c=game.get(owner);if(c==null)return false;
        for(FieldNode f:c.fields)if(f.name.equals(name))return true;
        return c.superName!=null&&field(c.superName,name);
    }
    static List<MethodNode> methods(String owner,String selector) {
        ClassNode c=game.get(owner);if(c==null)return List.of();
        String name=selector.contains("(")?selector.substring(0,selector.indexOf('(')):selector;
        String desc=selector.contains("(")?selector.substring(selector.indexOf('(')):null;
        List<MethodNode> out=new ArrayList<>();
        for(MethodNode m:c.methods)if(m.name.equals(name)&&(desc==null||m.desc.equals(desc)))out.add(m);
        if(out.isEmpty()&&c.superName!=null)out.addAll(methods(c.superName,selector));
        return out;
    }
    static List<AnnotationNode> annotations(List<AnnotationNode> a,List<AnnotationNode> b) {
        List<AnnotationNode> out=new ArrayList<>();if(a!=null)out.addAll(a);if(b!=null)out.addAll(b);return out;
    }
    static int checks=0,errors=0;
    static void require(boolean ok,String message){checks++;if(!ok){errors++;System.out.println("FAIL "+message);}}
    public static void main(String[] args)throws Exception {
        try(JarFile jar=new JarFile(args[0])) {
            for(var e:Collections.list(jar.entries()))if(e.getName().endsWith(".class")) {
                ClassNode c=new ClassNode();new ClassReader(jar.getInputStream(e).readAllBytes()).accept(c,0);game.put(c.name,c);
            }
        }
        try(var files=Files.walk(Path.of(args[1]))) {
            for(Path p:files.filter(p->p.toString().endsWith(".class")).toList()) {
                ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(p)).accept(c,0);
                List<String> targets=new ArrayList<>();
                for(var a:annotations(c.visibleAnnotations,c.invisibleAnnotations))if(a.desc.equals("Lorg/spongepowered/asm/mixin/Mixin;")) {
                    if(value(a,"value") instanceof List<?> v)for(Object t:v)targets.add(((Type)t).getInternalName());
                    if(value(a,"targets") instanceof List<?> v)for(Object t:v)targets.add(t.toString().replace('.','/'));
                }
                for(String target:targets) {
                    require(game.containsKey(target),c.name+" target "+target);
                    for(FieldNode f:c.fields)for(var a:annotations(f.visibleAnnotations,f.invisibleAnnotations))if(a.desc.endsWith("/Shadow;"))require(field(target,f.name),c.name+" shadow field "+f.name);
                    for(MethodNode m:c.methods)for(var a:annotations(m.visibleAnnotations,m.invisibleAnnotations)) {
                        if(a.desc.endsWith("/Accessor;")) {
                            String name=(String)value(a,"value");
                            if(name==null||name.isEmpty()){name=m.name.replaceFirst("^(get|set|is)","");name=Character.toLowerCase(name.charAt(0))+name.substring(1);}
                            require(field(target,name),c.name+" accessor "+name);
                        }
                        if(a.desc.endsWith("/Shadow;")||a.desc.endsWith("/Invoker;")) {
                            String name=(String)value(a,"value");if(name==null||name.isEmpty())name=m.name;
                            require(!methods(target,name+m.desc).isEmpty(),c.name+" shadow/invoker "+name+m.desc);
                        }
                        if(value(a,"method") instanceof List<?> selectors) {
                            List<MethodNode> selected=new ArrayList<>();
                            for(Object selector:selectors) {
                                var found=methods(target,selector.toString());selected.addAll(found);
                                require(!found.isEmpty(),c.name+" injection "+selector);
                            }
                            Object at=value(a,"at");List<?> ats=at instanceof List<?> l?l:at==null?List.of():List.of(at);
                            for(Object item:ats)if(item instanceof AnnotationNode an&&value(an,"target") instanceof String ref&&ref.startsWith("L")) {
                                int end=ref.indexOf(';');String owner=ref.substring(1,end),member=ref.substring(end+1);
                                boolean found=false;
                                for(MethodNode method:selected)for(AbstractInsnNode i:method.instructions) {
                                    if(i instanceof MethodInsnNode call&&call.owner.equals(owner)&&(call.name+call.desc).equals(member))found=true;
                                    if(i instanceof FieldInsnNode f&&f.owner.equals(owner)&&(f.name+":"+f.desc).equals(member))found=true;
                                }
                                require(found,c.name+" injection point "+ref);
                            }
                        }
                    }
                }
            }
        }
        System.out.println("Mixin checks: "+checks+", errors: "+errors);if(errors>0)System.exit(1);
    }
}
