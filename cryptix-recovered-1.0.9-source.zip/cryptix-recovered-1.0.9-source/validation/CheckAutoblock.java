import java.nio.file.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

public class CheckAutoblock {
    public static void main(String[] args) throws Exception {
        ClassNode c = new ClassNode();
        new ClassReader(Files.readAllBytes(Path.of(args[0]))).accept(c, 0);
        boolean use = false, release = false, usingGuard = false;
        for (MethodNode method : c.methods) {
            if (!java.util.Set.of("pm$71", "pm$77", "pm$78", "onEvent", "pm$76").contains(method.name)) continue;
            for (AbstractInsnNode insn : method.instructions) {
                if (insn instanceof TypeInsnNode type && type.getOpcode() == Opcodes.NEW
                        && (type.desc.endsWith("ServerboundUseItemPacket") || type.desc.endsWith("ServerboundSetCarriedItemPacket")))
                    throw new AssertionError("Raw use/slot packet in active autoblock path");
                if (insn instanceof MethodInsnNode call) {
                    if (call.name.equals("startUsingItem")) throw new AssertionError("Forced local item-use state");
                    if (call.owner.endsWith("/xb")) throw new AssertionError("Active autoblock packet buffering");
                    use |= method.name.equals("pm$77") && call.name.equals("useItem");
                    release |= method.name.equals("pm$78") && call.owner.equals("a/CombatPacketOrder") && call.name.equals("requestRelease");
                    usingGuard |= method.name.equals("pm$76") && call.name.equals("isUsingItem");
                }
            }
        }
        if (!use || !release || !usingGuard) throw new AssertionError("Missing vanilla use/release/attack guard");
        System.out.println("PASS: active autoblock uses vanilla use/release, guards attacks, and never fabricates use or slot state");
    }
}
