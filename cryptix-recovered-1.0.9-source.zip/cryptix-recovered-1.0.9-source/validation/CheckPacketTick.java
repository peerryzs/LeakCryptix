import a.CombatPacketOrder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.*;
import net.minecraft.world.InteractionHand;

public class CheckPacketTick {
    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        CombatPacketOrder.resetConnection();
        require(CombatPacketOrder.canAct(), "Fresh connection blocked");
        // Vanilla key handling releases before the module's player-update event.
        CombatPacketOrder.observe(new ServerboundPlayerActionPacket(
                ServerboundPlayerActionPacket.Action.RELEASE_USE_ITEM, BlockPos.ZERO, Direction.DOWN));
        require(!CombatPacketOrder.canAct(), "Release allowed a same-tick attack/use");
        CombatPacketOrder.observe(new ServerboundMovePlayerPacket.Rot(10, 20, true, false));
        require(!CombatPacketOrder.canAct(), "Movement incorrectly reset the input tick");
        CombatPacketOrder.observe(ServerboundClientTickEndPacket.INSTANCE);
        require(CombatPacketOrder.canAct(), "Next tick remained blocked");
        CombatPacketOrder.observe(new ServerboundAttackPacket(1));
        CombatPacketOrder.observe(ServerboundPunchPacket.INSTANCE);
        require(!CombatPacketOrder.canAct(), "Attack allowed a same-tick release/use");
        CombatPacketOrder.observe(ServerboundClientTickEndPacket.INSTANCE);
        CombatPacketOrder.observe(new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, 1, 10, 20));
        require(!CombatPacketOrder.canAct(), "Use allowed a same-tick attack/release");
        CombatPacketOrder.observe(ServerboundClientTickEndPacket.INSTANCE);
        CombatPacketOrder.observe(new ServerboundPickItemFromBlockPacket(BlockPos.ZERO, false));
        require(!CombatPacketOrder.canAct(), "Pick ignored");
        CombatPacketOrder.observe(ServerboundClientTickEndPacket.INSTANCE);
        CombatPacketOrder.observe(new ServerboundPlayerActionPacket(
                ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, BlockPos.ZERO, Direction.DOWN));
        require(!CombatPacketOrder.canAct(), "Dig ignored");
        CombatPacketOrder.resetConnection();
        require(CombatPacketOrder.canAct(), "Reconnect retained stale action state");
        System.out.println("PASS: real outgoing packet traces gate release, attack, use, pick and dig until client tick end; movement does not reset state");
    }
}
