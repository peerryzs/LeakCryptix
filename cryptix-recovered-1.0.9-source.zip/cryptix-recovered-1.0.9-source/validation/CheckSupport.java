import a.NativeGate;
import a.NativeSupport;
import java.nio.file.*;
import java.util.UUID;

public class CheckSupport {
    public static void main(String[] args)throws Exception {
        if(NativeGate.m0(null)||NativeGate.m0("")||NativeGate.m0("arbitrary|input")||NativeGate.f0)
            throw new AssertionError("Recovered boundary fabricated license success");
        String id=NativeSupport.m1();UUID.fromString(id);
        if(!id.equals(NativeSupport.m1()))throw new AssertionError("Unstable local ID");
        if(!id.equals(Files.readString(Path.of("cryptix-recovered/installation-id.txt")).trim()))
            throw new AssertionError("ID not persisted");
        NativeSupport.m3("validation-only");
        if(!Files.readString(Path.of("cryptix-recovered/support-diagnostic.txt")).contains("validation-only"))
            throw new AssertionError("Missing local diagnostic");
        boolean rejected=false;
        try {NativeSupport.m2();}catch(IllegalStateException expected){rejected=true;}
        if(!rejected)throw new AssertionError("Missing explicit unsupported-authorization error");
        System.out.println("PASS: recovered support contracts; local ID, local diagnostic, explicit license rejection");
    }
}
