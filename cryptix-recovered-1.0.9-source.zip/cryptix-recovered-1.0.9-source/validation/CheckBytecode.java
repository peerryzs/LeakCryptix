import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import java.nio.file.*;

public class CheckBytecode {
    public static void main(String[] args)throws Exception {
        int classes=0,methods=0,natives=0;
        try(var walk=Files.walk(Path.of(args[0]))) {
            for(Path p:walk.filter(p->p.toString().endsWith(".class")).toList()) {
                ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(p)).accept(c,0);classes++;
                if(c.version!=69)throw new AssertionError("Wrong Java release: "+c.name+" "+c.version);
                for(MethodNode m:c.methods) {
                    if((m.access&Opcodes.ACC_NATIVE)!=0)natives++;
                    if((m.access&(Opcodes.ACC_NATIVE|Opcodes.ACC_ABSTRACT))==0) {
                        new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);methods++;
                    }
                }
            }
        }
        if(natives!=0)throw new AssertionError(natives+" native declarations remain");
        System.out.println("PASS: "+classes+" Java 25 classes, "+methods+" method bodies verified, no native declarations");
    }
}
