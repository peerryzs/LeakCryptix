import net.fabricmc.loader.impl.lib.classtweaker.api.ClassTweaker;
import net.fabricmc.loader.impl.lib.classtweaker.reader.ClassTweakerReaderImpl;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import java.util.jar.JarFile;

/** Parse the actual packaged resource with Fabric Loader's runtime parser. */
public class CheckAccessWidener {
    public static void main(String[] args) throws Exception {
        var tweaker = ClassTweaker.newInstance();
        try (var mod = new JarFile(args[0]); var game = new JarFile(args[1])) {
            var entry = mod.getJarEntry("cryptix-recovered.accesswidener");
            if (entry == null) throw new AssertionError("Missing packaged access widener");
            new ClassTweakerReaderImpl(tweaker).read(mod.getInputStream(entry).readAllBytes(), "official");
            int checked = 0;
            for (String target : tweaker.getTargets()) {
                String path = target.replace('.', '/') + ".class";
                var targetEntry = game.getJarEntry(path);
                if (targetEntry == null) throw new AssertionError("Missing target " + target);
                var writer = new ClassWriter(0);
                var visitor = tweaker.createClassVisitor(Opcodes.ASM9, writer, (name, bytes) -> {});
                new ClassReader(game.getInputStream(targetEntry).readAllBytes()).accept(visitor, 0);
                new ClassReader(writer.toByteArray());
                checked++;
            }
            if (checked != 3) throw new AssertionError("Expected three affected classes, got " + checked);
            System.out.println("PASS: packaged access widener parses in official runtime namespace and transforms " + checked + " game classes");
        }
    }
}
