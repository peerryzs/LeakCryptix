import javax.tools.ToolProvider;
import java.util.ArrayList;
import java.util.List;

/** Small compiler driver, allowing reproducible builds without Gradle.
 * The OS releases compiler files on process exit. Leaving the file manager open
 * avoids a JDK zipfs canonical-path close bug under restricted Windows accounts.
 */
class CompileClient {
    public static void main(String[] args) {
        var compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new IllegalStateException("A Java 25+ JDK is required");
        List<String> options = new ArrayList<>();
        List<String> sources = new ArrayList<>();
        for (String arg : args) {
            if (arg.endsWith(".java")) sources.add(arg);
            else options.add(arg);
        }
        var manager = compiler.getStandardFileManager(null, null, java.nio.charset.StandardCharsets.UTF_8);
        boolean passed = compiler.getTask(null, manager, null, options, null,
            manager.getJavaFileObjectsFromStrings(sources)).call();
        System.exit(passed ? 0 : 1);
    }
}
