"""Apply the shipped Fabric access widener to the compile-only Minecraft jar.
The original download is left untouched and never bundled in the output mod.
"""
import struct, zipfile

def widened(data, wanted_fields=(), public_class=False):
    b=bytearray(data); pos=10; cp={}; count=struct.unpack_from('>H',b,8)[0]; i=1
    def u2(offset): return struct.unpack_from('>H',b,offset)[0]
    while i<count:
        tag=b[pos];pos+=1
        if tag==1:
            n=u2(pos);pos+=2;cp[i]=bytes(b[pos:pos+n]).decode('utf-8',errors='replace');pos+=n
        elif tag in (3,4,9,10,11,12,17,18):pos+=4
        elif tag in (5,6):pos+=8;i+=1
        elif tag in (7,8,16,19,20):cp[i]=u2(pos);pos+=2
        elif tag==15:pos+=3
        else:raise ValueError(tag)
        i+=1
    def accessible(at): struct.pack_into('>H',b,at,(u2(at)&~6)|1)
    if public_class:accessible(pos)
    pos+=6;pos+=2+2*u2(pos)
    for kind in ('fields','methods'):
        n=u2(pos);pos+=2
        for _ in range(n):
            if kind=='fields' and cp[u2(pos+2)] in wanted_fields:accessible(pos)
            attrs=u2(pos+6);pos+=8
            for _ in range(attrs):
                size=struct.unpack_from('>I',b,pos+2)[0];pos+=6+size
    n=u2(pos);pos+=2
    for _ in range(n):
        name=cp[u2(pos)];size=struct.unpack_from('>I',b,pos+2)[0];start=pos+6
        if name=='InnerClasses':
            for j in range(u2(start)):
                at=start+2+j*8; index=u2(at)
                if index and cp.get(cp.get(index))=='net/minecraft/client/gui/GuiGraphicsExtractor$ScissorStack':accessible(at+6)
        pos=start+size
    return b

def prepare(source,target):
    targets={
      'net/minecraft/client/gui/GuiGraphicsExtractor.class':(('guiRenderState','scissorStack'),False),
      'net/minecraft/client/gui/GuiGraphicsExtractor$ScissorStack.class':((),True),
      'net/minecraft/client/Minecraft.class':(('missTime',),False),
    }
    with zipfile.ZipFile(source) as zin,zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data=zin.read(item.filename)
            if item.filename in targets:data=widened(data,*targets[item.filename])
            zout.writestr(item,data)
    return target
