"""Run structural checks and the implemented in Java support-contract smoke test."""
from pathlib import Path
import os, subprocess, sys
from build import ROOT, CACHE, dependencies

def run():
    if not (ROOT/'build/cryptix-recovered-26.3.jar').exists():
        raise SystemExit('Run python build.py first')
    jars=dependencies()
    java=os.environ.get('JAVA','java')
    asm=os.pathsep.join(map(str,(CACHE/'libraries/org/ow2/asm').rglob('*.jar')))
    loader_cp=asm+os.pathsep+str(CACHE/'fabric-loader.jar')
    runtime_cp=os.pathsep.join(map(str,jars+[ROOT/'build/cryptix-recovered-26.3.jar']))
    checks=[('timer',[java,'-cp',runtime_cp,str(ROOT/'validation/CheckTimer.java')]),
            ('access-widener',[java,'-cp',loader_cp,str(ROOT/'validation/CheckAccessWidener.java'),str(ROOT/'build/cryptix-recovered-26.3.jar'),str(CACHE/'minecraft-26.3.jar')]),
            ('mixins',[java,'-cp',asm,str(ROOT/'validation/CheckMixins.java'),str(CACHE/'minecraft-26.3.jar'),str(ROOT/'build/classes/mixins')]),
            ('bytecode',[java,'-cp',asm,str(ROOT/'validation/CheckBytecode.java'),str(ROOT/'build/classes')]),
            ('combat-packets',[java,'-cp',asm,str(ROOT/'validation/CheckCombatPackets.java'),str(ROOT/'build/classes/a/CombatModuleNative.class')]),
            ('autoblock',[java,'-cp',asm,str(ROOT/'validation/CheckAutoblock.java'),str(ROOT/'build/classes/a/CombatModuleNative.class')]),
            ('packet-tick',[java,'-cp',runtime_cp,str(ROOT/'validation/CheckPacketTick.java')]),
            ('rotation-math',[java,'-cp',str(ROOT/'build/cryptix-recovered-26.3.jar'),str(ROOT/'validation/CheckRotationMath.java')]),
            ('support',[java,'-cp',str(ROOT/'build/cryptix-recovered-26.3.jar'),str(ROOT/'validation/CheckSupport.java')])]
    sandbox=ROOT/'build/validation-sandbox';sandbox.mkdir(parents=True,exist_ok=True)
    for name,cmd in checks:
        result=subprocess.run(cmd,cwd=sandbox,capture_output=True,text=True,encoding='utf-8',errors='replace')
        log=result.stdout+result.stderr
        print(log,flush=True)
        (ROOT/'validation'/f'{name}-results.txt').write_text(log,encoding='utf-8')
        if result.returncode:return result.returncode
    print('All checks passed. These do not replace an in-game launch test.')
    return 0

if __name__=='__main__':sys.exit(run())
