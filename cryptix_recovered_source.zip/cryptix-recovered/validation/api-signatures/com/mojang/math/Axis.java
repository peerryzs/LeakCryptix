package com.mojang.math;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface Axis {
    public static com.mojang.math.Axis YP = null;
    public static com.mojang.math.Axis ZP = null;
    public static com.mojang.math.Axis XP = null;
    public default org.joml.Quaternionf rotationDegrees(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
