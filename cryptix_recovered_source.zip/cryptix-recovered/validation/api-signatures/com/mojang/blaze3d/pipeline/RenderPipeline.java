package com.mojang.blaze3d.pipeline;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class RenderPipeline {
    public RenderPipeline() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
