package com.mojang.blaze3d.vertex;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class PoseStack {
    public void translate(float p0, float p1, float p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void mulPose(org.joml.Quaternionfc p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void scale(float p0, float p1, float p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void pushPose() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void popPose() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void translate(double p0, double p1, double p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public PoseStack() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
