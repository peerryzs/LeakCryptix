package com.mojang.blaze3d.platform;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class InputConstants {
    public static com.mojang.blaze3d.platform.InputConstants.Key UNKNOWN = null;
    public InputConstants() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static class Key {
        public int getValue() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public Key() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
    public static class Type {
        public static com.mojang.blaze3d.platform.InputConstants.Type KEYSYM = null;
        public static com.mojang.blaze3d.platform.InputConstants.Type MOUSE = null;
        public com.mojang.blaze3d.platform.InputConstants.Key getOrCreate(int p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public Type() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
}
