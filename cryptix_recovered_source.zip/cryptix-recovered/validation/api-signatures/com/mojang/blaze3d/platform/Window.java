package com.mojang.blaze3d.platform;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Window {
    public long handle() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getGuiScaledWidth() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getGuiScaledHeight() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Window() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
