package com.mojang.authlib;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class GameProfile {
    public java.util.UUID id() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public GameProfile() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
