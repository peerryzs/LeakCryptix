package com.mojang.brigadier;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class CommandDispatcher {
    public java.util.concurrent.CompletableFuture getCompletionSuggestions(com.mojang.brigadier.ParseResults p0, int p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public CommandDispatcher() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
