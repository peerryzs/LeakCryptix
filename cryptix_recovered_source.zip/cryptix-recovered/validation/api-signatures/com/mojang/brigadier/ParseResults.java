package com.mojang.brigadier;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ParseResults {
    public ParseResults() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
