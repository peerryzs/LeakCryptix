package com.mojang.brigadier;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class StringReader {
    public boolean canRead() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public char peek() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void skip() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public StringReader() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
