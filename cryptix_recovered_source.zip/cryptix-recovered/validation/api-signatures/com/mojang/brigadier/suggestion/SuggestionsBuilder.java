package com.mojang.brigadier.suggestion;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class SuggestionsBuilder {
    public SuggestionsBuilder(java.lang.String p0, int p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public SuggestionsBuilder() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
