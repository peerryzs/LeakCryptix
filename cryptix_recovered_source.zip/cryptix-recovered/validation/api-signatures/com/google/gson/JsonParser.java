package com.google.gson;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class JsonParser {
    public static com.google.gson.JsonElement parseString(java.lang.String p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static com.google.gson.JsonElement parseReader(java.io.Reader p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public JsonParser() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
