package com.google.gson;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class JsonElement {
    public com.google.gson.JsonObject getAsJsonObject() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public java.lang.String getAsString() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean getAsBoolean() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getAsInt() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getAsDouble() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public JsonElement() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
