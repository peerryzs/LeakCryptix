package com.google.gson;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class JsonObject extends com.google.gson.JsonElement {
    public com.google.gson.JsonElement get(java.lang.String p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public JsonObject() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void addProperty(java.lang.String p0, java.lang.Boolean p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void addProperty(java.lang.String p0, java.lang.Number p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void addProperty(java.lang.String p0, java.lang.String p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void add(java.lang.String p0, com.google.gson.JsonElement p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean has(java.lang.String p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public com.google.gson.JsonObject getAsJsonObject(java.lang.String p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
