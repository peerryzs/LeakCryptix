package com.google.gson;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Gson {
    public void toJson(com.google.gson.JsonElement p0, java.lang.Appendable p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Gson() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
