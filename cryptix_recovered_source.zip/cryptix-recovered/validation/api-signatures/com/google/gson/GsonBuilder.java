package com.google.gson;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class GsonBuilder {
    public GsonBuilder() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public com.google.gson.GsonBuilder setPrettyPrinting() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public com.google.gson.Gson create() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
