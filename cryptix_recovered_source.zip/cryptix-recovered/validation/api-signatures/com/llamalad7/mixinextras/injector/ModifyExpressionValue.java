package com.llamalad7.mixinextras.injector;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public @interface ModifyExpressionValue {
    String[] method() default {};
    org.spongepowered.asm.mixin.injection.At[] at() default {};
}
