package io.netty.channel;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ChannelFutureListener {
    public ChannelFutureListener() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
