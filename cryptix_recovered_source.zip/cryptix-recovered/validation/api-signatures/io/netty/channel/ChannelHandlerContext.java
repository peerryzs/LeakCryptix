package io.netty.channel;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ChannelHandlerContext {
    public ChannelHandlerContext() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
