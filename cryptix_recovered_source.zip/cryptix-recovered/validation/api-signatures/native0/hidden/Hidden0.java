package native0.hidden;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Hidden0 {
    public static void special_clinit_0_00(java.lang.Class p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static void special_clinit_1_30(java.lang.Class p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Hidden0() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
