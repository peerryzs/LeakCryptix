package org.lwjgl.glfw;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class GLFW {
    public static int glfwGetKey(long p0, int p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static int glfwGetMouseButton(long p0, int p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static java.lang.String glfwGetKeyName(int p0, int p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static void glfwSetWindowTitle(long p0, java.lang.CharSequence p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public GLFW() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
