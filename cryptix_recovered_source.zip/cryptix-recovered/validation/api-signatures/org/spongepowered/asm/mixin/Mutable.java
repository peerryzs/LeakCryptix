package org.spongepowered.asm.mixin;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public @interface Mutable {
}
