package org.spongepowered.asm.mixin.injection;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public @interface Inject {
    String[] method() default {};
    org.spongepowered.asm.mixin.injection.At[] at() default {};
    boolean cancellable() default false;
    org.spongepowered.asm.mixin.injection.Slice[] slice() default {};
}
