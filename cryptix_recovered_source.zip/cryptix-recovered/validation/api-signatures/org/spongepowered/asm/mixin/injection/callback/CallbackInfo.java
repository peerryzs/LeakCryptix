package org.spongepowered.asm.mixin.injection.callback;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class CallbackInfo {
    public void cancel() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public CallbackInfo() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
