package org.spongepowered.asm.mixin.injection;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public @interface ModifyVariable {
    String[] method() default {};
    org.spongepowered.asm.mixin.injection.At at() default @org.spongepowered.asm.mixin.injection.At;
    int ordinal() default 0;
}
