package org.spongepowered.asm.mixin.injection.callback;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class CallbackInfoReturnable extends org.spongepowered.asm.mixin.injection.callback.CallbackInfo {
    public java.lang.Object getReturnValue() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setReturnValue(java.lang.Object p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public CallbackInfoReturnable() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
