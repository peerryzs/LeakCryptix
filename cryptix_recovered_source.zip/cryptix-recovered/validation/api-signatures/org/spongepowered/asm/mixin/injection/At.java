package org.spongepowered.asm.mixin.injection;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public @interface At {
    String value() default "";
    String target() default "";
    org.spongepowered.asm.mixin.injection.At.Shift shift() default org.spongepowered.asm.mixin.injection.At.Shift.AFTER;
    int ordinal() default 0;
    int opcode() default 0;
    public static enum Shift {
        AFTER, BEFORE;
    }
}
