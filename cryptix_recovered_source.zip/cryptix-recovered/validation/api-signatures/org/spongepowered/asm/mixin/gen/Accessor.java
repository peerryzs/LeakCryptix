package org.spongepowered.asm.mixin.gen;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public @interface Accessor {
    String value() default "";
}
