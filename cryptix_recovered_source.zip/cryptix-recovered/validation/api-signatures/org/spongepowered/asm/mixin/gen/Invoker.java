package org.spongepowered.asm.mixin.gen;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public @interface Invoker {
    String value() default "";
}
