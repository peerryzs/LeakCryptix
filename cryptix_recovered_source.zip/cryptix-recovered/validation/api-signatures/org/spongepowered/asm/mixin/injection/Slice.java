package org.spongepowered.asm.mixin.injection;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public @interface Slice {
    org.spongepowered.asm.mixin.injection.At from() default @org.spongepowered.asm.mixin.injection.At;
}
