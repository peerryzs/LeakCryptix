package org.spongepowered.asm.mixin;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public @interface Mixin {
    Class<?>[] value() default {};
    String[] targets() default {};
}
