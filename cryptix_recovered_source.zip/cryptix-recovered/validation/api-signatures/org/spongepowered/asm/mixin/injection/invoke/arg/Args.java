package org.spongepowered.asm.mixin.injection.invoke.arg;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Args {
    public java.lang.Object get(int p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void set(int p0, java.lang.Object p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Args() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
