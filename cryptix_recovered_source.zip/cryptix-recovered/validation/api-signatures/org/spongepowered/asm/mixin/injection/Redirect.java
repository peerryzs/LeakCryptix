package org.spongepowered.asm.mixin.injection;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public @interface Redirect {
    String[] method() default {};
    org.spongepowered.asm.mixin.injection.At at() default @org.spongepowered.asm.mixin.injection.At;
}
