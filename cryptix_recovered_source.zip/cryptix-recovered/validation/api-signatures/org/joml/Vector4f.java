package org.joml;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Vector4f {
    public float w = 0.0f;
    public float x = 0.0f;
    public float y = 0.0f;
    public float z = 0.0f;
    public Vector4f() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public org.joml.Vector4f set(float p0, float p1, float p2, float p3) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public org.joml.Vector4f mul(org.joml.Matrix4fc p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
