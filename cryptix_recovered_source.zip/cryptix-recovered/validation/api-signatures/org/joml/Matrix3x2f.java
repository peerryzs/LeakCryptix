package org.joml;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Matrix3x2f {
    public Matrix3x2f() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
