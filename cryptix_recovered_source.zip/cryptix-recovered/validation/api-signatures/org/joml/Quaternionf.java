package org.joml;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Quaternionf implements org.joml.Quaternionfc {
    public Quaternionf() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
