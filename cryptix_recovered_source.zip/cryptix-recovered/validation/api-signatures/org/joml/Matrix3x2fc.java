package org.joml;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface Matrix3x2fc {
}
