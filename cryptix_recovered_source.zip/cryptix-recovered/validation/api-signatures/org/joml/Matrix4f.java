package org.joml;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Matrix4f implements org.joml.Matrix4fc {
    public Matrix4f() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public org.joml.Matrix4f set(org.joml.Matrix4fc p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
