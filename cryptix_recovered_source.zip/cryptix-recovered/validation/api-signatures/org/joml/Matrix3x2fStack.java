package org.joml;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Matrix3x2fStack implements org.joml.Matrix3x2fc {
    public org.joml.Matrix3x2fStack pushMatrix() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public org.joml.Matrix3x2f scale(float p0, float p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public org.joml.Matrix3x2fStack popMatrix() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Matrix3x2fStack() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
