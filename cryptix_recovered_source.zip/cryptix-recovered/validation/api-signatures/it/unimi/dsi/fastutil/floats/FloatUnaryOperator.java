package it.unimi.dsi.fastutil.floats;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface FloatUnaryOperator {
    public default float apply(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
