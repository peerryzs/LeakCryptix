# Compilation-only API signatures

These are nonfunctional, automatically inferred external API fixtures used ONLY to check Java source consistency. They are not Minecraft, Fabric, Gson, LWJGL, JOML, Mixin, or a native loader implementation. Most methods intentionally throw AssertionError. Do not put these files or their compiled classes in a client build, runtime classpath, or distributed mod. Use the real version-matched dependencies for a real build.

The declarations were inferred from bytecode call sites, supplemented with basic type relationships for compilation. They do not establish the real API's complete overload set, generic bounds, annotations, or runtime behavior.
