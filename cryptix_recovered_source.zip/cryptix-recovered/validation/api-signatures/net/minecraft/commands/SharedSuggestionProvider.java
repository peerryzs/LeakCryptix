package net.minecraft.commands;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class SharedSuggestionProvider {
    public static java.util.concurrent.CompletableFuture suggest(java.lang.Iterable p0, com.mojang.brigadier.suggestion.SuggestionsBuilder p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public SharedSuggestionProvider() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
