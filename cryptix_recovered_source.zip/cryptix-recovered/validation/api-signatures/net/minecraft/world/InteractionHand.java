package net.minecraft.world;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class InteractionHand {
    public static net.minecraft.world.InteractionHand MAIN_HAND = null;
    public InteractionHand() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
