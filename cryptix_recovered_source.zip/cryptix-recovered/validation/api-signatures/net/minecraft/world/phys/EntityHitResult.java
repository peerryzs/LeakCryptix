package net.minecraft.world.phys;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class EntityHitResult extends net.minecraft.world.phys.HitResult {
    public EntityHitResult(net.minecraft.world.entity.Entity p0, net.minecraft.world.phys.Vec3 p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 getLocation() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public EntityHitResult() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
