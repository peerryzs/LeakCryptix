package net.minecraft.world.phys;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class AABB {
    public double minX = 0.0;
    public double maxX = 0.0;
    public double minY = 0.0;
    public double maxY = 0.0;
    public double minZ = 0.0;
    public double maxZ = 0.0;
    public boolean contains(net.minecraft.world.phys.Vec3 p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public java.util.Optional clip(net.minecraft.world.phys.Vec3 p0, net.minecraft.world.phys.Vec3 p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.AABB inflate(double p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public AABB() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
