package net.minecraft.world.phys;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Vec2 {
    public float y = 0.0f;
    public float x = 0.0f;
    public Vec2(float p0, float p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float length() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec2 normalized() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Vec2() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
