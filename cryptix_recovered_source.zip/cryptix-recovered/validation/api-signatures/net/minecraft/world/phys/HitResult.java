package net.minecraft.world.phys;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class HitResult {
    public net.minecraft.world.phys.HitResult.Type getType() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public HitResult() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static class Type {
        public static net.minecraft.world.phys.HitResult.Type BLOCK = null;
        public Type() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
}
