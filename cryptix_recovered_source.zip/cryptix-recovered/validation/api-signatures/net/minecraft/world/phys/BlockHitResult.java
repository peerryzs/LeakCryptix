package net.minecraft.world.phys;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class BlockHitResult extends net.minecraft.world.phys.HitResult {
    public net.minecraft.core.BlockPos getBlockPos() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.core.Direction getDirection() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 getLocation() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public BlockHitResult(net.minecraft.world.phys.Vec3 p0, net.minecraft.core.Direction p1, net.minecraft.core.BlockPos p2, boolean p3) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public BlockHitResult() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
