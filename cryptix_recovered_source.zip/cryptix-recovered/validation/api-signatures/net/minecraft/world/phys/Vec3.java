package net.minecraft.world.phys;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Vec3 {
    public double y = 0.0;
    public double x = 0.0;
    public double z = 0.0;
    public net.minecraft.world.phys.Vec3 add(net.minecraft.world.phys.Vec3 p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 multiply(double p0, double p1, double p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Vec3(double p0, double p1, double p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 scale(double p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 subtract(double p0, double p1, double p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double distanceTo(net.minecraft.world.phys.Vec3 p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 normalize() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 subtract(net.minecraft.world.phys.Vec3 p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double dot(net.minecraft.world.phys.Vec3 p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static net.minecraft.world.phys.Vec3 atCenterOf(net.minecraft.core.Vec3i p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 add(double p0, double p1, double p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static net.minecraft.world.phys.Vec3 directionFromRotation(float p0, float p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Vec3() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
