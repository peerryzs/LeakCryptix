package net.minecraft.world.inventory;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Slot {
    public net.minecraft.world.item.ItemStack getItem() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Slot() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
