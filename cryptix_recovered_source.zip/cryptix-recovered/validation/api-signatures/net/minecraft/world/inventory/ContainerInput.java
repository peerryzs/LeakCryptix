package net.minecraft.world.inventory;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ContainerInput {
    public static net.minecraft.world.inventory.ContainerInput PICKUP = null;
    public static net.minecraft.world.inventory.ContainerInput QUICK_MOVE = null;
    public static net.minecraft.world.inventory.ContainerInput THROW = null;
    public static net.minecraft.world.inventory.ContainerInput SWAP = null;
    public ContainerInput() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
