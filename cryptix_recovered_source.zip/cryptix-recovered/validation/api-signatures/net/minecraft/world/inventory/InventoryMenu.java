package net.minecraft.world.inventory;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class InventoryMenu extends net.minecraft.world.inventory.AbstractContainerMenu {
    public InventoryMenu() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
