package net.minecraft.world.inventory;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class AbstractContainerMenu {
    public int containerId = 0;
    public AbstractContainerMenu() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
