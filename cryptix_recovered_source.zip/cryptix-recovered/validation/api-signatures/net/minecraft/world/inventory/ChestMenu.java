package net.minecraft.world.inventory;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ChestMenu extends net.minecraft.world.inventory.AbstractContainerMenu {
    public int containerId = 0;
    public net.minecraft.world.Container getContainer() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.inventory.Slot getSlot(int p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ChestMenu() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
