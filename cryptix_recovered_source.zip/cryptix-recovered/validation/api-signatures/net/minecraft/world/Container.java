package net.minecraft.world;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface Container {
    public default int getContainerSize() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
