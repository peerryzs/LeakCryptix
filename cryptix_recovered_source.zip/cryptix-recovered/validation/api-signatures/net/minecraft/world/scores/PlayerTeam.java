package net.minecraft.world.scores;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class PlayerTeam extends net.minecraft.world.scores.Team {
    public PlayerTeam() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
