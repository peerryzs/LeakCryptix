package net.minecraft.world.scores;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class TeamColor {
    public int rgb() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public TeamColor() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
