package net.minecraft.world.scores;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Team {
    public java.util.Optional getColor() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Team() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
