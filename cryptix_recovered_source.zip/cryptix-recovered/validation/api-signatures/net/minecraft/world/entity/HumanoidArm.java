package net.minecraft.world.entity;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class HumanoidArm {
    public static net.minecraft.world.entity.HumanoidArm RIGHT = null;
    public HumanoidArm() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
