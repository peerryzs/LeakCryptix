package net.minecraft.world.entity.projectile.hurtingprojectile;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Fireball extends net.minecraft.world.entity.Entity {
    public net.minecraft.world.entity.Entity getOwner() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Fireball() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
