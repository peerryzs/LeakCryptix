package net.minecraft.world.entity.player;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Abilities {
    public boolean flying = false;
    public void setFlyingSpeed(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Abilities() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
