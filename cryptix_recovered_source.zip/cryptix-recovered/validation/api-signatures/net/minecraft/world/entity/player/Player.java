package net.minecraft.world.entity.player;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Player extends net.minecraft.world.entity.LivingEntity {
    public double xOld = 0.0;
    public double yOld = 0.0;
    public double zOld = 0.0;
    public int deathTime = 0;
    public java.util.UUID getUUID() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isUsingItem() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.item.ItemStack getUseItem() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.scores.PlayerTeam getTeam() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getX() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getY() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getZ() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getBbWidth() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getBbHeight() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getHealth() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getMaxHealth() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.network.chat.Component getDisplayName() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public com.mojang.authlib.GameProfile getGameProfile() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isAlive() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isRemoved() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Player() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
