package net.minecraft.world.entity.projectile.hurtingprojectile;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class SmallFireball extends net.minecraft.world.entity.projectile.hurtingprojectile.Fireball {
    public SmallFireball() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
