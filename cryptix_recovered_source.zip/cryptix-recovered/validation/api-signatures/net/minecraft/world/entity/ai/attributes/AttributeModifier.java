package net.minecraft.world.entity.ai.attributes;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class AttributeModifier {
    public double amount() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public AttributeModifier() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
