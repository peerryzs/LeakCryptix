package net.minecraft.world.entity.player;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class PlayerSkin {
    public net.minecraft.core.ClientAsset.Texture body() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.core.ClientAsset.Texture elytra() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.entity.player.PlayerModelType model() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static net.minecraft.world.entity.player.PlayerSkin insecure(net.minecraft.core.ClientAsset.Texture p0, net.minecraft.core.ClientAsset.Texture p1, net.minecraft.core.ClientAsset.Texture p2, net.minecraft.world.entity.player.PlayerModelType p3) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public PlayerSkin() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
