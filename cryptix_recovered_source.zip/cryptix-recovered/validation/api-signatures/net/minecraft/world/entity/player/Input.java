package net.minecraft.world.entity.player;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Input {
    public boolean forward() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean backward() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean left() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean right() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean jump() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean shift() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean sprint() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Input(boolean p0, boolean p1, boolean p2, boolean p3, boolean p4, boolean p5, boolean p6) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Input() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
