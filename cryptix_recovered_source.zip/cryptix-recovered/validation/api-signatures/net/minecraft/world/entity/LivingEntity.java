package net.minecraft.world.entity;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class LivingEntity extends net.minecraft.world.entity.Entity {
    public int deathTime = 0;
    public net.minecraft.world.phys.Vec3 position() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isAlive() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isRemoved() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public LivingEntity() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
