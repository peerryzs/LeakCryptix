package net.minecraft.world.entity.ai.attributes;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Attributes {
    public static net.minecraft.core.Holder ATTACK_DAMAGE = null;
    public static net.minecraft.core.Holder ARMOR = null;
    public Attributes() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
