package net.minecraft.world.entity;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class PositionMoveRotation {
    public net.minecraft.world.phys.Vec3 position() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public PositionMoveRotation() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
