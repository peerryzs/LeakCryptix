package net.minecraft.world.entity.projectile.hurtingprojectile;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class LargeFireball extends net.minecraft.world.entity.projectile.hurtingprojectile.Fireball {
    public LargeFireball() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
