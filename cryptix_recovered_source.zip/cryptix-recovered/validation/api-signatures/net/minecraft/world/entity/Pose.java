package net.minecraft.world.entity;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Pose {
    public static net.minecraft.world.entity.Pose STANDING = null;
    public Pose() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
