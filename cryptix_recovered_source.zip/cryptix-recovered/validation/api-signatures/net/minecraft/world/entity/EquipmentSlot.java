package net.minecraft.world.entity;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class EquipmentSlot {
    public static net.minecraft.world.entity.EquipmentSlot HEAD = null;
    public static net.minecraft.world.entity.EquipmentSlot CHEST = null;
    public static net.minecraft.world.entity.EquipmentSlot LEGS = null;
    public static net.minecraft.world.entity.EquipmentSlot FEET = null;
    public static net.minecraft.world.entity.EquipmentSlot MAINHAND = null;
    public static net.minecraft.world.entity.EquipmentSlot[] values() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int ordinal() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public EquipmentSlot() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
