package net.minecraft.world.entity;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Entity {
    public float getEyeHeight(net.minecraft.world.entity.Pose p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getEyeHeight() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getYRot() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 getDeltaMovement() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setDeltaMovement(net.minecraft.world.phys.Vec3 p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getTeamColor() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.AABB getBoundingBox() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getX() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getY() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getZ() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getId() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 getEyePosition(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 getViewVector(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getEyeY() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isAlive() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 getEyePosition() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 position() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Entity() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
