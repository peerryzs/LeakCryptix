package net.minecraft.world.entity.player;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Inventory {
    public int getSelectedSlot() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.item.ItemStack getItem(int p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setSelectedSlot(int p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.core.NonNullList getNonEquipmentItems() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Inventory() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
