package net.minecraft.world.entity.player;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class PlayerModelType {
    public PlayerModelType() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
