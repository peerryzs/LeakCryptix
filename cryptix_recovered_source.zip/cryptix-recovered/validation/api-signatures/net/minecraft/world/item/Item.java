package net.minecraft.world.item;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Item implements net.minecraft.world.level.ItemLike {
    public Item() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
