package net.minecraft.world.item.equipment;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Equippable {
    public net.minecraft.world.entity.EquipmentSlot slot() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Equippable() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
