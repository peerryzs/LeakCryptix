package net.minecraft.world.item;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ItemUseAnimation {
    public static net.minecraft.world.item.ItemUseAnimation BLOCK = null;
    public ItemUseAnimation() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
