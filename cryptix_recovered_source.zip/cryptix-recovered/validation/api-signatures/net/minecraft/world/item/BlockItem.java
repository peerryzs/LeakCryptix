package net.minecraft.world.item;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class BlockItem extends net.minecraft.world.item.Item {
    public BlockItem() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
