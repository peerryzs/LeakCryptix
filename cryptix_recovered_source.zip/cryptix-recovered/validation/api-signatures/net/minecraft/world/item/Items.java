package net.minecraft.world.item;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Items {
    public static net.minecraft.world.item.Item SHIELD = null;
    public static net.minecraft.world.item.Item WIND_CHARGE = null;
    public static net.minecraft.world.item.Item FIRE_CHARGE = null;
    public static net.minecraft.world.item.Item HONEY_BOTTLE = null;
    public static net.minecraft.world.item.Item GOLDEN_APPLE = null;
    public Items() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
