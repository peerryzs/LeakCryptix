package net.minecraft.world.item;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ItemStack {
    public net.minecraft.world.item.ItemUseAnimation getUseAnimation() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isEmpty() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean is(java.lang.Object p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean is(net.minecraft.tags.TagKey p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getDestroySpeed(net.minecraft.world.level.block.state.BlockState p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public java.lang.Object get(net.minecraft.core.component.DataComponentType p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.item.Item getItem() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getCount() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void forEachModifier(net.minecraft.world.entity.EquipmentSlot p0, java.util.function.BiConsumer p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ItemStack(net.minecraft.world.level.ItemLike p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ItemStack() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
