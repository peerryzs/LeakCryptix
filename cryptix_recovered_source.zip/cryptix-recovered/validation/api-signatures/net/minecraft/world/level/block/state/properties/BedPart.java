package net.minecraft.world.level.block.state.properties;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class BedPart {
    public static net.minecraft.world.level.block.state.properties.BedPart HEAD = null;
    public static net.minecraft.world.level.block.state.properties.BedPart FOOT = null;
    public BedPart() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
