package net.minecraft.world.level.block.state;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class BlockState {
    public boolean canBeReplaced() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isFaceSturdy(net.minecraft.world.level.BlockGetter p0, net.minecraft.core.BlockPos p1, net.minecraft.core.Direction p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isAir() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public java.lang.Comparable getValue(net.minecraft.world.level.block.state.properties.Property p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.level.block.Block getBlock() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getDestroyProgress(net.minecraft.world.entity.player.Player p0, net.minecraft.world.level.BlockGetter p1, net.minecraft.core.BlockPos p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.level.block.SoundType getSoundType() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public BlockState() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
