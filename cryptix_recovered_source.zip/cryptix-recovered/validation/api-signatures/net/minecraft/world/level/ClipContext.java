package net.minecraft.world.level;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClipContext {
    public ClipContext(net.minecraft.world.phys.Vec3 p0, net.minecraft.world.phys.Vec3 p1, net.minecraft.world.level.ClipContext.Block p2, net.minecraft.world.level.ClipContext.Fluid p3, net.minecraft.world.entity.Entity p4) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ClipContext() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static class Block {
        public static net.minecraft.world.level.ClipContext.Block COLLIDER = null;
        public static net.minecraft.world.level.ClipContext.Block OUTLINE = null;
        public Block() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
    public static class Fluid {
        public static net.minecraft.world.level.ClipContext.Fluid NONE = null;
        public Fluid() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
}
