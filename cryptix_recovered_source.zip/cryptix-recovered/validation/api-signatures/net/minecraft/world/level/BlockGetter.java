package net.minecraft.world.level;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface BlockGetter {
}
