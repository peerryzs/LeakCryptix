package net.minecraft.world.level.block;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Blocks {
    public static net.minecraft.world.level.block.Block AIR = null;
    public Blocks() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
