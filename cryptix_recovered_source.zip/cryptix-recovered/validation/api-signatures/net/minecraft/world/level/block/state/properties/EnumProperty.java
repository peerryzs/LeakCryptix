package net.minecraft.world.level.block.state.properties;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class EnumProperty extends net.minecraft.world.level.block.state.properties.Property {
    public EnumProperty() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
