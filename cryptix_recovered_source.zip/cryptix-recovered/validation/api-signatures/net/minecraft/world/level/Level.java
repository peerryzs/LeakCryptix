package net.minecraft.world.level;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Level implements net.minecraft.world.level.BlockGetter {
    public Level() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
