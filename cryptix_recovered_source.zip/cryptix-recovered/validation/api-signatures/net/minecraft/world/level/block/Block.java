package net.minecraft.world.level.block;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Block {
    public net.minecraft.world.item.Item asItem() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Block() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
