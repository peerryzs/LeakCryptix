package net.minecraft.world.level.block;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class BedBlock extends net.minecraft.world.level.block.Block {
    public static net.minecraft.world.level.block.state.properties.EnumProperty FACING = null;
    public static net.minecraft.world.level.block.state.properties.EnumProperty PART = null;
    public BedBlock() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
