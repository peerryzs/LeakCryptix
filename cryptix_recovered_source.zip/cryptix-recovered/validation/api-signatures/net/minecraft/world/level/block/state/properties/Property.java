package net.minecraft.world.level.block.state.properties;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Property {
    public Property() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
