package net.minecraft.world.level.block;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class SoundType {
    public net.minecraft.sounds.SoundEvent getHitSound() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getVolume() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getPitch() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public SoundType() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
