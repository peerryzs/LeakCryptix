package net.minecraft.world;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class InteractionResult {
    public InteractionResult() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
