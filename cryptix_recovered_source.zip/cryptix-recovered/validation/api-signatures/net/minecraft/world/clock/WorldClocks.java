package net.minecraft.world.clock;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class WorldClocks {
    public static net.minecraft.resources.ResourceKey OVERWORLD = null;
    public WorldClocks() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
