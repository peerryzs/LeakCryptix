package net.minecraft;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ChatFormatting {
    public static net.minecraft.ChatFormatting GRAY = null;
    public ChatFormatting() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
