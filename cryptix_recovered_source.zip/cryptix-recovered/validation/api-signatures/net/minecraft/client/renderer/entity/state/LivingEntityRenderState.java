package net.minecraft.client.renderer.entity.state;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class LivingEntityRenderState extends net.minecraft.client.renderer.entity.state.EntityRenderState {
    public float xRot = 0.0f;
    public LivingEntityRenderState() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
