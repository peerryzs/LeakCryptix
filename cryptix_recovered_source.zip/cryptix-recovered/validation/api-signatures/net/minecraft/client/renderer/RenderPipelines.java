package net.minecraft.client.renderer;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class RenderPipelines {
    public static com.mojang.blaze3d.pipeline.RenderPipeline GUI_TEXTURED = null;
    public RenderPipelines() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
