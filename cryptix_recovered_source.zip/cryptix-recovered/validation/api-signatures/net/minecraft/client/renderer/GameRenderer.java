package net.minecraft.client.renderer;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class GameRenderer {
    public net.minecraft.client.Camera mainCamera() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public GameRenderer() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
