package net.minecraft.client.renderer.state.level;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class CameraRenderState {
    public CameraRenderState() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
