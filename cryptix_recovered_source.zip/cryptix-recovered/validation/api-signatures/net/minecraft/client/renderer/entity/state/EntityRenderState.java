package net.minecraft.client.renderer.entity.state;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class EntityRenderState {
    public int outlineColor = 0;
    public net.minecraft.network.chat.Component scoreText = null;
    public net.minecraft.world.phys.Vec3 nameTagAttachment = null;
    public int lightCoords = 0;
    public boolean isDiscrete = false;
    public net.minecraft.network.chat.Component nameTag = null;
    public EntityRenderState() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
