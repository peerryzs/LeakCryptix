package net.minecraft.client.renderer;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ItemInHandRenderer {
    public ItemInHandRenderer() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
