package net.minecraft.client.renderer.entity;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class EntityRenderer {
    public EntityRenderer() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
