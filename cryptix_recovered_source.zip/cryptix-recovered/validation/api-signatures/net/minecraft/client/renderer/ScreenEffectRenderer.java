package net.minecraft.client.renderer;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ScreenEffectRenderer {
    public ScreenEffectRenderer() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
