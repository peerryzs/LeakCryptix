package net.minecraft.client.renderer;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface SubmitNodeCollector {
    public default void submitNameTag(com.mojang.blaze3d.vertex.PoseStack p0, net.minecraft.world.phys.Vec3 p1, int p2, net.minecraft.network.chat.Component p3, boolean p4, int p5, net.minecraft.client.renderer.state.level.CameraRenderState p6) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
