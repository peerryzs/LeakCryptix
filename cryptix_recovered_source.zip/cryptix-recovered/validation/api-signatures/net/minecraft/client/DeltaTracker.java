package net.minecraft.client;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface DeltaTracker {
    public default float getGameTimeDeltaPartialTick(boolean p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static class Timer {
        public Timer() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
}
