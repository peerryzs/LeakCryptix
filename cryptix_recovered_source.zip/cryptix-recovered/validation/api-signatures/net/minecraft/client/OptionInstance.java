package net.minecraft.client;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class OptionInstance {
    public java.lang.Object get() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void set(java.lang.Object p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public OptionInstance() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
