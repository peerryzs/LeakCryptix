package net.minecraft.client.sounds;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class SoundEngine {
    public SoundEngine() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static class PlayResult {
        public static net.minecraft.client.sounds.SoundEngine.PlayResult NOT_STARTED = null;
        public PlayResult() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
}
