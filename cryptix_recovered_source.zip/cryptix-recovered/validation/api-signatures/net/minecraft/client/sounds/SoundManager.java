package net.minecraft.client.sounds;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class SoundManager {
    public net.minecraft.client.sounds.SoundEngine.PlayResult play(net.minecraft.client.resources.sounds.SoundInstance p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public SoundManager() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
