package net.minecraft.client.multiplayer;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class MultiPlayerGameMode {
    public void attack(net.minecraft.world.entity.player.Player p0, net.minecraft.world.entity.Entity p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.InteractionResult useItemOn(net.minecraft.client.player.LocalPlayer p0, net.minecraft.world.InteractionHand p1, net.minecraft.world.phys.BlockHitResult p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isDestroying() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean destroyBlock(net.minecraft.core.BlockPos p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void handleContainerInput(int p0, int p1, int p2, net.minecraft.world.inventory.ContainerInput p3, net.minecraft.world.entity.player.Player p4) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public MultiPlayerGameMode() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
