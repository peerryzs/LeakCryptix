package net.minecraft.client.multiplayer.prediction;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface PredictiveAction {
    public net.minecraft.network.protocol.Packet predict(int p0);
}
