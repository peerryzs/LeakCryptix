package net.minecraft.client.multiplayer;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientPacketListener implements net.minecraft.network.PacketListener {
    public void sendChat(java.lang.String p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void send(net.minecraft.network.protocol.Packet p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public java.util.Collection getOnlinePlayers() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ClientPacketListener() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
