package net.minecraft.client.multiplayer;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class PlayerInfo {
    public com.mojang.authlib.GameProfile getProfile() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public PlayerInfo() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
