package net.minecraft.client.multiplayer;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientLevel extends net.minecraft.world.level.Level {
    public java.util.List getEntities(net.minecraft.world.entity.Entity p0, net.minecraft.world.phys.AABB p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.entity.Entity getEntity(int p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.level.block.state.BlockState getBlockState(net.minecraft.core.BlockPos p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.BlockHitResult clip(net.minecraft.world.level.ClipContext p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public long getGameTime() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void destroyBlockProgress(int p0, net.minecraft.core.BlockPos p1, int p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isEmptyBlock(net.minecraft.core.BlockPos p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.client.ClientClockManager clockManager() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.core.RegistryAccess registryAccess() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setRainLevel(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setThunderLevel(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public java.util.List players() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public java.lang.Iterable entitiesForRendering() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ClientLevel() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
