package net.minecraft.client.player;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class LocalPlayer extends net.minecraft.client.player.AbstractClientPlayer {
    public float yBodyRot = 0.0f;
    public float yHeadRot = 0.0f;
    public boolean horizontalCollision = false;
    public int hurtTime = 0;
    public net.minecraft.client.player.ClientInput input = null;
    public int tickCount = 0;
    public net.minecraft.world.inventory.AbstractContainerMenu containerMenu = null;
    public net.minecraft.client.multiplayer.ClientPacketListener connection = null;
    public float yBodyRotO = 0.0f;
    public float yHeadRotO = 0.0f;
    public double fallDistance = 0.0;
    public double xOld = 0.0;
    public double zOld = 0.0;
    public int swingTime = 0;
    public void sendSystemMessage(net.minecraft.network.chat.Component p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getYRot() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.entity.player.Inventory getInventory() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isOnFire() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getX() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getEyeY() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getZ() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getXRot() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setYRot(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setXRot(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean onGround() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isInWater() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isInLava() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 getDeltaMovement() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getY() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getAttackStrengthScale(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void swing(net.minecraft.world.InteractionHand p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.item.ItemStack getMainHandItem() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 getEyePosition() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isShiftKeyDown() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 getEyePosition(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.AABB getBoundingBox() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void startUsingItem(net.minecraft.world.InteractionHand p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float distanceTo(net.minecraft.world.entity.Entity p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isSprinting() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isAlive() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setDeltaMovement(double p0, double p1, double p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getId() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setDeltaMovement(net.minecraft.world.phys.Vec3 p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.entity.player.Abilities getAbilities() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isUsingItem() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.core.BlockPos blockPosition() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getHealth() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 position() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.level.Level level() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isEyeInFluid(net.minecraft.tags.TagKey p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double distanceToSqr(double p0, double p1, double p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double distanceToSqr(net.minecraft.world.phys.Vec3 p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void closeContainer() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.item.ItemStack getItemBySlot(net.minecraft.world.entity.EquipmentSlot p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double distanceToSqr(net.minecraft.world.entity.Entity p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isAlliedTo(net.minecraft.world.entity.Entity p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.network.chat.Component getDisplayName() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public LocalPlayer() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
