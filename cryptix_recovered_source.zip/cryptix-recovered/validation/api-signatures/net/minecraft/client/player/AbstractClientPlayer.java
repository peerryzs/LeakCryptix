package net.minecraft.client.player;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class AbstractClientPlayer extends net.minecraft.world.entity.player.Player {
    public boolean horizontalCollision = false;
    public boolean isUsingItem() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getUseItemRemainingTicks() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.InteractionHand getUsedItemHand() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.entity.HumanoidArm getMainArm() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.item.ItemStack getMainHandItem() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public AbstractClientPlayer(net.minecraft.client.multiplayer.ClientLevel p0, com.mojang.authlib.GameProfile p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getX() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getY() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double getZ() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean onGround() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getYRot() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public float getXRot() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public AbstractClientPlayer() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
