package net.minecraft.client.player;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientInput {
    public net.minecraft.world.entity.player.Input keyPresses = null;
    public void makeJump() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec2 getMoveVector() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ClientInput() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
