package net.minecraft.client.player;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class KeyboardInput extends net.minecraft.client.player.ClientInput {
    public net.minecraft.world.entity.player.Input keyPresses = null;
    public KeyboardInput() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
