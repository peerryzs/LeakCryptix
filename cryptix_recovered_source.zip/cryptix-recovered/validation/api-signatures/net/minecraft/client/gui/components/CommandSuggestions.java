package net.minecraft.client.gui.components;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class CommandSuggestions {
    public CommandSuggestions() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
