package net.minecraft.client.gui.screens.multiplayer;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class JoinMultiplayerScreen extends net.minecraft.client.gui.screens.Screen {
    public int width = 0;
    public JoinMultiplayerScreen() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
