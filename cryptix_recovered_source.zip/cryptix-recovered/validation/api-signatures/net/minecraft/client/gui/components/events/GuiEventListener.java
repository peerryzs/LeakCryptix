package net.minecraft.client.gui.components.events;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface GuiEventListener {
}
