package net.minecraft.client.gui;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Hud {
    public Hud() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
