package net.minecraft.client.gui.screens.inventory;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class InventoryScreen extends net.minecraft.client.gui.screens.Screen {
    public InventoryScreen() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
