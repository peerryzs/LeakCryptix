package net.minecraft.client.gui.components;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Button extends net.minecraft.client.gui.components.AbstractWidget {
    public static net.minecraft.client.gui.components.Button.Builder builder(net.minecraft.network.chat.Component p0, net.minecraft.client.gui.components.Button.OnPress p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Button() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static class Builder {
        public net.minecraft.client.gui.components.Button.Builder bounds(int p0, int p1, int p2, int p3) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public net.minecraft.client.gui.components.Button build() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public Builder() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
    public static interface OnPress {
        public void onPress(net.minecraft.client.gui.components.Button p0);
    }
}
