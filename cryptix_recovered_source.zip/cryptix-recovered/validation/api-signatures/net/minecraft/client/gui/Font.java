package net.minecraft.client.gui;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Font {
    public int width(java.lang.String p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Font() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
