package net.minecraft.client.gui.screens;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ChatScreen extends net.minecraft.client.gui.screens.Screen {
    public ChatScreen() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
