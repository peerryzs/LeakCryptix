package net.minecraft.client.gui.components;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class EditBox extends net.minecraft.client.gui.components.AbstractWidget {
    public EditBox(net.minecraft.client.gui.Font p0, int p1, int p2, int p3, int p4, net.minecraft.network.chat.Component p5) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setMaxLength(int p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setValue(java.lang.String p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public java.lang.String getValue() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public EditBox() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
