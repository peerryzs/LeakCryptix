package net.minecraft.client.gui;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Gui {
    public net.minecraft.client.gui.screens.Screen screen() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setScreen(net.minecraft.client.gui.screens.Screen p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Gui() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
