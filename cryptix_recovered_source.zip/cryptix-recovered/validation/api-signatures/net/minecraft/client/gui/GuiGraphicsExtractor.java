package net.minecraft.client.gui;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class GuiGraphicsExtractor {
    public void text(net.minecraft.client.gui.Font p0, net.minecraft.network.chat.Component p1, int p2, int p3, int p4) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void fill(int p0, int p1, int p2, int p3, int p4) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void text(net.minecraft.client.gui.Font p0, java.lang.String p1, int p2, int p3, int p4) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public org.joml.Matrix3x2fStack pose() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void outline(int p0, int p1, int p2, int p3, int p4) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void item(net.minecraft.world.item.ItemStack p0, int p1, int p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void text(net.minecraft.client.gui.Font p0, java.lang.String p1, int p2, int p3, int p4, boolean p5) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void blit(com.mojang.blaze3d.pipeline.RenderPipeline p0, net.minecraft.resources.Identifier p1, int p2, int p3, float p4, float p5, int p6, int p7, int p8, int p9, int p10, int p11, int p12) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public GuiGraphicsExtractor() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
