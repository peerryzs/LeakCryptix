package net.minecraft.client.gui.screens;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Screen {
    public int width = 0;
    public int height = 0;
    public net.minecraft.client.gui.Font font = null;
    public net.minecraft.client.Minecraft minecraft = null;
    public Screen(net.minecraft.network.chat.Component p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void extractRenderState(net.minecraft.client.gui.GuiGraphicsExtractor p0, int p1, int p2, float p3) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean keyPressed(net.minecraft.client.input.KeyEvent p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent p0, boolean p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean mouseReleased(net.minecraft.client.input.MouseButtonEvent p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean mouseDragged(net.minecraft.client.input.MouseButtonEvent p0, double p1, double p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.network.chat.Component getTitle() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    protected void init() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void removed() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void onClose() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isPauseScreen() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.client.gui.components.events.GuiEventListener addRenderableWidget(net.minecraft.client.gui.components.events.GuiEventListener p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setInitialFocus(net.minecraft.client.gui.components.events.GuiEventListener p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.client.gui.components.events.GuiEventListener getFocused() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setFocused(net.minecraft.client.gui.components.events.GuiEventListener p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Screen() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
