package net.minecraft.client.gui.components;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class AbstractWidget implements net.minecraft.client.gui.components.events.GuiEventListener {
    public AbstractWidget() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
