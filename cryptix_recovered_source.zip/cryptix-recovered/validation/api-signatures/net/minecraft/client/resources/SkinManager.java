package net.minecraft.client.resources;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class SkinManager {
    public java.util.concurrent.CompletableFuture get(com.mojang.authlib.GameProfile p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public SkinManager() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
