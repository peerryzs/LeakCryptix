package net.minecraft.client.resources.sounds;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface SoundInstance {
    public default net.minecraft.resources.Identifier getIdentifier() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static net.minecraft.util.RandomSource createUnseededRandom() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
