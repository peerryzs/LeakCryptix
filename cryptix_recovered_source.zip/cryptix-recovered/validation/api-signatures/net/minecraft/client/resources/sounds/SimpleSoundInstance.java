package net.minecraft.client.resources.sounds;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class SimpleSoundInstance implements net.minecraft.client.resources.sounds.SoundInstance {
    public static net.minecraft.client.resources.sounds.SimpleSoundInstance forUI(net.minecraft.core.Holder p0, float p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public SimpleSoundInstance(net.minecraft.sounds.SoundEvent p0, net.minecraft.sounds.SoundSource p1, float p2, float p3, net.minecraft.util.RandomSource p4, net.minecraft.core.BlockPos p5) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public SimpleSoundInstance() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
