package net.minecraft.client;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class KeyMapping {
    public static void set(com.mojang.blaze3d.platform.InputConstants.Key p0, boolean p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static void click(com.mojang.blaze3d.platform.InputConstants.Key p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void setDown(boolean p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static void setAll() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean isDown() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public KeyMapping() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
