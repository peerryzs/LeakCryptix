package net.minecraft.client.input;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class MouseButtonEvent {
    public double x() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public double y() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int button() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public MouseButtonEvent() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
