package net.minecraft.client.input;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class KeyEvent {
    public int key() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public KeyEvent() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
