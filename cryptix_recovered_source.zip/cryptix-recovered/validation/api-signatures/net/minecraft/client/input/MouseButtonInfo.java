package net.minecraft.client.input;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class MouseButtonInfo {
    public int button() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int modifiers() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public MouseButtonInfo() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
