package net.minecraft.client;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Minecraft {
    public net.minecraft.client.player.LocalPlayer player = null;
    public net.minecraft.client.gui.Gui gui = null;
    public java.io.File gameDirectory = null;
    public net.minecraft.client.KeyboardHandler keyboardHandler = null;
    public net.minecraft.client.gui.Font font = null;
    public net.minecraft.client.Options options = null;
    public net.minecraft.client.MouseHandler mouseHandler = null;
    public net.minecraft.world.phys.HitResult hitResult = null;
    public net.minecraft.client.multiplayer.MultiPlayerGameMode gameMode = null;
    public net.minecraft.client.multiplayer.ClientLevel level = null;
    public net.minecraft.world.entity.Entity crosshairPickEntity = null;
    public net.minecraft.client.renderer.GameRenderer gameRenderer = null;
    public static net.minecraft.client.Minecraft getInstance() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public com.mojang.blaze3d.platform.Window getWindow() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.client.multiplayer.ClientPacketListener getConnection() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public void execute(java.lang.Runnable p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean shouldEntityAppearGlowing(net.minecraft.world.entity.Entity p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.client.sounds.SoundManager getSoundManager() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.entity.Entity getCameraEntity() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getFps() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.client.User getUser() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.client.resources.SkinManager getSkinManager() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Minecraft() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
