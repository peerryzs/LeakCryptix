package net.minecraft.client;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Camera {
    public net.minecraft.world.phys.Vec3 position() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public org.joml.Matrix4f getViewRotationProjectionMatrix(org.joml.Matrix4f p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Camera() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
