package net.minecraft.client;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientClockManager {
    public ClientClockManager() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
