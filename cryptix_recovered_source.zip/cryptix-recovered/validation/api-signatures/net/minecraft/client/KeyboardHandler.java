package net.minecraft.client;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class KeyboardHandler {
    public void setClipboard(java.lang.String p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public KeyboardHandler() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
