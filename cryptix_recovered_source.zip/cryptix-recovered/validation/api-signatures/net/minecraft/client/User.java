package net.minecraft.client;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class User {
    public java.lang.String getName() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public User(java.lang.String p0, java.util.UUID p1, java.lang.String p2, java.util.Optional p3, java.util.Optional p4) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public User() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
