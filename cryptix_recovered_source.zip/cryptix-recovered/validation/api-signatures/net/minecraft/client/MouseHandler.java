package net.minecraft.client;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class MouseHandler {
    public boolean isLeftPressed() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public MouseHandler() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
