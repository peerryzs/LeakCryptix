package net.minecraft.client;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Options {
    public net.minecraft.client.KeyMapping keyUse = null;
    public net.minecraft.client.KeyMapping keyUp = null;
    public net.minecraft.client.KeyMapping keyJump = null;
    public net.minecraft.client.KeyMapping keyRight = null;
    public net.minecraft.client.KeyMapping keyLeft = null;
    public net.minecraft.client.KeyMapping keySprint = null;
    public net.minecraft.client.KeyMapping keyShift = null;
    public net.minecraft.client.KeyMapping keyDown = null;
    public net.minecraft.client.OptionInstance autoJump() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.client.OptionInstance sensitivity() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.client.OptionInstance gamma() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Options() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
