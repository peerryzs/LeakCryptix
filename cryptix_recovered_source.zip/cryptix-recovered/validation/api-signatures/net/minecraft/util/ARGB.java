package net.minecraft.util;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ARGB {
    public static int opaque(int p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ARGB() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
