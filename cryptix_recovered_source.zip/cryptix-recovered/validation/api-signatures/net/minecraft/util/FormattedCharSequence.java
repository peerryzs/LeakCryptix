package net.minecraft.util;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class FormattedCharSequence {
    public static net.minecraft.util.FormattedCharSequence forward(java.lang.String p0, net.minecraft.network.chat.Style p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public FormattedCharSequence() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
