package net.minecraft.util;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Mth {
    public static float lerp(float p0, float p1, float p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static float sin(double p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static float sqrt(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static double lengthSquared(double p0, double p1, double p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static double square(double p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static float rotLerp(float p0, float p1, float p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static double clamp(double p0, double p1, double p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static float wrapDegrees(float p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static float cos(double p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static double wrapDegrees(double p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static float clamp(float p0, float p1, float p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Mth() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
