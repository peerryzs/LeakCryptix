package net.minecraft.util;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class RandomSource {
    public RandomSource() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
