package net.minecraft.network.chat;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class MutableComponent implements net.minecraft.network.chat.Component {
    public MutableComponent() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
