package net.minecraft.network.chat;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface Component {
    public static net.minecraft.network.chat.MutableComponent literal(java.lang.String p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public default java.lang.String getString() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
