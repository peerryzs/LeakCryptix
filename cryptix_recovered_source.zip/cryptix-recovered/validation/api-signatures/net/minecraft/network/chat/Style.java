package net.minecraft.network.chat;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Style {
    public static net.minecraft.network.chat.Style EMPTY = null;
    public net.minecraft.network.chat.Style withColor(net.minecraft.ChatFormatting p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Style() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
