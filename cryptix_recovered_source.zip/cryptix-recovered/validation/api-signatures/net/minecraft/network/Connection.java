package net.minecraft.network;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Connection {
    public Connection() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
