package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ServerboundPlayerActionPacket implements net.minecraft.network.protocol.Packet {
    public ServerboundPlayerActionPacket(net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action p0, net.minecraft.core.BlockPos p1, net.minecraft.core.Direction p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ServerboundPlayerActionPacket(net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action p0, net.minecraft.core.BlockPos p1, net.minecraft.core.Direction p2, int p3) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ServerboundPlayerActionPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static class Action {
        public static net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action RELEASE_USE_ITEM = null;
        public static net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action ABORT_DESTROY_BLOCK = null;
        public static net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action START_DESTROY_BLOCK = null;
        public static net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action STOP_DESTROY_BLOCK = null;
        public Action() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
}
