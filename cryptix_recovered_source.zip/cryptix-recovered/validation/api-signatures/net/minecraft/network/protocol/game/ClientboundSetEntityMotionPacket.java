package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientboundSetEntityMotionPacket implements net.minecraft.network.protocol.Packet {
    public int id() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.world.phys.Vec3 movement() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ClientboundSetEntityMotionPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
