package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ServerboundSwingPacket implements net.minecraft.network.protocol.Packet {
    public ServerboundSwingPacket(net.minecraft.world.InteractionHand p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ServerboundSwingPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
