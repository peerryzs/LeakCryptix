package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientboundSetTimePacket implements net.minecraft.network.protocol.Packet {
    public ClientboundSetTimePacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
