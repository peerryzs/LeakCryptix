package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientboundPlayerPositionPacket implements net.minecraft.network.protocol.Packet {
    public net.minecraft.world.entity.PositionMoveRotation change() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ClientboundPlayerPositionPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
