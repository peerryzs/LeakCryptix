package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ServerboundSetCarriedItemPacket implements net.minecraft.network.protocol.Packet {
    public ServerboundSetCarriedItemPacket(int p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getSlot() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ServerboundSetCarriedItemPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
