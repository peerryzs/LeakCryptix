package net.minecraft.network.protocol;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface Packet {
    public default void handle(net.minecraft.network.PacketListener p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
