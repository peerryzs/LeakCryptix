package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientboundSystemChatPacket implements net.minecraft.network.protocol.Packet {
    public net.minecraft.network.chat.Component content() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ClientboundSystemChatPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
