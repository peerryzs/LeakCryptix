package net.minecraft.network.protocol.common;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientboundPingPacket {
    public ClientboundPingPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
