package net.minecraft.network.protocol.common;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientboundDisconnectPacket {
    public ClientboundDisconnectPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
