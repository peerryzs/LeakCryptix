package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ServerboundUseItemPacket implements net.minecraft.network.protocol.Packet {
    public ServerboundUseItemPacket(net.minecraft.world.InteractionHand p0, int p1, float p2, float p3) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ServerboundUseItemPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
