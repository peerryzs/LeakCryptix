package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ServerboundMovePlayerPacket implements net.minecraft.network.protocol.Packet {
    public ServerboundMovePlayerPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static class Pos implements net.minecraft.network.protocol.Packet {
        public Pos(double p0, double p1, double p2, boolean p3, boolean p4) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public Pos() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
    public static class PosRot implements net.minecraft.network.protocol.Packet {
        public PosRot(double p0, double p1, double p2, float p3, float p4, boolean p5, boolean p6) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public PosRot() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
    public static class Rot implements net.minecraft.network.protocol.Packet {
        public Rot(float p0, float p1, boolean p2, boolean p3) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public Rot() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
    public static class StatusOnly implements net.minecraft.network.protocol.Packet {
        public StatusOnly(boolean p0, boolean p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public StatusOnly() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
}
