package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientboundStartConfigurationPacket implements net.minecraft.network.protocol.Packet {
    public ClientboundStartConfigurationPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
