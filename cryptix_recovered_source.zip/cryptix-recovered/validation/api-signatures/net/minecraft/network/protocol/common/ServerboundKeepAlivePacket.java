package net.minecraft.network.protocol.common;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ServerboundKeepAlivePacket {
    public ServerboundKeepAlivePacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
