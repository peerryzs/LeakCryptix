package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ServerboundContainerClickPacket implements net.minecraft.network.protocol.Packet {
    public net.minecraft.world.inventory.ContainerInput containerInput() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ServerboundContainerClickPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
