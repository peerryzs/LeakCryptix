package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ServerboundAttackPacket implements net.minecraft.network.protocol.Packet {
    public int entityId() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ServerboundAttackPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
