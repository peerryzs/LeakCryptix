package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ServerboundInteractPacket implements net.minecraft.network.protocol.Packet {
    public ServerboundInteractPacket(int p0, net.minecraft.world.InteractionHand p1, net.minecraft.world.phys.Vec3 p2, boolean p3) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ServerboundInteractPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
