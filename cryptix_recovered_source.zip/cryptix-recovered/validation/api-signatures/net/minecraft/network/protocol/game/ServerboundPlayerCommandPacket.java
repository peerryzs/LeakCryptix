package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ServerboundPlayerCommandPacket implements net.minecraft.network.protocol.Packet {
    public net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action getAction() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ServerboundPlayerCommandPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static class Action {
        public static net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action START_SPRINTING = null;
        public static net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action STOP_SPRINTING = null;
        public static net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action OPEN_INVENTORY = null;
        public Action() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
}
