package net.minecraft.network.protocol.game;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientboundSetTitleTextPacket implements net.minecraft.network.protocol.Packet {
    public net.minecraft.network.chat.Component text() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public ClientboundSetTitleTextPacket() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
