package net.minecraft.network;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface PacketListener {
}
