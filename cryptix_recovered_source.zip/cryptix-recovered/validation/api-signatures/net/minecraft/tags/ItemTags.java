package net.minecraft.tags;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ItemTags {
    public static net.minecraft.tags.TagKey SWORDS = null;
    public static net.minecraft.tags.TagKey PICKAXES = null;
    public static net.minecraft.tags.TagKey AXES = null;
    public static net.minecraft.tags.TagKey SHOVELS = null;
    public static net.minecraft.tags.TagKey HOES = null;
    public ItemTags() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
