package net.minecraft.tags;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class FluidTags {
    public static net.minecraft.tags.TagKey WATER = null;
    public FluidTags() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
