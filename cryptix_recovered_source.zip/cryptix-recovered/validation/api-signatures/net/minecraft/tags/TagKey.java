package net.minecraft.tags;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class TagKey {
    public TagKey() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
