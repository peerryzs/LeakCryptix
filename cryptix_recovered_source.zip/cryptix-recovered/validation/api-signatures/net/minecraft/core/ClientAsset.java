package net.minecraft.core;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ClientAsset {
    public ClientAsset() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static class ResourceTexture {
        public ResourceTexture(net.minecraft.resources.Identifier p0, net.minecraft.resources.Identifier p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public ResourceTexture() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
    public static interface Texture {
        public default net.minecraft.resources.Identifier id() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
}
