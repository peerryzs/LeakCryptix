package net.minecraft.core;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class BlockPos extends net.minecraft.core.Vec3i {
    public static net.minecraft.core.BlockPos ZERO = null;
    public net.minecraft.core.BlockPos relative(net.minecraft.core.Direction p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean equals(java.lang.Object p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.core.BlockPos above() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getX() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getY() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getZ() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public BlockPos(net.minecraft.core.Vec3i p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static net.minecraft.core.BlockPos containing(double p0, double p1, double p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public BlockPos(int p0, int p1, int p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.core.BlockPos below() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public net.minecraft.core.BlockPos atY(int p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public BlockPos() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static class MutableBlockPos extends net.minecraft.core.BlockPos {
        public MutableBlockPos() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public net.minecraft.core.BlockPos.MutableBlockPos set(int p0, int p1, int p2) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public int getX() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public int getY() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public int getZ() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
}
