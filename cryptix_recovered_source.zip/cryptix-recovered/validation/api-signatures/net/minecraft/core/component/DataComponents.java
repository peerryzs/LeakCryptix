package net.minecraft.core.component;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class DataComponents {
    public static net.minecraft.core.component.DataComponentType EQUIPPABLE = null;
    public DataComponents() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
