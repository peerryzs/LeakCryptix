package net.minecraft.core.component;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class DataComponentType {
    public DataComponentType() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
