package net.minecraft.core;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Vec3i {
    public Vec3i() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
