package net.minecraft.core;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class NonNullList extends java.util.ArrayList {
    public int size() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public java.lang.Object get(int p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public NonNullList() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
