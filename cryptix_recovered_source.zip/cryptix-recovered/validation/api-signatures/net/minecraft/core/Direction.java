package net.minecraft.core;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Direction {
    public static net.minecraft.core.Direction DOWN = null;
    public static net.minecraft.core.Direction NORTH = null;
    public static net.minecraft.core.Direction UP = null;
    public static net.minecraft.core.Direction SOUTH = null;
    public static net.minecraft.core.Direction EAST = null;
    public static net.minecraft.core.Direction WEST = null;
    public net.minecraft.core.Direction getOpposite() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getStepX() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getStepY() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public int getStepZ() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Direction() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static class Plane implements java.lang.Iterable {
        public static net.minecraft.core.Direction.Plane HORIZONTAL = null;
        public java.util.Iterator iterator() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
        public Plane() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
}
