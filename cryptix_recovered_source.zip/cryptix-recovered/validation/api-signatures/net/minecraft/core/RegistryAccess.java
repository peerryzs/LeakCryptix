package net.minecraft.core;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface RegistryAccess {
    public default java.util.Optional get(net.minecraft.resources.ResourceKey p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
