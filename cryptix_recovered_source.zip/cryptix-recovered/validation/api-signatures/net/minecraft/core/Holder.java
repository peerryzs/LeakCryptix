package net.minecraft.core;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface Holder {
    public boolean equals(java.lang.Object p0);
    public static class Reference {
        public Reference() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    }
}
