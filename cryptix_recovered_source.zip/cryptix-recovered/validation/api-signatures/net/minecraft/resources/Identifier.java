package net.minecraft.resources;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class Identifier {
    public static net.minecraft.resources.Identifier fromNamespaceAndPath(java.lang.String p0, java.lang.String p1) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public static net.minecraft.resources.Identifier parse(java.lang.String p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public boolean equals(java.lang.Object p0) { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
    public Identifier() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
