package net.minecraft.resources;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class ResourceKey {
    public ResourceKey() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
