package net.minecraft.sounds;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class SoundEvent {
    public SoundEvent() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
