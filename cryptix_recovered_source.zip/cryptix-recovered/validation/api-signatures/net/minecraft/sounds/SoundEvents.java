package net.minecraft.sounds;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class SoundEvents {
    public static net.minecraft.core.Holder.Reference UI_BUTTON_CLICK = null;
    public SoundEvents() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
