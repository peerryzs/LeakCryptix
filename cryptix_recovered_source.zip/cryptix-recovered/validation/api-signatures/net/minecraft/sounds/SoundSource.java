package net.minecraft.sounds;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public class SoundSource {
    public static net.minecraft.sounds.SoundSource BLOCKS = null;
    public SoundSource() { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }
}
