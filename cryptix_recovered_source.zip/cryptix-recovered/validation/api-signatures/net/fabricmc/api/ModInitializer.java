package net.fabricmc.api;

// COMPILE-ONLY API SIGNATURES. Not a functional implementation.
public interface ModInitializer {
}
