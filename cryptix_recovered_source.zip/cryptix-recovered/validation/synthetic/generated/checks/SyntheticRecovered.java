package checks;

/**
 * Reconstructed from checks/SyntheticOriginal.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public final class SyntheticRecovered {
    private static int effects;
    private int state;

    public SyntheticRecovered(int arg0) {
        this.state = arg0;
    }

    private static int touch(int arg0) {
        checks.SyntheticRecovered.effects = (checks.SyntheticRecovered.effects + 1);
        return arg0;
    }

    public static long wide(long arg0, long arg1, int arg2) {
        long local5 = 0L;
        local5 = (((arg0 * 31L) + arg1) ^ (arg0 >>> arg2));
        return (local5 - (arg1 << arg2));
    }

    public static int loops(int arg0) {
        int integer1 = 0;
        int integer2 = 0;
        int saved1 = 0;
        int integer3 = 0;
        integer1 = 0;
        integer2 = 0;
        loop4: while (true) {
            if ((integer2 >= arg0)) {
                break loop4;
            }
            saved1 = (integer2 & 1);
            if (!((saved1 == 0))) {
                if (!((integer2 != 7))) {
                    integer2++;
                    continue loop4;
                } else {
                    integer3 = 0;
                    loop17: while (true) {
                        if ((integer3 >= 4)) {
                            break loop17;
                        }
                        if (!((integer3 != 2))) {
                        } else {
                            integer1 = (integer1 + (integer2 * integer3));
                        }
                        integer3++;
                        continue loop17;
                    }
                    if (!((integer1 <= 100))) {
                        break loop4;
                    } else {
                        integer2++;
                        continue loop4;
                    }
                }
            } else {
                integer2++;
                continue loop4;
            }
        }
        return integer1;
    }

    public static int switches(int arg0) {
        int integer1 = 0;
        integer1 = 0;
        switch (arg0) {
            case -3:
            {
                integer1++;
                integer1 += 3;
                break;
            }
            case -2:
            case -1:
            case 0:
            case 1:
            case 3:
            default:
            {
                integer1 = (-arg0);
                break;
            }
            case 2:
            {
                integer1 += 3;
                break;
            }
            case 4:
            case 5:
            {
                integer1 = 8;
                break;
            }
        }
        return integer1;
    }

    public static int expressions(int arg0) {
        int[] reference1 = null;
        int integer2 = 0;
        checks.SyntheticRecovered.effects = 0;
        reference1 = new int[] {checks.SyntheticRecovered.touch(arg0), checks.SyntheticRecovered.touch((arg0 + 1)), checks.SyntheticRecovered.touch((arg0 + 2))};
        integer2 = (!((arg0 >= 0)) ? checks.SyntheticRecovered.touch(4) : (!((arg0 != 0)) ? checks.SyntheticRecovered.touch(5) : checks.SyntheticRecovered.touch(6)));
        return (((((reference1[0] * 1000) + (reference1[1] * 100)) + (reference1[2] * 10)) + integer2) + (checks.SyntheticRecovered.effects * 10000));
    }

    public static java.lang.String strings(java.lang.String arg0) {
        java.lang.String[] reference1 = null;
        java.lang.String reference2 = null;
        int integer3 = 0;
        int saved1 = 0;
        boolean saved2 = false;
        reference1 = arg0.split(":");
        reference2 = "";
        integer3 = 0;
        loop8: while (true) {
            saved1 = reference1.length;
            if ((integer3 >= saved1)) {
                break loop8;
            }
            saved2 = reference1[integer3].isEmpty();
            if (saved2) {
            } else {
                reference2 = ("" + reference2 + integer3 + "=" + reference1[integer3] + ";");
            }
            integer3++;
            continue loop8;
        }
        return reference2;
    }

    public static int catches(int arg0) {
        java.lang.ArithmeticException reference1 = null;
        try {
            return (100 / arg0);
        } catch (java.lang.ArithmeticException caught1) {
            reference1 = caught1;
            return -17;
        }
    }

    public static int floating(double arg0, double arg1) {
        int saved1 = 0;
        int saved2 = 0;
        int saved3 = 0;
        int saved4 = 0;
        int saved5 = 0;
        int saved6 = 0;
        int saved7 = 0;
        int saved8 = 0;
        int saved9 = 0;
        int saved10 = 0;
        int saved11 = 0;
        saved1 = cryptix.recovery.JvmSupport.dcmpg(arg0, arg1);
        saved2 = (!((saved1 >= 0)) ? 1 : 0);
        saved3 = cryptix.recovery.JvmSupport.dcmpg(arg0, arg1);
        saved4 = (saved2 | (!((saved3 > 0)) ? 2 : 0));
        saved5 = cryptix.recovery.JvmSupport.dcmpl(arg0, arg1);
        saved6 = (saved4 | (!((saved5 <= 0)) ? 4 : 0));
        saved7 = cryptix.recovery.JvmSupport.dcmpl(arg0, arg1);
        saved8 = (saved6 | (!((saved7 < 0)) ? 8 : 0));
        saved9 = cryptix.recovery.JvmSupport.dcmpl(arg0, arg1);
        saved10 = (saved8 | (!((saved9 != 0)) ? 16 : 0));
        saved11 = cryptix.recovery.JvmSupport.dcmpl(arg0, arg1);
        return (saved10 | (!((saved11 == 0)) ? 32 : 0));
    }

    public int compound(int arg0) {
        int saved1 = 0;
        saved1 = (this.state + arg0);
        this.state = saved1;
        return saved1;
    }

    public static int lambda(int arg0) {
        int integer1 = 0;
        java.util.function.IntUnaryOperator reference2 = null;
        integer1 = (arg0 + 3);
        final int captured1 = integer1;
        reference2 = (lambdaArg0) -> checks.SyntheticRecovered.recoveredCallback(captured1, lambdaArg0);
        return reference2.applyAsInt(arg0);
    }

    public static int booleanFlow(int arg0, int arg1, int arg2) {
        if (!((arg0 <= 0))) {
            if (!((arg1 < 0))) {
                if (!((arg2 != 2))) {
                    if (!((arg0 != arg1))) {
                        return 11;
                    } else {
                        if (!((arg0 == 0))) {
                            if (!((arg1 == 0))) {
                                if (!((arg2 != 0))) {
                                    return 7;
                                } else {
                                    return 3;
                                }
                            } else {
                                return 7;
                            }
                        } else {
                            return 7;
                        }
                    }
                } else {
                    if (!((arg0 == 0))) {
                        if (!((arg1 == 0))) {
                            if (!((arg2 != 0))) {
                                return 7;
                            } else {
                                return 3;
                            }
                        } else {
                            return 7;
                        }
                    } else {
                        return 7;
                    }
                }
            } else {
                return 11;
            }
        } else {
            if (!((arg2 != 2))) {
                if (!((arg0 != arg1))) {
                    return 11;
                } else {
                    if (!((arg0 == 0))) {
                        if (!((arg1 == 0))) {
                            if (!((arg2 != 0))) {
                                return 7;
                            } else {
                                return 3;
                            }
                        } else {
                            return 7;
                        }
                    } else {
                        return 7;
                    }
                }
            } else {
                if (!((arg0 == 0))) {
                    if (!((arg1 == 0))) {
                        if (!((arg2 != 0))) {
                            return 7;
                        } else {
                            return 3;
                        }
                    } else {
                        return 7;
                    }
                } else {
                    return 7;
                }
            }
        }
    }

    private static int recoveredCallback(int arg0, int arg1) {
        return (arg1 * arg0);
    }
}
