package checks;
public final class SyntheticOriginal {
    private static int effects;
    private int state;
    public SyntheticOriginal(int initial) { state = initial; }
    private static int touch(int n) { effects++; return n; }
    public static long wide(long a, long b, int shift) { long value = (a * 31L + b) ^ (a >>> shift); return value - (b << shift); }
    public static int loops(int n) {
        int value = 0;
        for (int i=0; i<n; i++) {
            if ((i & 1) == 0 || i == 7) continue;
            for (int j=0; j<4; j++) { if (j==2) continue; value += i*j; }
            if (value>100) break;
        }
        return value;
    }
    public static int switches(int n) {
        int v=0;
        switch (n) { case -3: v++; case 2: v += 3; break; case 4: case 5: v=8; break; default: v=-n; }
        return v;
    }
    public static int expressions(int n) {
        effects=0;
        int[] a = {touch(n), touch(n+1), touch(n+2)};
        int x = n<0 ? touch(4) : n==0 ? touch(5) : touch(6);
        return a[0]*1000 + a[1]*100 + a[2]*10 + x + effects*10000;
    }
    public static String strings(String s) {
        String[] items = s.split(":");
        String result="";
        for (int i=0;i<items.length;i++) { if (items[i].isEmpty()) continue; result += i+"="+items[i]+";"; }
        return result;
    }
    public static int catches(int n) {
        try { return 100/n; } catch (ArithmeticException e) { return -17; }
    }
    public static int floating(double a, double b) {
        return (a<b?1:0) | (a<=b?2:0) | (a>b?4:0) | (a>=b?8:0) | (a==b?16:0) | (a!=b?32:0);
    }
    public int compound(int n) { return state += n; }
    public static int lambda(int n) { int captured=n+3; java.util.function.IntUnaryOperator f=x->x*captured; return f.applyAsInt(n); }
    public static int booleanFlow(int a, int b, int c) {
        if ((a>0 && b<0) || (c==2 && a==b)) return 11;
        if (a==0 || b==0 || c==0) return 7;
        return 3;
    }
}
