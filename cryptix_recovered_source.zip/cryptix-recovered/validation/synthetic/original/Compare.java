package checks;
import java.util.*;
public class Compare {
    static int count;
    static void equal(Object a,Object b,String label) {
        count++;
        if(!Objects.equals(a,b)) throw new AssertionError(label+": original="+a+" recovered="+b);
    }
    public static void main(String[] args) {
        for(int a=-20;a<=30;a++) {
            equal(SyntheticOriginal.loops(a),SyntheticRecovered.loops(a),"loops "+a);
            equal(SyntheticOriginal.switches(a),SyntheticRecovered.switches(a),"switch "+a);
            equal(SyntheticOriginal.expressions(a),SyntheticRecovered.expressions(a),"expressions "+a);
            equal(SyntheticOriginal.catches(a),SyntheticRecovered.catches(a),"catches "+a);
            equal(SyntheticOriginal.lambda(a),SyntheticRecovered.lambda(a),"lambda "+a);
            SyntheticOriginal o=new SyntheticOriginal(a);SyntheticRecovered r=new SyntheticRecovered(a);
            for(int b=-3;b<=3;b++) {
                equal(o.compound(b),r.compound(b),"compound");
                for(int c=-3;c<=3;c++) equal(SyntheticOriginal.booleanFlow(a,b,c),SyntheticRecovered.booleanFlow(a,b,c),"booleanFlow "+a+" "+b+" "+c);
            }
        }
        long[] longs={0,1,-1,Long.MIN_VALUE,Long.MAX_VALUE,0x123456789abcdefL};
        for(long a:longs)for(long b:longs)for(int shift=0;shift<66;shift++) equal(SyntheticOriginal.wide(a,b,shift),SyntheticRecovered.wide(a,b,shift),"wide");
        double[] doubles={-Double.MAX_VALUE,-1,-0.0,0.0,1,Double.MAX_VALUE,Double.NaN,Double.POSITIVE_INFINITY,Double.NEGATIVE_INFINITY};
        for(double a:doubles)for(double b:doubles)equal(SyntheticOriginal.floating(a,b),SyntheticRecovered.floating(a,b),"floating "+a+" "+b);
        for(String s:new String[]{"",":","a","a:b",":a::b:c:","x:y:z"})equal(SyntheticOriginal.strings(s),SyntheticRecovered.strings(s),"strings "+s);
        System.out.println("PASS: "+count+" differential checks on independently authored synthetic code. No uploaded classes were executed.");
    }
}
