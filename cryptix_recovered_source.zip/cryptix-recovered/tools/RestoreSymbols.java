import java.io.*;
import java.nio.file.*;
import java.util.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import jdk.internal.org.objectweb.asm.commons.*;

/** Optional static-only post-compiler. Does not execute, initialize, or load target classes.
 * Restores known JVM names and removed opaque-zero fields. It does not establish
 * native ABI correctness, repair dependencies, or create a verified working mod.
 */
public final class RestoreSymbols {
    static final Map<String,String> classes=new HashMap<>(), fields=new HashMap<>(), methods=new HashMap<>();
    static final Map<String,List<String>> parents=new HashMap<>();
    static final Map<String,List<String[]>> zeroFields=new HashMap<>();
    static String key(String owner,String name,String descriptor) { return owner+"|"+name+"|"+descriptor; }
    static String member(Map<String,String> table,String owner,String name,String descriptor,Set<String> visited) {
        if(!visited.add(owner)) return null;
        String result=table.get(key(owner,name,descriptor));
        if(result!=null) return result;
        if(name.startsWith("<")) return null;
        for(String parent:parents.getOrDefault(owner,List.of())) {
            result=member(table,parent,name,descriptor,visited);
            if(result!=null) return result;
        }
        return null;
    }
    public static void main(String[] args) throws Exception {
        if(args.length!=3) throw new IllegalArgumentException("Usage: RestoreSymbols symbols.tsv compiled-source-directory output-directory");
        Path input=Path.of(args[1]).toAbsolutePath().normalize(), output=Path.of(args[2]).toAbsolutePath().normalize();
        if(output.equals(input)||output.startsWith(input)) throw new IllegalArgumentException("Use a separate output directory");
        for(String line:Files.readAllLines(Path.of(args[0]))) {
            if(line.isBlank()||line.startsWith("#")) continue;
            String[] parts=line.split("\t",-1);
            switch(parts[0]) {
                case "C" -> classes.put(parts[1],parts[2]);
                case "H" -> parents.put(parts[1],parts[2].isBlank()?List.of():List.of(parts[2].split(",")));
                case "F" -> fields.put(key(parts[1],parts[2],parts[3]),parts[4]);
                case "M" -> methods.put(key(parts[1],parts[2],parts[3]),parts[4]);
                case "Z" -> zeroFields.computeIfAbsent(parts[1],ignored->new ArrayList<>()).add(parts);
                default -> throw new IOException("Unrecognized mapping line: "+line);
            }
        }
        Remapper remapper=new Remapper() {
            public String map(String name) { return classes.getOrDefault(name,name); }
            public String mapFieldName(String owner,String name,String descriptor) {
                String found=member(fields,owner,name,descriptor,new HashSet<>());
                return found==null?name:found;
            }
            public String mapMethodName(String owner,String name,String descriptor) {
                String found=member(methods,owner,name,descriptor,new HashSet<>());
                return found==null?name:found;
            }
        };
        int count=0;
        try(var walk=Files.walk(input)) {
            for(Path path:walk.filter(p->p.toString().endsWith(".class")).toList()) {
                byte[] bytes=Files.readAllBytes(path);
                int version=((bytes[6]&255)<<8)|(bytes[7]&255);
                bytes[6]=0;bytes[7]=65;
                ClassNode node=new ClassNode(Opcodes.ASM9);
                new ClassReader(bytes).accept(node,0);node.version=version;
                if(!classes.containsKey(node.name)&&!node.name.equals("cryptix/recovery/JvmSupport")) continue;
                for(String[] f:zeroFields.getOrDefault(node.name,List.of())) {
                    if(node.fields.stream().noneMatch(existing->existing.name.equals(f[2])&&existing.desc.equals(f[3])))
                        node.fields.add(new FieldNode(Integer.parseInt(f[4]),f[2],f[3],null,f[5].isEmpty()?null:Integer.valueOf(f[5])));
                }
                ClassWriter writer=new ClassWriter(0);
                node.accept(new ClassRemapper(writer,remapper));
                Path destination=output.resolve(remapper.map(node.name)+".class");
                if(!destination.normalize().startsWith(output)) throw new IOException("Unsafe class path");
                Files.createDirectories(destination.getParent());Files.write(destination,writer.toByteArray());count++;
            }
        }
        System.out.println("Restored known JVM symbols in "+count+" classes. Native behavior and runtime compatibility remain unverified.");
    }
}
