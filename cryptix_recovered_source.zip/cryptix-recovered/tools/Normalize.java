import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import jdk.internal.org.objectweb.asm.tree.analysis.*;
import jdk.internal.org.objectweb.asm.util.Printer;

/** Static-only class normalization. Never loads or initializes target classes. */
public class Normalize implements Opcodes {
    static final Map<String,ClassNode> classes=new LinkedHashMap<>();
    static final Set<String> zeroFields=new TreeSet<>();
    static final Map<String,Object> strings=new TreeMap<>();
    static int folds=0, stringsDecoded=0, readsReplaced=0, nops=0;
    static String key(String owner,String name,String desc){return owner+'.'+name+':'+desc;}
    static String key(FieldInsnNode f){return key(f.owner,f.name,f.desc);}
    static Map<String,Object> map(Object... kv){Map<String,Object> r=new LinkedHashMap<>();for(int i=0;i<kv.length;i+=2)r.put((String)kv[i],kv[i+1]);return r;}
    static String json(Object o){
        if(o==null)return "null";
        if(o instanceof Number || o instanceof Boolean)return o.toString();
        if(o instanceof String s){StringBuilder b=new StringBuilder("\""); for(char c:s.toCharArray()){switch(c){case '\\':b.append("\\\\");break;case '"':b.append("\\\"");break;case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;default:if(c<32||Character.isSurrogate(c))b.append(String.format("\\u%04x",(int)c));else b.append(c);}} return b.append('"').toString();}
        if(o instanceof Map<?,?> m){StringJoiner j=new StringJoiner(",","{","}");m.forEach((k,v)->j.add(json(k.toString())+":"+json(v)));return j.toString();}
        if(o instanceof Iterable<?> l){StringJoiner j=new StringJoiner(",","[","]");for(Object v:l)j.add(json(v));return j.toString();}
        if(o instanceof Object[] a)return json(Arrays.asList(a));
        return json(o.toString());
    }
    static Object constant(AbstractInsnNode i){
        if(i==null)return null; int op=i.getOpcode();
        if(i instanceof LdcInsnNode l)return l.cst;
        if(op>=ICONST_M1&&op<=ICONST_5)return op-ICONST_0;
        if(op>=LCONST_0&&op<=LCONST_1)return (long)(op-LCONST_0);
        if(op>=FCONST_0&&op<=FCONST_2)return (float)(op-FCONST_0);
        if(op>=DCONST_0&&op<=DCONST_1)return (double)(op-DCONST_0);
        if(i instanceof IntInsnNode n&&(op==BIPUSH||op==SIPUSH))return n.operand;
        return null;
    }
    static AbstractInsnNode literal(Object v){
        if(v instanceof Integer n&&n>=-1&&n<=5)return new InsnNode(ICONST_0+n);
        return new LdcInsnNode(v);
    }
    static Object arithmetic(int op,Number a,Number b){
        int x=a.intValue(),y=b.intValue();long l=a.longValue(),r=b.longValue();
        return switch(op){case IADD->x+y;case ISUB->x-y;case IMUL->x*y;case IDIV->y==0?null:x/y;case IREM->y==0?null:x%y;case ISHL->x<<(y&31);case ISHR->x>>(y&31);case IUSHR->x>>>(y&31);case IAND->x&y;case IOR->x|y;case IXOR->x^y;case LADD->l+r;case LSUB->l-r;case LMUL->l*r;case LDIV->r==0?null:l/r;case LREM->r==0?null:l%r;case LSHL->l<<(y&63);case LSHR->l>>(y&63);case LUSHR->l>>>(y&63);case LAND->l&r;case LOR->l|r;case LXOR->l^r;default->null;};
    }
    static boolean foldNumbers(MethodNode m){
        boolean change=false;
        for(AbstractInsnNode i:m.instructions.toArray()){
            if(i.getOpcode()==GETSTATIC&&zeroFields.contains(key((FieldInsnNode)i))){m.instructions.set(i,new InsnNode(ICONST_0));readsReplaced++;change=true;}
        }
        boolean again=true;
        while(again){again=false;
            for(AbstractInsnNode i:m.instructions.toArray()){
                int op=i.getOpcode(); AbstractInsnNode b=i.getPrevious(),a=b==null?null:b.getPrevious();Object av=constant(a),bv=constant(b);Object v=null;
                if(av instanceof Number an && bv instanceof Number bn)v=arithmetic(op,an,bn);
                if(v!=null){m.instructions.remove(a);m.instructions.remove(b);m.instructions.set(i,literal(v));folds++;again=true;change=true;continue;}
                if(bv instanceof Number bn){
                    v=switch(op){case INEG->-bn.intValue();case LNEG->-bn.longValue();case I2B->(int)(byte)bn.intValue();case I2S->(int)(short)bn.intValue();case I2C->(int)(char)bn.intValue();default->null;};
                    if(v!=null){m.instructions.remove(b);m.instructions.set(i,literal(v));folds++;again=true;change=true;}
                }
            }
        }
        return change;
    }
    static void foldStrings(MethodNode m){
        for(AbstractInsnNode start:m.instructions.toArray()){
            if(!(start instanceof TypeInsnNode ti)||start.getOpcode()!=NEW||!ti.desc.equals("java/lang/String"))continue;
            try{
                List<AbstractInsnNode> region=new ArrayList<>(); AbstractInsnNode p=start; region.add(p);p=p.getNext();
                if(p==null||p.getOpcode()!=DUP)continue; region.add(p);p=p.getNext();
                Object size=constant(p); if(!(size instanceof Integer count)||count<0||count>100000)continue;region.add(p);p=p.getNext();
                if(!(p instanceof IntInsnNode ai)||ai.getOpcode()!=NEWARRAY||ai.operand!=T_BYTE)continue;region.add(p);p=p.getNext();
                byte[] bytes=new byte[count]; boolean[] seen=new boolean[count]; boolean valid=true;
                while(p!=null&&p.getOpcode()==DUP){
                    region.add(p);p=p.getNext();Object ix=constant(p);region.add(p);p=p.getNext();Object val=constant(p);region.add(p);p=p.getNext();
                    if(!(ix instanceof Integer index)||!(val instanceof Integer value)||index<0||index>=count||p.getOpcode()!=BASTORE){valid=false;break;}
                    bytes[index]=(byte)(int)value;seen[index]=true;region.add(p);p=p.getNext();
                }
                if(!valid)continue;
                if(!(p instanceof FieldInsnNode charset)||charset.getOpcode()!=GETSTATIC||!charset.owner.equals("java/nio/charset/StandardCharsets")||!charset.name.equals("UTF_8"))continue;
                region.add(p);p=p.getNext();
                if(!(p instanceof MethodInsnNode ctor)||ctor.getOpcode()!=INVOKESPECIAL||!ctor.owner.equals("java/lang/String")||!ctor.name.equals("<init>")||!ctor.desc.equals("([BLjava/nio/charset/Charset;)V"))continue;
                region.add(p);String value=new String(bytes,StandardCharsets.UTF_8);
                InsnList replacement=new InsnList();
                replacement.add(new TypeInsnNode(NEW,"java/lang/String"));
                replacement.add(new InsnNode(DUP));
                replacement.add(new LdcInsnNode(value));
                replacement.add(new MethodInsnNode(INVOKESPECIAL,"java/lang/String","<init>","(Ljava/lang/String;)V",false));
                m.instructions.insertBefore(start,replacement);for(AbstractInsnNode r:region)m.instructions.remove(r);stringsDecoded++;
            }catch(RuntimeException ex){throw new RuntimeException("Error string fold "+m.name,ex);}
        }
    }
    static Object annotVal(Object o){
        if(o instanceof AnnotationNode a)return annotation(a);
        if(o instanceof Type t)return map("type",t.getDescriptor());
        if(o instanceof String[] ss)return map("enumType",ss[0],"enumName",ss[1]);
        if(o instanceof List<?> list){List<Object> out=new ArrayList<>();for(Object i:list)out.add(annotVal(i));return out;}
        return o;
    }
    static Object annotation(AnnotationNode a){Map<String,Object> vals=new LinkedHashMap<>();if(a.values!=null)for(int i=0;i<a.values.size();i+=2)vals.put((String)a.values.get(i),annotVal(a.values.get(i+1)));return map("type",a.desc,"values",vals);}
    static Object annotations(List<AnnotationNode> a,List<AnnotationNode> b){List<Object> l=new ArrayList<>();if(a!=null)for(var v:a)l.add(annotation(v));if(b!=null)for(var v:b)l.add(annotation(v));return l;}
    static Object value(Object c){
        if(c instanceof Double d && !Double.isFinite(d))return map("ieee754",d.toString());
        if(c instanceof Float f && !Float.isFinite(f))return map("ieee754",f.toString());
        if(c instanceof Type t)return map("type",t.getDescriptor());
        if(c instanceof Handle h)return map("handle",h.getTag(),"owner",h.getOwner(),"name",h.getName(),"desc",h.getDesc(),"interface",h.isInterface());
        if(c instanceof ConstantDynamic d){List<Object> args=new ArrayList<>();for(int k=0;k<d.getBootstrapMethodArgumentCount();k++)args.add(value(d.getBootstrapMethodArgument(k)));return map("dynamic",d.getName(),"desc",d.getDescriptor(),"bootstrap",value(d.getBootstrapMethod()),"args",args);}
        return c;
    }
    static class TypedInterpreter extends BasicInterpreter {
        TypedInterpreter(){super(ASM9);}
        @Override public BasicValue newValue(Type type){if(type==null)return BasicValue.UNINITIALIZED_VALUE; if(type==Type.VOID_TYPE)return null; if(type.getSort()==Type.OBJECT||type.getSort()==Type.ARRAY)return new BasicValue(type);return super.newValue(type);}
        @Override public BasicValue merge(BasicValue a,BasicValue b){if(a.equals(b))return a; if(a.isReference()&&b.isReference()){if(a.getType().equals(NULL_TYPE))return b;if(b.getType().equals(NULL_TYPE))return a;return BasicValue.REFERENCE_VALUE;}return BasicValue.UNINITIALIZED_VALUE;}
    }
    static Object frame(Frame<BasicValue> f){if(f==null)return null;List<Object> locals=new ArrayList<>(),stack=new ArrayList<>();for(int i=0;i<f.getLocals();i++)locals.add(f.getLocal(i).getType()==null?null:f.getLocal(i).getType().getDescriptor());for(int i=0;i<f.getStackSize();i++)stack.add(f.getStack(i).getType()==null?null:f.getStack(i).getType().getDescriptor());return map("locals",locals,"stack",stack);}
    static Object dumpMethod(ClassNode c,MethodNode m){
        var result=map("name",m.name,"desc",m.desc,"signature",m.signature,"access",m.access,"maxLocals",m.maxLocals,"maxStack",m.maxStack,"exceptions",m.exceptions,"annotations",annotations(m.visibleAnnotations,m.invisibleAnnotations));
        Map<LabelNode,Integer> labels=new IdentityHashMap<>();int pc=0;
        for(AbstractInsnNode i:m.instructions)if(i instanceof LabelNode l)labels.put(l,pc);else if(i.getOpcode()>=0)pc++;
        Frame<BasicValue>[] frames=null;
        if((m.access&(ACC_NATIVE|ACC_ABSTRACT))==0){try{frames=new Analyzer<>(new TypedInterpreter()).analyze(c.name,m);}catch(Exception e){result.put("analysisError",e.toString());}}
        List<Object> code=new ArrayList<>();int idx=0;
        for(AbstractInsnNode i:m.instructions){int k=idx++;if(i.getOpcode()<0)continue;
            var d=map("op",Printer.OPCODES[i.getOpcode()],"opcode",i.getOpcode());
            if(frames!=null)d.put("frame",frame(frames[k]));
            if(i instanceof IntInsnNode x)d.put("operand",x.operand);
            else if(i instanceof VarInsnNode x)d.put("var",x.var);
            else if(i instanceof TypeInsnNode x)d.put("type",x.desc);
            else if(i instanceof FieldInsnNode x){d.put("owner",x.owner);d.put("name",x.name);d.put("desc",x.desc);}
            else if(i instanceof MethodInsnNode x){d.put("owner",x.owner);d.put("name",x.name);d.put("desc",x.desc);d.put("interface",x.itf);}
            else if(i instanceof InvokeDynamicInsnNode x){d.put("name",x.name);d.put("desc",x.desc);d.put("bootstrap",value(x.bsm));List<Object> args=new ArrayList<>();for(Object a:x.bsmArgs)args.add(value(a));d.put("args",args);}
            else if(i instanceof JumpInsnNode x)d.put("target",labels.get(x.label));
            else if(i instanceof LdcInsnNode x){d.put("value",value(x.cst));d.put("valueType",x.cst.getClass().getSimpleName());}
            else if(i instanceof IincInsnNode x){d.put("var",x.var);d.put("inc",x.incr);}
            else if(i instanceof TableSwitchInsnNode x){d.put("min",x.min);d.put("max",x.max);d.put("default",labels.get(x.dflt));d.put("targets",x.labels.stream().map(labels::get).toList());}
            else if(i instanceof LookupSwitchInsnNode x){d.put("keys",x.keys);d.put("default",labels.get(x.dflt));d.put("targets",x.labels.stream().map(labels::get).toList());}
            else if(i instanceof MultiANewArrayInsnNode x){d.put("desc",x.desc);d.put("dims",x.dims);}
            code.add(d);
        }
        result.put("code",code);result.put("handlers",m.tryCatchBlocks.stream().map(x->map("start",labels.get(x.start),"end",labels.get(x.end),"handler",labels.get(x.handler),"type",x.type)).toList());return result;
    }
    public static void main(String[] args)throws Exception{
        if(args.length!=2)throw new IllegalArgumentException("Usage: Normalize input.jar output-directory");
        Path out=Paths.get(args[1]);Files.createDirectories(out);Map<String,byte[]> resources=new LinkedHashMap<>();
        try(ZipFile zip=new ZipFile(args[0])){for(var e:Collections.list(zip.entries())){if(e.isDirectory())continue;byte[] b=zip.getInputStream(e).readAllBytes();if(e.getName().endsWith(".class")){int version=((b[6]&255)<<8)|(b[7]&255);byte[] parseBytes=b.clone();parseBytes[6]=0;parseBytes[7]=65;ClassNode c=new ClassNode(ASM9);new ClassReader(parseBytes).accept(c,0);c.version=version;classes.put(c.name,c);}else resources.put(e.getName(),b);}}
        Set<String> written=new HashSet<>();for(var c:classes.values())for(var m:c.methods)for(var i:m.instructions)if(i.getOpcode()==PUTSTATIC)written.add(key((FieldInsnNode)i));
        for(var c:classes.values())for(var f:c.fields)if(f.desc.equals("I")&&(f.access&(ACC_PRIVATE|ACC_STATIC))==(ACC_PRIVATE|ACC_STATIC)&&(f.value==null||Integer.valueOf(0).equals(f.value))&&!written.contains(key(c.name,f.name,f.desc)))zeroFields.add(key(c.name,f.name,f.desc));
        for(var c:classes.values())for(var m:c.methods){foldNumbers(m);foldStrings(m);for(var i:m.instructions.toArray())if(i.getOpcode()==NOP){m.instructions.remove(i);nops++;}}
        // Resolve constant string assignments, without evaluating any target Java code.
        for(var c:classes.values())for(var m:c.methods)if(m.name.equals("<clinit>"))for(var i:m.instructions)if(i.getOpcode()==PUTSTATIC){var f=(FieldInsnNode)i;AbstractInsnNode prev=i.getPrevious();
            if(prev instanceof MethodInsnNode ctor && ctor.owner.equals("java/lang/String") && ctor.name.equals("<init>") && ctor.desc.equals("(Ljava/lang/String;)V"))prev=prev.getPrevious();
            Object v=constant(prev);if(v instanceof String)strings.put(key(f),v);}
        // Keep field accesses intact in bytecode to preserve class initialization behavior.
        List<Object> dumped=new ArrayList<>();
        for(var c:classes.values()){
            var d=map("name",c.name,"super",c.superName,"interfaces",c.interfaces,"access",c.access,"version",c.version,"signature",c.signature,"annotations",annotations(c.visibleAnnotations,c.invisibleAnnotations));
            d.put("nestHost",c.nestHostClass);d.put("nestMembers",c.nestMembers);d.put("outerClass",c.outerClass);
            d.put("innerClasses",c.innerClasses.stream().map(x->map("name",x.name,"outerName",x.outerName,"innerName",x.innerName,"access",x.access)).toList());
            d.put("fields",c.fields.stream().map(f->map("name",f.name,"desc",f.desc,"signature",f.signature,"access",f.access,"value",value(f.value),"decodedString",strings.get(key(c.name,f.name,f.desc)),"opaqueZero",zeroFields.contains(key(c.name,f.name,f.desc)),"annotations",annotations(f.visibleAnnotations,f.invisibleAnnotations))).toList());
            d.put("methods",c.methods.stream().map(m->dumpMethod(c,m)).toList());dumped.add(d);
        }
        Files.writeString(out.resolve("normalized.json"),json(dumped));
        Files.writeString(out.resolve("strings.json"),json(strings));
        Files.writeString(out.resolve("normalization-report.json"),json(map("classes",classes.size(),"constantFolds",folds,"stringsDecoded",stringsDecoded,"zeroReadsReplaced",readsReplaced,"opaqueZeroFields",zeroFields,"nopsRemoved",nops)));
        try(ZipOutputStream zip=new ZipOutputStream(Files.newOutputStream(out.resolve("normalized.jar")))){
            for(var c:classes.values()){ClassWriter w=new ClassWriter(0);c.accept(w);zip.putNextEntry(new ZipEntry(c.name+".class"));zip.write(w.toByteArray());zip.closeEntry();}
            for(var e:resources.entrySet()){zip.putNextEntry(new ZipEntry(e.getKey()));zip.write(e.getValue());zip.closeEntry();}
        }
        System.out.println(Files.readString(out.resolve("normalization-report.json")));
    }
}
