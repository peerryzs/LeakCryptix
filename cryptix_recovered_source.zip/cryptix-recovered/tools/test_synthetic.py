import sys,json,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent));import recover_source as r
base=r.ROOT/'validation/synthetic';cs=json.loads((base/'normalized/normalized.json').read_text())
for c in cs:r.BYNAME[c['name']]=c;r.CM[c['name']]='checks/SyntheticRecovered'
for c in cs:
 for m in c['methods']:
  if m['name'].startswith('lambda$'):r.MM[(c['name'],m['name'])]='recoveredCallback'
results={}
for c in cs:r.class_source(c,base/'generated',results)
(base/'reconstruction.json').write_text(json.dumps(results,indent=2))
print({k:v for k,v in results.items() if v['status']!='reconstructed'})
