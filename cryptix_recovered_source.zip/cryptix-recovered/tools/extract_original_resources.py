#!/usr/bin/env python3
"""Copy exact original resources, including the DLL, without loading or executing them."""
import argparse, hashlib, pathlib, zipfile
parser=argparse.ArgumentParser()
parser.add_argument('jar',type=pathlib.Path)
parser.add_argument('destination',type=pathlib.Path)
a=parser.parse_args()
expected='4549e6578f0762adfad4c67e3e791b5c9ecad606986863ff74b47b13c9c4716d'
if hashlib.sha256(a.jar.read_bytes()).hexdigest()!=expected:
    raise SystemExit('Input SHA-256 does not match the analyzed cryptix.jar; no files copied.')
root=a.destination.resolve()
with zipfile.ZipFile(a.jar) as jar:
    for entry in jar.infolist():
        if entry.is_dir() or entry.filename.endswith('.class'):continue
        target=(root/entry.filename).resolve()
        if not target.is_relative_to(root):raise SystemExit('Unsafe ZIP entry: '+entry.filename)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(jar.read(entry))
print('Copied original resources. Nothing was executed.')
