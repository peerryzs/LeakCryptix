# Tools

The normalizer, source reconstructor, and name-restoration utility operate on classfile data only. They do not load the uploaded classes or execute the native library. `run-normalizer.sh` and `restore-symbols.sh` compile these tools using JDK internal ASM exports.

`CheckSyntax.java` invokes javac parsing only. `make_compile_scaffolding.py` generates nonfunctional external API fixtures; it is not a dependency downloader. `test_synthetic.py` reconstructs the independently authored validation test class.

The synthetic test source and its comparison harness are in `validation/synthetic/original/`. The fixture check uses `javac -proc:none` to prevent annotation processors from running. No compiled client classes, dependency fixtures, or replacement client JAR are distributed as a runnable deliverable.

Raw decoder/decompiler labels left in less certain methods are intentional. Descriptive names in `descriptive_names.py` are inferences, not fabricated claims about the author's original identifiers.
