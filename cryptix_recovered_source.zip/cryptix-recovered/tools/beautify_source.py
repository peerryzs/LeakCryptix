#!/usr/bin/env python3
"""Token-aware import cleanup; never rewrites string literals or comments."""
import re,pathlib,sys,collections
sys.path.insert(0,str(pathlib.Path(__file__).parent));import recover_source as r
lex=re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*.*?\*/',re.S)
known=set()
def add(n):
 if not n:return
 if n.startswith('['):
  for v in re.findall(r'L([^;]+);',n):add(v)
  return
 if n.startswith('L') and n.endswith(';'):n=n[1:-1]
 if '/' in n:known.add(r.CM.get(n,n).split('$')[0].replace('/','.'))
def desc(d):
 for n in re.findall(r'L([^;]+);',d or ''):add(n)
def ann(a):
 if isinstance(a,dict):
  for k,v in a.items():
   if k in ('type','enumType') and isinstance(v,str):desc(v)
   else:ann(v)
 elif isinstance(a,list):
  for v in a:ann(v)
for c in r.CLASSES:
 add(c['name']);add(c['super']);ann(c['annotations'])
 for n in c['interfaces']:add(n)
 for f in c['fields']:desc(f['desc']);ann(f['annotations'])
 for m in c['methods']:
  desc(m['desc']);ann(m['annotations'])
  for n in m['exceptions']:add(n)
  for i in m['code']:
   add(i.get('owner'));add(i.get('type'));desc(i.get('desc'));ann(i.get('args'));ann(i.get('value'))
known.update(['cryptix.recovery.JvmSupport','java.io.FileReader','java.io.FileWriter','java.lang.Throwable','java.lang.Object','java.lang.Exception','java.lang.String','java.lang.RuntimeException','java.lang.Math','java.util.Objects','java.lang.reflect.Array'])
pattern=re.compile(r'(?<![\w$])(?:'+'|'.join(re.escape(n) for n in sorted(known,key=len,reverse=True))+r')(?![\w$])')
for path in (r.ROOT/'source').rglob('*.java'):
 text=path.read_text();package=re.search(r'^package ([^;]+);',text).group(1);own=package+'.'+path.stem
 masked=lex.sub(lambda m:' '*len(m.group(0)),text)
 present=set(pattern.findall(masked));byshort=collections.defaultdict(list)
 for name in present:byshort[name.rsplit('.',1)[-1]].append(name)
 mapping={};imports=[]
 for name in present:
  short=name.rsplit('.',1)[-1]
  if len(byshort[short])>1:continue
  if short==path.stem and name!=own:continue
  mapping[name]=short
  if name!=own and name.rsplit('.',1)[0] not in ('java.lang',package):imports.append(name)
 parts=[];previous=0
 for match in lex.finditer(text):
  parts.append(pattern.sub(lambda m:mapping.get(m.group(0),m.group(0)),text[previous:match.start()]));parts.append(match.group(0));previous=match.end()
 parts.append(pattern.sub(lambda m:mapping.get(m.group(0),m.group(0)),text[previous:]));text=''.join(parts)
 if imports:
  imports='\n'.join('import '+name+';' for name in sorted(imports))
  text=text.replace('package '+package+';','package '+package+';\n\n'+imports,1)
 # Remove only self-assignments to generated, non-volatile local variables.
 text=re.sub(r'^\s*(reference\d+|integer\d+|floating\d+|number\d+|local\d+) = \1;\n','',text,flags=re.M)
 path.write_text(text)
print('Cleaned imports in',len(list((r.ROOT/'source').rglob('*.java'))),'Java files')
