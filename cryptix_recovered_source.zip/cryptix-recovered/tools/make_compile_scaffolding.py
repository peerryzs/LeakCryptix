#!/usr/bin/env python3
"""Generate non-executable API signature scaffolding for a source type-check.
Not Minecraft; never used as product code or as evidence of runtime equivalence.
"""
import sys,re,collections,pathlib,json
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import recover_source as r
OUT=r.ROOT/'validation/api-signatures';OUT.mkdir(parents=True,exist_ok=True)
for p in OUT.rglob('*.java'):p.unlink()
types={}
def external(n):return n and n not in r.BYNAME and not n.startswith(('java/','javax/','jdk/','['))
def ensure(n):
 if external(n):
  if '$' in n:ensure(n.rsplit('$',1)[0])
  return types.setdefault(n,{'fields':{},'methods':{},'interface':False,'enum':set(),'annotations':{},'super':None,'interfaces':set()})
def desc(d):
 for n in re.findall(r'L([^;]+);',d or ''):ensure(n)
def annval(v):
 if isinstance(v,list):
  ts=[annval(x) for x in v];return (ts[0] if ts else 'String')+'[]'
 if isinstance(v,dict):
  if 'type' in v and 'values' not in v:desc(v['type']);return 'Class<?>'
  if 'enumType' in v:
   name=v['enumType'][1:-1];t=ensure(name);t['enum'].add(v['enumName']);return r.typename(name)
  if 'values' in v:annot(v);return r.typename(v['type'])
 if isinstance(v,bool):return 'boolean'
 if isinstance(v,int):return 'int'
 if isinstance(v,float):return 'double'
 return 'String'
def annot(a):
 n=a['type'][1:-1];t=ensure(n)
 if t is None:return
 t['annotation']=True
 for k,v in a.get('values',{}).items():
  ty=annval(v);prev=t['annotations'].get(k)
  if prev and prev.endswith('[]'):ty=prev
  elif prev and ty.endswith('[]'):pass
  t['annotations'][k]=ty
for c in r.CLASSES:
 ensure(c['super'])
 for n in c['interfaces']:
  t=ensure(n)
  if t is not None:t['interface']=True
 for a in c['annotations']:annot(a)
 for f in c['fields']:
  desc(f['desc'])
  for a in f['annotations']:annot(a)
 for m in c['methods']:
  desc(m['desc'])
  for a in m['annotations']:annot(a)
  for i in m['code']:
   if 'type' in i:
    d=i['type'];desc(d) if d.startswith('[') else ensure(d)
   if 'desc' in i:desc(i['desc'])
   if i['op']=='LDC' and i.get('valueType')=='Type':desc(i['value']['type'])
   if 'owner' in i:
    t=ensure(i['owner'])
    if t is not None:
     if i['op'] in ('GETSTATIC','PUTSTATIC','GETFIELD','PUTFIELD'):
      t['fields'][i['name']]=(i['desc'],i['op'] in ('GETSTATIC','PUTSTATIC'))
     else:
      t['methods'][(i['name'],i['desc'])]=i['op']=='INVOKESTATIC'
      if i['op']=='INVOKEINTERFACE':t['interface']=True
   if i['op']=='INVOKEDYNAMIC' and i['bootstrap']['owner']=='java/lang/invoke/LambdaMetafactory':
    ats,ret=r.method_types(i['desc']);t=ensure(ret[1:-1]);sam=i['args'][0]['type']
    if t is not None:t['interface']=True;t['sam']=True;t['methods'][(i['name'],sam)]=False;desc(sam)
# Add relations needed to accurately represent expression assignments and casts.
parents={
'net/minecraft/world/item/BlockItem':'net/minecraft/world/item/Item',
'net/minecraft/world/level/block/state/properties/EnumProperty':'net/minecraft/world/level/block/state/properties/Property',
'net/minecraft/core/BlockPos':'net/minecraft/core/Vec3i',
'net/minecraft/world/scores/PlayerTeam':'net/minecraft/world/scores/Team',
'net/minecraft/world/inventory/InventoryMenu':'net/minecraft/world/inventory/AbstractContainerMenu',
'net/minecraft/client/gui/screens/inventory/InventoryScreen':'net/minecraft/client/gui/screens/Screen',
'net/minecraft/client/gui/screens/ChatScreen':'net/minecraft/client/gui/screens/Screen',
'net/minecraft/client/player/LocalPlayer':'net/minecraft/client/player/AbstractClientPlayer',
'net/minecraft/client/player/AbstractClientPlayer':'net/minecraft/world/entity/player/Player',
'net/minecraft/world/entity/player/Player':'net/minecraft/world/entity/LivingEntity',
'net/minecraft/world/entity/LivingEntity':'net/minecraft/world/entity/Entity',
'net/minecraft/world/entity/projectile/hurtingprojectile/Fireball':'net/minecraft/world/entity/Entity',
'net/minecraft/world/entity/projectile/hurtingprojectile/SmallFireball':'net/minecraft/world/entity/projectile/hurtingprojectile/Fireball',
'net/minecraft/world/entity/projectile/hurtingprojectile/LargeFireball':'net/minecraft/world/entity/projectile/hurtingprojectile/Fireball',
'net/minecraft/world/phys/EntityHitResult':'net/minecraft/world/phys/HitResult',
'net/minecraft/world/phys/BlockHitResult':'net/minecraft/world/phys/HitResult',
'net/minecraft/world/level/block/BedBlock':'net/minecraft/world/level/block/Block',
'net/minecraft/world/level/block/AirBlock':'net/minecraft/world/level/block/Block',
'net/minecraft/core/BlockPos$MutableBlockPos':'net/minecraft/core/BlockPos',
'net/minecraft/client/player/KeyboardInput':'net/minecraft/client/player/ClientInput',
'net/minecraft/world/inventory/ChestMenu':'net/minecraft/world/inventory/AbstractContainerMenu',
'net/minecraft/client/multiplayer/ClientLevel':'net/minecraft/world/level/Level',
'net/minecraft/client/gui/screens/multiplayer/JoinMultiplayerScreen':'net/minecraft/client/gui/screens/Screen',
'net/minecraft/client/gui/components/EditBox':'net/minecraft/client/gui/components/AbstractWidget',
'net/minecraft/client/gui/components/Button':'net/minecraft/client/gui/components/AbstractWidget',
'net/minecraft/core/NonNullList':'java/util/ArrayList',
'com/google/gson/JsonObject':'com/google/gson/JsonElement',
'com/google/gson/JsonArray':'com/google/gson/JsonElement',
'org/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable':'org/spongepowered/asm/mixin/injection/callback/CallbackInfo',
'net/minecraft/client/renderer/entity/state/LivingEntityRenderState':'net/minecraft/client/renderer/entity/state/EntityRenderState',
}
for child,parent in parents.items():
 if child in types:ensure(parent);types[child]['super']=parent
interfaces={
 'org/joml/Quaternionf':['org/joml/Quaternionfc'],
 'net/minecraft/world/level/Level':['net/minecraft/world/level/BlockGetter'],
 'net/minecraft/client/multiplayer/ClientPacketListener':['net/minecraft/network/PacketListener'],
 'net/minecraft/world/item/Item':['net/minecraft/world/level/ItemLike'],
 'net/minecraft/client/gui/components/AbstractWidget':['net/minecraft/client/gui/components/events/GuiEventListener'],
 'net/minecraft/network/chat/MutableComponent':['net/minecraft/network/chat/Component'],
 'org/joml/Matrix4f':['org/joml/Matrix4fc'],
 'org/joml/Matrix3x2fStack':['org/joml/Matrix3x2fc'],
 'net/minecraft/client/resources/sounds/SimpleSoundInstance':['net/minecraft/client/resources/sounds/SoundInstance'],
 'net/minecraft/core/Direction$Plane':['java/lang/Iterable'],
}
for n in list(types):
 if n.startswith('net/minecraft/network/protocol/game/') and n.split('/')[-1].endswith(('Packet','$PosRot','$Pos','$Rot','$StatusOnly')):interfaces[n]=['net/minecraft/network/protocol/Packet']
for n,ints in interfaces.items():
 if n not in types:continue
 for it in ints:
  t=ensure(it)
  if t is not None:t['interface']=True
  types[n]['interfaces'].add(it)
# Accessed inherited screen fields are not duplicated under obfuscated GUI subclasses.
screen=ensure('net/minecraft/client/gui/screens/Screen')
for n,d in [('width','I'),('height','I'),('font','Lnet/minecraft/client/gui/Font;'),('minecraft','Lnet/minecraft/client/Minecraft;')]:screen['fields'].setdefault(n,(d,False));desc(d)
# Source overrides that are not independently invoked in the bytecode.
for name,descriptor in [('init','()V'),('removed','()V'),('onClose','()V'),('isPauseScreen','()Z')]:screen['methods'].setdefault((name,descriptor),False)
# Recover inherited members referenced with an application-class owner.
for c in r.CLASSES:
 for m in c['methods']:
  for i in m['code']:
   owner=i.get('owner')
   if owner not in r.BYNAME:continue
   cur=r.BYNAME[owner];found=False;field=i['op'] in ('GETFIELD','GETSTATIC','PUTFIELD','PUTSTATIC')
   if not field and not i['op'].startswith('INVOKE'):continue
   if i['name'].startswith('<'):continue
   while cur:
    group=cur['fields'] if field else cur['methods']
    if any(x['name']==i['name'] and x['desc']==i['desc'] for x in group):found=True;break
    parent=cur['super']
    if parent not in r.BYNAME:break
    cur=r.BYNAME[parent]
   if not found and external(parent):
    t=ensure(parent)
    if field:t['fields'].setdefault(i['name'],(i['desc'],i['op'] in ('GETSTATIC','PUTSTATIC')))
    else:t['methods'].setdefault((i['name'],i['desc']),i['op']=='INVOKESTATIC')
# Add public inherited entity members referenced using a subclass as owner, already covered when emitted.
children=collections.defaultdict(list)
for name in types:
 if '$' in name:children[name.rsplit('$',1)[0]].append(name)
def java_type(d):return r.typename(d)
def annotation_default(ty):
 if ty.endswith('[]'):return '{}'
 if ty=='String':return '""'
 if ty=='boolean':return 'false'
 if ty in ('int','double'):return '0'
 if ty=='Class<?>':return 'Object.class'
 name=ty.replace('.','/')
 # Nested enum/annotation classes are keyed using dollar signs.
 n=next((n for n in types if r.typename(n)==ty),None)
 if n and types[n]['enum']:return ty+'.'+sorted(types[n]['enum'])[0]
 if n and types[n].get('annotation'):return '@'+ty
 return None

def emit(n,indent=''):
 t=types[n];short=n.rsplit('/',1)[-1].rsplit('$',1)[-1];ls=[];ann=t.get('annotation');enum=bool(t['enum']);it=t['interface']
 head='public '+('static ' if '$' in n else '')+('@interface ' if ann else 'enum ' if enum else 'interface ' if it else 'class ')+short
 if not ann and not enum:
  if t['super'] and not it:head+=' extends '+java_type(t['super'])
  ints=t['interfaces']
  if ints:head+=(' extends ' if it else ' implements ')+', '.join(java_type(x) for x in sorted(ints))
 ls.append(indent+head+' {');ind=indent+'    '
 if ann:
  for name,ty in t['annotations'].items():
   d=annotation_default(ty);ls.append(ind+ty+' '+name+'()'+(' default '+d if d is not None else '')+';')
 elif enum:ls.append(ind+', '.join(sorted(t['enum']))+';')
 else:
  for name,(d,static) in t['fields'].items():
   ls.append(ind+'public '+('static ' if static or it else '')+java_type(d)+' '+name+' = '+r.default(d)+';')
  methods=dict(t['methods'])
  if not it and not any(k[0]=='<init>' and k[1]=='()V' for k in methods):methods[('<init>','()V')]=False
  seen=set()
  for (name,d),static in methods.items():
   if name in ('<clinit>','clone') and it:continue
   args,ret=r.method_types(d);erased=(name,tuple(args))
   if erased in seen:continue
   seen.add(erased)
   if name=='<init>' and it:continue
   vis='protected ' if n=='net/minecraft/client/gui/screens/Screen' and name=='init' else 'public '
   head=vis+('static ' if static else 'default ' if it and name not in ('<init>',) else '')
   head+=(short if name=='<init>' else java_type(ret)+' '+name)+'('+', '.join(java_type(a)+' p'+str(k) for k,a in enumerate(args))+')'
   # Genuine SAM interfaces cannot have default implementation for their single abstract method.
   sam=it and not static and (name in ('equals','hashCode','toString') or t.get('sam') and len([x for x,v in methods.items() if not v])==1)
   if sam:head=head.replace('default ','');tail=';'
   else:tail=' { throw new AssertionError("COMPILE-ONLY API SIGNATURE"); }'
   ls.append(ind+head+tail)
 for child in sorted(children[n]):ls+=emit(child,ind)
 ls.append(indent+'}');return ls
for n in sorted(types):
 if '$' in n:continue
 path=OUT/(n+'.java');path.parent.mkdir(parents=True,exist_ok=True);package=n.rsplit('/',1)[0].replace('/','.')
 path.write_text('package '+package+';\n\n// COMPILE-ONLY API SIGNATURES. Not a functional implementation.\n'+'\n'.join(emit(n))+'\n')
(r.ROOT/'validation/signature-inventory.json').write_text(json.dumps(types,indent=2,default=lambda x:sorted(x) if isinstance(x,set) else {str(k):v for k,v in x.items()})) if False else None
print('Generated signature scaffolding for',len(types),'external types')
