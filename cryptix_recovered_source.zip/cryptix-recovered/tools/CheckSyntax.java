import java.io.*;
import java.nio.file.*;
import java.util.*;
import javax.tools.*;
import com.sun.source.util.*;
public class CheckSyntax {
 public static void main(String[] args)throws Exception {
  JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
  var diagnostics=new DiagnosticCollector<JavaFileObject>();
  var manager=compiler.getStandardFileManager(diagnostics,null,null);
  var paths=Files.walk(Path.of(args[0])).filter(p->p.toString().endsWith(".java")).map(Path::toFile).toList();
  var task=(JavacTask)compiler.getTask(null,manager,diagnostics,List.of("-proc:none","--release","21"),null,manager.getJavaFileObjectsFromFiles(paths));
  int count=0;for(var parsed:task.parse())count++;
  for(var d:diagnostics.getDiagnostics())System.out.println(d.getKind()+" "+(d.getSource()==null?"":d.getSource().getName())+":"+d.getLineNumber()+":"+d.getColumnNumber()+" "+d.getMessage(null));
  System.out.println("Parsed "+count+" source files; diagnostics: "+diagnostics.getDiagnostics().size());
 }
}
