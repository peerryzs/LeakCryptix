#!/usr/bin/env python3
"""Write exact JVM-level name mappings, including inherited member references."""
import sys,pathlib,re
sys.path.insert(0,str(pathlib.Path(__file__).parent));import recover_source as r
root=r.ROOT
lines=['# kind\treadable-owner\treadable-name/ancestor\tdescriptor\toriginal-name']
def md(d):return re.sub(r'L([^;]+);',lambda m:'L'+r.CM.get(m.group(1),m.group(1))+';',d)
for c in r.CLASSES:
 owner=r.CM[c['name']];lines.append('\t'.join(['C',owner,c['name']]))
 ancestors=[r.CM.get(n,n) for n in [c['super']]+c['interfaces'] if n]
 lines.append('\t'.join(['H',owner,','.join(ancestors)]))
 for f in c['fields']:
  if f['opaqueZero']:
   lines.append('\t'.join(['Z',owner,f['name'],f['desc'],str(f['access']),'' if f['value'] is None else str(f['value'])]))
  else:
   source_name='$VALUES' if c['name']=='a/ll' and f['desc']=='[La/ll;' else r.fieldname(c['name'],f['name'],f['desc'])
   lines.append('\t'.join(['F',owner,source_name,md(f['desc']),f['name']]))
 for m in c['methods']:
  lines.append('\t'.join(['M',owner,r.methodname(c['name'],m['name']),md(m['desc']),m['name']]))
(root/'symbols.tsv').write_text('\n'.join(lines)+'\n')
print('Wrote exact-symbol restoration map')
