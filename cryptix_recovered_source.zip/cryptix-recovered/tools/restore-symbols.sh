#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd -- "$(dirname -- "$0")" && pwd)"
FLAGS=(--add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED --add-exports java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED --add-exports java.base/jdk.internal.org.objectweb.asm.commons=ALL-UNNAMED)
javac "${FLAGS[@]}" "$HERE/RestoreSymbols.java"
java "${FLAGS[@]}" -cp "$HERE" RestoreSymbols "$@"
