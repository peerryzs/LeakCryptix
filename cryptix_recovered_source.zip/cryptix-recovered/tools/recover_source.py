#!/usr/bin/env python3
"""Static Java source reconstruction from Normalize's typed bytecode export.
No target classes are loaded or executed. Unsupported regions fail visibly.
"""
from __future__ import annotations
import json,re,sys,copy,collections,dataclasses,pathlib,traceback
ROOT=pathlib.Path(__file__).resolve().parent.parent
CLASSES=json.loads((ROOT/'normalized/normalized.json').read_text())
BYNAME={c['name']:c for c in CLASSES}
STRINGS=json.loads((ROOT/'normalized/strings.json').read_text())
CM={}; FM={}; MM={}; MODULES=[]

def parse_type(desc,pos=0):
 start=pos
 while desc[pos]=='[':pos+=1
 if desc[pos]=='L':pos=desc.index(';',pos)+1
 else:pos+=1
 return desc[start:pos],pos

def method_types(desc):
 args=[];p=1
 while desc[p]!=')':t,p=parse_type(desc,p);args.append(t)
 return args,desc[p+1:]

def field_key(owner,name,desc):return f'{owner}.{name}:{desc}'
def decoded(i):return STRINGS.get(field_key(i.get('owner',''),i.get('name',''),i.get('desc','')))
def ident(text,upper=False):
 parts=re.findall(r'[A-Za-z0-9]+',text)
 s=(''.join(p[:1].upper()+p[1:] for p in parts) or 'value')
 if not upper:s=s[0].lower()+s[1:]
 if s[0].isdigit():s='value'+s
 if s in {'default','switch','class','public','private','static','enum','record','new','return','case','void','this','super','long','float','int','short','boolean','double','byte','char','var','null','true','false','native','final','if','else','break','continue','for','while','do','try','catch','throw','throws','yield','package','import','interface','synchronized'}:s+='Value'
 return s

# Class and member names are inferred; original signatures remain in mappings.
CM.update({'a/j':'cryptix/CryptixClient','a/le':'cryptix/module/Module','a/ll':'cryptix/module/Category','a/pz':'cryptix/module/ModuleManager','a/rg':'cryptix/setting/Setting','a/xc':'cryptix/setting/BooleanSetting','a/lm':'cryptix/setting/NumberSetting','a/ju':'cryptix/setting/ModeSetting','a/se':'cryptix/setting/PositionSetting','a/l':'cryptix/event/Event','a/q':'cryptix/event/Events','a/ul':'cryptix/util/MinecraftAccess','a/u':'cryptix/input/KeybindManager','a/g':'cryptix/command/CommandManager','a/s':'cryptix/command/Command','a/n':'cryptix/command/BindCommand','a/x':'cryptix/command/HelpCommand','a/o':'cryptix/command/ToggleCommand','a/v':'cryptix/command/ConfigCommand','a/pj':'cryptix/util/TargetingUtils','a/dp':'cryptix/config/ConfigManager'})
for n,new in [('f22','COMBAT'),('f23','MOVEMENT'),('f24','PLAYER'),('f25','VISUAL'),('f26','MISC')]:FM[('a/ll',n)]=new
for c in CLASSES:
 if c['super']=='a/le':
  ctor=next(m for m in c['methods'] if m['name']=='<init>');category='misc';name=None
  for i in ctor['code']:
   if i['op']=='GETSTATIC' and i['owner']=='a/ll':category=FM[('a/ll',i['name'])].lower()
   if i['op']=='GETSTATIC' and decoded(i) is not None and name is None:name=decoded(i)
   if i['op']=='INVOKESPECIAL' and i['owner']=='a/le':break
  if not name:raise ValueError(c['name'])
  CM[c['name']]=f'cryptix/module/impl/{category}/{ident(name,True)}'
  MODULES.append({'original':c['name'],'name':name,'category':category,'class':CM[c['name']]})
 elif c['name'].startswith('mixins/'):
  ann=next((a for a in c['annotations'] if a['type'].endswith('/Mixin;')),None)
  if ann:
   types=ann['values'].get('value',[])
   target=types[0]['type'][1:-1] if types else c['name']
   CM[c['name']]='cryptix/mixin/'+target.rsplit('/',1)[-1].replace('$','')+'Mixin'
 elif c['super']=='a/l':CM[c['name']]='cryptix/event/impl/Event_'+c['name'].split('/')[-1]
 elif c['name'] not in CM and c['name'] not in ['a/i','a/b','native0/Loader']:
  group='gui' if c['super']=='net/minecraft/client/gui/screens/Screen' else 'util'
  CM[c['name']]='cryptix/'+group+'/Recovered_'+c['name'].split('/')[-1]

# Distinct mixins can target the same Minecraft class; never overwrite one.
reverse=collections.defaultdict(list)
for old,new in CM.items():reverse[new].append(old)
for new,originals in reverse.items():
 if len(originals)>1:
  for old in originals:CM[old]=new+'_'+old.rsplit('/',1)[-1]

# Explicitly preserve all native bridge symbols.
for n in ['a/i','a/b','native0/Loader']:CM[n]=n

def add_fields(owner,**names):
 for old,new in names.items():FM[(owner,old)]=new
add_fields('a/le',f0='mc',f15='settings',f238='category',f239='name',f240='displayName',f241='suffix',f242='cachedWidth',f243='keybind',f244='defaultKeybind',f245='enabled',f246='hidden',f247='toggleTime')
add_fields('a/rg',f883='name',f884='module')
add_fields('a/xc',f885='value',f886='defaultValue')
add_fields('a/lm',f888='minimum',f889='maximum',f890='increment',f891='value',f892='defaultValue')
add_fields('a/ju',f893='modes',f894='value',f895='defaultValue')
add_fields('a/l',f83='listeners',f84='cancelled',f85='listenerCount')
add_fields('a/ul',f0='mc')
for owner,names in {
'a/le':{'m132':'toggle','m123':'isEnabled','m136':'onDisable','m129':'setSuffix','m124':'getName','m128':'setHidden','m126':'isHidden','m127':'getToggleTime','m121':'setKeybind','m120':'getKeybind','m125':'getDisplayName','m122':'getCategory','m135':'onEnable','m137':'onEvent','m119':'getDefaultKeybind','m131':'getDisplayWidth','m133':'setEnabled','m130':'getSuffix','m134':'getEventPriority'},
'a/l':{'m8':'isCancelled','m9':'setCancelled','m10':'reset','m11':'dispatch'},
'a/rg':{'m219':'getModule','m218':'getName'},
'a/xc':{'m221':'getDefaultValue','m220':'getValue','m222':'setValue'},
'a/lm':{'m223':'getMinimum','m224':'getMaximum','m225':'getValue','m226':'getIncrement','m227':'getDefaultValue','m228':'setValue'},
'a/ju':{'m229':'getValue','m230':'getDefaultValue','m233':'is','m231':'setValue','m232':'getModes'},
'a/pz':{'m16':'initialize','m17':'sort','m18':'refresh','m19':'getModules','m20':'getSortedModules','m21':'getModulesInCategory','m22':'saveState'},
'a/j':{'m5':'sendChatMessage','m6':'sendPrefixedMessage'},
'a/u':{'m7':'pollKeybinds'},
'a/ll':{'m14':'values','m15':'valueOf'},
'a/zb':{'pm$61':'getMouseSensitivityStep','pm$62':'quantizeRotation'},
'a/pj':{'m53':'findTarget'},
}.items():
 for old,new in names.items():MM[(owner,old)]=new
# Avoid colliding with javac's own synthetic lambda implementation names.
for c in CLASSES:
 for m in c['methods']:
  if m['name'].startswith('lambda$') and not m['access']&256:
   parts=m['name'].split('$');MM[(c['name'],m['name'])]=ident(parts[1])+'Callback'+parts[-1]
# Surviving lambda implementation names also reveal several original enclosing method names.
for c in CLASSES:
 for m in c['methods']:
  if m['name'].startswith('<') or (c['name'],m['name']) in MM:continue
  originals={i['args'][1]['name'].split('$')[1] for i in m['code'] if i['op']=='INVOKEDYNAMIC' and i['bootstrap']['owner']=='java/lang/invoke/LambdaMetafactory' and i['args'][1]['owner']==c['name'] and i['args'][1]['name'].startswith('lambda$')}
  if len(originals)==1:MM[(c['name'],m['name'])]=ident(next(iter(originals)))
# Detect setting fields and instance references in the module manager.
for c in CLASSES:
 used=set(FM.get((c['name'],f['name']),f['name']) for f in c['fields'])
 for m in c['methods']:
  if m['name']!='<init>':continue
  pending=None
  for i in m['code']:
   if i['op']=='NEW':pending={'type':i['type'],'label':None}
   elif i['op']=='GETSTATIC' and pending is not None and pending['label'] is None and decoded(i) is not None:pending['label']=decoded(i)
   elif i['op']=='PUTFIELD' and pending and i['owner']==c['name']:
    if pending['type'] in ['a/xc','a/lm','a/ju','a/se'] and pending['label']:
     nm=ident(pending['label']);base=nm;k=2
     while nm in used:nm=base+str(k);k+=1
     FM[(c['name'],i['name'])]=nm;used.add(nm)
    pending=None
 for f in c['fields']:
  if c['name']=='a/pz' and f['desc'].startswith('La/') and f['desc'][1:-1] in CM:FM[(c['name'],f['name'])]=ident(CM[f['desc'][1:-1]].rsplit('/',1)[-1])
  if f.get('decodedString') is not None:
   text=f['decodedString'];base='TEXT_'+(re.sub(r'[^A-Za-z0-9]+','_',text).strip('_').upper() or 'EMPTY')
   if len(base)>55:base='TEXT_'+f['name'].upper()
   nm=base;k=2
   while nm in used:nm=base+'_'+str(k);k+=1
   FM[(c['name'],f['name'])]=nm;used.add(nm)

from descriptive_names import CLASS_NAMES,FIELD_NAMES,METHOD_NAMES
CM.update(CLASS_NAMES)
for owner,names in FIELD_NAMES.items():
 for old,new in names.items():FM[(owner,old)]=new
for owner,names in METHOD_NAMES.items():
 for old,new in names.items():MM[(owner,old)]=new
for f in BYNAME['a/q']['fields']:
 if f['desc'].startswith('La/') and f['desc'][1:-1] in CLASS_NAMES:
  simple=CLASS_NAMES[f['desc'][1:-1]].rsplit('/',1)[-1]
  FM[('a/q',f['name'])]=ident(simple[:-5] if simple.endswith('Event') else simple)

def ancestors(owner):
 seen=set()
 while owner and owner not in seen:
  seen.add(owner);yield owner
  c=BYNAME.get(owner)
  if not c:break
  for i in c['interfaces']:
   if i not in seen:yield i
  owner=c['super']

def fieldname(owner,name,desc=None):
 if owner=='a/i' and name=='f0' and desc=='Ljava/lang/String;':return 'f0String'
 for c in ancestors(owner):
  if (c,name) in FM:return FM[(c,name)]
 return name

def methodname(owner,name):
 if name.startswith('<'):return name
 for c in ancestors(owner):
  if (c,name) in MM:return MM[(c,name)]
 return name

def typename(desc):
 if desc=='L':desc='J'
 if desc.startswith('['):return typename(desc[1:])+'[]'
 if desc in {'V','Z','B','C','S','I','J','F','D'}:return {'V':'void','Z':'boolean','B':'byte','C':'char','S':'short','I':'int','J':'long','F':'float','D':'double'}[desc]
 if desc.startswith('L') and desc.endswith(';'):desc=desc[1:-1]
 return CM.get(desc,desc).replace('/','.').replace('$','.')

def quote(s):return json.dumps(s,ensure_ascii=True).replace('\\/','/')
def ref(desc):return desc.startswith(('L','[')) or desc=='null'
def default(desc):return 'null' if ref(desc) else 'false' if desc=='Z' else '0.0f' if desc=='F' else '0.0' if desc=='D' else '0L' if desc=='J' else '0'
def assignable(actual,expected):
 if actual==expected or actual=='null' and ref(expected):return True
 if ref(actual) and expected=='Ljava/lang/Object;':return True
 if actual.startswith('[') and expected in ('Ljava/lang/Cloneable;','Ljava/io/Serializable;'):return True
 if actual.startswith('[') and expected.startswith('['):return assignable(actual[1:],expected[1:])
 if actual.startswith('L') and expected.startswith('L'):
  if expected[1:-1] in ancestors(actual[1:-1]):return True
  known={'java/util/ArrayList':['java/util/List','java/util/Collection','java/lang/Iterable'], 'java/util/HashMap':['java/util/Map'],'java/util/LinkedHashMap':['java/util/Map'], 'java/util/LinkedList':['java/util/List','java/util/Collection','java/lang/Iterable'], 'java/util/HashSet':['java/util/Set','java/util/Collection','java/lang/Iterable'],'java/lang/String':['java/lang/CharSequence','java/io/Serializable'], 'net/minecraft/client/player/LocalPlayer':['net/minecraft/client/player/AbstractClientPlayer','net/minecraft/world/entity/player/Player','net/minecraft/world/entity/LivingEntity','net/minecraft/world/entity/Entity'], 'net/minecraft/world/entity/player/Player':['net/minecraft/world/entity/LivingEntity','net/minecraft/world/entity/Entity'],'net/minecraft/world/entity/LivingEntity':['net/minecraft/world/entity/Entity']}
  if expected[1:-1] in known.get(actual[1:-1],[]):return True
 return False

@dataclasses.dataclass(eq=False)
class E:
 text:str
 typ:str='I'
 kind:str='expr'
 data:object=None
 def __post_init__(self):
  if self.typ=='L':self.typ='J'
 def render(self):
  if self.kind=='new':
   if self.data.get('args') is None:raise ReconstructionError('Uninitialized allocation escaped a region')
   return 'new '+typename(self.typ)+'('+', '.join(self.data['args'])+')'
  if self.kind=='array':
   a=self.data;size=a['size'];vals=a['values']
   if isinstance(size,int) and len(vals)==size and set(vals)==set(range(size)):
    return 'new '+typename(self.typ)+' {'+', '.join(vals[i] for i in range(size))+'}'
   return 'new '+typename(self.typ[1:])+'['+str(size)+']'
  return self.text
 def signature(self):
  if self.kind in ('new','array'):return id(self)
  return (self.text,self.typ,self.kind)

class ReconstructionError(Exception):pass

def as_type(e,typ):
 if typ=='L':typ='J'
 s=e.render()
 if e.typ==typ or e.typ=='null' and ref(typ):return s
 if typ=='Z':
  if e.kind=='const' and e.data in [0,1]:return 'true' if e.data else 'false'
  return '('+s+' != 0)'
 if e.typ=='Z' and typ in 'BCSIJFD':return '('+s+' ? 1 : 0)'
 if ref(typ):
  if assignable(e.typ,typ):return s
  return '(('+typename(typ)+') '+('' if e.typ=='Ljava/lang/Object;' else '(Object) ')+s+')'
 if typ in ['B','S','C'] or e.typ in 'JFD' and typ in 'IJF' and ['I','J','F','D'].index(e.typ)>['I','J','F','D'].index(typ):return '(('+typename(typ)+') '+s+')'
 return s

def negate(s):
 if s=='true':return 'false'
 if s=='false':return 'true'
 if s.startswith('!(') and s.endswith(')'):return s[2:-1]
 # Boolean negation remains explicit; do not invert floating comparisons incorrectly.
 return '!('+s+')'

def jliteral(v,kind='Integer'):
 if isinstance(v,dict) and 'ieee754' in v:v=float(v['ieee754'])
 if kind=='String':return E(quote(v),'Ljava/lang/String;','const',v)
 if kind=='Type':return E(typename(v['type'])+'.class','Ljava/lang/Class;','const',v)
 if isinstance(v,bool):return E(str(v).lower(),'Z','const',v)
 typ={'Long':'J','Float':'F','Double':'D'}.get(kind,'I')
 if isinstance(v,float) and (v!=v or abs(v)==float('inf')):
  owner='Float' if typ=='F' else 'Double';constant='NaN' if v!=v else 'POSITIVE_INFINITY' if v>0 else 'NEGATIVE_INFINITY'
  return E(owner+'.'+constant,typ,'const',v)
 s=str(v)
 if typ=='J':s+='L'
 elif typ=='F':s+='f'
 return E(s,typ,'const',v)

def comparison(e,op):
 rel={'IFEQ':'==','IFNE':'!=','IFLT':'<','IFLE':'<=','IFGT':'>','IFGE':'>='}[op]
 if e.kind=='compare':
  a,b,how=e.data
  x,y=a.render(),b.render()
  if rel in ('==','!=') or how=='LCMP':return f'({x} {rel} {y})'
  if how.endswith('L'):
   return {'<':f'!({x} >= {y})','<=':f'!({x} > {y})','>':f'({x} > {y})','>=':f'({x} >= {y})'}[rel]
  return {'<':f'({x} < {y})','<=':f'({x} <= {y})','>':f'!({x} <= {y})','>=':f'!({x} < {y})'}[rel]
 if e.typ=='Z' and op in ('IFEQ','IFNE'):return negate(e.render()) if op=='IFEQ' else e.render()
 return f'({e.render()} {rel} 0)'

class MethodDecompiler:
 def __init__(self,c,m):
  self.c=c;self.m=m;self.code=m['code'];self.used=set();self.structural=set();self.declarations={};self.params={};self.var_types={};self.tempn=0;self.warnings=[];self.settings=[];self.depth=0
  self.argtypes,self.ret=method_types(m['desc']);slot=0 if m['access']&8 else 1
  if not m['access']&8:self.params[(0,'A')]=('this','L'+c['name']+';')
  arglabels={}
  if m['name']=='m137' and m['desc']=='(La/l;)V':arglabels[0]='event'
  if c['name']=='a/zb' and m['name']=='pm$62':arglabels={0:'rotation',1:'previousRotation'}
  if c['name'] in ['a/le','a/rg','a/xc','a/lm','a/ju','a/se'] and m['name']=='<init>':arglabels={0:'name',1:'module'} if c['name']!='a/le' else {0:'name'}
  self.paramdecl=[]
  for ix,t in enumerate(self.argtypes):
   name=arglabels.get(ix,'arg'+str(ix));key=(slot,'A' if ref(t) else 'I' if t in 'ZBCSI' else 'L' if t=='J' else t)
   self.params[key]=(name,t);self.paramdecl.append(typename(t)+' '+name);slot+=2 if t in ('J','D') else 1
  # Infer one declaration type per physical local slot and JVM storage category.
  observed=collections.defaultdict(set)
  for i in self.code:
   op=i['op'];fr=i.get('frame')
   if not fr:continue
   if op.endswith('STORE') and len(op)==6 and 'var' in i:
    typ=fr['stack'][-1] if fr['stack'] else None
    cat=op[0];observed[(i['var'],cat)].add(typ)
   elif op.endswith('LOAD') and len(op)==5 and 'var' in i:
    typ=fr['locals'][i['var']];cat=op[0];observed[(i['var'],cat)].add(typ)
  for k,types in observed.items():
   types={t for t in types if t and t!='Lnull;'}
   if k[1]=='A':
    if len(types)==1:t=next(iter(types))
    elif not types:t='Ljava/lang/Object;'
    else:
     candidate=next((x for x in types if all(assignable(y,x) for y in types)),None);t=candidate or 'Ljava/lang/Object;'
   else:t='J' if k[1]=='L' else k[1]
   self.var_types[k]=t
  self.assigned={ (i['var'],i['op'][0]) for i in self.code if i['op'] in ['ASTORE','ISTORE','LSTORE','FSTORE','DSTORE']}
  # Natural javac loops generally occupy nested intervals in classfile order.
  self.loops={}
  for p,i in enumerate(self.code):
   if 'target' in i and i['target']<=p:
    h=i['target'];self.loops[h]=max(p,self.loops.get(h,-1))
  self.loop_active=[];self.switch_active=[];self.synchronized_handlers=set();self.try_active=set();self.try_regions={}
  byhandler=collections.defaultdict(list)
  for h in m['handlers']:
   if h['type'] is not None:byhandler[h['handler']].append(h)
  for h,regions in byhandler.items():
   start=min(r['start'] for r in regions);last=h-1
   # Normal javac catch patterns jump over their handler or return before it.
   normal_end=h;join=len(self.code)
   if self.code[last]['op']=='GOTO' and self.code[last]['target']>h:
    normal_end=last;join=self.code[last]['target']
   self.try_regions[start]={'start':start,'normal_end':normal_end,'handler':h,'join':join,'types':list(dict.fromkeys(r['type'] for r in regions)),'regions':regions}

  # Postdominators identify real joins even for short-circuit boolean graphs.
  n=len(self.code); universe=(1<<(n+1))-1
  succ=[]
  for ix,ins in enumerate(self.code):
   op=ins['op']
   if op in ('RETURN','IRETURN','LRETURN','FRETURN','DRETURN','ARETURN','ATHROW'):ss=[n]
   elif op=='GOTO':ss=[ins['target']]
   elif op.startswith('IF'):ss=[ix+1,ins['target']]
   elif op in ('TABLESWITCH','LOOKUPSWITCH'):ss=[ins['default']]+ins['targets']
   else:ss=[ix+1]
   succ.append(ss)
  pd=[universe]*n+[1<<n]
  for iteration in range(n+2):
   changed=False
   for ix in range(n-1,-1,-1):
    common=universe
    for target in succ[ix]:common&=pd[target]
    value=(1<<ix)|common
    if value!=pd[ix]:pd[ix]=value;changed=True
   if not changed:break
  counts=[x.bit_count() for x in pd];self.ipd={}
  for ix in range(n):
   bits=pd[ix]&~(1<<ix);candidates=[]
   while bits:
    low=bits&-bits;candidates.append(low.bit_length()-1);bits-=low
   self.ipd[ix]=max(candidates,key=lambda j:counts[j]) if candidates else n
 def tmp(self,typ='I',prefix='value'):
  self.tempn+=1;n=prefix+str(self.tempn);self.declarations[n]=typ;return E(n,typ,'local')
 def local(self,slot,cat,write=False):
  key=(slot,cat);param=self.params.get(key)
  if param and (key not in self.assigned or param[0]!='this' and (cat!='A' or assignable(self.var_types.get(key,param[1]),param[1]))):return E(param[0],param[1],'local')
  typ=self.var_types.get(key,'Ljava/lang/Object;' if cat=='A' else cat)
  name=('reference' if cat=='A' else {'I':'integer','F':'floating','D':'number','J':'longValue'}.get(cat,'local'))+str(slot)
  self.declarations[name]=typ
  return E(name,typ,'local')
 def pop(self,st):
  if not st:raise ReconstructionError('operand stack underflow')
  return st.pop()
 def freeze(self,st,lines):
  # Preserve evaluation order for expressions that survive a side-effecting statement.
  done={}
  for k,e in enumerate(st):
   if e.kind in ('local','const') or e.kind=='new' and e.data.get('args') is None or e.kind=='array':continue
   sig=id(e)
   if sig not in done:
    t=self.tmp(e.typ,'saved');lines.append(t.text+' = '+e.render()+';');done[sig]=t
   st[k]=done[sig]
 def emit(self,lines,line,st):self.freeze(st,lines);lines.append(line)
 def step(self,p,st,lines):
  i=self.code[p];op=i['op'];self.used.add(p)
  if op=='ACONST_NULL':st.append(E('null','null','const',None))
  elif op.startswith('ICONST_'):v=-1 if op=='ICONST_M1' else int(op[-1]);st.append(jliteral(v))
  elif op.startswith(('LCONST_','FCONST_','DCONST_')):st.append(jliteral(float(op[-1]) if op[0] in 'FD' else int(op[-1]),{'L':'Long','F':'Float','D':'Double'}[op[0]]))
  elif op in ('BIPUSH','SIPUSH'):st.append(jliteral(i['operand']))
  elif op=='LDC':st.append(jliteral(i['value'],i['valueType']))
  elif op in ('ALOAD','ILOAD','LLOAD','FLOAD','DLOAD'):st.append(self.local(i['var'],op[0]))
  elif op in ('ASTORE','ISTORE','LSTORE','FSTORE','DSTORE'):
   e=self.pop(st);v=self.local(i['var'],op[0],True)
   for k,held in enumerate(st):
    if held.kind=='local' and held.text==v.text:
     snap=self.tmp(held.typ,'previous');lines.append(snap.text+' = '+held.render()+';');st[k]=snap
   self.emit(lines,v.text+' = '+as_type(e,v.typ)+';',st)
  elif op=='IINC':
   v=self.local(i['var'],'I');self.emit(lines,v.text+('++;' if i['inc']==1 else '--;' if i['inc']==-1 else ' += '+str(i['inc'])+';'),st)
  elif op=='GETSTATIC':
   st.append(E(typename(i['owner'])+'.'+fieldname(i['owner'],i['name'],i.get('desc')),i['desc'],'field'))
  elif op=='GETFIELD':
   obj=self.pop(st);r=as_type(obj,'L'+i['owner']+';');st.append(E(r+'.'+fieldname(i['owner'],i['name'],i.get('desc')),i['desc'],'field'))
  elif op in ('PUTFIELD','PUTSTATIC'):
   v=self.pop(st)
   if op=='PUTFIELD':obj=self.pop(st);base=as_type(obj,'L'+i['owner']+';')
   else:base=typename(i['owner'])
   lhs=fieldname(i['owner'],i['name'],i.get('desc')) if op=='PUTSTATIC' and i['owner']==self.c['name'] and self.m['name']=='<clinit>' else base+'.'+fieldname(i['owner'],i['name'],i.get('desc'))
   self.emit(lines,lhs+' = '+as_type(v,i['desc'])+';',st)
  elif op=='NEW':st.append(E('', 'L'+i['type']+';','new',{'args':None,'pc':p}))
  elif op=='DUP':
   if st[-1].kind not in ('new','array') or st[-1].kind=='new' and st[-1].data.get('args') is not None:self.freeze(st,lines)
   st.append(st[-1])
  elif op=='DUP_X1':
   self.freeze(st,lines);a=self.pop(st);b=self.pop(st);st.extend([a,b,a])
  elif op=='DUP2':
   self.freeze(st,lines)
   if st[-1].typ in ('J','D'):st.append(st[-1])
   else:st.extend(st[-2:])
  elif op=='POP':
   e=self.pop(st)
   if e.kind not in ('const','local'):
    # A non-call expression cannot appear as a Java statement.
    s=e.render()
    if e.kind in ('call','new'):self.emit(lines,s+';',st)
    else:v=self.tmp(e.typ,'discarded');self.emit(lines,v.text+' = '+s+';',st)
  elif op=='CHECKCAST':
   e=self.pop(st);typ=i['type'] if i['type'].startswith('[') else 'L'+i['type']+';';st.append(E('(('+typename(typ)+') '+('' if e.typ=='Ljava/lang/Object;' else '(Object) ')+e.render()+')',typ,'cast'))
  elif op=='INSTANCEOF':e=self.pop(st);st.append(E('('+e.render()+' instanceof '+typename(i['type'])+')','Z'))
  elif op in ('ANEWARRAY','NEWARRAY'):
   size=self.pop(st);elem=('L'+i['type']+';' if not i.get('type','').startswith('[') else i['type']) if op=='ANEWARRAY' else {4:'Z',5:'C',6:'F',7:'D',8:'B',9:'S',10:'I',11:'J'}[i['operand']]
   st.append(E('', '['+elem,'array',{'size':size.data if size.kind=='const' else size.render(),'values':{}}))
  elif op=='ARRAYLENGTH':
   e=self.pop(st);ft=i['frame']['stack'][-1]
   if ft and ft.startswith('['):text=as_type(e,ft)+'.length'
   elif e.typ.startswith('['):text=e.render()+'.length'
   else:text='java.lang.reflect.Array.getLength('+e.render()+')'
   st.append(E(text,'I'))
  elif op in ('AALOAD','IALOAD','LALOAD','FALOAD','DALOAD','BALOAD','CALOAD','SALOAD'):
   index=self.pop(st);arr=self.pop(st);ft=i['frame']['stack'][-2]
   at=ft if ft and ft.startswith('[') else arr.typ if arr.typ.startswith('[') else ('[Ljava/lang/Object;' if op=='AALOAD' else '['+op[0])
   typ=at[1:];st.append(E(as_type(arr,at)+'['+index.render()+']',typ,'field'))
  elif op in ('AASTORE','IASTORE','LASTORE','FASTORE','DASTORE','BASTORE','CASTORE','SASTORE'):
   v=self.pop(st);index=self.pop(st);arr=self.pop(st);ft=i['frame']['stack'][-3]
   at=ft if ft and ft.startswith('[') else arr.typ if arr.typ.startswith('[') else ('[Ljava/lang/Object;' if op=='AASTORE' else '['+op[0]);elem=at[1:]
   if arr.kind=='array' and index.kind=='const':arr.data['values'][int(index.data)]=as_type(v,elem)
   else:self.emit(lines,as_type(arr,at)+'['+index.render()+'] = '+as_type(v,elem)+';',st)
  elif op in ('LCMP','FCMPL','FCMPG','DCMPL','DCMPG'):
   b=self.pop(st);a=self.pop(st);st.append(E('cryptix.recovery.JvmSupport.'+op.lower()+'('+a.render()+', '+b.render()+')','I','compare',(a,b,op)))
  elif op in ('IADD','ISUB','IMUL','IDIV','IREM','IAND','IOR','IXOR','ISHL','ISHR','IUSHR','LADD','LSUB','LMUL','LDIV','LREM','LAND','LOR','LXOR','LSHL','LSHR','LUSHR','FADD','FSUB','FMUL','FDIV','FREM','DADD','DSUB','DMUL','DDIV','DREM'):
   b=self.pop(st);a=self.pop(st);sign={'ADD':'+','SUB':'-','MUL':'*','DIV':'/','REM':'%','AND':'&','OR':'|','XOR':'^','SHL':'<<','SHR':'>>','USHR':'>>>'}[op[1:]]
   st.append(E('('+as_type(a,op[0])+' '+sign+' '+as_type(b,'I' if op[1:] in ('SHL','SHR','USHR') else op[0])+')',op[0]))
  elif op in ('INEG','LNEG','FNEG','DNEG'):e=self.pop(st);st.append(E('(-'+e.render()+')',op[0]))
  elif re.fullmatch('[ILFD]2[ILFDBCS]',op):e=self.pop(st);st.append(E('(('+typename(op[2])+') '+e.render()+')',op[2]))
  elif op in ('INVOKESTATIC','INVOKEVIRTUAL','INVOKESPECIAL','INVOKEINTERFACE'):
   ats,ret=method_types(i['desc']);args=[self.pop(st) for _ in ats][::-1];argstr=[as_type(e,t) for e,t in zip(args,ats)]
   obj=None if op=='INVOKESTATIC' else self.pop(st)
   if i['name']=='<init>':
    if obj.kind=='new':
     obj.data['args']=argstr
     if not any(e is obj for e in st):self.emit(lines,obj.render()+';',st)
    elif obj.text in ('this','reference0') and self.m['name']=='<init>':
     if i['owner']==self.c['name']:lines.append('this('+', '.join(argstr)+');')
     elif i['owner'] not in ('java/lang/Object','java/lang/Record'):lines.append('super('+', '.join(argstr)+');')
    else:raise ReconstructionError('Unexpected constructor receiver '+obj.render())
   else:
    name=methodname(i['owner'],i['name'])
    if op=='INVOKESTATIC':base=typename(i['owner'])
    elif op=='INVOKESPECIAL' and obj.text=='this' and i['owner']!=self.c['name']:base='super'
    else:base=as_type(obj,i['owner'] if i['owner'].startswith('[') else 'L'+i['owner']+';')
    ex=E(base+'.'+name+'('+', '.join(argstr)+')',ret,'call')
    if ret=='V':self.emit(lines,ex.render()+';',st)
    else:st.append(ex)
  elif op=='INVOKEDYNAMIC':
   ats,ret=method_types(i['desc']);args=[self.pop(st) for _ in ats][::-1];bs=i['bootstrap'];owner=bs['owner']
   if owner=='java/lang/invoke/StringConcatFactory':
    recipe=i['args'][0] if i['args'] else '\x01'*len(args);chunks=[];part='';ai=0;ci=1
    for ch in recipe:
     if ch in ('\x01','\x02'):
      if part:chunks.append(quote(part));part=''
      if ch=='\x01':chunks.append(args[ai].render());ai+=1
      else:chunks.append(quote(str(i['args'][ci])));ci+=1
     else:part+=ch
    if part:chunks.append(quote(part))
    if not chunks:chunks=['""']
    elif not chunks[0].startswith('"'):chunks.insert(0,'""')
    st.append(E('('+' + '.join(chunks)+')','Ljava/lang/String;'))
   elif owner=='java/lang/invoke/LambdaMetafactory':
    # Evaluate captures now and bind immutable snapshots, as invokedynamic does.
    captured=[]
    for value,expected in zip(args,ats):
     self.tempn+=1;name='captured'+str(self.tempn)
     self.emit(lines,'final '+typename(expected)+' '+name+' = '+as_type(value,expected)+';',st)
     captured.append(E(name,expected,'local'))
    args=captured
    handle=i['args'][1];sam=i['args'][2]['type'];pars,_=method_types(sam);names=['lambdaArg'+str(k) for k in range(len(pars))]
    # Raw SAM targets erase reference parameters to Object. Cast to the implementation descriptor.
    hargs,hret=method_types(handle['desc'])
    values=list(args)+[E(n,'Ljava/lang/Object;' if ref(t) else t,'local') for n,t in zip(names,pars)]
    if handle['handle'] not in (6,8):
     receiver=values.pop(0);base=as_type(receiver,'L'+handle['owner']+';')
    castvalues=[as_type(v,t) for v,t in zip(values,hargs)]
    if handle['handle']==6:call=typename(handle['owner'])+'.'+methodname(handle['owner'],handle['name'])+'('+', '.join(castvalues)+')'
    elif handle['handle']==8:call='new '+typename(handle['owner'])+'('+', '.join(castvalues)+')'
    else:call=base+'.'+methodname(handle['owner'],handle['name'])+'('+', '.join(castvalues)+')'
    st.append(E('('+', '.join(names)+') -> '+call,ret,'lambda'))
   elif owner=='java/lang/runtime/ObjectMethods':
    fs=[f for f in self.c['fields'] if not f['access']&8]
    receiver=as_type(args[0],'L'+self.c['name']+';')
    accesses=[receiver+'.'+fieldname(self.c['name'],f['name']) for f in fs]
    if i['name']=='toString':
     names=i['args'][1].split(';');chunks=[quote(self.c['name'].split('/')[-1]+'[')]
     for k,(nm,v) in enumerate(zip(names,accesses)):chunks.extend([quote((', ' if k else '')+nm+'='),v])
     chunks.append(quote(']'));st.append(E('('+' + '.join(chunks)+')','Ljava/lang/String;'))
    elif i['name']=='hashCode':
     expr='0'
     for f,v in zip(fs,accesses):
      hashed=v if f['desc']=='I' else 'java.util.Objects.hashCode('+v+')'
      expr='(31 * '+expr+' + '+hashed+')'
     st.append(E(expr,'I'))
    elif i['name']=='equals':
     other=args[1].render();cls=typename(self.c['name']);tests=[]
     for f,v in zip(fs,accesses):
      rhs='(('+cls+') '+other+').'+fieldname(self.c['name'],f['name'])
      tests.append('java.util.Objects.equals('+v+', '+rhs+')' if ref(f['desc']) else '('+v+' == '+rhs+')')
     st.append(E('('+receiver+' == '+other+' || ('+other+' instanceof '+cls+' && '+' && '.join(tests)+'))','Z'))
    else:raise ReconstructionError('Unknown record operation')
   else:raise ReconstructionError('Unsupported invokedynamic bootstrap '+owner)
  elif op in ('MONITORENTER','MONITOREXIT'):raise ReconstructionError('Monitor region requires synchronized reconstruction')
  elif op=='NOP':pass
  else:raise ReconstructionError('Unsupported instruction '+op)
 def branch_condition(self,p,st):
  i=self.code[p];op=i['op'];self.used.add(p)
  if op in ('IFNULL','IFNONNULL'):
   e=self.pop(st);return '('+e.render()+(' == null)' if op=='IFNULL' else ' != null)')
  if op.startswith('IF_ICMP') or op.startswith('IF_ACMP'):
   b=self.pop(st);a=self.pop(st);rel={'EQ':'==','NE':'!=','LT':'<','LE':'<=','GT':'>','GE':'>='}[op[-2:]]
   if op.startswith('IF_ICMP') and a.typ=='Z' and b.typ!='Z':a=E(as_type(a,'I'),'I')
   if op.startswith('IF_ICMP') and b.typ=='Z' and a.typ!='Z':b=E(as_type(b,'I'),'I')
   return '('+a.render()+' '+rel+' '+b.render()+')'
  return comparison(self.pop(st),op)
 def merge(self,cond,a,b,la,lb,alivea,aliveb):
  if not alivea:return b
  if not aliveb:return a
  if len(a)!=len(b):raise ReconstructionError('Inconsistent stack sizes at join')
  result=[]
  for x,y in zip(a,b):
   if x.signature()==y.signature():result.append(x);continue
   typ=x.typ if x.typ==y.typ else y.typ if x.typ=='null' else x.typ if y.typ=='null' else 'Ljava/lang/Object;' if ref(x.typ) and ref(y.typ) else 'I' if {x.typ,y.typ}<={'Z','I'} else x.typ
   if not la and not lb:result.append(E('('+cond+' ? '+as_type(x,typ)+' : '+as_type(y,typ)+')',typ))
   else:
    v=self.tmp(typ,'branchValue');la.append(v.text+' = '+as_type(x,typ)+';');lb.append(v.text+' = '+as_type(y,typ)+';');result.append(v)
  return result
 def transfer(self,target,st,lines):
  if target in self.switch_active:
   lines.append('break switch'+str(target)+';');return False
  for h,last in reversed(self.loop_active):
   if target==h:lines.append('continue loop'+str(h)+';');return False
   if target==last+1 or target>last:
    # Select innermost enclosing loop whose next instruction is the target.
    exact=next(((a,b) for a,b in reversed(self.loop_active) if target==b+1),None)
    if exact:lines.append('break loop'+str(exact[0])+';');return False
  for h,last in reversed(self.loop_active):
   if h < target <= last and self.code[last]['op']=='GOTO' and self.code[last]['target']==h:
    tail=self.code[target:last]
    if all(not ins['op'].startswith('IF') and ins['op'] not in ('GOTO','TABLESWITCH','LOOKUPSWITCH','RETURN','ARETURN','IRETURN','LRETURN','DRETURN','FRETURN','ATHROW') for ins in tail):
     for pc in range(target,last):self.step(pc,st,lines)
     self.used.add(last);lines.append('continue loop'+str(h)+';');return False
  raise ReconstructionError('Non-structured transfer to '+str(target))
 def region(self,start,end,stack=None,suppress_loop=None):
  self.depth+=1
  if self.depth>100:raise ReconstructionError('Region recursion limit')
  st=list(stack or []);lines=[];p=start;alive=True
  try:
   while p<end:
    i=self.code[p];op=i['op']
    if i.get('frame') is None:
     self.structural.add(p);p+=1;continue
    if p in self.try_regions and p not in self.try_active:
     tr=self.try_regions[p];h=tr['handler'];join=tr['join'];ne=tr['normal_end']
     if join>end:raise ReconstructionError('Exception region crosses structured boundary')
     self.try_active.add(p)
     try:
      lb,sb,ab=self.region(p,ne,st)
      if ne!=h:self.structural.add(ne)
      self.tempn+=1;cn='caught'+str(self.tempn);ct='L'+tr['types'][0]+';'
      lh,sh,ah=self.region(h,join,[E(cn,ct,'local')])
     finally:self.try_active.remove(p)
     merged=self.merge('true',sb,sh,lb,lh,ab,ah)
     lines+=['try {']+['    '+x for x in lb]+['} catch ('+' | '.join(typename(t) for t in tr['types'])+' '+cn+') {']+['    '+x for x in lh]+['}']
     p=join;st=merged;alive=ab or ah
     if not alive:return lines,st,False
     continue
    if p in self.loops and p!=suppress_loop and self.loops[p]<end:
     last=self.loops[p];self.loop_active.append((p,last));body,sb,ab=self.region(p,last+1,st,p);self.loop_active.pop()
     if any(e.kind not in ('const','local') for e in st):raise ReconstructionError('Non-local operand stack across loop')
     lines+=['loop'+str(p)+': while (true) {']+['    '+s for s in body]+['}'];p=last+1;continue
    if op.startswith('IF'):
     self.freeze(st,lines);cond=self.branch_condition(p,st);target=i['target'];fall=p+1
     self.freeze(st,lines)
     if target<=p or target>end:
      branch=[];self.transfer(target,st,branch);lines+=['if ('+cond+') {']+['    '+s for s in branch]+['}'];p+=1;continue
     if target==end and self.loop_active and end==self.loop_active[-1][1]+1:
      lines+=['if ('+cond+') {','    break loop'+str(self.loop_active[-1][0])+';','}'];p+=1;continue
     # Use the true postdominating join, not just the nearest forward label.
     join=self.ipd.get(p,end)
     if join>target and join<=end and join>p:
      la,sa,aa=self.region(fall,join,st);lb,sb,ab=self.region(target,join,st)
      fc=negate(cond);merged=self.merge(fc,sa,sb,la,lb,aa,ab)
      if la or lb:
       lines+=['if ('+fc+') {']+['    '+s for s in la]+['} else {']+['    '+s for s in lb]+['}']
      st=merged;alive=aa or ab;p=join
      if not alive:return lines,st,False
     else:
      la,sa,aa=self.region(fall,target,st);lb=[];sb=list(st);fc=negate(cond)
      st=self.merge(fc,sa,sb,la,lb,aa,True)
      if la or lb:
       if not lb:lines+=['if ('+fc+') {']+['    '+s for s in la]+['}']
       else:lines+=['if ('+fc+') {']+['    '+s for s in la]+['} else {']+['    '+s for s in lb]+['}']
      p=target
     continue
    if op=='GOTO':
     self.used.add(p);target=i['target']
     if target==end:
      if any(target==last+1 for h,last in self.loop_active):return lines,st,self.transfer(target,st,lines)
      return lines,st,True
     if target>p and target<end:
      # Skipped code must belong to an alternative that another recursive region consumes.
      p=target;continue
     return lines,st,self.transfer(target,st,lines)
    if op in ('TABLESWITCH','LOOKUPSWITCH'):
     self.used.add(p);selector=self.pop(st);self.freeze(st,lines);join=min(self.ipd.get(p,end),end)
     if join<=p:raise ReconstructionError('Switch has backward join')
     groups=collections.OrderedDict()
     for key,target in zip(i.get('keys',list(range(i.get('min',0),i.get('max',-1)+1))),i['targets']):groups.setdefault(target,[]).append('case '+str(key)+':')
     groups.setdefault(i['default'],[]).append('default:')
     outcomes=[]
     for target,labels in groups.items():
      if target>join:raise ReconstructionError('Switch target beyond region')
      # A case reaching join exits the Java switch normally.
      ls,ss,aa=self.region(target,join,st)
      outcomes.append([labels,ls,ss,aa])
     live=[o for o in outcomes if o[3]]
     merged=list(st)
     if live:
      stacks=[o[2] for o in live]
      if any(len(x)!=len(stacks[0]) for x in stacks):raise ReconstructionError('Switch stack-height mismatch')
      merged=[]
      for k in range(len(stacks[0])):
       es=[x[k] for x in stacks]
       if all(e.signature()==es[0].signature() for e in es):merged.append(es[0]);continue
       typ=es[0].typ if all(e.typ==es[0].typ for e in es) else 'Ljava/lang/Object;' if all(ref(e.typ) for e in es) else 'I'
       tmp=self.tmp(typ,'switchValue');merged.append(tmp)
       for o in live:o[1].append(tmp.text+' = '+as_type(o[2][k],typ)+';')
     lines.append('switch ('+selector.render()+') {')
     for labels,ls,ss,aa in outcomes:
      lines += ['    '+s for s in labels]+['    {']+['        '+s for s in ls]+(['        break;'] if aa else [])+['    }']
     lines.append('}');st=merged;p=join;alive=bool(live)
     if not alive:return lines,st,False
     continue
    if op=='MONITORENTER':
     self.used.add(p);monitor=self.pop(st);self.freeze(st,lines)
     h=next((h for h in self.m['handlers'] if h['start']==p+1 and h['type'] is None),None)
     if not h:raise ReconstructionError('Unknown monitor protection pattern')
     e=h['end'];handler=h['handler']
     if self.code[e-1]['op']!='MONITOREXIT' or self.code[e-2]['op']!='ALOAD' or self.code[e]['op']!='GOTO':raise ReconstructionError('Non-canonical synchronized exit')
     join=self.code[e]['target']
     if self.code[join-1]['op']!='ATHROW':raise ReconstructionError('Non-canonical synchronized handler')
     body,ss,aa=self.region(p+1,e-2,st)
     self.structural.update(range(e-2,join));self.synchronized_handlers.add(handler)
     lines+=['synchronized ('+monitor.render()+') {']+['    '+x for x in body]+['}'];st=ss;p=join;alive=aa
     continue
    if op in ('RETURN','IRETURN','LRETURN','FRETURN','DRETURN','ARETURN','ATHROW'):
     self.used.add(p)
     if op=='RETURN':line='return;'
     elif op=='ATHROW':line='throw cryptix.recovery.JvmSupport.rethrow('+as_type(self.pop(st),'Ljava/lang/Throwable;')+');'
     else:line='return '+as_type(self.pop(st),self.ret)+';'
     self.emit(lines,line,st);return lines,st,False
    self.step(p,st,lines);p+=1
   return lines,st,alive
  finally:self.depth-=1
 def reconstruct(self):
  # Recover direct accessors without retaining the obfuscator's return-slot shuffle.
  fields=[i for i in self.code if i['op'] in ('GETFIELD','GETSTATIC','PUTFIELD','PUTSTATIC')]
  allowed={'ALOAD','ASTORE','ILOAD','ISTORE','LLOAD','LSTORE','FLOAD','FSTORE','DLOAD','DSTORE','GETFIELD','GETSTATIC','PUTFIELD','PUTSTATIC','RETURN','ARETURN','IRETURN','LRETURN','FRETURN','DRETURN'}
  if len(fields)==1 and not self.m['handlers'] and all(i['op'] in allowed for i in self.code):
   f=fields[0];base=typename(f['owner']) if f['op'].endswith('STATIC') else 'this';name=fieldname(f['owner'],f['name'],f['desc'])
   if not self.argtypes and self.ret==f['desc'] and f['op'] in ('GETFIELD','GETSTATIC'):
    self.used.update(range(len(self.code)));return [],['return '+base+'.'+name+';']
   if len(self.argtypes)==1 and self.ret=='V' and self.argtypes[0]==f['desc'] and f['op'] in ('PUTFIELD','PUTSTATIC') and self.m['name']!='<init>':
    param=self.paramdecl[0].rsplit(' ',1)[-1];self.used.update(range(len(self.code)));return [],[base+'.'+name+' = '+param+';']
  if self.c['name']=='native0/Loader' and self.m['name']=='<clinit>':
   self.used.update(range(len(self.code)))
   return [],(ROOT/'tools/native_loader_body.java.txt').read_text().splitlines()
  if self.c['name']=='a/dp' and self.m['name']=='m39':
   self.used.update(range(len(self.code)));owner=typename('a/dp');resolve=methodname('a/dp','m34');gson=fieldname('a/dp','f919')
   return [],[f'try (java.io.FileWriter writer = new java.io.FileWriter({owner}.{resolve}(arg0))) {{',f'    {owner}.{gson}.toJson(arg1, writer);','} catch (java.io.IOException exception) {','    exception.printStackTrace();','}']
  if self.c['name']=='a/os' and self.m['name']=='m29':
   owner=typename('a/os');enabled=fieldname('a/os','f905');flushing=fieldname('a/os','f906');queue=fieldname('a/os','f904')
   self.used.update(range(len(self.code)))
   return [],[f'if (!{owner}.{enabled} || {owner}.{flushing}) {{','    return false;','}',f'synchronized ({owner}.{queue}) {{',f'    {owner}.{queue}.add(arg0);','    return true;','}']
  if self.c['name']=='a/dp' and self.m['name']=='m40':
   owner=typename('a/dp');resolve=methodname('a/dp','m34')
   self.used.update(range(len(self.code)))
   return [],[f'java.io.File file = {owner}.{resolve}(arg0);','if (!file.exists()) {','    return new com.google.gson.JsonObject();','}','try (java.io.FileReader reader = new java.io.FileReader(file)) {','    return com.google.gson.JsonParser.parseReader(reader).getAsJsonObject();','} catch (java.lang.Exception exception) {','    exception.printStackTrace();','    return new com.google.gson.JsonObject();','}']
  if self.m['access']&(256|1024):return [],[]
  # Exception regions are emitted at their protected entry points.
  body,st,alive=self.region(0,len(self.code))
  missed=[p for p,i in enumerate(self.code) if i.get('frame') is not None and p not in self.used and p not in self.structural]
  if missed:raise ReconstructionError('Uncovered instructions: '+str(missed[:20]))
  if alive and self.ret!='V':raise ReconstructionError('Non-void method has no terminal return')
  if self.ret=='V' and body and body[-1]=='return;':body.pop()
  decls=[]
  for name,t in self.declarations.items():
   initial=default(t)
   if name.startswith('reference'):
    key=(int(name[9:]),'A')
    if key in self.params and assignable(self.params[key][1],t):initial=self.params[key][0]
   decls.append(typename(t)+' '+name+' = '+initial+';')
  # Constructor delegation must precede declarations.
  if self.m['name']=='<init>' and body and body[0].startswith(('super(','this(')):
   body=[body[0]]+decls+body[1:];decls=[]
  return decls,body

def annotation_value(v):
 if isinstance(v,dict):
  if 'enumType' in v:return typename(v['enumType'])+'.'+v['enumName']
  if 'values' in v:return annotation(v)
  if 'type' in v:return typename(v['type'])+'.class'
 if isinstance(v,list):return '{'+', '.join(annotation_value(x) for x in v)+'}'
 if isinstance(v,str):return quote(v)
 if isinstance(v,bool):return str(v).lower()
 return str(v)
def annotation(a):
 vals=a.get('values',{})
 return '@'+typename(a['type'])+('('+', '.join(k+' = '+annotation_value(v) for k,v in vals.items())+')' if vals else '')
def modifiers(flags,kind='method'):
 vals=[]
 for bit,s in [(1,'public'),(4,'protected'),(2,'private'),(8,'static'),(16,'final')]:
  if flags&bit:vals.append(s)
 if kind=='method':
  if flags&32:vals.append('synchronized')
  if flags&256:vals.append('native')
  if flags&1024:vals.append('abstract')
 elif kind=='field':
  if flags&64:vals.append('volatile')
  if flags&128:vals.append('transient')
 return ' '.join(vals)

CROSS_ACCESS=set()
for source_class in CLASSES:
 for method in source_class['methods']:
  for ins in method['code']:
   if 'owner' not in ins or 'name' not in ins or 'desc' not in ins:continue
   member_kind='fields' if ins['op'] in ('GETFIELD','GETSTATIC','PUTFIELD','PUTSTATIC') else 'methods'
   for owner in ancestors(ins['owner']):
    declaring=BYNAME.get(owner)
    if not declaring:continue
    member=next((m for m in declaring[member_kind] if m['name']==ins['name'] and m['desc']==ins['desc']),None)
    if member is not None:
     if owner!=source_class['name'] and not member['access']&1:CROSS_ACCESS.add((owner,member['name'],member['desc']))
     break

def source_access(owner,member):
 flags=member['access']
 if (owner,member['name'],member['desc']) in CROSS_ACCESS:flags=(flags&~(2|4))|1
 return flags

def class_source(c,outdir,failures):
 name=CM[c['name']];package,short=name.rsplit('/',1);lines=['package '+package.replace('/','.')+';','','/**',' * Reconstructed from '+c['name']+'.class; descriptive names are inferred.',' * See recovery-manifest.json for method-level validation and unresolved regions.',' */']
 lines += [annotation(a) for a in c['annotations']]
 if c['name']=='a/ul':
  lines+=['public interface '+short+' {','    net.minecraft.client.Minecraft '+fieldname(c['name'],'f0')+' = net.minecraft.client.Minecraft.getInstance();','}']
  failures[c['name']+'.<clinit>()V']={'status':'reconstructed','instructions':3,'note':'Interface initializer expressed as field initializer.'}
  path=outdir/(name+'.java');path.parent.mkdir(parents=True,exist_ok=True);path.write_text('\n'.join(lines)+'\n');return
 if c['name']=='a/ll':
  for m in c['methods']:failures[c['name']+'.'+m['name']+m['desc']]={'status':'enum-synthesized','instructions':len(m['code']),'note':'Represented by a Java enum declaration; compiler supplies the corresponding methods.'}
  lines+=['public enum '+short+' {','    COMBAT, MOVEMENT, PLAYER, VISUAL, MISC;']
  for f in c['fields']:
   if f.get('decodedString') is not None:
    lines.append('    private static final String '+fieldname(c['name'],f['name'],f['desc'])+' = new String('+quote(f['decodedString'])+');')
  lines.append('}');path=outdir/(name+'.java');path.parent.mkdir(parents=True,exist_ok=True);path.write_text('\n'.join(lines)+'\n');return
 flags=c['access'];isinterface=bool(flags&512)
 declaration='public '+('abstract ' if flags&1024 and not isinterface else '')+('final ' if flags&16 and not isinterface else '')+('interface ' if isinterface else 'class ')+short
 if c['super'] and c['super'] not in ['java/lang/Object','java/lang/Record'] and not isinterface:declaration+=' extends '+typename(c['super'])
 if c['interfaces']:declaration+=(' extends ' if isinterface else ' implements ')+', '.join(typename(i) for i in c['interfaces'])
 lines.append(declaration+' {')
 assigned={ (i['owner'],i['name']) for m in c['methods'] for i in m['code'] if i['op'] in ('PUTSTATIC','PUTFIELD') }
 for f in c['fields']:
  if f['opaqueZero']:continue
  if c['name']=='a/ll' and f['access']&4096:continue
  for a in f['annotations']:lines.append('    '+annotation(a))
  decl='    '+modifiers(source_access(c['name'],f),'field')+' '+typename(f['desc'])+' '+fieldname(c['name'],f['name'],f['desc'])
  v=f['value']
  if v is not None and (c['name'],f['name']) not in assigned:decl+=' = '+as_type(jliteral(v,'String' if isinstance(v,str) else {'J':'Long','F':'Float','D':'Double'}.get(f['desc'],'Integer')),f['desc'])
  elif f['access']&16 and (c['name'],f['name']) not in assigned:decl+=' = '+default(f['desc'])
  lines.append(decl+';')
 for m in c['methods']:
  lines.append('')
  dc=MethodDecompiler(c,m);key=c['name']+'.'+m['name']+m['desc'];status='reconstructed'
  for a in m['annotations']:lines.append('    '+annotation(a))
  if m['name']=='<clinit>':head='static'
  else:
   head=modifiers(source_access(c['name'],m))+' '
   head+=(short if m['name']=='<init>' else typename(dc.ret)+' '+methodname(c['name'],m['name']))+'('+', '.join(dc.paramdecl)+')'
   if m['exceptions']:head+=' throws '+', '.join(typename(e) for e in m['exceptions'])
  if m['access']&(256|1024):
   lines.append('    '+head+';');failures[key]={'status':'native' if m['access']&256 else 'abstract','instructions':0};continue
  try:
   decl,body=dc.reconstruct();failures[key]={'status':'reconstructed','instructions':len(m['code']),'coveredInstructions':len(dc.used|dc.structural)}
   if m['name']=='<clinit>' and not decl and not body:lines.pop();continue
   lines.append('    '+head+' {')
   lines+=['        '+l for l in decl+body];lines.append('    }')
  except Exception as ex:
   failures[key]={'status':'unresolved','instructions':len(m['code']),'error':str(ex)}
   lines.append('    '+head+' {')
   # This is deliberately NOT presented as functional recovered code.
   lines.append('        // UNRESOLVED: '+str(ex).replace('\n',' ')[:300])
   if m['name']=='<clinit>':lines.append('        cryptix.recovery.JvmSupport.unresolved('+quote(key)+');')
   else:lines.append('        throw new UnsupportedOperationException('+quote('Unrecovered method: '+key)+');')
   lines.append('    }')
 lines.append('}')
 path=outdir/(name+'.java');path.parent.mkdir(parents=True,exist_ok=True);path.write_text('\n'.join(lines)+'\n')

def main():
 out=ROOT/'source';out.mkdir(exist_ok=True);failures={}
 for path in out.rglob('*.java'):path.unlink()
 for c in CLASSES:class_source(c,out,failures)
 support=out/'cryptix/recovery/JvmSupport.java';support.parent.mkdir(parents=True,exist_ok=True);support.write_text((ROOT/'tools/JvmSupport.java').read_text())
 (ROOT/'recovery-manifest.json').write_text(json.dumps(failures,indent=2))
 (ROOT/'mappings.json').write_text(json.dumps({'classes':CM,'fields':{k[0]+'.'+k[1]:v for k,v in FM.items()},'methods':{k[0]+'.'+k[1]:v for k,v in MM.items()},'modules':MODULES},indent=2))
 print(collections.Counter(v['status'] for v in failures.values()))
 mods={c['original'] for c in MODULES}
 print('MODULES',collections.Counter(v['status'] for k,v in failures.items() if k.split('.')[0] in mods))
 for k,v in failures.items():
  if v['status']=='unresolved':print(k,v['error'])
if __name__=='__main__':main()
