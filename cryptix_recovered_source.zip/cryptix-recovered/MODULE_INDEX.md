# Cryptix module source index

All 55 entries are direct subclasses of the original `a/le` module base. Categories follow the original constructors, even when a category looks unusual. All listed module methods have reconstructed bodies; none is replaced by an unresolved-method exception. Runtime equivalence is not certified.

## Combat — 8 modules

| Module | Original class | Methods | Java source |
|---|---|---:|---|
| AimAssist | `a/zb` | 5 | [AimAssist.java](source/cryptix/module/impl/combat/AimAssist.java) |
| AntiBot | `a/zs` | 4 | [AntiBot.java](source/cryptix/module/impl/combat/AntiBot.java) |
| AutoClicker | `a/ql` | 5 | [AutoClicker.java](source/cryptix/module/impl/combat/AutoClicker.java) |
| Criticals | `a/jo` | 5 | [Criticals.java](source/cryptix/module/impl/combat/Criticals.java) |
| KillAura | `a/wt` | 21 | [KillAura.java](source/cryptix/module/impl/combat/KillAura.java) |
| SprintReset | `a/rh` | 3 | [SprintReset.java](source/cryptix/module/impl/combat/SprintReset.java) |
| TriggerBot | `a/wh` | 3 | [TriggerBot.java](source/cryptix/module/impl/combat/TriggerBot.java) |
| Velocity | `a/na` | 7 | [Velocity.java](source/cryptix/module/impl/combat/Velocity.java) |

## Movement — 12 modules

| Module | Original class | Methods | Java source |
|---|---|---:|---|
| AntiSwim | `a/ct` | 2 | [AntiSwim.java](source/cryptix/module/impl/movement/AntiSwim.java) |
| AutoWalk | `a/qu` | 5 | [AutoWalk.java](source/cryptix/module/impl/movement/AutoWalk.java) |
| Flight | `a/si` | 3 | [Flight.java](source/cryptix/module/impl/movement/Flight.java) |
| InvMove | `a/qa` | 4 | [InvMove.java](source/cryptix/module/impl/movement/InvMove.java) |
| KeepSprint | `a/nx` | 3 | [KeepSprint.java](source/cryptix/module/impl/movement/KeepSprint.java) |
| LongJump | `a/ap` | 11 | [LongJump.java](source/cryptix/module/impl/movement/LongJump.java) |
| MoveFix | `a/uu` | 4 | [MoveFix.java](source/cryptix/module/impl/movement/MoveFix.java) |
| NoSlow | `a/va` | 3 | [NoSlow.java](source/cryptix/module/impl/movement/NoSlow.java) |
| Speed | `a/kd` | 4 | [Speed.java](source/cryptix/module/impl/movement/Speed.java) |
| Sprint | `a/ag` | 4 | [Sprint.java](source/cryptix/module/impl/movement/Sprint.java) |
| Stasis | `a/mx` | 5 | [Stasis.java](source/cryptix/module/impl/movement/Stasis.java) |
| Timer | `a/fl` | 4 | [Timer.java](source/cryptix/module/impl/movement/Timer.java) |

## Player — 13 modules

| Module | Original class | Methods | Java source |
|---|---|---:|---|
| AutoHead | `a/fm` | 3 | [AutoHead.java](source/cryptix/module/impl/player/AutoHead.java) |
| AutoTool | `a/sq` | 3 | [AutoTool.java](source/cryptix/module/impl/player/AutoTool.java) |
| Backtrack | `a/lk` | 4 | [Backtrack.java](source/cryptix/module/impl/player/Backtrack.java) |
| BedAura | `a/lx` | 13 | [BedAura.java](source/cryptix/module/impl/player/BedAura.java) |
| ChestStealer | `a/em` | 3 | [ChestStealer.java](source/cryptix/module/impl/player/ChestStealer.java) |
| Eagle | `a/dx` | 5 | [Eagle.java](source/cryptix/module/impl/player/Eagle.java) |
| FastMine | `a/vw` | 3 | [FastMine.java](source/cryptix/module/impl/player/FastMine.java) |
| FastPlace | `a/xi` | 3 | [FastPlace.java](source/cryptix/module/impl/player/FastPlace.java) |
| InvManager | `a/zf` | 13 | [InvManager.java](source/cryptix/module/impl/player/InvManager.java) |
| LagRange | `a/ho` | 7 | [LagRange.java](source/cryptix/module/impl/player/LagRange.java) |
| NoFall | `a/cs` | 3 | [NoFall.java](source/cryptix/module/impl/player/NoFall.java) |
| NoJumpDelay | `a/aj` | 3 | [NoJumpDelay.java](source/cryptix/module/impl/player/NoJumpDelay.java) |
| Scaffold | `a/wq` | 14 | [Scaffold.java](source/cryptix/module/impl/player/Scaffold.java) |

## Visual — 18 modules

| Module | Original class | Methods | Java source |
|---|---|---:|---|
| AutoBlockIn | `a/vv` | 4 | [AutoBlockIn.java](source/cryptix/module/impl/visual/AutoBlockIn.java) |
| Ambience | `a/to` | 4 | [Ambience.java](source/cryptix/module/impl/visual/Ambience.java) |
| Animations | `a/cw` | 2 | [Animations.java](source/cryptix/module/impl/visual/Animations.java) |
| AntiFire | `a/nz` | 2 | [AntiFire.java](source/cryptix/module/impl/visual/AntiFire.java) |
| BedPlates | `a/uk` | 3 | [BedPlates.java](source/cryptix/module/impl/visual/BedPlates.java) |
| BreakProgress | `a/zx` | 3 | [BreakProgress.java](source/cryptix/module/impl/visual/BreakProgress.java) |
| Cape | `a/ca` | 2 | [Cape.java](source/cryptix/module/impl/visual/Cape.java) |
| ClickGUI | `a/ln` | 3 | [ClickGUI.java](source/cryptix/module/impl/visual/ClickGUI.java) |
| FullBright | `a/vl` | 5 | [FullBright.java](source/cryptix/module/impl/visual/FullBright.java) |
| HUD | `a/vr` | 5 | [HUD.java](source/cryptix/module/impl/visual/HUD.java) |
| Hotbar | `a/bo` | 2 | [Hotbar.java](source/cryptix/module/impl/visual/Hotbar.java) |
| NameTags | `a/up` | 3 | [NameTags.java](source/cryptix/module/impl/visual/NameTags.java) |
| NoHurtCam | `a/ai` | 3 | [NoHurtCam.java](source/cryptix/module/impl/visual/NoHurtCam.java) |
| PlayerESP | `a/dn` | 6 | [PlayerESP.java](source/cryptix/module/impl/visual/PlayerESP.java) |
| Scoreboard | `a/xl` | 2 | [Scoreboard.java](source/cryptix/module/impl/visual/Scoreboard.java) |
| SessionInfo | `a/gh` | 4 | [SessionInfo.java](source/cryptix/module/impl/visual/SessionInfo.java) |
| TargetHUD | `a/xz` | 12 | [TargetHUD.java](source/cryptix/module/impl/visual/TargetHUD.java) |
| Theme | `a/dq` | 2 | [Theme.java](source/cryptix/module/impl/visual/Theme.java) |

## Misc — 4 modules

| Module | Original class | Methods | Java source |
|---|---|---:|---|
| AutoGG | `a/aw` | 3 | [AutoGG.java](source/cryptix/module/impl/misc/AutoGG.java) |
| Disabler | `a/oj` | 3 | [Disabler.java](source/cryptix/module/impl/misc/Disabler.java) |
| Whitelist | `a/tc` | 3 | [Whitelist.java](source/cryptix/module/impl/misc/Whitelist.java) |
| WindCharge | `a/ek` | 6 | [WindCharge.java](source/cryptix/module/impl/misc/WindCharge.java) |
