# Cryptix — reconstructed Java source

**Start with [MODULE_INDEX.md](MODULE_INDEX.md).** All 55 module classes are under `source/cryptix/module/impl/`.

This is a source-recovery package, not a verified replacement client. All 264 module methods have reconstructed bodies. The entire Java class inventory is represented, but native implementations remain native, and actual Minecraft/DLL behavior has not been tested. See [RECOVERY_REPORT.md](RECOVERY_REPORT.md) before treating the source as functionally identical.

## Contents

| Location | Contents |
|---|---|
| `source/` | 151 reconstructed classes plus `JvmSupport`; modules, mixins, GUI, settings, events, config, and native declarations |
| `MODULE_INDEX.md` | Direct links to all 55 modules and their original names |
| `mappings.json`, `symbols.tsv` | Readable-to-original class/member mappings |
| `recovery-manifest.json` | Original method signatures and recovery coverage |
| `normalized/` | Decoded strings, typed normalized bytecode, and transformation counts |
| `audit/` | Original Java class bytes and original classfile inventory |
| `original-resources/` | Original Fabric/mixin metadata and image assets; DLL omitted |
| `tools/` | Reproducible static normalizer/reconstructor, syntax checker, and optional JVM-symbol restorer |
| `validation/` | Compiler logs, explicitly nonfunctional API fixtures, and synthetic differential tests |

## Reading and rerunning

The already generated source can be opened in any Java editor. It does not need to be regenerated just to read or port a module.

The static tools were exercised with Python 3 and JDK 21. From this directory, the following regenerates the normalized analysis and readable source from the original JAR:

```sh
bash tools/run-normalizer.sh /path/to/cryptix.jar normalized
python tools/recover_source.py
python tools/beautify_source.py
python tools/write_symbol_map.py
```

These commands overwrite generated analysis/source inside this package, not the input JAR. The normalizer will also create a transformed `normalized.jar`; that is an analysis artifact, **not a verified mod to install**. The delivered archive omits that large generated JAR and the DLL.

The supplied client's own metadata requires Java 25 and the matching Minecraft/Fabric environment. Passing the package's JDK 21 fixture check does not override those requirements.

## Optional original-symbol restoration

When compiling with real dependencies, JVM names may need to be restored for the original resources/native code. After compilation, an optional static utility is available:

```sh
bash tools/restore-symbols.sh symbols.tsv /path/to/compiled/classes /path/to/separate/restored/classes
```

It handles known class/member renames and the native field-name collision. It deliberately excludes unrelated dependency classes and compile-only API fixtures. It does not supply real dependencies, reconstruct the DLL, validate native authentication, restore all metadata, or guarantee a working client. Use the original metadata only with appropriately restored symbols; the supplied original entrypoint and mixin names do not directly name the readable packages.

## Validation fixtures are not product code

`validation/api-signatures/` is for compiler checks only. Its methods intentionally throw assertion errors. Do not include this directory or its compiled output in a runtime classpath or mod. The native Hidden0 fixture is only a declaration aid, not a working bridge or a replacement for the original native implementation.
