package native0;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Reconstructed from native0/Loader.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Loader {

    public Loader() {
    }

    public static native void registerNativesForClass(int arg0, Class arg1);

    static {
        String os = System.getProperty("os.name").toLowerCase();
        String architecture = System.getProperty("os.arch").toLowerCase();
        String platform;
        switch (architecture) {
            case "x86_64": case "amd64": platform = "x64"; break;
            case "aarch64": platform = "arm64"; break;
            case "arm": platform = "arm32"; break;
            case "x86": platform = "x86"; break;
            default: platform = "raw" + architecture;
        }
        String extension;
        if (os.contains("nix") || os.contains("nux") || os.contains("aix")) {
            extension = "linux.so";
        } else if (os.contains("win")) {
            extension = "windows.dll";
        } else if (os.contains("mac")) {
            extension = "macos.dylib";
        } else {
            extension = "raw" + os;
        }
        String resource = String.format("/%s/%s-%s", Loader.class.getName().split("\\.")[0], platform, extension);
        File temporaryLibrary;
        try {
            temporaryLibrary = File.createTempFile("lib", null);
            temporaryLibrary.deleteOnExit();
            if (!temporaryLibrary.exists()) {
                throw new IOException();
            }
        } catch (IOException exception) {
            throw new UnsatisfiedLinkError("Failed to create temp file");
        }
        byte[] buffer = new byte[2048];
        try (InputStream input = Loader.class.getResourceAsStream(resource)) {
            if (input == null) {
                throw new UnsatisfiedLinkError(String.format("Failed to open lib file: %s", resource));
            }
            try (FileOutputStream output = new FileOutputStream(temporaryLibrary)) {
                int count;
                while ((count = input.read(buffer)) != -1) {
                    output.write(buffer, 0, count);
                }
            }
        } catch (IOException exception) {
            throw new UnsatisfiedLinkError(String.format("Failed to copy file: %s", exception.getMessage()));
        }
        System.load(temporaryLibrary.getAbsolutePath());
    }
}
