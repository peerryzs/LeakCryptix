package cryptix;

import cryptix.command.CommandManager;
import cryptix.config.ConfigManager;
import cryptix.module.ModuleManager;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import net.fabricmc.api.ModInitializer;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/**
 * Reconstructed from a/j.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class CryptixClient implements ModInitializer {
    private static final String TEXT_02X;
    public static final String f2 = null;
    private static final String TEXT_UNKNOWN;
    public static final String f1 = null;
    private static final String TEXT_SHA_256;

    public static void sendChatMessage(String arg0) {
        Minecraft.getInstance().player.sendSystemMessage(((Component) (Object) Component.literal(arg0)));
    }

    public void onInitialize() {
        ModuleManager.initialize();
        CommandManager.m8();
        ConfigManager.initialize();
    }

    public static void sendPrefixedMessage(String arg0) {
        arg0 = ("\u00a7f[\u00a7aCryptix\u00a7f] " + arg0);
        Minecraft.getInstance().player.sendSystemMessage(((Component) (Object) Component.literal(arg0)));
    }

    static {
        TEXT_SHA_256 = new String("SHA-256");
        TEXT_02X = new String("%02x");
        TEXT_UNKNOWN = new String("unknown");
    }

    public static String m4(String arg0) {
        Object reference1 = null;
        byte[] reference2 = null;
        StringBuilder reference3 = null;
        byte[] reference4 = null;
        int integer5 = 0;
        int integer6 = 0;
        int integer7 = 0;
        try {
            reference1 = MessageDigest.getInstance(CryptixClient.TEXT_SHA_256);
            reference2 = ((MessageDigest) reference1).digest(arg0.getBytes(StandardCharsets.UTF_8));
            reference3 = new StringBuilder();
            reference4 = reference2;
            integer5 = reference4.length;
            integer6 = 0;
            loop20: while (true) {
                if ((integer6 >= integer5)) {
                    break loop20;
                }
                integer7 = reference4[integer6];
                reference3.append(String.format(CryptixClient.TEXT_02X, new Object[] {Byte.valueOf(((byte) integer7))}));
                integer6++;
                continue loop20;
            }
            arg0 = reference3.toString();
            return arg0;
        } catch (Exception caught1) {
            reference1 = caught1;
            ((Exception) reference1).printStackTrace();
            arg0 = CryptixClient.TEXT_UNKNOWN;
            return arg0;
        }
    }

    public CryptixClient() {
    }
}
