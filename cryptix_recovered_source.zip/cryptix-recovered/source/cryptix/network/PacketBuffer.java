package cryptix.network;

import cryptix.util.MinecraftAccess;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.network.protocol.Packet;

/**
 * Reconstructed from a/os.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class PacketBuffer implements MinecraftAccess {
    private static boolean flushing;
    private static final List queuedPackets;
    private static boolean buffering;

    public static void stopAndFlush() {
        PacketBuffer.buffering = false;
        PacketBuffer.flush();
    }

    public static void startBuffering() {
        boolean saved1 = false;
        saved1 = PacketBuffer.buffering;
        if (!(saved1)) {
            PacketBuffer.queuedPackets.clear();
        }
        PacketBuffer.buffering = true;
    }

    public static boolean isBuffering() {
        return PacketBuffer.buffering;
    }

    private static void flush() {
        List saved1 = null;
        List reference0 = null;
        Iterator reference1 = null;
        boolean saved2 = false;
        Packet reference2 = null;
        PacketBuffer.flushing = true;
        saved1 = PacketBuffer.queuedPackets;
        reference0 = saved1;
        synchronized (saved1) {
            reference1 = PacketBuffer.queuedPackets.iterator();
            loop9: while (true) {
                saved2 = reference1.hasNext();
                if (!(saved2)) {
                    break loop9;
                }
                reference2 = ((Packet) reference1.next());
                MinecraftAccess.mc.getConnection().send(reference2);
                continue loop9;
            }
            PacketBuffer.queuedPackets.clear();
        }
        PacketBuffer.flushing = false;
    }

    public static boolean queuePacket(Packet arg0) {
        if (!PacketBuffer.buffering || PacketBuffer.flushing) {
            return false;
        }
        synchronized (PacketBuffer.queuedPackets) {
            PacketBuffer.queuedPackets.add(arg0);
            return true;
        }
    }

    static {
        queuedPackets = new ArrayList();
    }

    public PacketBuffer() {
    }
}
