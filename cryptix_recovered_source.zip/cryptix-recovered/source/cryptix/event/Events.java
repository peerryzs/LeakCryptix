package cryptix.event;

import cryptix.event.impl.EntityColorEvent;
import cryptix.event.impl.HudRenderEvent;
import cryptix.event.impl.HurtCameraEvent;
import cryptix.event.impl.ItemUseSlowdownEvent;
import cryptix.event.impl.KeybindEvent;
import cryptix.event.impl.MotionEvent;
import cryptix.event.impl.MouseButtonEvent;
import cryptix.event.impl.MovementInputEvent;
import cryptix.event.impl.NameTagRenderEvent;
import cryptix.event.impl.PacketReceiveEvent;
import cryptix.event.impl.PacketSendEvent;
import cryptix.event.impl.PlayerAiStepEvent;
import cryptix.event.impl.PostInputEvent;
import cryptix.event.impl.PostMotionEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.event.impl.SoundPlayEvent;
import cryptix.event.impl.SprintEvent;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/**
 * Reconstructed from a/q.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Events {
    public static final KeybindEvent keybind;
    public static final PacketReceiveEvent packetReceive;
    public static final MouseButtonEvent mouseButton;
    public static final ItemUseSlowdownEvent itemUseSlowdown;
    public static final MotionEvent motion;
    public static final MovementInputEvent movementInput;
    public static final PostInputEvent postInput;
    public static final EntityColorEvent entityColor;
    public static final HudRenderEvent hudRender;
    public static final HurtCameraEvent hurtCamera;
    public static final PostMotionEvent postMotion;
    public static final SprintEvent sprint;
    public static final PacketSendEvent packetSend;
    public static final RotationEvent rotation;
    public static final List f20;
    public static final NameTagRenderEvent nameTagRender;
    public static final PlayerAiStepEvent playerAiStep;
    public static final SoundPlayEvent soundPlay;

    public Events() {
    }

    public static void refreshAllListeners() {
        LocalPlayer saved1 = null;
        Iterator reference0 = null;
        boolean saved2 = false;
        Event reference1 = null;
        saved1 = Minecraft.getInstance().player;
        if (!((saved1 != null))) {
            return;
        } else {
            reference0 = Events.f20.iterator();
            loop7: while (true) {
                saved2 = reference0.hasNext();
                if (!(saved2)) {
                    break loop7;
                }
                reference1 = ((Event) reference0.next());
                reference1.refreshListeners();
                continue loop7;
            }
            return;
        }
    }

    static {
        motion = new MotionEvent();
        postMotion = new PostMotionEvent();
        rotation = new RotationEvent();
        keybind = new KeybindEvent();
        hudRender = new HudRenderEvent();
        hurtCamera = new HurtCameraEvent();
        movementInput = new MovementInputEvent();
        postInput = new PostInputEvent();
        itemUseSlowdown = new ItemUseSlowdownEvent();
        packetSend = new PacketSendEvent();
        packetReceive = new PacketReceiveEvent();
        sprint = new SprintEvent();
        nameTagRender = new NameTagRenderEvent();
        entityColor = new EntityColorEvent();
        mouseButton = new MouseButtonEvent();
        soundPlay = new SoundPlayEvent();
        playerAiStep = new PlayerAiStepEvent();
        f20 = List.of(new Event[] {Events.motion, Events.postMotion, Events.rotation, Events.keybind, Events.hudRender, Events.hurtCamera, Events.movementInput, Events.postInput, Events.itemUseSlowdown, Events.packetSend, Events.packetReceive, Events.sprint, Events.nameTagRender, Events.entityColor, Events.mouseButton, Events.soundPlay, Events.playerAiStep});
    }
}
