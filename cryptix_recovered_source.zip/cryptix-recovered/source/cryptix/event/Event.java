package cryptix.event;

import cryptix.module.Module;
import cryptix.module.ModuleManager;
import java.util.List;

/**
 * Reconstructed from a/l.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public abstract class Event {
    private Module[] listeners;
    private int listenerCount;
    private boolean cancelled;

    public Event() {
        this.listeners = new Module[ModuleManager.getModules().size()];
    }

    public void dispatch() {
        int integer1 = 0;
        int saved1 = 0;
        this.cancelled = false;
        integer1 = 0;
        loop5: while (true) {
            saved1 = this.listenerCount;
            if ((integer1 >= saved1)) {
                break loop5;
            }
            this.listeners[integer1].onEvent(this);
            integer1++;
            continue loop5;
        }
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void refreshListeners() {
        List reference1 = null;
        int integer2 = 0;
        int integer3 = 0;
        Module reference4 = null;
        boolean saved1 = false;
        int integer5 = 0;
        int integer6 = 0;
        int saved2 = 0;
        reference1 = ModuleManager.getModules();
        this.listenerCount = 0;
        integer2 = 0;
        integer3 = reference1.size();
        loop10: while (true) {
            if ((integer2 >= integer3)) {
                break loop10;
            }
            reference4 = ((Module) reference1.get(integer2));
            saved1 = reference4.isEnabled();
            if (!(saved1)) {
            } else {
                integer5 = reference4.getEventPriority(this);
                integer6 = (this.listenerCount - 1);
                loop31: while (true) {
                    if ((integer6 < 0)) {
                        break loop31;
                    }
                    saved2 = this.listeners[integer6].getEventPriority(this);
                    if ((saved2 <= integer5)) {
                        break loop31;
                    }
                    this.listeners[(integer6 + 1)] = this.listeners[integer6];
                    integer6--;
                    continue loop31;
                }
                this.listeners[(integer6 + 1)] = reference4;
                this.listenerCount = (this.listenerCount + 1);
            }
            integer2++;
            continue loop10;
        }
    }

    public void setCancelled(boolean arg0) {
        this.cancelled = arg0;
    }
}
