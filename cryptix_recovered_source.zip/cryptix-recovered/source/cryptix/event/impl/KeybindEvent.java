package cryptix.event.impl;

import cryptix.event.Event;

/**
 * Reconstructed from a/z.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class KeybindEvent extends Event {

    public KeybindEvent() {
        super();
    }
}
