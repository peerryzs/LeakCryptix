package cryptix.event.impl;

import cryptix.event.Event;
import net.minecraft.resources.Identifier;

/**
 * Reconstructed from a/m.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class SoundPlayEvent extends Event {
    private Identifier soundIdentifier;

    public Identifier getSoundIdentifier() {
        return this.soundIdentifier;
    }

    public SoundPlayEvent update(Identifier arg0) {
        SoundPlayEvent reference0 = this;
        reference0.soundIdentifier = arg0;
        return reference0;
    }

    public SoundPlayEvent() {
        super();
    }
}
