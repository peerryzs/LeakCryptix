package cryptix.event.impl;

import cryptix.event.Event;

/**
 * Reconstructed from a/r.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class MouseButtonEvent extends Event {
    private int f87;
    private int f88;
    private int f86;

    public MouseButtonEvent() {
        super();
    }

    public boolean m18() {
        int saved1 = 0;
        int integer0 = 0;
        saved1 = this.f87;
        integer0 = (!((saved1 != 2)) ? 1 : 0);
        return (integer0 != 0);
    }

    public int m13() {
        return this.f86;
    }

    public boolean m16() {
        int saved1 = 0;
        int integer0 = 0;
        saved1 = this.f87;
        integer0 = (!((saved1 != 1)) ? 1 : 0);
        return (integer0 != 0);
    }

    public boolean m21() {
        int saved1 = 0;
        int integer0 = 0;
        saved1 = this.f86;
        integer0 = (!((saved1 != 2)) ? 1 : 0);
        return (integer0 != 0);
    }

    public int m15() {
        return this.f88;
    }

    public MouseButtonEvent m12(int arg0, int arg1, int arg2) {
        MouseButtonEvent reference0 = this;
        reference0.f86 = arg0;
        reference0.f87 = arg1;
        reference0.f88 = arg2;
        return reference0;
    }

    public boolean m17() {
        int saved1 = 0;
        int integer0 = 0;
        saved1 = this.f87;
        integer0 = (!((saved1 != 0)) ? 1 : 0);
        return (integer0 != 0);
    }

    public int m14() {
        return this.f87;
    }

    public boolean m20() {
        int saved1 = 0;
        int integer0 = 0;
        saved1 = this.f86;
        integer0 = (!((saved1 != 1)) ? 1 : 0);
        return (integer0 != 0);
    }

    public boolean m19() {
        int saved1 = 0;
        int integer0 = 0;
        saved1 = this.f86;
        integer0 = (!((saved1 != 0)) ? 1 : 0);
        return (integer0 != 0);
    }
}
