package cryptix.event.impl;

import cryptix.event.Event;

/**
 * Reconstructed from a/ck.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class ItemUseSlowdownEvent extends Event {
    private float multiplier;

    public float getMultiplier() {
        return this.multiplier;
    }

    public void setMultiplier(float arg0) {
        this.multiplier = arg0;
    }

    public ItemUseSlowdownEvent() {
        super();
    }

    public ItemUseSlowdownEvent update(float arg0) {
        ItemUseSlowdownEvent reference0 = this;
        reference0.multiplier = arg0;
        return reference0;
    }
}
