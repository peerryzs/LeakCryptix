package cryptix.event.impl;

import cryptix.event.Event;
import cryptix.render.ProjectionUtils;
import cryptix.util.Recovered_eg;
import cryptix.util.Recovered_sf;
import cryptix.util.Recovered_uf;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Reconstructed from a/as.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class HudRenderEvent extends Event {
    private GuiGraphicsExtractor graphics;
    private DeltaTracker deltaTracker;

    public GuiGraphicsExtractor getGraphics() {
        return this.graphics;
    }

    public HudRenderEvent update(GuiGraphicsExtractor arg0, DeltaTracker arg1) {
        HudRenderEvent reference0 = this;
        reference0.graphics = arg0;
        reference0.deltaTracker = arg1;
        ProjectionUtils.m47();
        Recovered_uf.m57();
        Recovered_eg.m32();
        Recovered_sf.m24(reference0.getPartialTick());
        return reference0;
    }

    public DeltaTracker getDeltaTracker() {
        return this.deltaTracker;
    }

    public float getPartialTick() {
        float floating0 = 0.0f;
        floating0 = this.deltaTracker.getGameTimeDeltaPartialTick(false);
        return floating0;
    }

    public HudRenderEvent() {
        super();
    }
}
