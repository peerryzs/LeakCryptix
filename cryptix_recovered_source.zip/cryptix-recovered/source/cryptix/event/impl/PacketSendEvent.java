package cryptix.event.impl;

import cryptix.event.Event;
import net.minecraft.network.protocol.Packet;

/**
 * Reconstructed from a/k.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class PacketSendEvent extends Event {
    private Packet packet;

    public PacketSendEvent() {
        super();
    }

    public PacketSendEvent update(Packet arg0) {
        PacketSendEvent reference0 = this;
        reference0.packet = arg0;
        return reference0;
    }

    public Packet getPacket() {
        return this.packet;
    }
}
