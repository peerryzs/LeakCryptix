package cryptix.event.impl;

import cryptix.event.Event;

/**
 * Reconstructed from a/ko.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class SprintEvent extends Event {
    private int f125;
    private boolean f126;

    public void m98(int arg0) {
        this.f125 = arg0;
    }

    public int m97() {
        return this.f125;
    }

    public boolean m99() {
        return this.f126;
    }

    public SprintEvent m96(int arg0, boolean arg1) {
        SprintEvent reference0 = this;
        reference0.f125 = arg0;
        reference0.f126 = arg1;
        return reference0;
    }

    public void m100(boolean arg0) {
        this.f126 = arg0;
    }

    public SprintEvent() {
        super();
    }
}
