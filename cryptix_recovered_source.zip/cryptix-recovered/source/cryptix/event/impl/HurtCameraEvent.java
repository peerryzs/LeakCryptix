package cryptix.event.impl;

import cryptix.event.Event;

/**
 * Reconstructed from a/c.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class HurtCameraEvent extends Event {

    public HurtCameraEvent() {
        super();
    }
}
