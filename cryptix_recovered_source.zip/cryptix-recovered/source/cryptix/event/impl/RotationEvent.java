package cryptix.event.impl;

import cryptix.event.Event;
import cryptix.input.KeybindManager;
import cryptix.util.Recovered_sf;

/**
 * Reconstructed from a/a.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class RotationEvent extends Event {
    private float yaw;
    private boolean f120;
    private float pitch;
    private float previousPitch;
    private boolean f121;
    private float previousYaw;

    public float getYaw() {
        return this.yaw;
    }

    public void setPreviousPitch(float arg0) {
        this.previousPitch = arg0;
    }

    public void setPreviousYaw(float arg0) {
        this.previousYaw = arg0;
    }

    public float getPreviousYaw() {
        return this.previousYaw;
    }

    public void setYaw(float arg0) {
        this.yaw = arg0;
    }

    public RotationEvent() {
        super();
    }

    public RotationEvent update(float arg0, float arg1) {
        RotationEvent reference0 = this;
        KeybindManager.pollKeybinds();
        Recovered_sf.m23();
        reference0.previousYaw = reference0.yaw;
        reference0.previousPitch = reference0.pitch;
        reference0.yaw = arg0;
        reference0.pitch = arg1;
        reference0.f120 = false;
        reference0.f121 = true;
        return reference0;
    }

    public boolean m87() {
        return this.f121;
    }

    public boolean m85() {
        return this.f120;
    }

    public void setPitch(float arg0) {
        this.pitch = arg0;
    }

    public float getPitch() {
        return this.pitch;
    }

    public float getPreviousPitch() {
        return this.previousPitch;
    }

    public void m86(boolean arg0) {
        this.f120 = arg0;
    }

    public void m88(boolean arg0) {
        this.f121 = arg0;
    }
}
