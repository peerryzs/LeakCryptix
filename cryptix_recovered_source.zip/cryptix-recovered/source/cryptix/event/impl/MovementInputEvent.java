package cryptix.event.impl;

import cryptix.event.Event;

/**
 * Reconstructed from a/f.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class MovementInputEvent extends Event {
    private boolean f106;
    private boolean f103;
    private boolean f107;
    private boolean f104;
    private boolean f108;
    private boolean f102;
    private boolean f105;

    public MovementInputEvent m48(boolean arg0, boolean arg1, boolean arg2, boolean arg3, boolean arg4, boolean arg5, boolean arg6) {
        MovementInputEvent reference0 = this;
        reference0.f102 = arg0;
        reference0.f103 = arg1;
        reference0.f104 = arg2;
        reference0.f105 = arg3;
        reference0.f106 = arg4;
        reference0.f107 = arg5;
        reference0.f108 = arg6;
        return reference0;
    }

    public boolean m49() {
        return this.f102;
    }

    public void m56(boolean arg0) {
        this.f102 = arg0;
    }

    public void m62(boolean arg0) {
        this.f108 = arg0;
    }

    public MovementInputEvent() {
        super();
    }

    public void m59(boolean arg0) {
        this.f105 = arg0;
    }

    public boolean m52() {
        return this.f105;
    }

    public void m60(boolean arg0) {
        this.f106 = arg0;
    }

    public boolean m55() {
        return this.f108;
    }

    public boolean m54() {
        return this.f107;
    }

    public boolean m53() {
        return this.f106;
    }

    public boolean m50() {
        return this.f103;
    }

    public void m58(boolean arg0) {
        this.f104 = arg0;
    }

    public boolean m51() {
        return this.f104;
    }

    public void m57(boolean arg0) {
        this.f103 = arg0;
    }

    public void m61(boolean arg0) {
        this.f107 = arg0;
    }
}
