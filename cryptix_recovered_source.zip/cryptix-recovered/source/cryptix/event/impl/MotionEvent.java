package cryptix.event.impl;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.module.ModuleManager;
import cryptix.recovery.JvmSupport;
import cryptix.util.Recovered_it;
import net.minecraft.client.Minecraft;

/**
 * Reconstructed from a/d.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class MotionEvent extends Event {
    private double y;
    private double x;
    private float yaw;
    private float pitch;
    private double z;
    private boolean horizontalCollision;
    private boolean onGround;

    public void setX(double arg0) {
        this.x = arg0;
    }

    public void setHorizontalCollision(boolean arg0) {
        this.horizontalCollision = arg0;
    }

    public MotionEvent() {
        super();
    }

    public double getY() {
        return this.y;
    }

    public void setOnGround(boolean arg0) {
        this.onGround = arg0;
    }

    public double getZ() {
        return this.z;
    }

    public void setY(double arg0) {
        this.y = arg0;
    }

    public float getPitch() {
        return this.pitch;
    }

    public boolean isOnGround() {
        return this.onGround;
    }

    public float getYaw() {
        return this.yaw;
    }

    public double getX() {
        return this.x;
    }

    public boolean hasHorizontalCollision() {
        return this.horizontalCollision;
    }

    public MotionEvent update(double arg0, double arg1, double arg2, boolean arg3, boolean arg4) {
        boolean saved1 = false;
        MotionEvent reference0 = this;
        int saved2 = 0;
        boolean saved3 = false;
        boolean saved4 = false;
        saved1 = Events.rotation.m87();
        if (!(saved1)) {
            reference0.yaw = Events.rotation.getYaw();
            reference0.pitch = Events.rotation.getPitch();
        }
        saved2 = JvmSupport.fcmpl(Events.rotation.getYaw(), Minecraft.getInstance().player.getYRot());
        if (!((saved2 == 0))) {
            Minecraft.getInstance().player.yBodyRot = Events.rotation.getYaw();
        }
        saved3 = ModuleManager.animations.isEnabled();
        if (saved3) {
            saved4 = ModuleManager.animations.oldBodyYaw.getValue();
            if (saved4) {
                Minecraft.getInstance().player.yBodyRot = Recovered_it.m52(Events.rotation.getYaw(), Minecraft.getInstance().player.yBodyRot);
            }
        }
        reference0.x = arg0;
        reference0.y = arg1;
        reference0.z = arg2;
        reference0.onGround = arg3;
        reference0.horizontalCollision = arg4;
        Minecraft.getInstance().player.yHeadRot = Events.rotation.getYaw();
        return reference0;
    }

    public void setZ(double arg0) {
        this.z = arg0;
    }
}
