package cryptix.event.impl;

import cryptix.event.Event;

/**
 * Reconstructed from a/h.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class PostInputEvent extends Event {

    public PostInputEvent() {
        super();
    }
}
