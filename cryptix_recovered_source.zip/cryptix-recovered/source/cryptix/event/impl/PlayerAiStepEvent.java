package cryptix.event.impl;

import cryptix.event.Event;

/**
 * Reconstructed from a/p.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class PlayerAiStepEvent extends Event {

    public PlayerAiStepEvent() {
        super();
    }
}
