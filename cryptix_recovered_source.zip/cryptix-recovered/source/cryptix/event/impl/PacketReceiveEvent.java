package cryptix.event.impl;

import cryptix.event.Event;
import net.minecraft.network.protocol.Packet;

/**
 * Reconstructed from a/t.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class PacketReceiveEvent extends Event {
    private Packet packet;

    public void setPacket(Packet arg0) {
        this.packet = arg0;
    }

    public Packet getPacket() {
        return this.packet;
    }

    public PacketReceiveEvent update(Packet arg0) {
        PacketReceiveEvent reference0 = this;
        reference0.packet = arg0;
        return reference0;
    }

    public PacketReceiveEvent() {
        super();
    }
}
