package cryptix.event.impl;

import cryptix.event.Event;
import net.minecraft.world.entity.Entity;

/**
 * Reconstructed from a/y.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class EntityColorEvent extends Event {
    private int color;
    private Entity entity;

    public int getColor() {
        return this.color;
    }

    public void setColor(int arg0) {
        this.color = arg0;
    }

    public EntityColorEvent update(int arg0, Entity arg1) {
        EntityColorEvent reference0 = this;
        reference0.color = arg0;
        reference0.entity = arg1;
        return reference0;
    }

    public Entity getEntity() {
        return this.entity;
    }

    public EntityColorEvent() {
        super();
    }
}
