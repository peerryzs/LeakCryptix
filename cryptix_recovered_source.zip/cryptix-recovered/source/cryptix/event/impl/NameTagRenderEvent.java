package cryptix.event.impl;

import com.mojang.blaze3d.vertex.PoseStack;
import cryptix.event.Event;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Reconstructed from a/w.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class NameTagRenderEvent extends Event {
    private Vec3 f92;
    private int f93;
    private Entity f96;
    private Component f90;
    private PoseStack f89;
    private Component f91;
    private int f94;
    private boolean f95;

    public void m35(int arg0) {
        this.f94 = arg0;
    }

    public Vec3 m25() {
        return this.f92;
    }

    public void m34(int arg0) {
        this.f93 = arg0;
    }

    public int m26() {
        return this.f93;
    }

    public boolean m28() {
        return this.f95;
    }

    public NameTagRenderEvent() {
        super();
    }

    public NameTagRenderEvent m22(PoseStack arg0, Component arg1, Vec3 arg2, int arg3, int arg4, boolean arg5, Entity arg6) {
        NameTagRenderEvent reference0 = this;
        reference0.f90 = arg1;
        reference0.f91 = arg1;
        reference0.f92 = arg2;
        reference0.f93 = arg3;
        reference0.f94 = arg4;
        reference0.f95 = arg5;
        reference0.f89 = arg0;
        reference0.f96 = arg6;
        return reference0;
    }

    public PoseStack m29() {
        return this.f89;
    }

    public Component m23() {
        return this.f90;
    }

    public void m33(Vec3 arg0) {
        this.f92 = arg0;
    }

    public int m27() {
        return this.f94;
    }

    public void m32(Component arg0) {
        this.f91 = arg0;
    }

    public Entity m30() {
        return this.f96;
    }

    public Component m24() {
        return this.f91;
    }

    public void m31(Component arg0) {
        this.f90 = arg0;
    }

    public void m36(boolean arg0) {
        this.f95 = arg0;
    }
}
