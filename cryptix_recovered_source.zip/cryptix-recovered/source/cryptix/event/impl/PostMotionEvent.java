package cryptix.event.impl;

import cryptix.event.Event;

/**
 * Reconstructed from a/e.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class PostMotionEvent extends Event {

    public PostMotionEvent() {
        super();
    }
}
