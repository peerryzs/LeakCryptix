package cryptix.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import cryptix.module.Module;
import cryptix.module.ModuleManager;
import cryptix.setting.BooleanSetting;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;
import cryptix.setting.PositionSetting;
import cryptix.setting.Setting;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import net.minecraft.client.Minecraft;

/**
 * Reconstructed from a/dp.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class ConfigManager {
    private static final Gson gson;
    private static final String TEXT_HIDDEN;
    private static final String TEXT_X;
    private static final String TEXT_EMPTY;
    private static final String TEXT_KEY;
    private static final String TEXT_SETTINGS;
    private static final String TEXT_JSON;
    private static final String TEXT_CRYPTIX_CONFIGS;
    private static final String TEXT_HEIGHT;
    private static final File configDirectory;
    private static final String TEXT_WIDTH;
    private static final String TEXT_ENABLED;
    private static final String TEXT_Y;

    public static boolean delete(String arg0) {
        int integer0 = 0;
        integer0 = (ConfigManager.getConfigFile(arg0).delete() ? 1 : 0);
        return (integer0 != 0);
    }

    public static File getConfigDirectory() {
        return ConfigManager.configDirectory;
    }

    public static boolean exists(String arg0) {
        int integer0 = 0;
        integer0 = (ConfigManager.getConfigFile(arg0).exists() ? 1 : 0);
        return (integer0 != 0);
    }

    public static File getConfigFile(String arg0) {
        Object reference0 = arg0;
        reference0 = new File(ConfigManager.configDirectory, ("" + reference0 + ".json"));
        return ((File) reference0);
    }

    private static boolean listCallback0(File arg0, String arg1) {
        int integer0 = 0;
        integer0 = (arg1.endsWith(ConfigManager.TEXT_JSON) ? 1 : 0);
        return (integer0 != 0);
    }

    public static String[] list() {
        Object reference0 = null;
        String[] reference1 = null;
        int integer2 = 0;
        int saved1 = 0;
        reference0 = ConfigManager.configDirectory.listFiles((lambdaArg0, lambdaArg1) -> ConfigManager.listCallback0(((File) lambdaArg0), ((String) lambdaArg1)));
        if (!((reference0 != null))) {
            reference0 = new String[] {};
            return ((String[]) reference0);
        } else {
            reference1 = new String[((File[]) reference0).length];
            integer2 = 0;
            loop17: while (true) {
                saved1 = ((File[]) reference0).length;
                if ((integer2 >= saved1)) {
                    break loop17;
                }
                reference1[integer2] = ((File[]) reference0)[integer2].getName().replace(ConfigManager.TEXT_JSON, ConfigManager.TEXT_EMPTY);
                integer2++;
                continue loop17;
            }
            reference0 = reference1;
            return ((String[]) reference0);
        }
    }

    public static void save(String arg0) {
        JsonObject reference1 = null;
        Iterator reference2 = null;
        boolean saved1 = false;
        Module reference3 = null;
        JsonObject reference4 = null;
        JsonObject reference5 = null;
        Iterator reference6 = null;
        boolean saved2 = false;
        Setting reference7 = null;
        boolean saved3 = false;
        BooleanSetting reference8 = null;
        boolean saved4 = false;
        NumberSetting reference9 = null;
        boolean saved5 = false;
        ModeSetting reference10 = null;
        boolean saved6 = false;
        PositionSetting reference11 = null;
        JsonObject reference12 = null;
        reference1 = new JsonObject();
        reference2 = ModuleManager.getModules().iterator();
        loop7: while (true) {
            saved1 = reference2.hasNext();
            if (!(saved1)) {
                break loop7;
            }
            reference3 = ((Module) reference2.next());
            reference4 = new JsonObject();
            reference4.addProperty(ConfigManager.TEXT_ENABLED, Boolean.valueOf(reference3.isEnabled()));
            reference4.addProperty(ConfigManager.TEXT_HIDDEN, Boolean.valueOf(reference3.isHidden()));
            reference4.addProperty(ConfigManager.TEXT_KEY, ((Number) (Object) Integer.valueOf(reference3.getKeybind())));
            reference5 = new JsonObject();
            reference6 = reference3.settings.iterator();
            loop44: while (true) {
                saved2 = reference6.hasNext();
                if (!(saved2)) {
                    break loop44;
                }
                reference7 = ((Setting) reference6.next());
                saved3 = (reference7 instanceof BooleanSetting);
                if (saved3) {
                    reference8 = ((BooleanSetting) (Object) reference7);
                    reference5.addProperty(reference7.getName(), Boolean.valueOf(reference8.getValue()));
                } else {
                    saved4 = (reference7 instanceof NumberSetting);
                    if (saved4) {
                        reference9 = ((NumberSetting) (Object) reference7);
                        reference5.addProperty(reference7.getName(), ((Number) (Object) Double.valueOf(reference9.getValue())));
                    } else {
                        saved5 = (reference7 instanceof ModeSetting);
                        if (saved5) {
                            reference10 = ((ModeSetting) (Object) reference7);
                            reference5.addProperty(reference7.getName(), reference10.getValue());
                        } else {
                            saved6 = (reference7 instanceof PositionSetting);
                            if (saved6) {
                                reference11 = ((PositionSetting) (Object) reference7);
                                reference12 = new JsonObject();
                                reference12.addProperty(ConfigManager.TEXT_X, ((Number) (Object) Integer.valueOf(reference11.getX())));
                                reference12.addProperty(ConfigManager.TEXT_Y, ((Number) (Object) Integer.valueOf(reference11.getY())));
                                reference12.addProperty(ConfigManager.TEXT_WIDTH, ((Number) (Object) Integer.valueOf(reference11.getWidth())));
                                reference12.addProperty(ConfigManager.TEXT_HEIGHT, ((Number) (Object) Integer.valueOf(reference11.getHeight())));
                                reference5.add(reference7.getName(), ((JsonElement) (Object) reference12));
                            }
                        }
                    }
                }
                continue loop44;
            }
            reference4.add(ConfigManager.TEXT_SETTINGS, ((JsonElement) (Object) reference5));
            reference1.add(reference3.getName(), ((JsonElement) (Object) reference4));
            continue loop7;
        }
        ConfigManager.writeJson(arg0, reference1);
    }

    public static void initialize() {
        boolean saved1 = false;
        saved1 = ConfigManager.configDirectory.exists();
        if (!(saved1)) {
            ConfigManager.configDirectory.mkdirs();
        }
    }

    public ConfigManager() {
    }

    static {
        TEXT_ENABLED = new String("enabled");
        TEXT_HIDDEN = new String("hidden");
        TEXT_KEY = new String("key");
        TEXT_X = new String("x");
        TEXT_Y = new String("y");
        TEXT_WIDTH = new String("width");
        TEXT_HEIGHT = new String("height");
        TEXT_SETTINGS = new String("settings");
        TEXT_JSON = new String(".json");
        TEXT_EMPTY = new String("");
        TEXT_CRYPTIX_CONFIGS = new String("cryptix/configs");
        gson = new GsonBuilder().setPrettyPrinting().create();
        configDirectory = new File(Minecraft.getInstance().gameDirectory, ConfigManager.TEXT_CRYPTIX_CONFIGS);
    }

    public static JsonObject readJson(String arg0) {
        File file = ConfigManager.getConfigFile(arg0);
        if (!file.exists()) {
            return new JsonObject();
        }
        try (FileReader reader = new FileReader(file)) {
            return JsonParser.parseReader(reader).getAsJsonObject();
        } catch (Exception exception) {
            exception.printStackTrace();
            return new JsonObject();
        }
    }

    public static void resetToDefaults(String arg0) {
        Iterator reference1 = null;
        boolean saved1 = false;
        Module reference2 = null;
        Iterator reference3 = null;
        boolean saved2 = false;
        Setting reference4 = null;
        boolean saved3 = false;
        BooleanSetting reference5 = null;
        boolean saved4 = false;
        NumberSetting reference6 = null;
        boolean saved5 = false;
        ModeSetting reference7 = null;
        boolean saved6 = false;
        reference1 = ModuleManager.getModules().iterator();
        loop3: while (true) {
            saved1 = reference1.hasNext();
            if (!(saved1)) {
                break loop3;
            }
            reference2 = ((Module) reference1.next());
            reference2.setEnabled(false);
            reference2.setHidden(false);
            reference2.setKeybind(reference2.getDefaultKeybind());
            reference3 = reference2.settings.iterator();
            loop24: while (true) {
                saved2 = reference3.hasNext();
                if (!(saved2)) {
                    break loop24;
                }
                reference4 = ((Setting) reference3.next());
                saved3 = (reference4 instanceof BooleanSetting);
                if (saved3) {
                    reference5 = ((BooleanSetting) (Object) reference4);
                    ((BooleanSetting) (Object) reference4).setValue(reference5.getDefaultValue());
                } else {
                    saved4 = (reference4 instanceof NumberSetting);
                    if (saved4) {
                        reference6 = ((NumberSetting) (Object) reference4);
                        ((NumberSetting) (Object) reference4).setValue(reference6.getDefaultValue());
                    } else {
                        saved5 = (reference4 instanceof ModeSetting);
                        if (saved5) {
                            reference7 = ((ModeSetting) (Object) reference4);
                            ((ModeSetting) (Object) reference4).setValue(reference7.getDefaultValue());
                        } else {
                            saved6 = (reference4 instanceof PositionSetting);
                            if (saved6) {
                                ((PositionSetting) (Object) reference4).setPosition(0, 0);
                            }
                        }
                    }
                }
                continue loop24;
            }
            continue loop3;
        }
        ConfigManager.save(arg0);
    }

    public static void load(String arg0) {
        Object reference1 = null;
        Iterator reference2 = null;
        boolean saved1 = false;
        Module reference3 = null;
        boolean saved2 = false;
        JsonObject reference4 = null;
        JsonObject reference5 = null;
        Iterator reference6 = null;
        boolean saved3 = false;
        Setting reference7 = null;
        boolean saved4 = false;
        boolean saved5 = false;
        BooleanSetting reference8 = null;
        boolean saved6 = false;
        NumberSetting reference9 = null;
        boolean saved7 = false;
        ModeSetting reference10 = null;
        boolean saved8 = false;
        PositionSetting reference11 = null;
        JsonObject reference12 = null;
        try {
            reference1 = ConfigManager.readJson(arg0);
            reference2 = ModuleManager.getModules().iterator();
            loop6: while (true) {
                saved1 = reference2.hasNext();
                if (!(saved1)) {
                    break loop6;
                }
                reference3 = ((Module) reference2.next());
                saved2 = ((JsonObject) reference1).has(reference3.getName());
                if (!(saved2)) {
                    continue loop6;
                }
                reference4 = ((JsonObject) reference1).getAsJsonObject(reference3.getName());
                reference3.setEnabled(reference4.get(ConfigManager.TEXT_ENABLED).getAsBoolean());
                reference3.setHidden(reference4.get(ConfigManager.TEXT_HIDDEN).getAsBoolean());
                reference3.setKeybind(reference4.get(ConfigManager.TEXT_KEY).getAsInt());
                reference5 = reference4.getAsJsonObject(ConfigManager.TEXT_SETTINGS);
                reference6 = reference3.settings.iterator();
                loop50: while (true) {
                    saved3 = reference6.hasNext();
                    if (!(saved3)) {
                        break loop50;
                    }
                    reference7 = ((Setting) reference6.next());
                    saved4 = reference5.has(reference7.getName());
                    if (!(saved4)) {
                        continue loop50;
                    }
                    saved5 = (reference7 instanceof BooleanSetting);
                    if (saved5) {
                        reference8 = ((BooleanSetting) (Object) reference7);
                        reference8.setValue(reference5.get(reference7.getName()).getAsBoolean());
                    } else {
                        saved6 = (reference7 instanceof NumberSetting);
                        if (saved6) {
                            reference9 = ((NumberSetting) (Object) reference7);
                            reference9.setValue(reference5.get(reference7.getName()).getAsDouble());
                        } else {
                            saved7 = (reference7 instanceof ModeSetting);
                            if (saved7) {
                                reference10 = ((ModeSetting) (Object) reference7);
                                reference10.setValue(reference5.get(reference7.getName()).getAsString());
                            } else {
                                saved8 = (reference7 instanceof PositionSetting);
                                if (saved8) {
                                    reference11 = ((PositionSetting) (Object) reference7);
                                    reference12 = reference5.getAsJsonObject(reference7.getName());
                                    reference11.setPosition(reference12.get(ConfigManager.TEXT_X).getAsInt(), reference12.get(ConfigManager.TEXT_Y).getAsInt());
                                    reference11.setWidth(reference12.get(ConfigManager.TEXT_WIDTH).getAsInt());
                                    reference11.setHeight(reference12.get(ConfigManager.TEXT_HEIGHT).getAsInt());
                                }
                            }
                        }
                    }
                    continue loop50;
                }
                continue loop6;
            }
        } catch (Exception caught9) {
            reference1 = caught9;
            ((Exception) reference1).printStackTrace();
        }
    }

    public static void writeJson(String arg0, JsonObject arg1) {
        try (FileWriter writer = new FileWriter(ConfigManager.getConfigFile(arg0))) {
            ConfigManager.gson.toJson(arg1, writer);
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }
}
