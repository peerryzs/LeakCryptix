package cryptix.mixin;

import cryptix.event.Events;
import cryptix.event.impl.MouseButtonEvent;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.input.MouseButtonInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/th.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {MouseHandler.class})
public class MouseHandlerMixin {

    @Inject(method = {"onButton"}, at = {@At(value = "HEAD")}, cancellable = true)
    private void pm$44(long arg0, MouseButtonInfo arg1, int arg2, CallbackInfo arg3) {
        MouseButtonEvent reference6 = null;
        boolean saved1 = false;
        reference6 = Events.mouseButton.m12(arg1.button(), arg2, arg1.modifiers());
        reference6.dispatch();
        saved1 = reference6.isCancelled();
        if (saved1) {
            arg3.cancel();
        }
    }

    public MouseHandlerMixin() {
    }
}
