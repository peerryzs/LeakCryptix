package cryptix.mixin;

import cryptix.module.ModuleManager;
import cryptix.recovery.JvmSupport;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/**
 * Reconstructed from mixins/se.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {Hud.class})
public class HudMixin {
    @Unique
    private float f220;
    @Shadow
    private Minecraft minecraft;
    @Unique
    private long f222;
    @Unique
    private long f223;
    @Unique
    private int f221;
    @Unique
    private float f219;

    public HudMixin() {
        this.f221 = -1;
        this.f223 = 100000000L;
    }

    @ModifyArg(method = {"displayScoreboardSidebar"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;fill(IIIII)V"), index = 2)
    private int pm$32(int arg0) {
        int integer0 = 0;
        integer0 = (arg0 - this.pm$27());
        return integer0;
    }

    @Unique
    private void pm$24(GuiGraphicsExtractor arg0, DeltaTracker arg1) {
        LocalPlayer reference3 = null;
        int integer4 = 0;
        int saved1 = 0;
        int saved2 = 0;
        long local5 = 0L;
        int saved3 = 0;
        long local7 = 0L;
        int saved4 = 0;
        float floating9 = 0.0f;
        reference3 = this.minecraft.player;
        if (!((reference3 != null))) {
            this.f221 = -1;
            return;
        } else {
            integer4 = reference3.getInventory().getSelectedSlot();
            saved1 = this.f221;
            if (!((saved1 != -1))) {
                this.f221 = integer4;
                this.f219 = ((float) integer4);
                this.f220 = ((float) integer4);
                return;
            } else {
                saved2 = this.f221;
                if (!((integer4 == saved2))) {
                    this.f220 = this.f219;
                    this.f222 = System.nanoTime();
                    this.f221 = integer4;
                }
                local5 = this.f223;
                saved3 = JvmSupport.lcmp(local5, 0L);
                if (!((saved3 > 0))) {
                    this.f219 = ((float) integer4);
                    return;
                } else {
                    local7 = (System.nanoTime() - this.f222);
                    saved4 = JvmSupport.lcmp(local7, local5);
                    if (!((saved4 < 0))) {
                        this.f219 = ((float) integer4);
                        return;
                    } else {
                        floating9 = (((float) local7) / ((float) local5));
                        floating9 = (floating9 * (floating9 * (3.0f - (2.0f * floating9))));
                        this.f219 = Mth.lerp(floating9, this.f220, ((float) integer4));
                        return;
                    }
                }
            }
        }
    }

    @ModifyArg(method = {"displayScoreboardSidebar"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;fill(IIIII)V"), index = 0)
    private int pm$31(int arg0) {
        int integer0 = 0;
        integer0 = (arg0 - this.pm$27());
        return integer0;
    }

    @ModifyArgs(method = {"extractItemHotbar"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIII)V", ordinal = 1))
    private void pm$26(Args arg0) {
        int integer2 = 0;
        float floating3 = 0.0f;
        float floating4 = 0.0f;
        boolean saved1 = false;
        integer2 = ((Integer) arg0.get(2)).intValue();
        floating3 = (this.f219 * 20.0f);
        floating4 = (((float) this.f221) * 20.0f);
        saved1 = ModuleManager.hotbar.isEnabled();
        if (saved1) {
            arg0.set(2, Integer.valueOf(Math.round(((((float) integer2) + floating3) - floating4))));
        }
    }

    private int pm$27() {
        boolean saved1 = false;
        int integer0 = 0;
        saved1 = ModuleManager.scoreboard.isEnabled();
        integer0 = (saved1 ? ((int) ModuleManager.scoreboard.x.getValue()) : 0);
        return integer0;
    }

    @Inject(method = {"extractItemHotbar"}, at = {@At(value = "HEAD")})
    private void pm$25(GuiGraphicsExtractor arg0, DeltaTracker arg1, CallbackInfo arg2) {
        boolean saved1 = false;
        saved1 = ModuleManager.hotbar.isEnabled();
        if (!(saved1)) {
            return;
        } else {
            this.f223 = ((long) (ModuleManager.hotbar.animationTime.getValue() * 1000000.0));
            this.pm$24(arg0, arg1);
            return;
        }
    }

    @ModifyArg(method = {"displayScoreboardSidebar"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIIZ)V"), index = 3)
    private int pm$30(int arg0) {
        int integer0 = 0;
        integer0 = (arg0 - this.pm$28());
        return integer0;
    }

    @ModifyArg(method = {"displayScoreboardSidebar"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIIZ)V"), index = 2)
    private int pm$29(int arg0) {
        int integer0 = 0;
        integer0 = (arg0 - this.pm$27());
        return integer0;
    }

    private int pm$28() {
        boolean saved1 = false;
        int integer0 = 0;
        saved1 = ModuleManager.scoreboard.isEnabled();
        integer0 = (saved1 ? ((int) ModuleManager.scoreboard.y.getValue()) : 0);
        return integer0;
    }

    @ModifyArg(method = {"displayScoreboardSidebar"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;fill(IIIII)V"), index = 3)
    private int pm$34(int arg0) {
        int integer0 = 0;
        integer0 = (arg0 - this.pm$28());
        return integer0;
    }

    @ModifyArg(method = {"displayScoreboardSidebar"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;fill(IIIII)V"), index = 1)
    private int pm$33(int arg0) {
        int integer0 = 0;
        integer0 = (arg0 - this.pm$28());
        return integer0;
    }
}
