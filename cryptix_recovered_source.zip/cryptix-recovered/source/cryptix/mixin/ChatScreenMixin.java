package cryptix.mixin;

import cryptix.command.CommandManager;
import net.minecraft.client.gui.screens.ChatScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/kq.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {ChatScreen.class})
public class ChatScreenMixin {
    private static final String TEXT_EMPTY;

    static {
        TEXT_EMPTY = new String(".");
    }

    @Inject(method = {"handleChatInput"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/ChatComponent;addRecentChat(Ljava/lang/String;)V", shift = At.Shift.AFTER)}, cancellable = true)
    private void pm$16(String arg0, boolean arg1, CallbackInfo arg2) {
        boolean saved1 = false;
        CommandManager.m12(arg0);
        saved1 = arg0.startsWith(ChatScreenMixin.TEXT_EMPTY);
        if (saved1) {
            arg2.cancel();
        }
    }

    public ChatScreenMixin() {
    }
}
