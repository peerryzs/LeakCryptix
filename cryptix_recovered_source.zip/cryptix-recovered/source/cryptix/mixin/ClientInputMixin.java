package cryptix.mixin;

import net.minecraft.client.player.ClientInput;
import net.minecraft.world.phys.Vec2;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Reconstructed from mixins/kt.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {ClientInput.class})
public interface ClientInputMixin {

    @Accessor(value = "moveVector")
    public abstract void setMoveVector(Vec2 arg0);

    @Accessor(value = "moveVector")
    public abstract Vec2 getMoveVector();
}
