package cryptix.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Reconstructed from mixins/el.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {Screen.class})
public interface ScreenMixin {

    @Invoker(value = "addRenderableWidget")
    public abstract GuiEventListener invokeAddRenderableWidget(GuiEventListener arg0);

    @Accessor(value = "minecraft")
    public abstract Minecraft getMinecraft();
}
