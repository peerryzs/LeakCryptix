package cryptix.mixin;

import cryptix.util.Recovered_hp;
import it.unimi.dsi.fastutil.floats.FloatUnaryOperator;
import net.minecraft.client.DeltaTracker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

/**
 * Reconstructed from mixins/lt.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {DeltaTracker.Timer.class})
public class DeltaTrackerTimerMixin {
    @Shadow
    private long lastMs;
    @Shadow
    private FloatUnaryOperator targetMsptProvider;
    @Shadow
    private float msPerTick;
    @Shadow
    private float deltaTickResidual;
    @Shadow
    private float deltaTicks;

    public DeltaTrackerTimerMixin() {
    }

    @Overwrite
    public int advanceGameTime(long arg0) {
        float saved1 = 0.0f;
        boolean saved2 = false;
        int integer3 = 0;
        int integer0 = 0;
        saved1 = ((float) (arg0 - this.lastMs));
        saved2 = Recovered_hp.m62();
        this.deltaTicks = (saved1 / (saved2 ? this.targetMsptProvider.apply(this.msPerTick) : (this.msPerTick / Recovered_hp.m60())));
        this.lastMs = arg0;
        this.deltaTickResidual = (this.deltaTickResidual + this.deltaTicks);
        integer3 = ((int) this.deltaTickResidual);
        this.deltaTickResidual = (this.deltaTickResidual - ((float) integer3));
        integer0 = integer3;
        return integer0;
    }
}
