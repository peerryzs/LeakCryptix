package cryptix.mixin;

import a.b;
import a.i;
import com.mojang.blaze3d.platform.Window;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/zg.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {Window.class})
public class WindowMixin {
    private static final String TEXT_CRYPTIX_1_0_8;
    @Shadow
    private long handle;

    @Inject(method = {"setTitle"}, at = {@At(value = "HEAD")}, cancellable = true)
    private void pm$46(String arg0, CallbackInfo arg1) {
        boolean saved1 = false;
        LocalPlayer saved2 = null;
        saved1 = i.f0;
        if (!(saved1)) {
            saved2 = Minecraft.getInstance().player;
            if (!((saved2 == null))) {
                b.m3(b.m1());
                b.m2();
            }
        }
        arg1.cancel();
        GLFW.glfwSetWindowTitle(this.handle, WindowMixin.TEXT_CRYPTIX_1_0_8);
    }

    public WindowMixin() {
    }

    static {
        TEXT_CRYPTIX_1_0_8 = new String("Cryptix | 1.0.8");
    }
}
