package cryptix.mixin;

import cryptix.event.Events;
import cryptix.module.ModuleManager;
import cryptix.recovery.JvmSupport;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/xk.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {Entity.class})
public abstract class EntityMixin {

    @Shadow
    public abstract void setSwimming(boolean arg0);

    @Shadow
    protected static Vec3 getInputVector(Vec3 arg0, float arg1, float arg2) {
        throw JvmSupport.rethrow(((Throwable) (Object) new AssertionError()));
    }

    public EntityMixin() {
    }

    @Overwrite
    public void moveRelative(float arg0, Vec3 arg1) {
        Entity reference3 = null;
        Vec3 reference4 = null;
        LocalPlayer saved1 = null;
        boolean saved2 = false;
        reference3 = ((Entity) (Object) this);
        reference4 = EntityMixin.getInputVector(arg1, arg0, reference3.getYRot());
        saved1 = Minecraft.getInstance().player;
        if (!((reference3 != saved1))) {
            saved2 = Events.rotation.m85();
            if (saved2) {
                reference4 = EntityMixin.getInputVector(arg1, arg0, Events.rotation.getYaw());
            }
        }
        reference3.setDeltaMovement(reference3.getDeltaMovement().add(reference4));
    }

    @Inject(method = {"updateSwimming"}, at = {@At(value = "HEAD")}, cancellable = true)
    private void pm$47(CallbackInfo arg0) {
        boolean saved1 = false;
        saved1 = ModuleManager.antiSwim.isEnabled();
        if (saved1) {
            this.setSwimming(false);
            arg0.cancel();
        }
    }
}
