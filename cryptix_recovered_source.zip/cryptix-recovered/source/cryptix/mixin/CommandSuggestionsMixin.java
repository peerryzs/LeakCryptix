package cryptix.mixin;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import cryptix.command.Command;
import cryptix.command.CommandManager;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.CommandSuggestions;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Reconstructed from mixins/vk.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {CommandSuggestions.class})
public class CommandSuggestionsMixin {
    private static final String TEXT_EMPTY;
    private static final String TEXT_EMPTY_2;
    @Shadow
    @Final
    private EditBox input;
    private static final String TEXT_EMPTY_3;

    @ModifyVariable(method = {"updateCommandInfo"}, at = @At(value = "STORE"), ordinal = 1)
    private boolean pm$17(boolean arg0) {
        boolean saved1 = false;
        int branchValue2 = 0;
        int integer0 = 0;
        if (!(arg0)) {
            saved1 = this.input.getValue().startsWith(CommandSuggestionsMixin.TEXT_EMPTY_3);
            branchValue2 = (saved1 ? 1 : 0);
        } else {
            branchValue2 = 1;
        }
        integer0 = branchValue2;
        return (integer0 != 0);
    }

    @Redirect(method = {"updateCommandInfo"}, at = @At(value = "INVOKE", target = "Lcom/mojang/brigadier/CommandDispatcher;getCompletionSuggestions(Lcom/mojang/brigadier/ParseResults;I)Ljava/util/concurrent/CompletableFuture;"))
    private CompletableFuture pm$19(CommandDispatcher arg0, ParseResults arg1, int arg2) {
        Object reference0 = this;
        String reference4 = null;
        boolean saved1 = false;
        String reference5 = null;
        int integer6 = 0;
        String reference7 = null;
        boolean saved2 = false;
        Object reference8 = null;
        int saved3 = 0;
        Object reference9 = null;
        Command reference10 = null;
        Object reference11 = null;
        Object reference12 = null;
        int saved4 = 0;
        int integer13 = 0;
        int integer14 = 0;
        SuggestionsBuilder reference15 = null;
        reference4 = ((CommandSuggestionsMixin) reference0).input.getValue();
        saved1 = reference4.startsWith(CommandSuggestionsMixin.TEXT_EMPTY_3);
        if (!(saved1)) {
            reference0 = arg0.getCompletionSuggestions(arg1, arg2);
            return ((CompletableFuture) reference0);
        } else {
            reference5 = reference4.substring(1);
            integer6 = Math.max(0, (arg2 - 1));
            integer6 = Math.min(integer6, reference5.length());
            reference7 = reference5.substring(0, integer6);
            saved2 = reference7.contains(CommandSuggestionsMixin.TEXT_EMPTY_2);
            if (!(saved2)) {
                reference8 = new SuggestionsBuilder(reference4, 1);
                reference0 = SharedSuggestionProvider.suggest(((Iterable) (Object) CommandManager.m11()), ((SuggestionsBuilder) reference8));
                return ((CompletableFuture) reference0);
            } else {
                reference8 = reference7.split(CommandSuggestionsMixin.TEXT_EMPTY_2, -1);
                saved3 = ((String[]) reference8).length;
                reference9 = (!((saved3 <= 0)) ? ((String[]) reference8)[0] : CommandSuggestionsMixin.TEXT_EMPTY);
                reference10 = CommandManager.m10(((String) reference9));
                if (!((reference10 != null))) {
                    reference11 = CommandManager.m11();
                    reference12 = new SuggestionsBuilder(reference4, 1);
                    reference0 = SharedSuggestionProvider.suggest(((Iterable) reference11), ((SuggestionsBuilder) reference12));
                    return ((CompletableFuture) reference0);
                } else {
                    saved4 = ((String[]) reference8).length;
                    if (!((saved4 > 1))) {
                        reference11 = new String[] {};
                    } else {
                        reference11 = ((String[]) (Object) Arrays.copyOfRange(((Object[]) reference8), 1, ((String[]) reference8).length));
                    }
                    reference12 = reference10.m1(((String[]) reference11));
                    integer13 = reference7.lastIndexOf(32);
                    if (!((integer13 != -1))) {
                        integer14 = 1;
                    } else {
                        integer14 = ((integer13 + 1) + 1);
                    }
                    reference15 = new SuggestionsBuilder(reference4, integer14);
                    reference0 = SharedSuggestionProvider.suggest(((Iterable) reference12), reference15);
                    return ((CompletableFuture) reference0);
                }
            }
        }
    }

    @ModifyVariable(method = {"updateCommandInfo"}, at = @At(value = "STORE"), ordinal = 0)
    private StringReader pm$18(StringReader arg0) {
        Object reference0 = this;
        boolean saved1 = false;
        boolean saved2 = false;
        char saved3 = 0;
        saved1 = ((CommandSuggestionsMixin) reference0).input.getValue().startsWith(CommandSuggestionsMixin.TEXT_EMPTY_3);
        if (saved1) {
            saved2 = arg0.canRead();
            if (saved2) {
                saved3 = arg0.peek();
                if (!((saved3 != 46))) {
                    arg0.skip();
                }
            }
        }
        reference0 = arg0;
        return ((StringReader) reference0);
    }

    public CommandSuggestionsMixin() {
    }

    @Inject(method = {"formatChat"}, at = {@At(value = "HEAD")}, cancellable = true)
    private void pm$20(String arg0, int arg1, CallbackInfoReturnable arg2) {
        boolean saved1 = false;
        saved1 = this.input.getValue().startsWith(CommandSuggestionsMixin.TEXT_EMPTY_3);
        if (saved1) {
            arg2.setReturnValue(FormattedCharSequence.forward(arg0, Style.EMPTY.withColor(ChatFormatting.GRAY)));
        }
    }

    static {
        TEXT_EMPTY_3 = new String(".");
        TEXT_EMPTY_2 = new String(" ");
        TEXT_EMPTY = new String("");
    }
}
