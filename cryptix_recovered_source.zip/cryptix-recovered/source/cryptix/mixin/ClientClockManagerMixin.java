package cryptix.mixin;

import java.util.Map;
import net.minecraft.client.ClientClockManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Reconstructed from mixins/ta.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {ClientClockManager.class})
public interface ClientClockManagerMixin {

    @Accessor(value = "clocks")
    public abstract Map getClocks();
}
