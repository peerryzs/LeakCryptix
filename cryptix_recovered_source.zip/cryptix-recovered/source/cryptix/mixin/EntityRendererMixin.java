package cryptix.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import cryptix.event.Events;
import cryptix.event.impl.EntityColorEvent;
import cryptix.event.impl.NameTagRenderEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ARGB;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/jb.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {EntityRenderer.class})
public abstract class EntityRendererMixin {
    private Entity f230;

    @Inject(method = {"extractRenderState(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/entity/state/EntityRenderState;F)V"}, at = {@At(value = "TAIL")})
    private void pm$56(Entity arg0, EntityRenderState arg1, float arg2, CallbackInfo arg3) {
        int integer5 = 0;
        EntityColorEvent saved1 = null;
        EntityColorEvent reference6 = null;
        integer5 = (Minecraft.getInstance().shouldEntityAppearGlowing(arg0) ? 1 : 0);
        saved1 = Events.entityColor;
        reference6 = saved1.update((!((integer5 == 0)) ? ARGB.opaque(arg0.getTeamColor()) : 0), arg0);
        reference6.dispatch();
        arg1.outlineColor = reference6.getColor();
    }

    @Inject(method = {"extractRenderState(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/entity/state/EntityRenderState;F)V"}, at = {@At(value = "HEAD")})
    private void pm$57(Entity arg0, EntityRenderState arg1, float arg2, CallbackInfo arg3) {
        this.f230 = arg0;
    }

    public EntityRendererMixin() {
    }

    @Inject(method = {"submitNameDisplay(Lnet/minecraft/client/renderer/entity/state/EntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;I)V"}, at = {@At(value = "HEAD")}, cancellable = true)
    private void pm$55(EntityRenderState arg0, PoseStack arg1, SubmitNodeCollector arg2, CameraRenderState arg3, int arg4, CallbackInfo arg5) {
        Component saved1 = null;
        NameTagRenderEvent saved2 = null;
        Component saved3 = null;
        Vec3 saved4 = null;
        int saved5 = 0;
        boolean saved6 = false;
        NameTagRenderEvent reference7 = null;
        Component saved7 = null;
        NameTagRenderEvent saved8 = null;
        Component saved9 = null;
        Vec3 saved10 = null;
        int saved11 = 0;
        boolean saved12 = false;
        arg1.pushPose();
        saved1 = arg0.scoreText;
        if (!((saved1 == null))) {
            saved2 = Events.nameTagRender;
            saved3 = arg0.scoreText;
            saved4 = arg0.nameTagAttachment;
            saved5 = arg0.lightCoords;
            saved6 = arg0.isDiscrete;
            reference7 = saved2.m22(arg1, saved3, saved4, arg4, saved5, ((!(saved6) ? 1 : 0) != 0), this.f230);
            reference7.dispatch();
            arg2.submitNameTag(arg1, reference7.m25(), reference7.m26(), reference7.m24(), reference7.m28(), reference7.m27(), arg3);
            arg1.translate(0.0f, 0.25875f, 0.0f);
        }
        saved7 = arg0.nameTag;
        if (!((saved7 == null))) {
            saved8 = Events.nameTagRender;
            saved9 = arg0.nameTag;
            saved10 = arg0.nameTagAttachment;
            saved11 = arg0.lightCoords;
            saved12 = arg0.isDiscrete;
            reference7 = saved8.m22(arg1, saved9, saved10, arg4, saved11, ((!(saved12) ? 1 : 0) != 0), this.f230);
            reference7.dispatch();
            arg2.submitNameTag(arg1, reference7.m25(), reference7.m26(), reference7.m24(), reference7.m28(), reference7.m27(), arg3);
        }
        arg1.popPose();
        arg5.cancel();
    }
}
