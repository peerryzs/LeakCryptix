package cryptix.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Reconstructed from mixins/ss.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(targets = {"net.minecraft.client.ClientClockManager$ClockInstance"})
public interface ssMixin {

    @Accessor(value = "totalTicks")
    public abstract long getTotalTicks();

    @Accessor(value = "totalTicks")
    public abstract void setTotalTicks(long arg0);
}
