package cryptix.mixin;

import com.mojang.authlib.GameProfile;
import cryptix.event.Events;
import cryptix.event.impl.ItemUseSlowdownEvent;
import cryptix.event.impl.MotionEvent;
import cryptix.event.impl.PostMotionEvent;
import cryptix.event.impl.SprintEvent;
import cryptix.recovery.JvmSupport;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/ei.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {LocalPlayer.class})
public abstract class LocalPlayerMixin_ei extends AbstractClientPlayer {
    @Shadow
    private float yRotLast;
    @Shadow
    private double yLast;
    @Shadow
    @Final
    public ClientPacketListener connection;
    @Shadow
    private int sprintTriggerTime;
    @Shadow
    private double xLast;
    @Shadow
    private boolean autoJumpEnabled;
    @Shadow
    private boolean lastOnGround;
    @Shadow
    private int positionReminder;
    @Shadow
    private float xRotLast;
    @Shadow
    private double zLast;
    @Shadow
    private boolean lastHorizontalCollision;
    @Shadow
    @Final
    protected Minecraft minecraft;

    @Inject(method = {"aiStep"}, at = {@At(value = "FIELD", target = "Lnet/minecraft/world/entity/player/Abilities;mayfly:Z", opcode = 180)})
    private void pm$53(CallbackInfo arg0) {
        Events.playerAiStep.dispatch();
    }

    public LocalPlayerMixin_ei(ClientLevel arg0, GameProfile arg1) {
        super(arg0, arg1);
    }

    @Redirect(method = {"modifyInput"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;itemUseSpeedMultiplier()F"))
    private float pm$51(LocalPlayer arg0) {
        ItemUseSlowdownEvent reference2 = null;
        float floating0 = 0.0f;
        reference2 = Events.itemUseSlowdown.update(this.itemUseSpeedMultiplier());
        reference2.dispatch();
        floating0 = reference2.getMultiplier();
        return floating0;
    }

    @Shadow
    protected abstract float itemUseSpeedMultiplier();

    @Overwrite
    private void sendPosition() {
        MotionEvent reference1 = null;
        boolean saved1 = false;
        float floating3 = 0.0f;
        float floating4 = 0.0f;
        double number5 = 0.0;
        double number7 = 0.0;
        double number9 = 0.0;
        double number11 = 0.0;
        double number13 = 0.0;
        int saved2 = 0;
        int saved3 = 0;
        int branchValue4 = 0;
        int integer15 = 0;
        int saved5 = 0;
        int saved6 = 0;
        int branchValue7 = 0;
        int integer2 = 0;
        int integer16 = 0;
        boolean saved8 = false;
        boolean saved9 = false;
        boolean saved10 = false;
        boolean saved11 = false;
        boolean saved12 = false;
        boolean saved13 = false;
        boolean saved14 = false;
        boolean saved15 = false;
        PostMotionEvent reference2 = null;
        reference1 = Events.motion.update(this.getX(), this.getY(), this.getZ(), this.onGround(), this.horizontalCollision);
        reference1.dispatch();
        this.sendIsSprintingIfNeeded();
        saved1 = this.isControlledCamera();
        if (saved1) {
            floating3 = Events.rotation.getYaw();
            floating4 = Events.rotation.getPitch();
            number5 = (reference1.getX() - this.xLast);
            number7 = (reference1.getY() - this.yLast);
            number9 = (reference1.getZ() - this.zLast);
            number11 = ((double) (floating3 - this.yRotLast));
            number13 = ((double) (floating4 - this.xRotLast));
            this.positionReminder = (this.positionReminder + 1);
            saved2 = JvmSupport.dcmpl(Mth.lengthSquared(number5, number7, number9), Mth.square(0.0002));
            if (!((saved2 > 0))) {
                saved3 = this.positionReminder;
                branchValue4 = (!((saved3 < 20)) ? 1 : 0);
            } else {
                branchValue4 = 1;
            }
            integer15 = branchValue4;
            saved5 = JvmSupport.dcmpl(number11, 0.0);
            if (!((saved5 != 0))) {
                saved6 = JvmSupport.dcmpl(number13, 0.0);
                branchValue7 = (!((saved6 == 0)) ? 1 : 0);
            } else {
                branchValue7 = 1;
            }
            integer2 = branchValue7;
            integer16 = branchValue7;
            if (!((integer15 == 0))) {
                if (!((integer2 == 0))) {
                    this.connection.send(((Packet) (Object) new ServerboundMovePlayerPacket.PosRot(reference1.getX(), reference1.getY(), reference1.getZ(), floating3, floating4, reference1.isOnGround(), reference1.hasHorizontalCollision())));
                } else {
                    if (!((integer15 == 0))) {
                        this.connection.send(((Packet) (Object) new ServerboundMovePlayerPacket.Pos(reference1.getX(), reference1.getY(), reference1.getZ(), reference1.isOnGround(), reference1.hasHorizontalCollision())));
                    } else {
                        if (!((integer2 == 0))) {
                            this.connection.send(((Packet) (Object) new ServerboundMovePlayerPacket.Rot(floating3, floating4, reference1.isOnGround(), reference1.hasHorizontalCollision())));
                        } else {
                            saved8 = this.lastOnGround;
                            saved9 = reference1.isOnGround();
                            if (!((saved8 != saved9))) {
                                saved10 = this.lastHorizontalCollision;
                                saved11 = reference1.hasHorizontalCollision();
                                if (!((saved10 == saved11))) {
                                    this.connection.send(((Packet) (Object) new ServerboundMovePlayerPacket.StatusOnly(reference1.isOnGround(), reference1.hasHorizontalCollision())));
                                }
                            } else {
                                this.connection.send(((Packet) (Object) new ServerboundMovePlayerPacket.StatusOnly(reference1.isOnGround(), reference1.hasHorizontalCollision())));
                            }
                        }
                    }
                }
            } else {
                if (!((integer15 == 0))) {
                    this.connection.send(((Packet) (Object) new ServerboundMovePlayerPacket.Pos(reference1.getX(), reference1.getY(), reference1.getZ(), reference1.isOnGround(), reference1.hasHorizontalCollision())));
                } else {
                    if (!((integer2 == 0))) {
                        this.connection.send(((Packet) (Object) new ServerboundMovePlayerPacket.Rot(floating3, floating4, reference1.isOnGround(), reference1.hasHorizontalCollision())));
                    } else {
                        saved12 = this.lastOnGround;
                        saved13 = reference1.isOnGround();
                        if (!((saved12 != saved13))) {
                            saved14 = this.lastHorizontalCollision;
                            saved15 = reference1.hasHorizontalCollision();
                            if (!((saved14 == saved15))) {
                                this.connection.send(((Packet) (Object) new ServerboundMovePlayerPacket.StatusOnly(reference1.isOnGround(), reference1.hasHorizontalCollision())));
                            }
                        } else {
                            this.connection.send(((Packet) (Object) new ServerboundMovePlayerPacket.StatusOnly(reference1.isOnGround(), reference1.hasHorizontalCollision())));
                        }
                    }
                }
            }
            if (!((integer15 == 0))) {
                this.xLast = reference1.getX();
                this.yLast = reference1.getY();
                this.zLast = reference1.getZ();
                this.positionReminder = 0;
            }
            if (!((integer2 == 0))) {
                this.yRotLast = floating3;
                this.xRotLast = floating4;
            }
            this.lastOnGround = reference1.isOnGround();
            this.lastHorizontalCollision = reference1.hasHorizontalCollision();
            this.autoJumpEnabled = ((Boolean) this.minecraft.options.autoJump().get()).booleanValue();
        }
        reference2 = Events.postMotion;
        reference2.dispatch();
    }

    @Shadow
    protected abstract boolean canStartSprinting();

    @Redirect(method = {"aiStep"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;canStartSprinting()Z"))
    private boolean pm$52(LocalPlayer arg0) {
        SprintEvent reference2 = null;
        int integer0 = 0;
        reference2 = Events.sprint.m96(this.sprintTriggerTime, this.canStartSprinting());
        reference2.dispatch();
        integer0 = (reference2.m99() ? 1 : 0);
        return (integer0 != 0);
    }

    @Shadow
    protected abstract boolean isControlledCamera();

    @Inject(method = {"tick"}, at = {@At(value = "HEAD")}, cancellable = true)
    private void pm$50(CallbackInfo arg0) {
        boolean saved1 = false;
        Events.rotation.update(this.getYRot(), this.getXRot()).dispatch();
        saved1 = Events.rotation.isCancelled();
        if (saved1) {
            arg0.cancel();
        }
    }

    @Shadow
    protected abstract void sendIsSprintingIfNeeded();
}
