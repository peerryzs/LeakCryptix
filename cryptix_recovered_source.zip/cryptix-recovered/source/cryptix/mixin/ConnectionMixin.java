package cryptix.mixin;

import cryptix.event.Events;
import cryptix.event.impl.PacketReceiveEvent;
import cryptix.event.impl.PacketSendEvent;
import cryptix.network.PacketBuffer;
import cryptix.util.Recovered_gt;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.game.ClientboundStartConfigurationPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/aw.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {Connection.class})
public class ConnectionMixin {

    @Inject(method = {"channelRead0"}, at = {@At(value = "HEAD")}, cancellable = true)
    private void pm$22(ChannelHandlerContext arg0, Packet arg1, CallbackInfo arg2) {
        PacketReceiveEvent reference4 = null;
        boolean saved1 = false;
        boolean saved2 = false;
        boolean saved3 = false;
        reference4 = Events.packetReceive.update(arg1);
        reference4.dispatch();
        saved1 = (arg1 instanceof ClientboundDisconnectPacket);
        if (!(saved1)) {
            saved2 = (arg1 instanceof ClientboundStartConfigurationPacket);
            if (saved2) {
                PacketBuffer.stopAndFlush();
            }
        } else {
            PacketBuffer.stopAndFlush();
        }
        saved3 = reference4.isCancelled();
        if (saved3) {
            arg2.cancel();
        }
    }

    @Inject(method = {"send(Lnet/minecraft/network/protocol/Packet;Lio/netty/channel/ChannelFutureListener;Z)V"}, at = {@At(value = "HEAD")}, cancellable = true)
    private void pm$21(Packet arg0, ChannelFutureListener arg1, boolean arg2, CallbackInfo arg3) {
        PacketSendEvent reference5 = null;
        boolean saved1 = false;
        boolean saved2 = false;
        boolean saved3 = false;
        reference5 = Events.packetSend.update(arg0);
        reference5.dispatch();
        saved1 = reference5.isCancelled();
        if (saved1) {
            arg3.cancel();
            return;
        } else {
            saved2 = PacketBuffer.queuePacket(reference5.getPacket());
            if (saved2) {
                arg3.cancel();
            }
            saved3 = Recovered_gt.m25(reference5.getPacket());
            if (saved3) {
                arg3.cancel();
            }
            return;
        }
    }

    public ConnectionMixin() {
    }
}
