package cryptix.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import cryptix.event.Events;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/ih.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {GameRenderer.class})
public class GameRendererMixin {

    @Inject(method = {"bobHurt"}, at = {@At(value = "HEAD")}, cancellable = true)
    private void pm$58(CameraRenderState arg0, PoseStack arg1, CallbackInfo arg2) {
        boolean saved1 = false;
        Events.hurtCamera.dispatch();
        saved1 = Events.hurtCamera.isCancelled();
        if (saved1) {
            arg2.cancel();
        }
    }

    public GameRendererMixin() {
    }
}
