package cryptix.mixin;

import cryptix.event.Events;
import cryptix.event.impl.MovementInputEvent;
import cryptix.event.impl.PostInputEvent;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.world.entity.player.Input;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/hv.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {KeyboardInput.class})
public class KeyboardInputMixin {

    public KeyboardInputMixin() {
    }

    @Inject(method = {"tick"}, at = {@At(value = "HEAD")})
    private void pm$39(CallbackInfo arg0) {
        KeyboardInput reference2 = null;
        Input reference3 = null;
        MovementInputEvent reference4 = null;
        reference2 = ((KeyboardInput) (Object) this);
        reference3 = reference2.keyPresses;
        reference4 = Events.movementInput.m48(reference3.forward(), reference3.backward(), reference3.left(), reference3.right(), reference3.jump(), reference3.shift(), reference3.sprint());
        reference4.dispatch();
        reference2.keyPresses = new Input(reference4.m49(), reference4.m50(), reference4.m51(), reference4.m52(), reference4.m53(), reference4.m54(), reference4.m55());
    }

    @Inject(method = {"tick"}, at = {@At(value = "TAIL")})
    private void pm$40(CallbackInfo arg0) {
        PostInputEvent reference2 = null;
        reference2 = Events.postInput;
        reference2.dispatch();
    }
}
