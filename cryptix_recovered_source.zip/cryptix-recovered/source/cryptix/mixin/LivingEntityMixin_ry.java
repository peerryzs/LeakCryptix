package cryptix.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import cryptix.event.Events;
import cryptix.module.ModuleManager;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Reconstructed from mixins/ry.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {LivingEntity.class})
public abstract class LivingEntityMixin_ry {

    @ModifyExpressionValue(method = {"jumpFromGround"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getYRot()F")})
    private float pm$49(float arg0) {
        boolean saved1 = false;
        boolean saved2 = false;
        float floating0 = 0.0f;
        saved1 = Events.rotation.m85();
        if (saved1) {
            saved2 = Events.rotation.m87();
            floating0 = (saved2 ? Events.rotation.getYaw() : Events.motion.getYaw());
            return floating0;
        } else {
            floating0 = arg0;
            return floating0;
        }
    }

    @ModifyReturnValue(method = {"getCurrentSwingDuration"}, at = {@At(value = "RETURN")})
    private int pm$48(int arg0) {
        boolean saved1 = false;
        int integer0 = 0;
        saved1 = ModuleManager.animations.isEnabled();
        if (saved1) {
            integer0 = ((int) (((double) arg0) * ModuleManager.animations.swingTime.getValue()));
            return integer0;
        } else {
            integer0 = arg0;
            return integer0;
        }
    }

    public LivingEntityMixin_ry() {
    }
}
