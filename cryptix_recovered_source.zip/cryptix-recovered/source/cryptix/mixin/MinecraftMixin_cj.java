package cryptix.mixin;

import cryptix.event.Events;
import cryptix.gui.LicenseScreen;
import cryptix.module.ModuleManager;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/cj.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {Minecraft.class})
public class MinecraftMixin_cj {
    private LicenseScreen f227;
    private boolean f228;

    public MinecraftMixin_cj() {
        this.f228 = false;
    }

    @Inject(method = {"onResourceLoadFinished"}, at = {@At(value = "TAIL")})
    private void pm$41(CallbackInfo arg0) {
        boolean saved1 = false;
        saved1 = this.f228;
        if (!(saved1)) {
            this.f227 = new LicenseScreen();
            Minecraft.getInstance().gui.setScreen(this.f227);
            ModuleManager.initializeSortedModules();
            this.f228 = true;
        }
    }

    @Inject(method = {"run"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/util/profiling/SingleTickProfiler;createTickProfiler(Ljava/lang/String;)Lnet/minecraft/util/profiling/SingleTickProfiler;", shift = At.Shift.BEFORE)})
    private void pm$42(CallbackInfo arg0) {
        boolean saved1 = false;
        LicenseScreen saved2 = null;
        int saved3 = 0;
        saved1 = (Minecraft.getInstance().gui.screen() instanceof LicenseScreen);
        if (!(saved1)) {
            saved2 = this.f227;
            if (!((saved2 == null))) {
                saved3 = LicenseScreen.f21.length();
                if (!((saved3 == 16))) {
                    System.exit(0);
                }
            }
        }
    }

    @Inject(method = {"handleKeybinds"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;handleKeybinds()V", shift = At.Shift.AFTER)})
    private void pm$43(CallbackInfo arg0) {
        Events.keybind.dispatch();
    }
}
