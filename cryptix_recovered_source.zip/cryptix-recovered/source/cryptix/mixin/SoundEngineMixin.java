package cryptix.mixin;

import cryptix.event.Events;
import cryptix.event.impl.SoundPlayEvent;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundEngine;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Reconstructed from mixins/ti.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {SoundEngine.class})
public class SoundEngineMixin {

    @Inject(method = {"play"}, at = {@At(value = "HEAD")}, cancellable = true)
    private void pm$45(SoundInstance arg0, CallbackInfoReturnable arg1) {
        SoundPlayEvent reference3 = null;
        boolean saved1 = false;
        reference3 = Events.soundPlay.update(arg0.getIdentifier());
        reference3.dispatch();
        saved1 = reference3.isCancelled();
        if (saved1) {
            arg1.setReturnValue(SoundEngine.PlayResult.NOT_STARTED);
        }
    }

    public SoundEngineMixin() {
    }
}
