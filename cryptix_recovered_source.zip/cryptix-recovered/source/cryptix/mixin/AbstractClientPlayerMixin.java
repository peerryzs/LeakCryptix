package cryptix.mixin;

import cryptix.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Reconstructed from mixins/xi.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {AbstractClientPlayer.class})
public class AbstractClientPlayerMixin {
    private static final String TEXT_CAPE3_PNG;
    private static final String TEXT_CAPE;
    private static final String TEXT_CRYPTIX;
    @Unique
    private static final ClientAsset.Texture f212;
    private static final String TEXT_CRYPTIX_2;
    @Unique
    private static final ClientAsset.Texture f211;
    private static final String TEXT_CAPE3;
    @Unique
    private static final ClientAsset.Texture f214;
    @Unique
    private static final ClientAsset.Texture f213;
    private static final String TEXT_CAPE2;
    private static final String TEXT_CAPE4;
    private static final String TEXT_CAT;
    private static final String TEXT_PUSHY;
    private static final String TEXT_SKY;
    private static final String TEXT_CAPE_PNG;
    private static final String TEXT_CAPE2_PNG;
    private static final String TEXT_CAPE4_PNG;

    static {
        TEXT_CRYPTIX = new String("Cryptix");
        TEXT_CAT = new String("Cat");
        TEXT_PUSHY = new String("Pushy");
        TEXT_SKY = new String("Sky");
        TEXT_CRYPTIX_2 = new String("cryptix");
        TEXT_CAPE = new String("cape");
        TEXT_CAPE_PNG = new String("cape.png");
        TEXT_CAPE2 = new String("cape2");
        TEXT_CAPE2_PNG = new String("cape2.png");
        TEXT_CAPE3 = new String("cape3");
        TEXT_CAPE3_PNG = new String("cape3.png");
        TEXT_CAPE4 = new String("cape4");
        TEXT_CAPE4_PNG = new String("cape4.png");
        f211 = ((ClientAsset.Texture) (Object) new ClientAsset.ResourceTexture(Identifier.fromNamespaceAndPath(AbstractClientPlayerMixin.TEXT_CRYPTIX_2, AbstractClientPlayerMixin.TEXT_CAPE), Identifier.fromNamespaceAndPath(AbstractClientPlayerMixin.TEXT_CRYPTIX_2, AbstractClientPlayerMixin.TEXT_CAPE_PNG)));
        f212 = ((ClientAsset.Texture) (Object) new ClientAsset.ResourceTexture(Identifier.fromNamespaceAndPath(AbstractClientPlayerMixin.TEXT_CRYPTIX_2, AbstractClientPlayerMixin.TEXT_CAPE2), Identifier.fromNamespaceAndPath(AbstractClientPlayerMixin.TEXT_CRYPTIX_2, AbstractClientPlayerMixin.TEXT_CAPE2_PNG)));
        f213 = ((ClientAsset.Texture) (Object) new ClientAsset.ResourceTexture(Identifier.fromNamespaceAndPath(AbstractClientPlayerMixin.TEXT_CRYPTIX_2, AbstractClientPlayerMixin.TEXT_CAPE3), Identifier.fromNamespaceAndPath(AbstractClientPlayerMixin.TEXT_CRYPTIX_2, AbstractClientPlayerMixin.TEXT_CAPE3_PNG)));
        f214 = ((ClientAsset.Texture) (Object) new ClientAsset.ResourceTexture(Identifier.fromNamespaceAndPath(AbstractClientPlayerMixin.TEXT_CRYPTIX_2, AbstractClientPlayerMixin.TEXT_CAPE4), Identifier.fromNamespaceAndPath(AbstractClientPlayerMixin.TEXT_CRYPTIX_2, AbstractClientPlayerMixin.TEXT_CAPE4_PNG)));
    }

    public AbstractClientPlayerMixin() {
    }

    @Inject(method = {"getSkin"}, at = {@At(value = "RETURN")}, cancellable = true)
    private void pm$14(CallbackInfoReturnable arg0) {
        AbstractClientPlayer reference2 = null;
        LocalPlayer saved1 = null;
        boolean saved2 = false;
        PlayerSkin reference3 = null;
        String reference4 = null;
        int integer5 = 0;
        String reference6 = null;
        int saved3 = 0;
        boolean saved4 = false;
        boolean saved5 = false;
        boolean saved6 = false;
        boolean saved7 = false;
        reference2 = ((AbstractClientPlayer) (Object) this);
        saved1 = Minecraft.getInstance().player;
        if (!((reference2 == saved1))) {
            return;
        } else {
            saved2 = ModuleManager.cape.isEnabled();
            if (saved2) {
                reference3 = ((PlayerSkin) arg0.getReturnValue());
                reference4 = ModuleManager.cape.cape.getValue();
                integer5 = -1;
                reference6 = reference4;
                saved3 = reference4.hashCode();
                if (!((saved3 != -1582842115))) {
                    saved4 = reference4.equals(AbstractClientPlayerMixin.TEXT_CRYPTIX);
                    if (saved4) {
                        integer5 = 0;
                    }
                } else {
                    if (!((saved3 != 67510))) {
                        saved5 = reference4.equals(AbstractClientPlayerMixin.TEXT_CAT);
                        if (saved5) {
                            integer5 = 1;
                        }
                    } else {
                        if (!((saved3 != 83201))) {
                            saved6 = reference4.equals(AbstractClientPlayerMixin.TEXT_SKY);
                            if (saved6) {
                                integer5 = 3;
                            }
                        } else {
                            if (!((saved3 != 77481087))) {
                                saved7 = reference4.equals(AbstractClientPlayerMixin.TEXT_PUSHY);
                                if (saved7) {
                                    integer5 = 2;
                                }
                            } else {
                            }
                        }
                    }
                }
                switch (integer5) {
                    case 0:
                    {
                        arg0.setReturnValue(PlayerSkin.insecure(reference3.body(), AbstractClientPlayerMixin.f211, reference3.elytra(), reference3.model()));
                        break;
                    }
                    case 1:
                    {
                        arg0.setReturnValue(PlayerSkin.insecure(reference3.body(), AbstractClientPlayerMixin.f212, reference3.elytra(), reference3.model()));
                        break;
                    }
                    case 2:
                    {
                        arg0.setReturnValue(PlayerSkin.insecure(reference3.body(), AbstractClientPlayerMixin.f213, reference3.elytra(), reference3.model()));
                        break;
                    }
                    case 3:
                    {
                        arg0.setReturnValue(PlayerSkin.insecure(reference3.body(), AbstractClientPlayerMixin.f214, reference3.elytra(), reference3.model()));
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
            }
            return;
        }
    }
}
