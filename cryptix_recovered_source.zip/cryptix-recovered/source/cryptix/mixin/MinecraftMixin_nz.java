package cryptix.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.User;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Reconstructed from mixins/nz.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {Minecraft.class})
public interface MinecraftMixin_nz {

    @Accessor(value = "rightClickDelay")
    public abstract int getRightClickDelay();

    @Accessor(value = "rightClickDelay")
    public abstract void setRightClickDelay(int arg0);

    @Accessor(value = "user")
    @Mutable
    public abstract void setUser(User arg0);

    @Accessor(value = "user")
    public abstract User getUser();
}
