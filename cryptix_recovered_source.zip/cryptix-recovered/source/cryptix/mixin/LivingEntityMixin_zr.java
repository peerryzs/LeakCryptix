package cryptix.mixin;

import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Reconstructed from mixins/zr.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {LivingEntity.class})
public interface LivingEntityMixin_zr {

    @Accessor(value = "noJumpDelay")
    public abstract void setNoJumpDelay(int arg0);
}
