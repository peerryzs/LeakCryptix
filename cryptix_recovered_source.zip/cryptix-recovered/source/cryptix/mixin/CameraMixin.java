package cryptix.mixin;

import cryptix.module.ModuleManager;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Pose;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Reconstructed from mixins/wg.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {Camera.class})
public class CameraMixin {

    @Redirect(method = {"tick"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getEyeHeight()F"))
    private float pm$15(Entity arg0) {
        boolean saved1 = false;
        boolean saved2 = false;
        float floating0 = 0.0f;
        saved1 = ModuleManager.animations.removeSneakAnim.getValue();
        if (saved1) {
            saved2 = ModuleManager.animations.isEnabled();
            if (saved2) {
                floating0 = arg0.getEyeHeight(Pose.STANDING);
                return floating0;
            } else {
                floating0 = arg0.getEyeHeight();
                return floating0;
            }
        } else {
            floating0 = arg0.getEyeHeight();
            return floating0;
        }
    }

    public CameraMixin() {
    }
}
