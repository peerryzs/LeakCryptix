package cryptix.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import cryptix.module.ModuleManager;
import cryptix.module.impl.combat.KillAura;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/xj.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {ItemInHandRenderer.class})
public class ItemInHandRendererMixin {
    private static final String TEXT_1_7;
    private static final String TEXT_EXHIBITION;

    static {
        TEXT_1_7 = new String("1.7");
        TEXT_EXHIBITION = new String("Exhibition");
    }

    @Inject(method = {"submitArmWithItem"}, slice = {@Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getUseAnimation()Lnet/minecraft/world/item/ItemUseAnimation;"))}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;applyItemArmTransform(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/entity/HumanoidArm;F)V", shift = At.Shift.AFTER)})
    private void pm$37(AbstractClientPlayer arg0, float arg1, float arg2, InteractionHand arg3, float arg4, ItemStack arg5, float arg6, PoseStack arg7, SubmitNodeCollector arg8, int arg9, CallbackInfo arg10) {
        boolean saved1 = false;
        KillAura reference12 = null;
        boolean saved2 = false;
        int saved3 = 0;
        boolean saved4 = false;
        InteractionHand saved5 = null;
        ItemUseAnimation saved6 = null;
        ItemUseAnimation saved7 = null;
        int branchValue8 = 0;
        int branchValue9 = 0;
        int branchValue10 = 0;
        InteractionHand saved11 = null;
        ItemUseAnimation saved12 = null;
        ItemUseAnimation saved13 = null;
        int branchValue14 = 0;
        int branchValue15 = 0;
        boolean saved16 = false;
        InteractionHand saved17 = null;
        ItemUseAnimation saved18 = null;
        ItemUseAnimation saved19 = null;
        int branchValue20 = 0;
        int branchValue21 = 0;
        int branchValue22 = 0;
        int branchValue23 = 0;
        int integer13 = 0;
        boolean saved24 = false;
        float floating14 = 0.0f;
        float floating15 = 0.0f;
        float floating16 = 0.0f;
        float floating17 = 0.0f;
        float floating18 = 0.0f;
        float floating19 = 0.0f;
        HumanoidArm reference20 = null;
        HumanoidArm saved25 = null;
        float floating21 = 0.0f;
        String reference22 = null;
        String reference23 = null;
        int integer24 = 0;
        String reference25 = null;
        int saved26 = 0;
        boolean saved27 = false;
        boolean saved28 = false;
        HumanoidArm saved29 = null;
        int saved30 = 0;
        boolean saved31 = false;
        boolean saved32 = false;
        saved1 = ModuleManager.animations.isEnabled();
        if (!(saved1)) {
            return;
        } else {
            reference12 = ModuleManager.killAura;
            saved2 = arg0.isUsingItem();
            if (saved2) {
                saved3 = arg0.getUseItemRemainingTicks();
                if (!((saved3 > 0))) {
                    if (!((reference12 == null))) {
                        saved4 = reference12.f16;
                        if (saved4) {
                            saved5 = arg0.getUsedItemHand();
                            if (!((saved5 != arg3))) {
                                saved6 = arg5.getUseAnimation();
                                saved7 = ItemUseAnimation.BLOCK;
                                branchValue8 = (!((saved6 != saved7)) ? 1 : 0);
                            } else {
                                branchValue8 = 0;
                            }
                            branchValue9 = branchValue8;
                        } else {
                            branchValue9 = 0;
                        }
                        branchValue10 = branchValue9;
                    } else {
                        branchValue10 = 0;
                    }
                    branchValue15 = branchValue10;
                } else {
                    saved11 = arg0.getUsedItemHand();
                    if (!((saved11 != arg3))) {
                        saved12 = arg5.getUseAnimation();
                        saved13 = ItemUseAnimation.BLOCK;
                        branchValue14 = (!((saved12 != saved13)) ? 1 : 0);
                    } else {
                        branchValue14 = 0;
                    }
                    branchValue15 = branchValue14;
                }
                branchValue23 = branchValue15;
            } else {
                if (!((reference12 == null))) {
                    saved16 = reference12.f16;
                    if (saved16) {
                        saved17 = arg0.getUsedItemHand();
                        if (!((saved17 != arg3))) {
                            saved18 = arg5.getUseAnimation();
                            saved19 = ItemUseAnimation.BLOCK;
                            branchValue20 = (!((saved18 != saved19)) ? 1 : 0);
                        } else {
                            branchValue20 = 0;
                        }
                        branchValue21 = branchValue20;
                    } else {
                        branchValue21 = 0;
                    }
                    branchValue22 = branchValue21;
                } else {
                    branchValue22 = 0;
                }
                branchValue23 = branchValue22;
            }
            integer13 = branchValue23;
            saved24 = ModuleManager.animations.onlyWhileBlocking.getValue();
            if (saved24) {
                if (!((integer13 != 0))) {
                    return;
                } else {
                    floating14 = Mth.sin(((double) ((arg4 * arg4) * 3.1415927f)));
                    floating15 = Mth.sin(((double) (Mth.sqrt(arg4) * 3.1415927f)));
                    floating16 = ((float) ModuleManager.animations.scale.getValue());
                    floating17 = ((float) ModuleManager.animations.x.getValue());
                    floating18 = ((float) ModuleManager.animations.y.getValue());
                    floating19 = ((float) ModuleManager.animations.z.getValue());
                    reference20 = arg0.getMainArm();
                    saved25 = HumanoidArm.RIGHT;
                    floating21 = (!((reference20 != saved25)) ? 1.0f : -1.0f);
                    arg7.translate(floating17, floating18, floating19);
                    if (!((integer13 == 0))) {
                        reference22 = ModuleManager.animations.mode.getValue();
                        reference23 = reference22;
                        integer24 = -1;
                        reference25 = reference23;
                        saved26 = reference23.hashCode();
                        if (!((saved26 != -352259601))) {
                            saved27 = reference23.equals(ItemInHandRendererMixin.TEXT_EXHIBITION);
                            if (saved27) {
                                integer24 = 1;
                            }
                        } else {
                            if (!((saved26 != 48570))) {
                                saved28 = reference23.equals(ItemInHandRendererMixin.TEXT_1_7);
                                if (saved28) {
                                    integer24 = 0;
                                }
                            } else {
                            }
                        }
                        switch (integer24) {
                            case 0:
                            {
                                arg7.mulPose(((Quaternionfc) (Object) Axis.YP.rotationDegrees((45.0f * floating21))));
                                arg7.mulPose(((Quaternionfc) (Object) Axis.YP.rotationDegrees((-10.0f * floating21))));
                                arg7.mulPose(((Quaternionfc) (Object) Axis.YP.rotationDegrees(((floating14 * -20.0f) * floating21))));
                                arg7.mulPose(((Quaternionfc) (Object) Axis.ZP.rotationDegrees(((floating15 * -20.0f) * floating21))));
                                arg7.mulPose(((Quaternionfc) (Object) Axis.XP.rotationDegrees((floating15 * -80.0f))));
                                arg7.mulPose(((Quaternionfc) (Object) Axis.YP.rotationDegrees((-45.0f * floating21))));
                                break;
                            }
                            case 1:
                            {
                                arg7.mulPose(((Quaternionfc) (Object) Axis.XP.rotationDegrees(((-floating15) * 50.0f))));
                                arg7.mulPose(((Quaternionfc) (Object) Axis.YP.rotationDegrees(((-floating15) * 30.0f))));
                                break;
                            }
                            default:
                            {
                                break;
                            }
                        }
                        arg7.translate(0.0f, 0.06f, 0.0f);
                    }
                    arg7.scale((0.95f * floating16), (0.95f * floating16), (0.95f * floating16));
                    return;
                }
            } else {
                floating14 = Mth.sin(((double) ((arg4 * arg4) * 3.1415927f)));
                floating15 = Mth.sin(((double) (Mth.sqrt(arg4) * 3.1415927f)));
                floating16 = ((float) ModuleManager.animations.scale.getValue());
                floating17 = ((float) ModuleManager.animations.x.getValue());
                floating18 = ((float) ModuleManager.animations.y.getValue());
                floating19 = ((float) ModuleManager.animations.z.getValue());
                reference20 = arg0.getMainArm();
                saved29 = HumanoidArm.RIGHT;
                floating21 = (!((reference20 != saved29)) ? 1.0f : -1.0f);
                arg7.translate(floating17, floating18, floating19);
                if (!((integer13 == 0))) {
                    reference22 = ModuleManager.animations.mode.getValue();
                    reference23 = reference22;
                    integer24 = -1;
                    reference25 = reference23;
                    saved30 = reference23.hashCode();
                    if (!((saved30 != -352259601))) {
                        saved31 = reference23.equals(ItemInHandRendererMixin.TEXT_EXHIBITION);
                        if (saved31) {
                            integer24 = 1;
                        }
                    } else {
                        if (!((saved30 != 48570))) {
                            saved32 = reference23.equals(ItemInHandRendererMixin.TEXT_1_7);
                            if (saved32) {
                                integer24 = 0;
                            }
                        } else {
                        }
                    }
                    switch (integer24) {
                        case 0:
                        {
                            arg7.mulPose(((Quaternionfc) (Object) Axis.YP.rotationDegrees((45.0f * floating21))));
                            arg7.mulPose(((Quaternionfc) (Object) Axis.YP.rotationDegrees((-10.0f * floating21))));
                            arg7.mulPose(((Quaternionfc) (Object) Axis.YP.rotationDegrees(((floating14 * -20.0f) * floating21))));
                            arg7.mulPose(((Quaternionfc) (Object) Axis.ZP.rotationDegrees(((floating15 * -20.0f) * floating21))));
                            arg7.mulPose(((Quaternionfc) (Object) Axis.XP.rotationDegrees((floating15 * -80.0f))));
                            arg7.mulPose(((Quaternionfc) (Object) Axis.YP.rotationDegrees((-45.0f * floating21))));
                            break;
                        }
                        case 1:
                        {
                            arg7.mulPose(((Quaternionfc) (Object) Axis.XP.rotationDegrees(((-floating15) * 50.0f))));
                            arg7.mulPose(((Quaternionfc) (Object) Axis.YP.rotationDegrees(((-floating15) * 30.0f))));
                            break;
                        }
                        default:
                        {
                            break;
                        }
                    }
                    arg7.translate(0.0f, 0.06f, 0.0f);
                }
                arg7.scale((0.95f * floating16), (0.95f * floating16), (0.95f * floating16));
                return;
            }
        }
    }

    @Redirect(method = {"submitArmWithItem"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/AbstractClientPlayer;isUsingItem()Z"))
    private boolean pm$35(AbstractClientPlayer arg0) {
        KillAura reference2 = null;
        boolean saved1 = false;
        ItemStack reference3 = null;
        boolean saved2 = false;
        ItemUseAnimation saved3 = null;
        ItemUseAnimation saved4 = null;
        int integer0 = 0;
        reference2 = ModuleManager.killAura;
        if (!((reference2 == null))) {
            saved1 = reference2.f16;
            if (saved1) {
                reference3 = arg0.getMainHandItem();
                saved2 = reference3.isEmpty();
                if (!(saved2)) {
                    saved3 = reference3.getUseAnimation();
                    saved4 = ItemUseAnimation.BLOCK;
                    if (!((saved3 != saved4))) {
                        integer0 = 1;
                        return (integer0 != 0);
                    } else {
                        integer0 = (arg0.isUsingItem() ? 1 : 0);
                        return (integer0 != 0);
                    }
                } else {
                    integer0 = (arg0.isUsingItem() ? 1 : 0);
                    return (integer0 != 0);
                }
            } else {
                integer0 = (arg0.isUsingItem() ? 1 : 0);
                return (integer0 != 0);
            }
        } else {
            integer0 = (arg0.isUsingItem() ? 1 : 0);
            return (integer0 != 0);
        }
    }

    @Redirect(method = {"submitArmWithItem"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/AbstractClientPlayer;getUseItemRemainingTicks()I"))
    private int pm$36(AbstractClientPlayer arg0) {
        KillAura reference2 = null;
        boolean saved1 = false;
        int integer0 = 0;
        reference2 = ModuleManager.killAura;
        if (!((reference2 == null))) {
            saved1 = reference2.f16;
            if (saved1) {
                integer0 = 20;
                return integer0;
            } else {
                integer0 = arg0.getUseItemRemainingTicks();
                return integer0;
            }
        } else {
            integer0 = arg0.getUseItemRemainingTicks();
            return integer0;
        }
    }

    public ItemInHandRendererMixin() {
    }
}
