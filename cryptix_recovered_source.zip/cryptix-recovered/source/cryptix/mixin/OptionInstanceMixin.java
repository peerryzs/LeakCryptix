package cryptix.mixin;

import net.minecraft.client.OptionInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Reconstructed from mixins/bt.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {OptionInstance.class})
public interface OptionInstanceMixin {

    @Accessor(value = "value")
    public abstract Object getValue();

    @Accessor(value = "value")
    public abstract void setValue(Object arg0);
}
