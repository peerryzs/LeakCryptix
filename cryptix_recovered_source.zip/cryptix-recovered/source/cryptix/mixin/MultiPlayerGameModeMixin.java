package cryptix.mixin;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.multiplayer.prediction.PredictiveAction;
import net.minecraft.core.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Reconstructed from mixins/wa.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {MultiPlayerGameMode.class})
public interface MultiPlayerGameModeMixin {

    @Accessor(value = "destroyProgress")
    public abstract float getDestroyProgress();

    @Invoker(value = "startPrediction")
    public abstract void invokeStartPrediction(ClientLevel arg0, PredictiveAction arg1);

    @Accessor(value = "isDestroying")
    public abstract boolean isDestroying();

    @Accessor(value = "destroyBlockPos")
    public abstract BlockPos getDestroyBlockPos();

    @Accessor(value = "destroyProgress")
    public abstract void setDestroyProgress(float arg0);

    @Accessor(value = "destroyDelay")
    public abstract void setDestroyDelay(int arg0);
}
