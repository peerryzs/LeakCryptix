package cryptix.mixin;

import cryptix.event.Events;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/oz.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {LivingEntityRenderer.class})
public class LivingEntityRendererMixin {

    @Inject(method = {"extractRenderState"}, at = {@At(value = "FIELD", target = "Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;xRot:F", shift = At.Shift.AFTER)})
    private void pm$59(LivingEntity arg0, LivingEntityRenderState arg1, float arg2, CallbackInfo arg3) {
        LocalPlayer saved1 = null;
        saved1 = Minecraft.getInstance().player;
        if (!((arg0 != saved1))) {
            arg1.xRot = Mth.rotLerp(arg2, Events.rotation.getPreviousPitch(), Events.rotation.getPitch());
        }
    }

    public LivingEntityRendererMixin() {
    }
}
