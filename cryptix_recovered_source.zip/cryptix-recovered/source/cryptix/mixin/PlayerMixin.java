package cryptix.mixin;

import cryptix.module.ModuleManager;
import cryptix.module.impl.movement.KeepSprint;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Reconstructed from mixins/yo.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {Player.class})
public class PlayerMixin {

    @Redirect(method = {"causeExtraKnockback"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/phys/Vec3;multiply(DDD)Lnet/minecraft/world/phys/Vec3;"))
    private Vec3 pm$54(Vec3 arg0, double arg1, double arg2, double arg3) {
        KeepSprint reference8 = null;
        double number9 = 0.0;
        Vec3 reference0 = null;
        reference8 = ModuleManager.keepSprint;
        number9 = reference8.m161();
        reference0 = arg0.multiply(number9, arg2, number9);
        return reference0;
    }

    public PlayerMixin() {
    }
}
