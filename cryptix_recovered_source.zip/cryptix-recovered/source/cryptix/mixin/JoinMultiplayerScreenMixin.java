package cryptix.mixin;

import cryptix.gui.TokenLoginScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reconstructed from mixins/wm.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {JoinMultiplayerScreen.class})
public class JoinMultiplayerScreenMixin {
    private static final String TEXT_TOKEN_LOGIN;

    private static void addTokenLoginButtonCallback0(JoinMultiplayerScreen arg0, Button arg1) {
        ((ScreenMixin) (Object) arg0).getMinecraft().gui.setScreen(new TokenLoginScreen());
    }

    static {
        TEXT_TOKEN_LOGIN = new String("Token Login");
    }

    @Inject(method = {"init"}, at = {@At(value = "TAIL")})
    private void addTokenLoginButton(CallbackInfo arg0) {
        JoinMultiplayerScreen reference2 = null;
        ScreenMixin saved2 = null;
        MutableComponent saved3 = null;
        reference2 = ((JoinMultiplayerScreen) (Object) this);
        saved2 = ((ScreenMixin) (Object) reference2);
        saved3 = Component.literal(JoinMultiplayerScreenMixin.TEXT_TOKEN_LOGIN);
        final JoinMultiplayerScreen captured1 = reference2;
        saved2.invokeAddRenderableWidget(((GuiEventListener) (Object) Button.builder(((Component) (Object) saved3), (lambdaArg0) -> JoinMultiplayerScreenMixin.addTokenLoginButtonCallback0(captured1, ((Button) lambdaArg0))).bounds((reference2.width - 110), 5, 105, 20).build()));
    }

    public JoinMultiplayerScreenMixin() {
    }
}
