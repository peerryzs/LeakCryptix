package cryptix.mixin;

import cryptix.module.ModuleManager;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Reconstructed from mixins/as.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {ScreenEffectRenderer.class})
public class ScreenEffectRendererMixin {

    @Redirect(method = {"submit"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;isOnFire()Z"))
    private boolean pm$60(LocalPlayer arg0) {
        boolean saved1 = false;
        int integer0 = 0;
        saved1 = ModuleManager.antiFire.isEnabled();
        if (saved1) {
            integer0 = 0;
            return (integer0 != 0);
        } else {
            integer0 = (arg0.isOnFire() ? 1 : 0);
            return (integer0 != 0);
        }
    }

    public ScreenEffectRendererMixin() {
    }
}
