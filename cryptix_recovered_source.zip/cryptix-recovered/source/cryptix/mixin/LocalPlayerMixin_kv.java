package cryptix.mixin;

import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Reconstructed from mixins/kv.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
@Mixin(value = {LocalPlayer.class})
public interface LocalPlayerMixin_kv {

    @Accessor(value = "zLast")
    public abstract void setZLast(double arg0);

    @Accessor(value = "xLast")
    public abstract void setXLast(double arg0);

    @Accessor(value = "xRotLast")
    public abstract void setXRotLast(float arg0);

    @Accessor(value = "yRotLast")
    public abstract void setYRotLast(float arg0);
}
