package cryptix.util;

import cryptix.recovery.JvmSupport;
import net.minecraft.util.Mth;

/**
 * Reconstructed from a/it.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_it implements MinecraftAccess {

    public static float m50() {
        float floating0 = 0.0f;
        int integer1 = 0;
        int integer2 = 0;
        int integer3 = 0;
        int integer4 = 0;
        int saved1 = 0;
        floating0 = MinecraftAccess.mc.player.getYRot();
        integer1 = (MinecraftAccess.mc.options.keyUp.isDown() ? 1 : 0);
        integer2 = (MinecraftAccess.mc.options.keyDown.isDown() ? 1 : 0);
        integer3 = (MinecraftAccess.mc.options.keyLeft.isDown() ? 1 : 0);
        integer4 = (MinecraftAccess.mc.options.keyRight.isDown() ? 1 : 0);
        if (!((integer1 == 0))) {
            if (!((integer2 != 0))) {
                if (!((integer3 == 0))) {
                    if (!((integer4 != 0))) {
                        floating0 = (floating0 - 45.0f);
                    } else {
                        if (!((integer4 == 0))) {
                            if (!((integer3 != 0))) {
                                floating0 = (floating0 + 45.0f);
                            }
                        }
                    }
                } else {
                    if (!((integer4 == 0))) {
                        if (!((integer3 != 0))) {
                            floating0 = (floating0 + 45.0f);
                        }
                    }
                }
            } else {
                if (!((integer2 == 0))) {
                    if (!((integer1 != 0))) {
                        floating0 = (floating0 + 180.0f);
                        if (!((integer3 == 0))) {
                            if (!((integer4 != 0))) {
                                floating0 = (floating0 + 45.0f);
                            } else {
                                if (!((integer4 == 0))) {
                                    if (!((integer3 != 0))) {
                                        floating0 = (floating0 - 45.0f);
                                    }
                                }
                            }
                        } else {
                            if (!((integer4 == 0))) {
                                if (!((integer3 != 0))) {
                                    floating0 = (floating0 - 45.0f);
                                }
                            }
                        }
                    } else {
                        if (!((integer3 == 0))) {
                            if (!((integer4 != 0))) {
                                floating0 = (floating0 - 90.0f);
                            } else {
                                if (!((integer4 == 0))) {
                                    if (!((integer3 != 0))) {
                                        floating0 = (floating0 + 90.0f);
                                    }
                                }
                            }
                        } else {
                            if (!((integer4 == 0))) {
                                if (!((integer3 != 0))) {
                                    floating0 = (floating0 + 90.0f);
                                }
                            }
                        }
                    }
                } else {
                    if (!((integer3 == 0))) {
                        if (!((integer4 != 0))) {
                            floating0 = (floating0 - 90.0f);
                        } else {
                            if (!((integer4 == 0))) {
                                if (!((integer3 != 0))) {
                                    floating0 = (floating0 + 90.0f);
                                }
                            }
                        }
                    } else {
                        if (!((integer4 == 0))) {
                            if (!((integer3 != 0))) {
                                floating0 = (floating0 + 90.0f);
                            }
                        }
                    }
                }
            }
        } else {
            if (!((integer2 == 0))) {
                if (!((integer1 != 0))) {
                    floating0 = (floating0 + 180.0f);
                    if (!((integer3 == 0))) {
                        if (!((integer4 != 0))) {
                            floating0 = (floating0 + 45.0f);
                        } else {
                            if (!((integer4 == 0))) {
                                if (!((integer3 != 0))) {
                                    floating0 = (floating0 - 45.0f);
                                }
                            }
                        }
                    } else {
                        if (!((integer4 == 0))) {
                            if (!((integer3 != 0))) {
                                floating0 = (floating0 - 45.0f);
                            }
                        }
                    }
                } else {
                    if (!((integer3 == 0))) {
                        if (!((integer4 != 0))) {
                            floating0 = (floating0 - 90.0f);
                        } else {
                            if (!((integer4 == 0))) {
                                if (!((integer3 != 0))) {
                                    floating0 = (floating0 + 90.0f);
                                }
                            }
                        }
                    } else {
                        if (!((integer4 == 0))) {
                            if (!((integer3 != 0))) {
                                floating0 = (floating0 + 90.0f);
                            }
                        }
                    }
                }
            } else {
                if (!((integer3 == 0))) {
                    if (!((integer4 != 0))) {
                        floating0 = (floating0 - 90.0f);
                    } else {
                        if (!((integer4 == 0))) {
                            if (!((integer3 != 0))) {
                                floating0 = (floating0 + 90.0f);
                            }
                        }
                    }
                } else {
                    if (!((integer4 == 0))) {
                        if (!((integer3 != 0))) {
                            floating0 = (floating0 + 90.0f);
                        }
                    }
                }
            }
        }
        floating0 = (floating0 % 360.0f);
        saved1 = JvmSupport.fcmpg(floating0, 0.0f);
        if (!((saved1 >= 0))) {
            floating0 = (floating0 + 360.0f);
        }
        return floating0;
    }

    public static boolean m51() {
        float floating0 = 0.0f;
        int saved1 = 0;
        int saved2 = 0;
        int branchValue3 = 0;
        int integer0 = 0;
        floating0 = (Recovered_it.m50() % 90.0f);
        saved1 = JvmSupport.fcmpl(floating0, 20.0f);
        if (!((saved1 <= 0))) {
            saved2 = JvmSupport.fcmpg(floating0, 70.0f);
            branchValue3 = (!((saved2 >= 0)) ? 1 : 0);
        } else {
            branchValue3 = 0;
        }
        integer0 = branchValue3;
        return (integer0 != 0);
    }

    public Recovered_it() {
    }

    public static float m52(float arg0, float arg1) {
        float floating2 = 0.0f;
        double number3 = 0.0;
        double number5 = 0.0;
        double number7 = 0.0;
        int saved1 = 0;
        int saved2 = 0;
        float floating9 = 0.0f;
        float floating10 = 0.0f;
        float floating11 = 0.0f;
        float floating12 = 0.0f;
        int saved3 = 0;
        floating2 = arg1;
        number3 = (MinecraftAccess.mc.player.getX() - MinecraftAccess.mc.player.xOld);
        number5 = (MinecraftAccess.mc.player.getZ() - MinecraftAccess.mc.player.zOld);
        number7 = ((number3 * number3) + (number5 * number5));
        saved1 = JvmSupport.dcmpl(number7, 0.0025);
        if (!((saved1 <= 0))) {
            floating2 = (((float) Math.toDegrees(Math.atan2(number5, number3))) - 90.0f);
        }
        saved2 = JvmSupport.fcmpl(((float) MinecraftAccess.mc.player.swingTime), 0.0f);
        if (!((saved2 <= 0))) {
            floating2 = arg0;
        }
        floating9 = Mth.wrapDegrees((floating2 - arg1));
        floating10 = (arg1 + (floating9 * 0.3f));
        floating11 = Mth.wrapDegrees((arg0 - floating10));
        floating11 = Mth.clamp(floating11, -75.0f, 75.0f);
        floating12 = (arg0 - floating11);
        saved3 = JvmSupport.fcmpl((floating11 * floating11), 2500.0f);
        if (!((saved3 <= 0))) {
            floating12 = (floating12 + (floating11 * 0.2f));
        }
        arg0 = floating12;
        return arg0;
    }
}
