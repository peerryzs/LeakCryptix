package cryptix.util;

import cryptix.recovery.JvmSupport;
import net.minecraft.network.protocol.Packet;

/**
 * Reconstructed from a/jd.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_jd {
    private final long f921;
    public final Packet f48;

    public Recovered_jd(Packet arg0, long arg1) {
        this.f48 = arg0;
        this.f921 = (System.currentTimeMillis() + arg1);
    }

    public boolean m245() {
        int saved1 = 0;
        int integer0 = 0;
        saved1 = JvmSupport.lcmp(System.currentTimeMillis(), this.f921);
        integer0 = (!((saved1 < 0)) ? 1 : 0);
        return (integer0 != 0);
    }
}
