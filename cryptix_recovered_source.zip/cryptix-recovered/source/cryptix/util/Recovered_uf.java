package cryptix.util;

import cryptix.module.ModuleManager;
import java.awt.Color;
import net.minecraft.util.Mth;

/**
 * Reconstructed from a/uf.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_uf {
    private static int f949;
    private static final String TEXT_CHERRY;
    private static final String TEXT_FROST;
    private static final String TEXT_OCEAN;
    private static int f947;
    private static int f943;
    private static int f948;
    private static int f946;
    private static final String TEXT_COTTON_CANDY;
    private static int f944;
    private static final float f940 = 0.0027777778f;
    private static final double f941 = 0.00016666666666666666;
    private static final double f942 = 0.001;
    private static final String TEXT_INFERNO;
    private static final String TEXT_NOVA;
    private static boolean f955;
    private static String f951;
    private static float f954;
    private static int f945;
    private static final String TEXT_EMERALD;
    private static long f952;
    private static double f953;
    private static int f950;
    private static final String TEXT_SAKURA;
    private static final String TEXT_RAINBOW;
    private static final String TEXT_GOLD;

    static {
        TEXT_RAINBOW = new String("Rainbow");
        TEXT_GOLD = new String("Gold");
        TEXT_OCEAN = new String("Ocean");
        TEXT_NOVA = new String("Nova");
        TEXT_EMERALD = new String("Emerald");
        TEXT_INFERNO = new String("Inferno");
        TEXT_SAKURA = new String("Sakura");
        TEXT_CHERRY = new String("Cherry");
        TEXT_FROST = new String("Frost");
        TEXT_COTTON_CANDY = new String("Cotton Candy");
        f943 = -1;
        f944 = -1;
    }

    private static int pm$123(int arg0) {
        float floating1 = 0.0f;
        floating1 = ((Recovered_uf.f954 + (((float) arg0) * 0.0027777778f)) % 1.0f);
        arg0 = (Color.HSBtoRGB(floating1, 1.0f, 1.0f) | -16777216);
        return arg0;
    }

    public static int m58(int arg0) {
        boolean saved1 = false;
        double number1 = 0.0;
        int integer3 = 0;
        int integer4 = 0;
        int integer5 = 0;
        saved1 = Recovered_uf.f955;
        if (saved1) {
            arg0 = Recovered_uf.pm$123(arg0);
            return arg0;
        } else {
            number1 = (((double) (Mth.sin((Recovered_uf.f953 + ((double) arg0))) + 1.0f)) * 0.5);
            integer3 = ((int) (((double) Recovered_uf.f945) + (((double) (Recovered_uf.f948 - Recovered_uf.f945)) * number1)));
            integer4 = ((int) (((double) Recovered_uf.f946) + (((double) (Recovered_uf.f949 - Recovered_uf.f946)) * number1)));
            integer5 = ((int) (((double) Recovered_uf.f947) + (((double) (Recovered_uf.f950 - Recovered_uf.f947)) * number1)));
            arg0 = (((-16777216 | (integer3 << 16)) | (integer4 << 8)) | integer5);
            return arg0;
        }
    }

    public Recovered_uf() {
    }

    public static void m57() {
        String reference0 = null;
        double number1 = 0.0;
        boolean saved1 = false;
        String reference3 = null;
        int integer4 = 0;
        String reference5 = null;
        int saved2 = 0;
        boolean saved3 = false;
        boolean saved4 = false;
        boolean saved5 = false;
        boolean saved6 = false;
        boolean saved7 = false;
        boolean saved8 = false;
        boolean saved9 = false;
        boolean saved10 = false;
        boolean saved11 = false;
        reference0 = ModuleManager.theme.theme.getValue();
        number1 = ModuleManager.theme.speed.getValue();
        Recovered_uf.f952 = System.currentTimeMillis();
        Recovered_uf.f954 = ((float) (((((double) Recovered_uf.f952) * number1) % 6000.0) * 0.00016666666666666666));
        Recovered_uf.f953 = ((((double) Recovered_uf.f952) * 0.001) * number1);
        Recovered_uf.f955 = Recovered_uf.TEXT_RAINBOW.equals(reference0);
        saved1 = reference0.equals(Recovered_uf.f951);
        if (saved1) {
            return;
        } else {
            Recovered_uf.f951 = reference0;
            reference3 = reference0;
            integer4 = -1;
            reference5 = reference3;
            saved2 = reference3.hashCode();
            if (!((saved2 != -1825862521))) {
                saved3 = reference3.equals(Recovered_uf.TEXT_SAKURA);
                if (saved3) {
                    integer4 = 5;
                }
            } else {
                if (!((saved2 != -685180305))) {
                    saved4 = reference3.equals(Recovered_uf.TEXT_INFERNO);
                    if (saved4) {
                        integer4 = 4;
                    }
                } else {
                    if (!((saved2 != 2225280))) {
                        saved5 = reference3.equals(Recovered_uf.TEXT_GOLD);
                        if (saved5) {
                            integer4 = 0;
                        }
                    } else {
                        if (!((saved2 != 2434124))) {
                            saved6 = reference3.equals(Recovered_uf.TEXT_NOVA);
                            if (saved6) {
                                integer4 = 2;
                            }
                        } else {
                            if (!((saved2 != 30590468))) {
                                saved7 = reference3.equals(Recovered_uf.TEXT_EMERALD);
                                if (saved7) {
                                    integer4 = 3;
                                }
                            } else {
                                if (!((saved2 != 68152996))) {
                                    saved8 = reference3.equals(Recovered_uf.TEXT_FROST);
                                    if (saved8) {
                                        integer4 = 7;
                                    }
                                } else {
                                    if (!((saved2 != 76007646))) {
                                        saved9 = reference3.equals(Recovered_uf.TEXT_OCEAN);
                                        if (saved9) {
                                            integer4 = 1;
                                        }
                                    } else {
                                        if (!((saved2 != 1929002704))) {
                                            saved10 = reference3.equals(Recovered_uf.TEXT_COTTON_CANDY);
                                            if (saved10) {
                                                integer4 = 8;
                                            }
                                        } else {
                                            if (!((saved2 != 2017321401))) {
                                                saved11 = reference3.equals(Recovered_uf.TEXT_CHERRY);
                                                if (saved11) {
                                                    integer4 = 6;
                                                }
                                            } else {
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            switch (integer4) {
                case 0:
                {
                    Recovered_uf.f943 = -23296;
                    Recovered_uf.f944 = -256;
                    break;
                }
                case 1:
                {
                    Recovered_uf.f943 = -16726273;
                    Recovered_uf.f944 = -16747777;
                    break;
                }
                case 2:
                {
                    Recovered_uf.f943 = -39736;
                    Recovered_uf.f944 = -15100161;
                    break;
                }
                case 3:
                {
                    Recovered_uf.f943 = -16718218;
                    Recovered_uf.f944 = -15315669;
                    break;
                }
                case 4:
                {
                    Recovered_uf.f943 = -43230;
                    Recovered_uf.f944 = -8768993;
                    break;
                }
                case 5:
                {
                    Recovered_uf.f943 = -32597;
                    Recovered_uf.f944 = -2080517;
                    break;
                }
                case 6:
                {
                    Recovered_uf.f943 = -2278039;
                    Recovered_uf.f944 = -2051145;
                    break;
                }
                case 7:
                {
                    Recovered_uf.f943 = -2104349;
                    Recovered_uf.f944 = -4405814;
                    break;
                }
                case 8:
                {
                    Recovered_uf.f943 = -10225153;
                    Recovered_uf.f944 = -38708;
                    break;
                }
                default:
                {
                    Recovered_uf.f943 = -1;
                    Recovered_uf.f944 = -1;
                    break;
                }
            }
            Recovered_uf.f945 = ((Recovered_uf.f943 >> 16) & 255);
            Recovered_uf.f946 = ((Recovered_uf.f943 >> 8) & 255);
            Recovered_uf.f947 = (Recovered_uf.f943 & 255);
            Recovered_uf.f948 = ((Recovered_uf.f944 >> 16) & 255);
            Recovered_uf.f949 = ((Recovered_uf.f944 >> 8) & 255);
            Recovered_uf.f950 = (Recovered_uf.f944 & 255);
            return;
        }
    }
}
