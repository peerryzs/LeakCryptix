package cryptix.util;

import cryptix.config.ConfigManager;
import cryptix.recovery.JvmSupport;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Reconstructed from a/qj.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_qj extends Recovered_gm {
    private int f173;
    private static final String TEXT_XDG_OPEN;
    private static final String TEXT_OS_NAME;
    private final Map f174;
    private static final String TEXT_REMOVE;
    private static final String TEXT_WIN;
    private static final String TEXT_OPEN;
    private static final String TEXT_SAVE;
    private static final String TEXT_RESET;
    private static final String TEXT_MAC;
    private static final String TEXT_EXPLORER_EXE;
    private static final String TEXT_LOAD;
    private static final String TEXT_CREATE_CONFIG;
    private static final String TEXT_OPEN_FOLDER;

    public void m104(double arg0, double arg1, int arg2) {
        int integer6 = 0;
        String[] reference7 = null;
        Object reference8 = null;
        int integer9 = 0;
        int integer10 = 0;
        Object reference11 = null;
        int saved1 = 0;
        int saved2 = 0;
        int saved3 = 0;
        int saved4 = 0;
        Map saved5 = null;
        boolean saved6 = false;
        boolean saved7 = false;
        int saved8 = 0;
        int saved9 = 0;
        int saved10 = 0;
        int saved11 = 0;
        int saved12 = 0;
        int saved13 = 0;
        int saved14 = 0;
        int saved15 = 0;
        int saved16 = 0;
        int saved17 = 0;
        int saved18 = 0;
        int saved19 = 0;
        int saved20 = 0;
        int saved21 = 0;
        int saved22 = 0;
        int saved23 = 0;
        int saved24 = 0;
        int saved25 = 0;
        int saved26 = 0;
        int saved27 = 0;
        int saved28 = 0;
        int saved29 = 0;
        int saved30 = 0;
        int saved31 = 0;
        int saved32 = 0;
        boolean saved33 = false;
        String reference9 = null;
        boolean saved34 = false;
        boolean saved35 = false;
        int saved37 = 0;
        int saved38 = 0;
        int saved39 = 0;
        int saved40 = 0;
        boolean saved41 = false;
        boolean saved42 = false;
        boolean saved43 = false;
        int saved45 = 0;
        int saved46 = 0;
        int saved47 = 0;
        int saved48 = 0;
        boolean saved49 = false;
        boolean saved50 = false;
        boolean saved51 = false;
        int saved53 = 0;
        int saved54 = 0;
        int saved55 = 0;
        int saved56 = 0;
        boolean saved57 = false;
        boolean saved58 = false;
        boolean saved59 = false;
        integer6 = (this.f5 + 17);
        reference7 = ConfigManager.list();
        reference8 = reference7;
        integer9 = ((String[]) reference8).length;
        integer10 = 0;
        loop14: while (true) {
            if ((integer10 >= integer9)) {
                break loop14;
            }
            reference11 = ((String[]) reference8)[integer10];
            saved1 = JvmSupport.dcmpl(arg0, ((double) this.f4));
            if (!((saved1 < 0))) {
                saved2 = JvmSupport.dcmpg(arg0, ((double) (this.f4 + 100)));
                if (!((saved2 > 0))) {
                    saved3 = JvmSupport.dcmpl(arg1, ((double) (integer6 - 2)));
                    if (!((saved3 < 0))) {
                        saved4 = JvmSupport.dcmpg(arg1, ((double) (integer6 + 10)));
                        if (!((saved4 > 0))) {
                            if (!((arg2 != 1))) {
                                saved5 = this.f174;
                                saved6 = ((Boolean) this.f174.getOrDefault(reference11, Boolean.valueOf(false))).booleanValue();
                                saved5.put(reference11, Boolean.valueOf(((!(saved6) ? 1 : 0) != 0)));
                            } else {
                                if (!((arg2 != 0))) {
                                    ConfigManager.load(((String) reference11));
                                }
                            }
                            return;
                        }
                    }
                }
            }
            integer6 += 12;
            saved7 = ((Boolean) this.f174.getOrDefault(reference11, Boolean.valueOf(false))).booleanValue();
            if (saved7) {
                saved8 = JvmSupport.dcmpl(arg0, ((double) this.f4));
                if (!((saved8 < 0))) {
                    saved9 = JvmSupport.dcmpg(arg0, ((double) (this.f4 + 100)));
                    if (!((saved9 > 0))) {
                        saved10 = JvmSupport.dcmpl(arg1, ((double) (integer6 - 2)));
                        if (!((saved10 < 0))) {
                            saved11 = JvmSupport.dcmpg(arg1, ((double) (integer6 + 10)));
                            if (!((saved11 > 0))) {
                                if (!((arg2 != 0))) {
                                    ConfigManager.load(((String) reference11));
                                }
                                return;
                            }
                        }
                    }
                }
                integer6 += 12;
                saved12 = JvmSupport.dcmpl(arg0, ((double) this.f4));
                if (!((saved12 < 0))) {
                    saved13 = JvmSupport.dcmpg(arg0, ((double) (this.f4 + 100)));
                    if (!((saved13 > 0))) {
                        saved14 = JvmSupport.dcmpl(arg1, ((double) (integer6 - 2)));
                        if (!((saved14 < 0))) {
                            saved15 = JvmSupport.dcmpg(arg1, ((double) (integer6 + 10)));
                            if (!((saved15 > 0))) {
                                if (!((arg2 != 0))) {
                                    ConfigManager.save(((String) reference11));
                                }
                                return;
                            }
                        }
                    }
                }
                integer6 += 12;
                saved16 = JvmSupport.dcmpl(arg0, ((double) this.f4));
                if (!((saved16 < 0))) {
                    saved17 = JvmSupport.dcmpg(arg0, ((double) (this.f4 + 100)));
                    if (!((saved17 > 0))) {
                        saved18 = JvmSupport.dcmpl(arg1, ((double) (integer6 - 2)));
                        if (!((saved18 < 0))) {
                            saved19 = JvmSupport.dcmpg(arg1, ((double) (integer6 + 10)));
                            if (!((saved19 > 0))) {
                                if (!((arg2 != 0))) {
                                    ConfigManager.delete(((String) reference11));
                                    this.f174.remove(reference11);
                                }
                                return;
                            }
                        }
                    }
                }
                integer6 += 12;
                saved20 = JvmSupport.dcmpl(arg0, ((double) this.f4));
                if (!((saved20 < 0))) {
                    saved21 = JvmSupport.dcmpg(arg0, ((double) (this.f4 + 100)));
                    if (!((saved21 > 0))) {
                        saved22 = JvmSupport.dcmpl(arg1, ((double) (integer6 - 2)));
                        if (!((saved22 < 0))) {
                            saved23 = JvmSupport.dcmpg(arg1, ((double) (integer6 + 10)));
                            if (!((saved23 > 0))) {
                                if (!((arg2 != 0))) {
                                    ConfigManager.resetToDefaults(((String) reference11));
                                }
                                return;
                            }
                        }
                    }
                }
                integer6 += 12;
            }
            integer10++;
            continue loop14;
        }
        saved24 = JvmSupport.dcmpl(arg0, ((double) this.f4));
        if (!((saved24 < 0))) {
            saved25 = JvmSupport.dcmpg(arg0, ((double) (this.f4 + 100)));
            if (!((saved25 > 0))) {
                saved26 = JvmSupport.dcmpl(arg1, ((double) (integer6 - 2)));
                if (!((saved26 < 0))) {
                    saved27 = JvmSupport.dcmpg(arg1, ((double) (integer6 + 10)));
                    if (!((saved27 > 0))) {
                        if (!((arg2 != 0))) {
                            saved28 = this.f173;
                            this.f173 = (saved28 + 1);
                            reference8 = ("Config" + saved28);
                            ConfigManager.save(((String) reference8));
                        }
                        return;
                    } else {
                        integer6 += 12;
                        saved29 = JvmSupport.dcmpl(arg0, ((double) this.f4));
                        if (!((saved29 < 0))) {
                            saved30 = JvmSupport.dcmpg(arg0, ((double) (this.f4 + 100)));
                            if (!((saved30 > 0))) {
                                saved31 = JvmSupport.dcmpl(arg1, ((double) (integer6 - 2)));
                                if (!((saved31 < 0))) {
                                    saved32 = JvmSupport.dcmpg(arg1, ((double) (integer6 + 10)));
                                    if (!((saved32 > 0))) {
                                        if (!((arg2 != 0))) {
                                            try {
                                                reference8 = ConfigManager.getConfigDirectory();
                                                saved33 = ((File) reference8).exists();
                                                if (!(saved33)) {
                                                    ((File) reference8).mkdirs();
                                                }
                                                reference9 = System.getProperty(Recovered_qj.TEXT_OS_NAME).toLowerCase();
                                                saved34 = reference9.contains(Recovered_qj.TEXT_WIN);
                                                if (saved34) {
                                                    new ProcessBuilder(new String[] {Recovered_qj.TEXT_EXPLORER_EXE, ((File) reference8).getAbsolutePath()}).start();
                                                } else {
                                                    saved35 = reference9.contains(Recovered_qj.TEXT_MAC);
                                                    if (saved35) {
                                                        new ProcessBuilder(new String[] {Recovered_qj.TEXT_OPEN, ((File) reference8).getAbsolutePath()}).start();
                                                    } else {
                                                        new ProcessBuilder(new String[] {Recovered_qj.TEXT_XDG_OPEN, ((File) reference8).getAbsolutePath()}).start();
                                                    }
                                                }
                                            } catch (IOException caught36) {
                                                reference8 = caught36;
                                                ((IOException) reference8).printStackTrace();
                                            }
                                        }
                                        return;
                                    } else {
                                        return;
                                    }
                                } else {
                                    return;
                                }
                            } else {
                                return;
                            }
                        } else {
                            return;
                        }
                    }
                } else {
                    integer6 += 12;
                    saved37 = JvmSupport.dcmpl(arg0, ((double) this.f4));
                    if (!((saved37 < 0))) {
                        saved38 = JvmSupport.dcmpg(arg0, ((double) (this.f4 + 100)));
                        if (!((saved38 > 0))) {
                            saved39 = JvmSupport.dcmpl(arg1, ((double) (integer6 - 2)));
                            if (!((saved39 < 0))) {
                                saved40 = JvmSupport.dcmpg(arg1, ((double) (integer6 + 10)));
                                if (!((saved40 > 0))) {
                                    if (!((arg2 != 0))) {
                                        try {
                                            reference8 = ConfigManager.getConfigDirectory();
                                            saved41 = ((File) reference8).exists();
                                            if (!(saved41)) {
                                                ((File) reference8).mkdirs();
                                            }
                                            reference9 = System.getProperty(Recovered_qj.TEXT_OS_NAME).toLowerCase();
                                            saved42 = reference9.contains(Recovered_qj.TEXT_WIN);
                                            if (saved42) {
                                                new ProcessBuilder(new String[] {Recovered_qj.TEXT_EXPLORER_EXE, ((File) reference8).getAbsolutePath()}).start();
                                            } else {
                                                saved43 = reference9.contains(Recovered_qj.TEXT_MAC);
                                                if (saved43) {
                                                    new ProcessBuilder(new String[] {Recovered_qj.TEXT_OPEN, ((File) reference8).getAbsolutePath()}).start();
                                                } else {
                                                    new ProcessBuilder(new String[] {Recovered_qj.TEXT_XDG_OPEN, ((File) reference8).getAbsolutePath()}).start();
                                                }
                                            }
                                        } catch (IOException caught44) {
                                            reference8 = caught44;
                                            ((IOException) reference8).printStackTrace();
                                        }
                                    }
                                    return;
                                } else {
                                    return;
                                }
                            } else {
                                return;
                            }
                        } else {
                            return;
                        }
                    } else {
                        return;
                    }
                }
            } else {
                integer6 += 12;
                saved45 = JvmSupport.dcmpl(arg0, ((double) this.f4));
                if (!((saved45 < 0))) {
                    saved46 = JvmSupport.dcmpg(arg0, ((double) (this.f4 + 100)));
                    if (!((saved46 > 0))) {
                        saved47 = JvmSupport.dcmpl(arg1, ((double) (integer6 - 2)));
                        if (!((saved47 < 0))) {
                            saved48 = JvmSupport.dcmpg(arg1, ((double) (integer6 + 10)));
                            if (!((saved48 > 0))) {
                                if (!((arg2 != 0))) {
                                    try {
                                        reference8 = ConfigManager.getConfigDirectory();
                                        saved49 = ((File) reference8).exists();
                                        if (!(saved49)) {
                                            ((File) reference8).mkdirs();
                                        }
                                        reference9 = System.getProperty(Recovered_qj.TEXT_OS_NAME).toLowerCase();
                                        saved50 = reference9.contains(Recovered_qj.TEXT_WIN);
                                        if (saved50) {
                                            new ProcessBuilder(new String[] {Recovered_qj.TEXT_EXPLORER_EXE, ((File) reference8).getAbsolutePath()}).start();
                                        } else {
                                            saved51 = reference9.contains(Recovered_qj.TEXT_MAC);
                                            if (saved51) {
                                                new ProcessBuilder(new String[] {Recovered_qj.TEXT_OPEN, ((File) reference8).getAbsolutePath()}).start();
                                            } else {
                                                new ProcessBuilder(new String[] {Recovered_qj.TEXT_XDG_OPEN, ((File) reference8).getAbsolutePath()}).start();
                                            }
                                        }
                                    } catch (IOException caught52) {
                                        reference8 = caught52;
                                        ((IOException) reference8).printStackTrace();
                                    }
                                }
                                return;
                            } else {
                                return;
                            }
                        } else {
                            return;
                        }
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
        } else {
            integer6 += 12;
            saved53 = JvmSupport.dcmpl(arg0, ((double) this.f4));
            if (!((saved53 < 0))) {
                saved54 = JvmSupport.dcmpg(arg0, ((double) (this.f4 + 100)));
                if (!((saved54 > 0))) {
                    saved55 = JvmSupport.dcmpl(arg1, ((double) (integer6 - 2)));
                    if (!((saved55 < 0))) {
                        saved56 = JvmSupport.dcmpg(arg1, ((double) (integer6 + 10)));
                        if (!((saved56 > 0))) {
                            if (!((arg2 != 0))) {
                                try {
                                    reference8 = ConfigManager.getConfigDirectory();
                                    saved57 = ((File) reference8).exists();
                                    if (!(saved57)) {
                                        ((File) reference8).mkdirs();
                                    }
                                    reference9 = System.getProperty(Recovered_qj.TEXT_OS_NAME).toLowerCase();
                                    saved58 = reference9.contains(Recovered_qj.TEXT_WIN);
                                    if (saved58) {
                                        new ProcessBuilder(new String[] {Recovered_qj.TEXT_EXPLORER_EXE, ((File) reference8).getAbsolutePath()}).start();
                                    } else {
                                        saved59 = reference9.contains(Recovered_qj.TEXT_MAC);
                                        if (saved59) {
                                            new ProcessBuilder(new String[] {Recovered_qj.TEXT_OPEN, ((File) reference8).getAbsolutePath()}).start();
                                        } else {
                                            new ProcessBuilder(new String[] {Recovered_qj.TEXT_XDG_OPEN, ((File) reference8).getAbsolutePath()}).start();
                                        }
                                    }
                                } catch (IOException caught60) {
                                    reference8 = caught60;
                                    ((IOException) reference8).printStackTrace();
                                }
                            }
                            return;
                        } else {
                            return;
                        }
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            } else {
                return;
            }
        }
    }

    public void m101(GuiGraphicsExtractor arg0) {
        int integer2 = 0;
        Minecraft reference3 = null;
        int integer4 = 0;
        String[] reference5 = null;
        int integer6 = 0;
        int integer7 = 0;
        Object reference8 = null;
        boolean saved1 = false;
        integer2 = Recovered_eg.m31();
        reference3 = Minecraft.getInstance();
        arg0.fill(this.f4, this.f5, (this.f4 + 100), (this.f5 + 15), integer2);
        arg0.text(reference3.font, this.f3, (this.f4 + 4), (this.f5 + 3), -1);
        integer4 = (this.f5 + 17);
        reference5 = ConfigManager.list();
        integer6 = reference5.length;
        integer7 = 0;
        loop46: while (true) {
            if ((integer7 >= integer6)) {
                break loop46;
            }
            reference8 = reference5[integer7];
            arg0.fill(this.f4, (integer4 - 2), (this.f4 + 100), (integer4 + 10), -2146430960);
            arg0.text(reference3.font, ((String) reference8), (this.f4 + 4), integer4, -1426063361);
            integer4 += 12;
            saved1 = ((Boolean) this.f174.getOrDefault(reference8, Boolean.valueOf(false))).booleanValue();
            if (saved1) {
                arg0.fill(this.f4, (integer4 - 2), (this.f4 + 100), (integer4 + 46), -2145378272);
                arg0.text(reference3.font, Recovered_qj.TEXT_LOAD, (this.f4 + 4), integer4, -11141291);
                integer4 += 12;
                arg0.text(reference3.font, Recovered_qj.TEXT_SAVE, (this.f4 + 4), integer4, -171);
                integer4 += 12;
                arg0.text(reference3.font, Recovered_qj.TEXT_REMOVE, (this.f4 + 4), integer4, -43691);
                integer4 += 12;
                arg0.text(reference3.font, Recovered_qj.TEXT_RESET, (this.f4 + 4), integer4, -11162881);
                integer4 += 12;
            }
            integer7++;
            continue loop46;
        }
        arg0.fill(this.f4, (integer4 - 2), (this.f4 + 100), (integer4 + 10), -1440590558);
        arg0.text(reference3.font, Recovered_qj.TEXT_CREATE_CONFIG, (this.f4 + 4), integer4, -11141291);
        integer4 += 12;
        arg0.fill(this.f4, (integer4 - 2), (this.f4 + 100), (integer4 + 10), -1440590558);
        arg0.text(reference3.font, Recovered_qj.TEXT_OPEN_FOLDER, (this.f4 + 4), integer4, -11141291);
    }

    static {
        TEXT_LOAD = new String("Load");
        TEXT_SAVE = new String("Save");
        TEXT_REMOVE = new String("Remove");
        TEXT_RESET = new String("Reset");
        TEXT_CREATE_CONFIG = new String("Create Config");
        TEXT_OPEN_FOLDER = new String("Open Folder");
        TEXT_OS_NAME = new String("os.name");
        TEXT_WIN = new String("win");
        TEXT_EXPLORER_EXE = new String("explorer.exe");
        TEXT_MAC = new String("mac");
        TEXT_OPEN = new String("open");
        TEXT_XDG_OPEN = new String("xdg-open");
    }

    public Recovered_qj(String arg0, int arg1, int arg2) {
        super(arg0, arg1, arg2, null);
        this.f173 = 1;
        this.f174 = new HashMap();
    }
}
