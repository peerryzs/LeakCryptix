package cryptix.util;

import com.mojang.blaze3d.platform.Window;
import cryptix.event.Events;
import cryptix.module.ModuleManager;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.Mth;

/**
 * Reconstructed from a/sf.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_sf implements MinecraftAccess {
    private static int f646;
    private static int f645;
    private static int f651;
    private static String f648;
    private static final String TEXT_0_FBLOCKS;
    private static int f650;
    private static int f649;
    private static int f647;

    public static void m24(float arg0) {
        int integer1 = 0;
        boolean saved1 = false;
        GuiGraphicsExtractor reference2 = null;
        int integer3 = 0;
        integer1 = ((int) (((float) Recovered_sf.f646) + (((float) (Recovered_sf.f645 - Recovered_sf.f646)) * arg0)));
        if (!((integer1 <= 0))) {
            saved1 = ModuleManager.scaffold.blockCount.getValue();
            if (saved1) {
                reference2 = Events.hudRender.getGraphics();
                integer3 = ((Recovered_sf.f649 & 16777215) | (integer1 << 24));
                reference2.text(MinecraftAccess.mc.font, Recovered_sf.f648, Recovered_sf.f650, Recovered_sf.f651, integer3);
            }
        }
    }

    static {
        TEXT_0_FBLOCKS = new String("0 \u00a7fBlocks");
        f648 = Recovered_sf.TEXT_0_FBLOCKS;
        f649 = -1;
    }

    public static void m23() {
        int integer0 = 0;
        float floating1 = 0.0f;
        Window reference2 = null;
        int integer3 = 0;
        int saved1 = 0;
        int saved2 = 0;
        int saved3 = 0;
        int saved4 = 0;
        integer0 = (ModuleManager.scaffold.isEnabled() ? 1 : 0);
        floating1 = (!((integer0 == 0)) ? 255.0f : 0.0f);
        Recovered_sf.f646 = Recovered_sf.f645;
        Recovered_sf.f645 = ((int) Mth.lerp(0.5f, ((float) Recovered_sf.f645), floating1));
        if (!((integer0 != 0))) {
            return;
        } else {
            reference2 = MinecraftAccess.mc.getWindow();
            Recovered_sf.f650 = ((reference2.getGuiScaledWidth() >> 1) + 5);
            Recovered_sf.f651 = ((reference2.getGuiScaledHeight() >> 1) + 5);
            integer3 = Recovered_ee.m46();
            saved1 = Recovered_sf.f647;
            if (!((integer3 == saved1))) {
                Recovered_sf.f647 = integer3;
                Recovered_sf.f648 = ("" + integer3 + " \u00a7fBlocks");
                saved2 = Recovered_sf.f647;
                if (!((saved2 > 10))) {
                    Recovered_sf.f649 = -43691;
                } else {
                    saved3 = Recovered_sf.f647;
                    if (!((saved3 > 20))) {
                        Recovered_sf.f649 = -22016;
                    } else {
                        saved4 = Recovered_sf.f647;
                        if (!((saved4 > 30))) {
                            Recovered_sf.f649 = -171;
                        } else {
                            Recovered_sf.f649 = -1;
                        }
                    }
                }
            }
            return;
        }
    }

    public Recovered_sf() {
    }
}
