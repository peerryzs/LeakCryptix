package cryptix.util;

import cryptix.recovery.JvmSupport;

/**
 * Reconstructed from a/eg.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_eg {
    private static int f907;

    public static int m30(float arg0) {
        int saved1 = 0;
        int saved2 = 0;
        int saved3 = 0;
        int branchValue4 = 0;
        int branchValue5 = 0;
        int integer0 = 0;
        saved1 = JvmSupport.dcmpg(((double) arg0), 0.3);
        if (!((saved1 >= 0))) {
            branchValue5 = -43691;
        } else {
            saved2 = JvmSupport.dcmpg(((double) arg0), 0.5);
            if (!((saved2 >= 0))) {
                branchValue4 = -22016;
            } else {
                saved3 = JvmSupport.dcmpg(((double) arg0), 0.7);
                branchValue4 = (!((saved3 >= 0)) ? -171 : -11141291);
            }
            branchValue5 = branchValue4;
        }
        integer0 = branchValue5;
        return integer0;
    }

    public static void m32() {
        Recovered_eg.f907 = Recovered_uf.m58(0);
    }

    public static int m31() {
        return Recovered_eg.f907;
    }

    public Recovered_eg() {
    }
}
