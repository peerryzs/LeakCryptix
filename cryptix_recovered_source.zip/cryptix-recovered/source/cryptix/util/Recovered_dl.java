package cryptix.util;

import net.minecraft.world.phys.Vec3;

/**
 * Reconstructed from a/dl.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public final class Recovered_dl {
    public double f51;
    public double f50;
    public double f49;

    public Recovered_dl(double arg0, double arg1, double arg2) {
        this.m246(arg0, arg1, arg2);
    }

    public Recovered_dl m248(Vec3 arg0) {
        Recovered_dl reference0 = this;
        reference0 = reference0.m246(arg0.x, arg0.y, arg0.z);
        return reference0;
    }

    public Recovered_dl m247(Recovered_dl arg0) {
        Recovered_dl reference0 = this;
        reference0 = reference0.m246(arg0.f49, arg0.f50, arg0.f51);
        return reference0;
    }

    public Recovered_dl() {
    }

    public Recovered_dl m246(double arg0, double arg1, double arg2) {
        Recovered_dl reference0 = this;
        reference0.f49 = arg0;
        reference0.f50 = arg1;
        reference0.f51 = arg2;
        return reference0;
    }

    public Vec3 m249() {
        Object reference0 = this;
        reference0 = new Vec3(((Recovered_dl) reference0).f49, ((Recovered_dl) reference0).f50, ((Recovered_dl) reference0).f51);
        return ((Vec3) reference0);
    }
}
