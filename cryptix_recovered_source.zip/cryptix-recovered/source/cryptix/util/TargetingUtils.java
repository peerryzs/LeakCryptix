package cryptix.util;

import cryptix.module.ModuleManager;
import cryptix.recovery.JvmSupport;
import java.util.Iterator;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/**
 * Reconstructed from a/pj.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class TargetingUtils implements MinecraftAccess {

    public static LivingEntity m54(double arg0, boolean arg1) {
        boolean saved1 = false;
        Player reference0 = null;
        Player reference3 = null;
        double number4 = 0.0;
        double number6 = 0.0;
        LocalPlayer reference8 = null;
        double number9 = 0.0;
        double number11 = 0.0;
        double number13 = 0.0;
        Iterator reference15 = null;
        boolean saved2 = false;
        Player reference16 = null;
        LocalPlayer saved3 = null;
        boolean saved4 = false;
        boolean saved5 = false;
        int saved6 = 0;
        boolean saved7 = false;
        boolean saved8 = false;
        double number17 = 0.0;
        double number19 = 0.0;
        double number21 = 0.0;
        double number23 = 0.0;
        int saved9 = 0;
        int saved10 = 0;
        saved1 = ModuleManager.scaffold.isEnabled();
        if (saved1) {
            reference0 = null;
            return reference0;
        } else {
            reference3 = null;
            number4 = 1.7976931348623157e+308;
            number6 = (arg0 * arg0);
            reference8 = MinecraftAccess.mc.player;
            number9 = reference8.getX();
            number11 = reference8.getY();
            number13 = reference8.getZ();
            reference15 = MinecraftAccess.mc.level.players().iterator();
            loop32: while (true) {
                saved2 = reference15.hasNext();
                if (!(saved2)) {
                    break loop32;
                }
                reference16 = ((Player) reference15.next());
                saved3 = MinecraftAccess.mc.player;
                if (!((reference16 != saved3))) {
                    continue loop32;
                }
                saved4 = TargetingUtils.pm$122(reference16);
                if (saved4) {
                    continue loop32;
                }
                saved5 = reference16.isAlive();
                if (!(saved5)) {
                    continue loop32;
                }
                saved6 = reference16.deathTime;
                if (!((saved6 <= 0))) {
                    continue loop32;
                }
                saved7 = reference16.isRemoved();
                if (saved7) {
                    continue loop32;
                }
                saved8 = ModuleManager.antiBot.m140(reference16);
                if (saved8) {
                    if (arg1) {
                        continue loop32;
                    }
                }
                number17 = (reference16.getX() - number9);
                number19 = (reference16.getY() - number11);
                number21 = (reference16.getZ() - number13);
                number23 = (((number17 * number17) + (number19 * number19)) + (number21 * number21));
                saved9 = JvmSupport.dcmpl(number23, number6);
                if (!((saved9 <= 0))) {
                    continue loop32;
                }
                saved10 = JvmSupport.dcmpg(number23, number4);
                if (!((saved10 >= 0))) {
                    number4 = number23;
                    reference3 = reference16;
                }
                continue loop32;
            }
            reference0 = reference3;
            return reference0;
        }
    }

    public TargetingUtils() {
    }

    public static Entity m56() {
        Entity reference0 = null;
        double number1 = 0.0;
        Iterator reference3 = null;
        boolean saved1 = false;
        Entity reference4 = null;
        boolean saved2 = false;
        LivingEntity reference5 = null;
        LocalPlayer saved3 = null;
        boolean saved4 = false;
        boolean saved5 = false;
        double number6 = 0.0;
        int saved6 = 0;
        reference0 = null;
        number1 = 1.7976931348623157e+308;
        reference3 = MinecraftAccess.mc.level.players().iterator();
        loop9: while (true) {
            saved1 = reference3.hasNext();
            if (!(saved1)) {
                break loop9;
            }
            reference4 = ((Entity) reference3.next());
            saved2 = (reference4 instanceof LivingEntity);
            if (!(saved2)) {
                continue loop9;
            }
            reference5 = ((LivingEntity) (Object) reference4);
            saved3 = MinecraftAccess.mc.player;
            if ((reference4 == saved3)) {
                continue loop9;
            }
            saved4 = reference5.isAlive();
            if (!(saved4)) {
                continue loop9;
            }
            saved5 = ModuleManager.antiBot.m140(reference4);
            if (saved5) {
                continue loop9;
            }
            number6 = MinecraftAccess.mc.player.distanceToSqr(reference4);
            saved6 = JvmSupport.dcmpg(number6, number1);
            if (!((saved6 >= 0))) {
                number1 = number6;
                reference0 = reference4;
            }
            continue loop9;
        }
        return reference0;
    }

    public static LivingEntity m55(boolean arg0) {
        LivingEntity reference1 = null;
        double number2 = 0.0;
        Iterator reference4 = null;
        boolean saved1 = false;
        Entity reference5 = null;
        boolean saved2 = false;
        LivingEntity reference6 = null;
        LocalPlayer saved3 = null;
        boolean saved4 = false;
        int saved5 = 0;
        boolean saved6 = false;
        boolean saved7 = false;
        boolean saved8 = false;
        boolean saved9 = false;
        double number7 = 0.0;
        int saved10 = 0;
        int saved11 = 0;
        LivingEntity reference0 = null;
        reference1 = null;
        number2 = -1.0;
        reference4 = MinecraftAccess.mc.level.entitiesForRendering().iterator();
        loop9: while (true) {
            saved1 = reference4.hasNext();
            if (!(saved1)) {
                break loop9;
            }
            reference5 = ((Entity) reference4.next());
            saved2 = (reference5 instanceof LivingEntity);
            if (!(saved2)) {
                continue loop9;
            }
            reference6 = ((LivingEntity) (Object) reference5);
            saved3 = MinecraftAccess.mc.player;
            if (!((reference6 != saved3))) {
                continue loop9;
            }
            saved4 = reference6.isAlive();
            if (!(saved4)) {
                continue loop9;
            }
            saved5 = reference6.deathTime;
            if (!((saved5 <= 0))) {
                continue loop9;
            }
            saved6 = reference6.isRemoved();
            if (saved6) {
                continue loop9;
            }
            saved7 = ModuleManager.antiBot.m140(reference5);
            if (saved7) {
                if (arg0) {
                    continue loop9;
                }
            }
            saved8 = ModuleManager.scaffold.isEnabled();
            if (saved8) {
                continue loop9;
            }
            saved9 = (reference5 instanceof Player);
            if (!(saved9)) {
                continue loop9;
            }
            number7 = ((double) MinecraftAccess.mc.player.distanceTo(reference6));
            saved10 = JvmSupport.dcmpg(number7, 11.0);
            if (!((saved10 >= 0))) {
                continue loop9;
            }
            saved11 = JvmSupport.dcmpl(number7, number2);
            if (!((saved11 <= 0))) {
                number2 = number7;
                reference1 = reference6;
            }
            continue loop9;
        }
        reference0 = reference1;
        return reference0;
    }

    public static LivingEntity findTarget(double arg0, boolean arg1) {
        boolean saved1 = false;
        Player reference0 = null;
        Player reference3 = null;
        double number4 = 0.0;
        double number6 = 0.0;
        LocalPlayer reference8 = null;
        double number9 = 0.0;
        double number11 = 0.0;
        double number13 = 0.0;
        Iterator reference15 = null;
        boolean saved2 = false;
        Player reference16 = null;
        LocalPlayer saved3 = null;
        boolean saved4 = false;
        int saved5 = 0;
        boolean saved6 = false;
        boolean saved7 = false;
        double number17 = 0.0;
        double number19 = 0.0;
        double number21 = 0.0;
        double number23 = 0.0;
        int saved8 = 0;
        int saved9 = 0;
        saved1 = ModuleManager.scaffold.isEnabled();
        if (saved1) {
            reference0 = null;
            return reference0;
        } else {
            reference3 = null;
            number4 = 1.7976931348623157e+308;
            number6 = (arg0 * arg0);
            reference8 = MinecraftAccess.mc.player;
            number9 = reference8.getX();
            number11 = reference8.getY();
            number13 = reference8.getZ();
            reference15 = MinecraftAccess.mc.level.players().iterator();
            loop32: while (true) {
                saved2 = reference15.hasNext();
                if (!(saved2)) {
                    break loop32;
                }
                reference16 = ((Player) reference15.next());
                saved3 = MinecraftAccess.mc.player;
                if (!((reference16 != saved3))) {
                    continue loop32;
                }
                saved4 = reference16.isAlive();
                if (!(saved4)) {
                    continue loop32;
                }
                saved5 = reference16.deathTime;
                if (!((saved5 <= 0))) {
                    continue loop32;
                }
                saved6 = reference16.isRemoved();
                if (saved6) {
                    continue loop32;
                }
                saved7 = ModuleManager.antiBot.m140(reference16);
                if (saved7) {
                    if (arg1) {
                        continue loop32;
                    }
                }
                number17 = (reference16.getX() - number9);
                number19 = (reference16.getY() - number11);
                number21 = (reference16.getZ() - number13);
                number23 = (((number17 * number17) + (number19 * number19)) + (number21 * number21));
                saved8 = JvmSupport.dcmpl(number23, number6);
                if (!((saved8 <= 0))) {
                    continue loop32;
                }
                saved9 = JvmSupport.dcmpg(number23, number4);
                if (!((saved9 >= 0))) {
                    number4 = number23;
                    reference3 = reference16;
                }
                continue loop32;
            }
            reference0 = reference3;
            return reference0;
        }
    }

    private static boolean pm$122(Player arg0) {
        LocalPlayer saved1 = null;
        int integer0 = 0;
        boolean saved2 = false;
        String reference1 = null;
        String reference2 = null;
        int saved3 = 0;
        int saved4 = 0;
        String reference3 = null;
        String reference4 = null;
        boolean saved5 = false;
        if (!((arg0 == null))) {
            saved1 = MinecraftAccess.mc.player;
            if (!((saved1 != null))) {
                integer0 = 0;
                return (integer0 != 0);
            } else {
                saved2 = MinecraftAccess.mc.player.isAlliedTo(arg0);
                if (saved2) {
                    integer0 = 1;
                    return (integer0 != 0);
                } else {
                    reference1 = MinecraftAccess.mc.player.getDisplayName().getString();
                    reference2 = arg0.getDisplayName().getString();
                    saved3 = reference1.length();
                    if (!((saved3 < 2))) {
                        saved4 = reference2.length();
                        if (!((saved4 < 2))) {
                            reference3 = reference1.substring(0, 2);
                            reference4 = reference2.substring(0, 2);
                            saved5 = reference3.equals(reference4);
                            if (saved5) {
                                integer0 = 1;
                                return (integer0 != 0);
                            } else {
                                integer0 = 0;
                                return (integer0 != 0);
                            }
                        } else {
                            integer0 = 0;
                            return (integer0 != 0);
                        }
                    } else {
                        integer0 = 0;
                        return (integer0 != 0);
                    }
                }
            }
        } else {
            integer0 = 0;
            return (integer0 != 0);
        }
    }
}
