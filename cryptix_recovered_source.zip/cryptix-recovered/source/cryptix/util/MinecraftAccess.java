package cryptix.util;

import net.minecraft.client.Minecraft;

/**
 * Reconstructed from a/ul.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public interface MinecraftAccess {
    Minecraft mc = Minecraft.getInstance();
}
