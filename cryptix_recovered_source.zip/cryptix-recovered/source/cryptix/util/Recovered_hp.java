package cryptix.util;

import cryptix.recovery.JvmSupport;

/**
 * Reconstructed from a/hp.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_hp {
    private static float f956;

    public static float m60() {
        return Recovered_hp.f956;
    }

    public Recovered_hp() {
    }

    public static void m59(float arg0) {
        Recovered_hp.f956 = arg0;
    }

    public static boolean m62() {
        int saved1 = 0;
        int integer0 = 0;
        saved1 = JvmSupport.fcmpl(Recovered_hp.f956, 1.0f);
        integer0 = (!((saved1 != 0)) ? 1 : 0);
        return (integer0 != 0);
    }

    public static void m61() {
        Recovered_hp.f956 = 1.0f;
    }

    static {
        f956 = 1.0f;
    }
}
