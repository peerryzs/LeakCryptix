package cryptix.util;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

/**
 * Reconstructed from a/fe.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class PlacementData {
    public BlockPos position;
    public Direction face;

    public void set(BlockPos arg0, Direction arg1) {
        this.position = arg0;
        this.face = arg1;
    }

    public PlacementData() {
    }
}
