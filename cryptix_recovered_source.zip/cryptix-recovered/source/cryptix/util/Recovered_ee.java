package cryptix.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Reconstructed from a/ee.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_ee {
    private static final Minecraft f922;

    public Recovered_ee() {
    }

    static {
        f922 = Minecraft.getInstance();
    }

    public static boolean m44() {
        LocalPlayer saved1 = null;
        int integer0 = 0;
        Item reference0 = null;
        saved1 = Recovered_ee.f922.player;
        if (!((saved1 != null))) {
            integer0 = 0;
            return (integer0 != 0);
        } else {
            reference0 = Recovered_ee.f922.player.getMainHandItem().getItem();
            integer0 = (Recovered_ee.f922.player.getMainHandItem().is(ItemTags.SWORDS) ? 1 : 0);
            return (integer0 != 0);
        }
    }

    public static boolean m45() {
        LocalPlayer saved1 = null;
        int integer0 = 0;
        Item reference0 = null;
        saved1 = Recovered_ee.f922.player;
        if (!((saved1 != null))) {
            integer0 = 0;
            return (integer0 != 0);
        } else {
            reference0 = Recovered_ee.f922.player.getMainHandItem().getItem();
            integer0 = ((reference0 instanceof BlockItem) ? 1 : 0);
            return (integer0 != 0);
        }
    }

    public static int m46() {
        int integer0 = 0;
        Inventory reference1 = null;
        int integer2 = 0;
        ItemStack reference3 = null;
        boolean saved1 = false;
        integer0 = 0;
        reference1 = Recovered_ee.f922.player.getInventory();
        integer2 = 0;
        loop8: while (true) {
            if ((integer2 >= 9)) {
                break loop8;
            }
            reference3 = reference1.getItem(integer2);
            saved1 = (reference3.getItem() instanceof BlockItem);
            if (saved1) {
                integer0 = (integer0 + reference3.getCount());
            }
            integer2++;
            continue loop8;
        }
        return integer0;
    }
}
