package cryptix.util;

import net.minecraft.network.protocol.Packet;

/**
 * Reconstructed from a/jr.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class QueuedPacket {
     long time;
    public Packet packet;

    public QueuedPacket(Packet arg0, long arg1) {
        this.packet = arg0;
        this.time = arg1;
    }
}
