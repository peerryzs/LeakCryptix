package cryptix.util;

import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;
import cryptix.setting.PositionSetting;
import cryptix.setting.Setting;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.lwjgl.glfw.GLFW;

/**
 * Reconstructed from a/mw.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_mw {
    public boolean f13;
    private static final String TEXT_AON;
    private double f182;
    public boolean f12;
    private static final String TEXT_COFF;
    public int f10;
    private static final String TEXT_NONE;
    private NumberSetting f181;
    public int f11;
    public final Module f7;
    public int f9;
    public int f14;
    public int f8;
    private static final String TEXT_EMPTY;
    private static final String TEXT_PRESS_KEY;
    private long f183;
    private static final String TEXT_BIND;

    public void m112(double arg0, double arg1, int arg2) {
        boolean saved1 = false;
        boolean saved2 = false;
        boolean saved3 = false;
        boolean saved4 = false;
        int integer6 = 0;
        Iterator reference7 = null;
        boolean saved5 = false;
        Setting reference8 = null;
        int saved6 = 0;
        int saved7 = 0;
        int saved8 = 0;
        int saved9 = 0;
        boolean saved10 = false;
        Object reference9 = null;
        String[] reference10 = null;
        int integer11 = 0;
        int integer12 = 0;
        int saved11 = 0;
        boolean saved12 = false;
        boolean saved13 = false;
        boolean saved14 = false;
        boolean saved15 = false;
        boolean saved16 = false;
        int integer7 = 0;
        int saved17 = 0;
        int saved18 = 0;
        int saved19 = 0;
        int saved20 = 0;
        Module saved21 = null;
        boolean saved22 = false;
        boolean saved23 = false;
        boolean saved24 = false;
        int saved25 = 0;
        int saved26 = 0;
        int saved27 = 0;
        int saved28 = 0;
        boolean saved29 = false;
        int saved30 = 0;
        boolean saved31 = false;
        boolean saved32 = false;
        boolean saved33 = false;
        boolean saved34 = false;
        boolean saved35 = false;
        int saved36 = 0;
        int saved37 = 0;
        int saved38 = 0;
        int saved39 = 0;
        Module saved40 = null;
        boolean saved41 = false;
        boolean saved42 = false;
        boolean saved43 = false;
        boolean saved44 = false;
        boolean saved45 = false;
        int saved46 = 0;
        int saved47 = 0;
        int saved48 = 0;
        int saved49 = 0;
        boolean saved50 = false;
        int saved51 = 0;
        boolean saved52 = false;
        boolean saved53 = false;
        boolean saved54 = false;
        boolean saved55 = false;
        boolean saved56 = false;
        int saved57 = 0;
        int saved58 = 0;
        int saved59 = 0;
        int saved60 = 0;
        Module saved61 = null;
        boolean saved62 = false;
        boolean saved63 = false;
        boolean saved64 = false;
        int saved65 = 0;
        int saved66 = 0;
        int saved67 = 0;
        int saved68 = 0;
        boolean saved69 = false;
        int saved70 = 0;
        boolean saved71 = false;
        boolean saved72 = false;
        boolean saved73 = false;
        boolean saved74 = false;
        boolean saved75 = false;
        int saved76 = 0;
        int saved77 = 0;
        int saved78 = 0;
        int saved79 = 0;
        Module saved80 = null;
        boolean saved81 = false;
        if (!((arg2 != 0))) {
            saved1 = this.m113(arg0, arg1);
            if (saved1) {
                this.f7.toggle();
                return;
            } else {
                if (!((arg2 != 1))) {
                    saved2 = this.m113(arg0, arg1);
                    if (saved2) {
                        saved3 = this.f12;
                        this.f12 = ((!(saved3) ? 1 : 0) != 0);
                        return;
                    } else {
                        saved4 = this.f12;
                        if (!(saved4)) {
                            return;
                        } else {
                            integer6 = this.f11;
                            reference7 = this.f7.settings.iterator();
                            loop40: while (true) {
                                saved5 = reference7.hasNext();
                                if (!(saved5)) {
                                    break loop40;
                                }
                                reference8 = ((Setting) reference7.next());
                                saved6 = JvmSupport.dcmpl(arg0, ((double) (this.f8 + 5)));
                                if (!((saved6 < 0))) {
                                    saved7 = JvmSupport.dcmpg(arg0, ((double) (this.f8 + this.f10)));
                                    if (!((saved7 > 0))) {
                                        saved8 = JvmSupport.dcmpl(arg1, ((double) (this.f9 + integer6)));
                                        if (!((saved8 < 0))) {
                                            saved9 = JvmSupport.dcmpg(arg1, ((double) ((this.f9 + integer6) + 12)));
                                            if (!((saved9 > 0))) {
                                                saved10 = (reference8 instanceof ModeSetting);
                                                if (saved10) {
                                                    reference9 = ((ModeSetting) (Object) reference8);
                                                    if (!((arg2 != 0))) {
                                                        reference10 = ((ModeSetting) reference9).getModes();
                                                        integer11 = 0;
                                                        integer12 = 0;
                                                        loop97: while (true) {
                                                            saved11 = reference10.length;
                                                            if ((integer12 >= saved11)) {
                                                                break loop97;
                                                            }
                                                            saved12 = reference10[integer12].equals(((ModeSetting) reference9).getValue());
                                                            if (saved12) {
                                                                integer11 = integer12;
                                                                break loop97;
                                                            } else {
                                                                integer12++;
                                                                continue loop97;
                                                            }
                                                        }
                                                        ((ModeSetting) reference9).setValue(reference10[((integer11 + 1) % reference10.length)]);
                                                    }
                                                }
                                                saved13 = (reference8 instanceof BooleanSetting);
                                                if (saved13) {
                                                    reference9 = ((BooleanSetting) (Object) reference8);
                                                    if (!((arg2 != 0))) {
                                                        saved14 = ((BooleanSetting) reference9).getValue();
                                                        ((BooleanSetting) reference9).setValue(((!(saved14) ? 1 : 0) != 0));
                                                    }
                                                }
                                                saved15 = (reference8 instanceof PositionSetting);
                                                if (saved15) {
                                                    reference9 = ((PositionSetting) (Object) reference8);
                                                    if (!((arg2 != 0))) {
                                                        ((PositionSetting) reference9).openEditor();
                                                    }
                                                }
                                                saved16 = (reference8 instanceof NumberSetting);
                                                if (saved16) {
                                                    reference9 = ((NumberSetting) (Object) reference8);
                                                    if (!((arg2 != 0))) {
                                                        this.f181 = ((NumberSetting) reference9);
                                                        this.f182 = ((NumberSetting) reference9).getValue();
                                                        this.f183 = System.nanoTime();
                                                        this.updateSlider(((NumberSetting) reference9), arg0);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                integer6 += 12;
                                continue loop40;
                            }
                            integer7 = ((this.f9 + this.f11) + (this.f7.settings.size() * 12));
                            saved17 = JvmSupport.dcmpl(arg0, ((double) this.f8));
                            if (!((saved17 < 0))) {
                                saved18 = JvmSupport.dcmpg(arg0, ((double) (this.f8 + this.f10)));
                                if (!((saved18 > 0))) {
                                    saved19 = JvmSupport.dcmpl(arg1, ((double) integer7));
                                    if (!((saved19 < 0))) {
                                        saved20 = JvmSupport.dcmpg(arg1, ((double) (integer7 + this.f11)));
                                        if (!((saved20 > 0))) {
                                            if (!((arg2 != 0))) {
                                                this.f13 = true;
                                            } else {
                                                if (!((arg2 != 1))) {
                                                    saved21 = this.f7;
                                                    saved22 = this.f7.isHidden();
                                                    saved21.setHidden(((!(saved22) ? 1 : 0) != 0));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            return;
                        }
                    }
                } else {
                    saved23 = this.f12;
                    if (!(saved23)) {
                        return;
                    } else {
                        integer6 = this.f11;
                        reference7 = this.f7.settings.iterator();
                        loop40: while (true) {
                            saved24 = reference7.hasNext();
                            if (!(saved24)) {
                                break loop40;
                            }
                            reference8 = ((Setting) reference7.next());
                            saved25 = JvmSupport.dcmpl(arg0, ((double) (this.f8 + 5)));
                            if (!((saved25 < 0))) {
                                saved26 = JvmSupport.dcmpg(arg0, ((double) (this.f8 + this.f10)));
                                if (!((saved26 > 0))) {
                                    saved27 = JvmSupport.dcmpl(arg1, ((double) (this.f9 + integer6)));
                                    if (!((saved27 < 0))) {
                                        saved28 = JvmSupport.dcmpg(arg1, ((double) ((this.f9 + integer6) + 12)));
                                        if (!((saved28 > 0))) {
                                            saved29 = (reference8 instanceof ModeSetting);
                                            if (saved29) {
                                                reference9 = ((ModeSetting) (Object) reference8);
                                                if (!((arg2 != 0))) {
                                                    reference10 = ((ModeSetting) reference9).getModes();
                                                    integer11 = 0;
                                                    integer12 = 0;
                                                    loop97: while (true) {
                                                        saved30 = reference10.length;
                                                        if ((integer12 >= saved30)) {
                                                            break loop97;
                                                        }
                                                        saved31 = reference10[integer12].equals(((ModeSetting) reference9).getValue());
                                                        if (saved31) {
                                                            integer11 = integer12;
                                                            break loop97;
                                                        } else {
                                                            integer12++;
                                                            continue loop97;
                                                        }
                                                    }
                                                    ((ModeSetting) reference9).setValue(reference10[((integer11 + 1) % reference10.length)]);
                                                }
                                            }
                                            saved32 = (reference8 instanceof BooleanSetting);
                                            if (saved32) {
                                                reference9 = ((BooleanSetting) (Object) reference8);
                                                if (!((arg2 != 0))) {
                                                    saved33 = ((BooleanSetting) reference9).getValue();
                                                    ((BooleanSetting) reference9).setValue(((!(saved33) ? 1 : 0) != 0));
                                                }
                                            }
                                            saved34 = (reference8 instanceof PositionSetting);
                                            if (saved34) {
                                                reference9 = ((PositionSetting) (Object) reference8);
                                                if (!((arg2 != 0))) {
                                                    ((PositionSetting) reference9).openEditor();
                                                }
                                            }
                                            saved35 = (reference8 instanceof NumberSetting);
                                            if (saved35) {
                                                reference9 = ((NumberSetting) (Object) reference8);
                                                if (!((arg2 != 0))) {
                                                    this.f181 = ((NumberSetting) reference9);
                                                    this.f182 = ((NumberSetting) reference9).getValue();
                                                    this.f183 = System.nanoTime();
                                                    this.updateSlider(((NumberSetting) reference9), arg0);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            integer6 += 12;
                            continue loop40;
                        }
                        integer7 = ((this.f9 + this.f11) + (this.f7.settings.size() * 12));
                        saved36 = JvmSupport.dcmpl(arg0, ((double) this.f8));
                        if (!((saved36 < 0))) {
                            saved37 = JvmSupport.dcmpg(arg0, ((double) (this.f8 + this.f10)));
                            if (!((saved37 > 0))) {
                                saved38 = JvmSupport.dcmpl(arg1, ((double) integer7));
                                if (!((saved38 < 0))) {
                                    saved39 = JvmSupport.dcmpg(arg1, ((double) (integer7 + this.f11)));
                                    if (!((saved39 > 0))) {
                                        if (!((arg2 != 0))) {
                                            this.f13 = true;
                                        } else {
                                            if (!((arg2 != 1))) {
                                                saved40 = this.f7;
                                                saved41 = this.f7.isHidden();
                                                saved40.setHidden(((!(saved41) ? 1 : 0) != 0));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        return;
                    }
                }
            }
        } else {
            if (!((arg2 != 1))) {
                saved42 = this.m113(arg0, arg1);
                if (saved42) {
                    saved43 = this.f12;
                    this.f12 = ((!(saved43) ? 1 : 0) != 0);
                    return;
                } else {
                    saved44 = this.f12;
                    if (!(saved44)) {
                        return;
                    } else {
                        integer6 = this.f11;
                        reference7 = this.f7.settings.iterator();
                        loop40: while (true) {
                            saved45 = reference7.hasNext();
                            if (!(saved45)) {
                                break loop40;
                            }
                            reference8 = ((Setting) reference7.next());
                            saved46 = JvmSupport.dcmpl(arg0, ((double) (this.f8 + 5)));
                            if (!((saved46 < 0))) {
                                saved47 = JvmSupport.dcmpg(arg0, ((double) (this.f8 + this.f10)));
                                if (!((saved47 > 0))) {
                                    saved48 = JvmSupport.dcmpl(arg1, ((double) (this.f9 + integer6)));
                                    if (!((saved48 < 0))) {
                                        saved49 = JvmSupport.dcmpg(arg1, ((double) ((this.f9 + integer6) + 12)));
                                        if (!((saved49 > 0))) {
                                            saved50 = (reference8 instanceof ModeSetting);
                                            if (saved50) {
                                                reference9 = ((ModeSetting) (Object) reference8);
                                                if (!((arg2 != 0))) {
                                                    reference10 = ((ModeSetting) reference9).getModes();
                                                    integer11 = 0;
                                                    integer12 = 0;
                                                    loop97: while (true) {
                                                        saved51 = reference10.length;
                                                        if ((integer12 >= saved51)) {
                                                            break loop97;
                                                        }
                                                        saved52 = reference10[integer12].equals(((ModeSetting) reference9).getValue());
                                                        if (saved52) {
                                                            integer11 = integer12;
                                                            break loop97;
                                                        } else {
                                                            integer12++;
                                                            continue loop97;
                                                        }
                                                    }
                                                    ((ModeSetting) reference9).setValue(reference10[((integer11 + 1) % reference10.length)]);
                                                }
                                            }
                                            saved53 = (reference8 instanceof BooleanSetting);
                                            if (saved53) {
                                                reference9 = ((BooleanSetting) (Object) reference8);
                                                if (!((arg2 != 0))) {
                                                    saved54 = ((BooleanSetting) reference9).getValue();
                                                    ((BooleanSetting) reference9).setValue(((!(saved54) ? 1 : 0) != 0));
                                                }
                                            }
                                            saved55 = (reference8 instanceof PositionSetting);
                                            if (saved55) {
                                                reference9 = ((PositionSetting) (Object) reference8);
                                                if (!((arg2 != 0))) {
                                                    ((PositionSetting) reference9).openEditor();
                                                }
                                            }
                                            saved56 = (reference8 instanceof NumberSetting);
                                            if (saved56) {
                                                reference9 = ((NumberSetting) (Object) reference8);
                                                if (!((arg2 != 0))) {
                                                    this.f181 = ((NumberSetting) reference9);
                                                    this.f182 = ((NumberSetting) reference9).getValue();
                                                    this.f183 = System.nanoTime();
                                                    this.updateSlider(((NumberSetting) reference9), arg0);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            integer6 += 12;
                            continue loop40;
                        }
                        integer7 = ((this.f9 + this.f11) + (this.f7.settings.size() * 12));
                        saved57 = JvmSupport.dcmpl(arg0, ((double) this.f8));
                        if (!((saved57 < 0))) {
                            saved58 = JvmSupport.dcmpg(arg0, ((double) (this.f8 + this.f10)));
                            if (!((saved58 > 0))) {
                                saved59 = JvmSupport.dcmpl(arg1, ((double) integer7));
                                if (!((saved59 < 0))) {
                                    saved60 = JvmSupport.dcmpg(arg1, ((double) (integer7 + this.f11)));
                                    if (!((saved60 > 0))) {
                                        if (!((arg2 != 0))) {
                                            this.f13 = true;
                                        } else {
                                            if (!((arg2 != 1))) {
                                                saved61 = this.f7;
                                                saved62 = this.f7.isHidden();
                                                saved61.setHidden(((!(saved62) ? 1 : 0) != 0));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        return;
                    }
                }
            } else {
                saved63 = this.f12;
                if (!(saved63)) {
                    return;
                } else {
                    integer6 = this.f11;
                    reference7 = this.f7.settings.iterator();
                    loop40: while (true) {
                        saved64 = reference7.hasNext();
                        if (!(saved64)) {
                            break loop40;
                        }
                        reference8 = ((Setting) reference7.next());
                        saved65 = JvmSupport.dcmpl(arg0, ((double) (this.f8 + 5)));
                        if (!((saved65 < 0))) {
                            saved66 = JvmSupport.dcmpg(arg0, ((double) (this.f8 + this.f10)));
                            if (!((saved66 > 0))) {
                                saved67 = JvmSupport.dcmpl(arg1, ((double) (this.f9 + integer6)));
                                if (!((saved67 < 0))) {
                                    saved68 = JvmSupport.dcmpg(arg1, ((double) ((this.f9 + integer6) + 12)));
                                    if (!((saved68 > 0))) {
                                        saved69 = (reference8 instanceof ModeSetting);
                                        if (saved69) {
                                            reference9 = ((ModeSetting) (Object) reference8);
                                            if (!((arg2 != 0))) {
                                                reference10 = ((ModeSetting) reference9).getModes();
                                                integer11 = 0;
                                                integer12 = 0;
                                                loop97: while (true) {
                                                    saved70 = reference10.length;
                                                    if ((integer12 >= saved70)) {
                                                        break loop97;
                                                    }
                                                    saved71 = reference10[integer12].equals(((ModeSetting) reference9).getValue());
                                                    if (saved71) {
                                                        integer11 = integer12;
                                                        break loop97;
                                                    } else {
                                                        integer12++;
                                                        continue loop97;
                                                    }
                                                }
                                                ((ModeSetting) reference9).setValue(reference10[((integer11 + 1) % reference10.length)]);
                                            }
                                        }
                                        saved72 = (reference8 instanceof BooleanSetting);
                                        if (saved72) {
                                            reference9 = ((BooleanSetting) (Object) reference8);
                                            if (!((arg2 != 0))) {
                                                saved73 = ((BooleanSetting) reference9).getValue();
                                                ((BooleanSetting) reference9).setValue(((!(saved73) ? 1 : 0) != 0));
                                            }
                                        }
                                        saved74 = (reference8 instanceof PositionSetting);
                                        if (saved74) {
                                            reference9 = ((PositionSetting) (Object) reference8);
                                            if (!((arg2 != 0))) {
                                                ((PositionSetting) reference9).openEditor();
                                            }
                                        }
                                        saved75 = (reference8 instanceof NumberSetting);
                                        if (saved75) {
                                            reference9 = ((NumberSetting) (Object) reference8);
                                            if (!((arg2 != 0))) {
                                                this.f181 = ((NumberSetting) reference9);
                                                this.f182 = ((NumberSetting) reference9).getValue();
                                                this.f183 = System.nanoTime();
                                                this.updateSlider(((NumberSetting) reference9), arg0);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        integer6 += 12;
                        continue loop40;
                    }
                    integer7 = ((this.f9 + this.f11) + (this.f7.settings.size() * 12));
                    saved76 = JvmSupport.dcmpl(arg0, ((double) this.f8));
                    if (!((saved76 < 0))) {
                        saved77 = JvmSupport.dcmpg(arg0, ((double) (this.f8 + this.f10)));
                        if (!((saved77 > 0))) {
                            saved78 = JvmSupport.dcmpl(arg1, ((double) integer7));
                            if (!((saved78 < 0))) {
                                saved79 = JvmSupport.dcmpg(arg1, ((double) (integer7 + this.f11)));
                                if (!((saved79 > 0))) {
                                    if (!((arg2 != 0))) {
                                        this.f13 = true;
                                    } else {
                                        if (!((arg2 != 1))) {
                                            saved80 = this.f7;
                                            saved81 = this.f7.isHidden();
                                            saved80.setHidden(((!(saved81) ? 1 : 0) != 0));
                                        }
                                    }
                                }
                            }
                        }
                    }
                    return;
                }
            }
        }
    }

    public int m114() {
        int saved1 = 0;
        boolean saved2 = false;
        int integer0 = 0;
        saved1 = this.f11;
        saved2 = this.f12;
        integer0 = (saved1 + (saved2 ? ((this.f7.settings.size() * 12) + this.f11) : 0));
        return integer0;
    }

    public boolean m113(double arg0, double arg1) {
        int saved1 = 0;
        int saved2 = 0;
        int saved3 = 0;
        int saved4 = 0;
        int branchValue5 = 0;
        int branchValue6 = 0;
        int branchValue7 = 0;
        int integer0 = 0;
        saved1 = JvmSupport.dcmpl(arg0, ((double) this.f8));
        if (!((saved1 < 0))) {
            saved2 = JvmSupport.dcmpg(arg0, ((double) (this.f8 + this.f10)));
            if (!((saved2 > 0))) {
                saved3 = JvmSupport.dcmpl(arg1, ((double) this.f9));
                if (!((saved3 < 0))) {
                    saved4 = JvmSupport.dcmpg(arg1, ((double) (this.f9 + this.f11)));
                    branchValue5 = (!((saved4 > 0)) ? 1 : 0);
                } else {
                    branchValue5 = 0;
                }
                branchValue6 = branchValue5;
            } else {
                branchValue6 = 0;
            }
            branchValue7 = branchValue6;
        } else {
            branchValue7 = 0;
        }
        integer0 = branchValue7;
        return (integer0 != 0);
    }

    public void m115(int arg0) {
        boolean saved1 = false;
        Module saved2 = null;
        saved1 = this.f13;
        if (saved1) {
            saved2 = this.f7;
            saved2.setKeybind((!((arg0 != 256)) ? 0 : arg0));
            this.f13 = false;
        }
    }

    private void updateSlider(NumberSetting arg0, double arg1) {
        double number4 = 0.0;
        number4 = Math.max(0.0, Math.min(1.0, ((arg1 - ((double) this.f8)) / ((double) this.f10))));
        arg0.setValue((arg0.getMinimum() + (number4 * (arg0.getMaximum() - arg0.getMinimum()))));
    }

    public void m118(float arg0, boolean arg1) {
        int integer3 = 0;
        float floating4 = 0.0f;
        int saved1 = 0;
        integer3 = (arg1 ? 255 : 0);
        floating4 = (1.0f - ((float) Math.exp(((double) (-15.0f * arg0)))));
        this.f14 = (this.f14 + ((int) (((float) (integer3 - this.f14)) * floating4)));
        saved1 = Math.abs((this.f14 - integer3));
        if (!((saved1 > 1))) {
            this.f14 = integer3;
        }
    }

    public void m116(double arg0, double arg1) {
        NumberSetting saved1 = null;
        saved1 = this.f181;
        if (!((saved1 == null))) {
            this.updateSlider(this.f181, arg0);
        }
    }

    public void m117() {
        this.f181 = null;
        this.f183 = 0L;
    }

    static {
        TEXT_EMPTY = new String("");
        TEXT_AON = new String("\u00a7aON");
        TEXT_COFF = new String("\u00a7cOFF");
        TEXT_BIND = new String("Bind: ");
        TEXT_PRESS_KEY = new String("Press key...");
        TEXT_NONE = new String("NONE");
    }

    public void m111(GuiGraphicsExtractor arg0, int arg1) {
        int integer3 = 0;
        int integer4 = 0;
        int integer5 = 0;
        int integer6 = 0;
        int integer7 = 0;
        Font saved1 = null;
        String saved2 = null;
        int saved3 = 0;
        int saved4 = 0;
        boolean saved5 = false;
        boolean saved6 = false;
        int integer8 = 0;
        Object reference9 = null;
        boolean saved7 = false;
        Object reference10 = null;
        String reference11 = null;
        boolean saved8 = false;
        ModeSetting reference12 = null;
        boolean saved9 = false;
        BooleanSetting reference13 = null;
        boolean saved10 = false;
        boolean saved11 = false;
        Object reference14 = null;
        boolean saved12 = false;
        NumberSetting reference15 = null;
        double number16 = 0.0;
        double number18 = 0.0;
        NumberSetting saved13 = null;
        long local20 = 0L;
        double number22 = 0.0;
        double number24 = 0.0;
        double number20 = 0.0;
        int saved14 = 0;
        int integer24 = 0;
        float floating12 = 0.0f;
        float floating13 = 0.0f;
        boolean saved15 = false;
        int saved16 = 0;
        boolean saved17 = false;
        integer3 = ((((128 * this.f14) / 255) << 24) | 1052688);
        integer4 = ((((170 * this.f14) / 255) << 24) | 16777215);
        integer5 = ((arg1 & 16777215) | (((255 * this.f14) / 255) << 24));
        integer6 = ((((128 * this.f14) / 255) << 24) | 2105376);
        integer7 = (((80 * this.f14) / 255) << 24);
        arg0.fill(this.f8, this.f9, (this.f8 + this.f10), (this.f9 + this.f11), integer3);
        saved1 = Minecraft.getInstance().font;
        saved2 = this.f7.getName();
        saved3 = (this.f8 + 4);
        saved4 = (this.f9 + 4);
        saved5 = this.f7.isEnabled();
        arg0.text(saved1, saved2, saved3, saved4, (saved5 ? integer5 : integer4));
        saved6 = this.f12;
        if (!(saved6)) {
            return;
        } else {
            integer8 = this.f11;
            reference9 = this.f7.settings.iterator();
            loop106: while (true) {
                saved7 = ((Iterator) reference9).hasNext();
                if (!(saved7)) {
                    break loop106;
                }
                reference10 = ((Setting) ((Iterator) reference9).next());
                arg0.fill(this.f8, (this.f9 + integer8), (this.f8 + this.f10), ((this.f9 + integer8) + 12), integer6);
                reference11 = Recovered_mw.TEXT_EMPTY;
                saved8 = (reference10 instanceof ModeSetting);
                if (saved8) {
                    reference12 = ((ModeSetting) reference10);
                    reference11 = reference12.getValue();
                } else {
                    saved9 = (reference10 instanceof BooleanSetting);
                    if (saved9) {
                        reference13 = ((BooleanSetting) reference10);
                        saved10 = reference13.getValue();
                        reference11 = (saved10 ? Recovered_mw.TEXT_AON : Recovered_mw.TEXT_COFF);
                    } else {
                        saved11 = (reference10 instanceof PositionSetting);
                        if (saved11) {
                            reference14 = ((PositionSetting) reference10);
                            reference11 = Recovered_mw.TEXT_COFF;
                        } else {
                            saved12 = (reference10 instanceof NumberSetting);
                            if (saved12) {
                                reference15 = ((NumberSetting) reference10);
                                number16 = reference15.getValue();
                                number18 = number16;
                                saved13 = this.f181;
                                if (!((reference15 != saved13))) {
                                    local20 = System.nanoTime();
                                    number22 = Math.min((((double) (local20 - this.f183)) * 1e-09), 0.05);
                                    this.f183 = local20;
                                    number24 = (1.0 - Math.exp((-18.0 * number22)));
                                    this.f182 = (this.f182 + ((number16 - this.f182) * number24));
                                    number18 = this.f182;
                                }
                                number20 = (reference15.getMaximum() - reference15.getMinimum());
                                saved14 = JvmSupport.dcmpl(number20, 0.0);
                                number22 = (!((saved14 != 0)) ? 0.0 : ((number18 - reference15.getMinimum()) / number20));
                                number22 = Math.max(0.0, Math.min(1.0, number22));
                                integer24 = ((int) (((double) this.f10) * number22));
                                arg0.fill(this.f8, ((this.f9 + integer8) + 11), (this.f8 + this.f10), ((this.f9 + integer8) + 12), integer7);
                                arg0.fill(this.f8, ((this.f9 + integer8) + 11), (this.f8 + integer24), ((this.f9 + integer8) + 12), integer5);
                                reference11 = String.valueOf(number16);
                            }
                        }
                    }
                }
                arg0.pose().pushMatrix();
                arg0.pose().scale(0.8f, 0.8f);
                floating12 = (((float) (this.f8 + 4)) * 1.25f);
                floating13 = ((((float) (this.f9 + integer8)) + 3.5f) * 1.25f);
                reference14 = ("" + ((Setting) reference10).getName() + ": ");
                arg0.text(Minecraft.getInstance().font, ((String) reference14), ((int) floating12), ((int) floating13), integer4);
                arg0.text(Minecraft.getInstance().font, reference11, ((int) (floating12 + ((float) Minecraft.getInstance().font.width(((String) reference14))))), ((int) floating13), integer5);
                arg0.pose().popMatrix();
                integer8 += 12;
                continue loop106;
            }
            arg0.fill(this.f8, (this.f9 + integer8), (this.f8 + this.f10), ((this.f9 + integer8) + this.f11), integer6);
            reference9 = Recovered_mw.TEXT_BIND;
            saved15 = this.f13;
            if (saved15) {
                reference10 = Recovered_mw.TEXT_PRESS_KEY;
            } else {
                saved16 = this.f7.getKeybind();
                if (!((saved16 != 0))) {
                    reference10 = Recovered_mw.TEXT_NONE;
                } else {
                    reference11 = GLFW.glfwGetKeyName(this.f7.getKeybind(), 0);
                    reference10 = (!((reference11 == null)) ? reference11.toUpperCase() : String.valueOf(this.f7.getKeybind()));
                }
            }
            saved17 = this.f7.isHidden();
            if (saved17) {
                reference10 = ("" + reference10 + " \u00a7c(Hidden)");
            }
            arg0.text(Minecraft.getInstance().font, ((String) reference9), (this.f8 + 4), ((this.f9 + integer8) + 4), integer4);
            arg0.text(Minecraft.getInstance().font, ((String) reference10), ((this.f8 + 4) + Minecraft.getInstance().font.width(((String) reference9))), ((this.f9 + integer8) + 4), integer5);
            return;
        }
    }

    public Recovered_mw(Module arg0) {
        this.f11 = 15;
        this.f7 = arg0;
    }
}
