package cryptix.util;

import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Reconstructed from a/gm.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_gm {
    public int f5;
    private final List f149;
    public int f4;
    protected final int width;
    private final int f146;
    public boolean f6;
    public final String f3;
    private long f148;
    private float f147;

    public void m107() {
        boolean saved1 = false;
        Iterator reference1 = null;
        boolean saved2 = false;
        Recovered_mw reference2 = null;
        saved1 = this.f6;
        if (!(saved1)) {
            return;
        } else {
            reference1 = this.f149.iterator();
            loop8: while (true) {
                saved2 = reference1.hasNext();
                if (!(saved2)) {
                    break loop8;
                }
                reference2 = ((Recovered_mw) reference1.next());
                reference2.m117();
                continue loop8;
            }
            return;
        }
    }

    public List m108() {
        return this.f149;
    }

    public void m101(GuiGraphicsExtractor arg0) {
        int integer2 = 0;
        long local3 = 0L;
        int saved1 = 0;
        float floating5 = 0.0f;
        boolean saved2 = false;
        float floating6 = 0.0f;
        float floating7 = 0.0f;
        float floating8 = 0.0f;
        int saved3 = 0;
        int integer9 = 0;
        Iterator reference10 = null;
        boolean saved4 = false;
        Recovered_mw reference11 = null;
        int integer10 = 0;
        int integer11 = 0;
        Iterator reference12 = null;
        boolean saved5 = false;
        Recovered_mw reference13 = null;
        boolean saved6 = false;
        int saved7 = 0;
        integer2 = Recovered_eg.m31();
        local3 = System.nanoTime();
        saved1 = JvmSupport.lcmp(this.f148, 0L);
        if (!((saved1 != 0))) {
            this.f148 = local3;
        }
        floating5 = Math.min((((float) (local3 - this.f148)) * 1e-09f), 0.05f);
        this.f148 = local3;
        saved2 = this.f6;
        floating6 = (saved2 ? 1.0f : 0.0f);
        floating7 = 12.0f;
        floating8 = (1.0f - ((float) Math.exp(((double) ((-floating7) * floating5)))));
        this.f147 = (this.f147 + ((floating6 - this.f147) * floating8));
        saved3 = JvmSupport.fcmpg(Math.abs((this.f147 - floating6)), 0.001f);
        if (!((saved3 >= 0))) {
            this.f147 = floating6;
        }
        arg0.fill(this.f4, this.f5, (this.f4 + 100), (this.f5 + 15), integer2);
        arg0.text(Minecraft.getInstance().font, this.f3, (this.f4 + 4), (this.f5 + 3), -1);
        integer9 = 15;
        reference10 = this.f149.iterator();
        loop102: while (true) {
            saved4 = reference10.hasNext();
            if (!(saved4)) {
                break loop102;
            }
            reference11 = ((Recovered_mw) reference10.next());
            integer9 = (integer9 + reference11.m114());
            continue loop102;
        }
        integer10 = 15;
        integer11 = ((int) (((float) integer9) * this.f147));
        reference12 = this.f149.iterator();
        loop128: while (true) {
            saved5 = reference12.hasNext();
            if (!(saved5)) {
                break loop128;
            }
            reference13 = ((Recovered_mw) reference12.next());
            if (!((integer10 <= integer11))) {
                reference13.m118(floating5, false);
                break loop128;
            } else {
                reference13.m118(floating5, this.f6);
                reference13.f8 = this.f4;
                reference13.f9 = (this.f5 + integer10);
                reference13.f10 = 100;
                saved6 = this.f6;
                if (!(saved6)) {
                    saved7 = reference13.f14;
                    if (!((saved7 <= 5))) {
                        reference13.m111(arg0, integer2);
                    }
                } else {
                    reference13.m111(arg0, integer2);
                }
                integer10 = (integer10 + reference13.m114());
                continue loop128;
            }
        }
    }

    public boolean m103(double arg0, double arg1) {
        int saved1 = 0;
        int saved2 = 0;
        int saved3 = 0;
        int saved4 = 0;
        int branchValue5 = 0;
        int branchValue6 = 0;
        int branchValue7 = 0;
        int integer0 = 0;
        saved1 = JvmSupport.dcmpl(arg0, ((double) this.f4));
        if (!((saved1 < 0))) {
            saved2 = JvmSupport.dcmpg(arg0, ((double) (this.f4 + 100)));
            if (!((saved2 > 0))) {
                saved3 = JvmSupport.dcmpl(arg1, ((double) this.f5));
                if (!((saved3 < 0))) {
                    saved4 = JvmSupport.dcmpg(arg1, ((double) (this.f5 + 15)));
                    branchValue5 = (!((saved4 > 0)) ? 1 : 0);
                } else {
                    branchValue5 = 0;
                }
                branchValue6 = branchValue5;
            } else {
                branchValue6 = 0;
            }
            branchValue7 = branchValue6;
        } else {
            branchValue7 = 0;
        }
        integer0 = branchValue7;
        return (integer0 != 0);
    }

    public void m106(double arg0, double arg1) {
        boolean saved1 = false;
        Iterator reference5 = null;
        boolean saved2 = false;
        Recovered_mw reference6 = null;
        saved1 = this.f6;
        if (!(saved1)) {
            return;
        } else {
            reference5 = this.f149.iterator();
            loop8: while (true) {
                saved2 = reference5.hasNext();
                if (!(saved2)) {
                    break loop8;
                }
                reference6 = ((Recovered_mw) reference5.next());
                reference6.m116(arg0, arg1);
                continue loop8;
            }
            return;
        }
    }

    public boolean m102(double arg0, double arg1) {
        int saved1 = 0;
        int saved2 = 0;
        int saved3 = 0;
        int saved4 = 0;
        int branchValue5 = 0;
        int branchValue6 = 0;
        int branchValue7 = 0;
        int integer0 = 0;
        saved1 = JvmSupport.dcmpl(arg0, ((double) this.f4));
        if (!((saved1 < 0))) {
            saved2 = JvmSupport.dcmpg(arg0, ((double) (this.f4 + 100)));
            if (!((saved2 > 0))) {
                saved3 = JvmSupport.dcmpl(arg1, ((double) this.f5));
                if (!((saved3 < 0))) {
                    saved4 = JvmSupport.dcmpg(arg1, ((double) (this.f5 + 15)));
                    branchValue5 = (!((saved4 > 0)) ? 1 : 0);
                } else {
                    branchValue5 = 0;
                }
                branchValue6 = branchValue5;
            } else {
                branchValue6 = 0;
            }
            branchValue7 = branchValue6;
        } else {
            branchValue7 = 0;
        }
        integer0 = branchValue7;
        return (integer0 != 0);
    }

    public void m104(double arg0, double arg1, int arg2) {
        boolean saved1 = false;
        boolean saved2 = false;
        boolean saved3 = false;
        Iterator reference6 = null;
        boolean saved4 = false;
        Recovered_mw reference7 = null;
        boolean saved5 = false;
        boolean saved6 = false;
        if (!((arg2 != 1))) {
            saved1 = this.m103(arg0, arg1);
            if (saved1) {
                saved2 = this.f6;
                this.f6 = ((!(saved2) ? 1 : 0) != 0);
                return;
            } else {
                saved3 = this.f6;
                if (!(saved3)) {
                    return;
                } else {
                    reference6 = this.f149.iterator();
                    loop25: while (true) {
                        saved4 = reference6.hasNext();
                        if (!(saved4)) {
                            break loop25;
                        }
                        reference7 = ((Recovered_mw) reference6.next());
                        reference7.m112(arg0, arg1, arg2);
                        continue loop25;
                    }
                    return;
                }
            }
        } else {
            saved5 = this.f6;
            if (!(saved5)) {
                return;
            } else {
                reference6 = this.f149.iterator();
                loop25: while (true) {
                    saved6 = reference6.hasNext();
                    if (!(saved6)) {
                        break loop25;
                    }
                    reference7 = ((Recovered_mw) reference6.next());
                    reference7.m112(arg0, arg1, arg2);
                    continue loop25;
                }
                return;
            }
        }
    }

    public Recovered_gm(String arg0, int arg1, int arg2, List arg3) {
        Iterator reference5 = null;
        boolean saved1 = false;
        Module reference6 = null;
        this.width = 100;
        this.f146 = 15;
        this.f149 = new ArrayList();
        this.f3 = arg0;
        this.f4 = arg1;
        this.f5 = arg2;
        if (!((arg3 == null))) {
            reference5 = arg3.iterator();
            loop27: while (true) {
                saved1 = reference5.hasNext();
                if (!(saved1)) {
                    break loop27;
                }
                reference6 = ((Module) reference5.next());
                this.f149.add(new Recovered_mw(reference6));
                continue loop27;
            }
        }
    }

    public void m105(int arg0) {
        Iterator reference2 = null;
        boolean saved1 = false;
        Recovered_mw reference3 = null;
        reference2 = this.f149.iterator();
        loop4: while (true) {
            saved1 = reference2.hasNext();
            if (!(saved1)) {
                break loop4;
            }
            reference3 = ((Recovered_mw) reference2.next());
            reference3.m115(arg0);
            continue loop4;
        }
    }
}
