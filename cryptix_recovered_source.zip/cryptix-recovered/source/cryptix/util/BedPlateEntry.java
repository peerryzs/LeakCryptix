package cryptix.util;

import java.util.Objects;
import net.minecraft.world.item.ItemStack;

/**
 * Reconstructed from a/uz.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public final class BedPlateEntry {
    public final int y;
    public final int z;
    public final int x;
    public final ItemStack stack;

    public ItemStack stack() {
        return this.stack;
    }

    public final String toString() {
        Object reference0 = this;
        reference0 = ("uz[" + "x=" + ((BedPlateEntry) reference0).y + ", y=" + ((BedPlateEntry) reference0).z + ", z=" + ((BedPlateEntry) reference0).x + ", stack=" + ((BedPlateEntry) reference0).stack + "]");
        return ((String) reference0);
    }

    public final boolean equals(Object arg0) {
        int integer0 = 0;
        integer0 = ((this == arg0 || (arg0 instanceof BedPlateEntry && (this.y == ((BedPlateEntry) arg0).y) && (this.z == ((BedPlateEntry) arg0).z) && (this.x == ((BedPlateEntry) arg0).x) && Objects.equals(this.stack, ((BedPlateEntry) arg0).stack))) ? 1 : 0);
        return (integer0 != 0);
    }

    public int y() {
        return this.y;
    }

    public int x() {
        return this.x;
    }

    public BedPlateEntry(int arg0, int arg1, int arg2, ItemStack arg3) {
        this.x = arg0;
        this.y = arg1;
        this.z = arg2;
        this.stack = arg3;
    }

    public int z() {
        return this.z;
    }

    public final int hashCode() {
        int integer0 = 0;
        integer0 = (31 * (31 * (31 * (31 * 0 + this.y) + this.z) + this.x) + Objects.hashCode(this.stack));
        return integer0;
    }
}
