package cryptix.util;

import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;

/**
 * Reconstructed from a/gt.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_gt implements MinecraftAccess {
    private static int f903;
    private static final String TEXT_BAD_PACKET;
    private static int f902;

    public Recovered_gt() {
    }

    public static boolean m25(Packet arg0) {
        boolean saved1 = false;
        ServerboundSetCarriedItemPacket reference1 = null;
        int integer2 = 0;
        int saved2 = 0;
        int saved3 = 0;
        int saved4 = 0;
        int integer0 = 0;
        saved1 = (arg0 instanceof ServerboundSetCarriedItemPacket);
        if (saved1) {
            reference1 = ((ServerboundSetCarriedItemPacket) (Object) arg0);
            integer2 = reference1.getSlot();
            saved2 = Recovered_gt.f902;
            if (!((integer2 == saved2))) {
                saved3 = Minecraft.getInstance().player.tickCount;
                saved4 = Recovered_gt.f903;
                if (!((saved3 != saved4))) {
                    System.out.println(Recovered_gt.TEXT_BAD_PACKET);
                    integer0 = 1;
                    return (integer0 != 0);
                } else {
                    Recovered_gt.f902 = integer2;
                    Recovered_gt.f903 = Minecraft.getInstance().player.tickCount;
                    integer0 = 0;
                    return (integer0 != 0);
                }
            } else {
                System.out.println(Recovered_gt.TEXT_BAD_PACKET);
                integer0 = 1;
                return (integer0 != 0);
            }
        } else {
            integer0 = 0;
            return (integer0 != 0);
        }
    }

    static {
        TEXT_BAD_PACKET = new String("bad packet");
    }
}
