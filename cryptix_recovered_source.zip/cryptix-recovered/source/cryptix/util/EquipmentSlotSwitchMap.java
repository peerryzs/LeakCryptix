package cryptix.util;

import net.minecraft.world.entity.EquipmentSlot;

/**
 * Reconstructed from a/gj.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class EquipmentSlotSwitchMap {
    public static final int[] $SwitchMap$net$minecraft$world$entity$EquipmentSlot;

    static {
        java.lang.NoSuchFieldError reference0 = null;
        $SwitchMap$net$minecraft$world$entity$EquipmentSlot = new int[EquipmentSlot.values().length];
        try {
            EquipmentSlotSwitchMap.$SwitchMap$net$minecraft$world$entity$EquipmentSlot[EquipmentSlot.HEAD.ordinal()] = 1;
        } catch (java.lang.NoSuchFieldError caught1) {
            reference0 = caught1;
        }
        try {
            EquipmentSlotSwitchMap.$SwitchMap$net$minecraft$world$entity$EquipmentSlot[EquipmentSlot.CHEST.ordinal()] = 2;
        } catch (java.lang.NoSuchFieldError caught2) {
            reference0 = caught2;
        }
        try {
            EquipmentSlotSwitchMap.$SwitchMap$net$minecraft$world$entity$EquipmentSlot[EquipmentSlot.LEGS.ordinal()] = 3;
        } catch (java.lang.NoSuchFieldError caught3) {
            reference0 = caught3;
        }
        try {
            EquipmentSlotSwitchMap.$SwitchMap$net$minecraft$world$entity$EquipmentSlot[EquipmentSlot.FEET.ordinal()] = 4;
        } catch (java.lang.NoSuchFieldError caught4) {
            reference0 = caught4;
        }
    }
}
