package cryptix.command;

import cryptix.CryptixClient;
import net.minecraft.client.Minecraft;

/**
 * Reconstructed from a/o.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class SayCommand extends Command {
    private static final String TEXT_S;
    private static final String TEXT_SAY_MESSAGE;
    private static final String TEXT_SAY;
    private static final String TEXT_SAY_2;

    public void m0(String[] arg0, String arg1) {
        int saved1 = 0;
        String reference3 = null;
        saved1 = arg0.length;
        if (!((saved1 <= 1))) {
            reference3 = arg1.substring((arg1.indexOf(32) + 1));
            Minecraft.getInstance().getConnection().sendChat(reference3);
        } else {
            CryptixClient.sendPrefixedMessage(("Usage: ." + this.f1));
        }
    }

    public SayCommand() {
        super(SayCommand.TEXT_SAY, SayCommand.TEXT_SAY_MESSAGE, new String[] {SayCommand.TEXT_SAY_2, SayCommand.TEXT_S});
    }

    static {
        TEXT_SAY = new String("Say");
        TEXT_SAY_MESSAGE = new String("say <message>");
        TEXT_SAY_2 = new String("say");
        TEXT_S = new String("s");
    }
}
