package cryptix.command;

import cryptix.CryptixClient;
import cryptix.module.Module;
import cryptix.module.ModuleManager;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * Reconstructed from a/v.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class ToggleCommand extends Command {
    private static final String TEXT_DISABLED;
    private static final String TEXT_TOGGLE;
    private static final String TEXT_INVALID_MODULE;
    private static final String TEXT_TOGGLE_NAME;
    private static final String TEXT_T;
    private static final String TEXT_ENABLED;
    private static final String TEXT_TOGGLE_2;

    static {
        TEXT_TOGGLE_2 = new String("Toggle");
        TEXT_TOGGLE_NAME = new String("toggle <name>");
        TEXT_TOGGLE = new String("toggle");
        TEXT_T = new String("t");
        TEXT_ENABLED = new String("Enabled");
        TEXT_DISABLED = new String("Disabled");
        TEXT_INVALID_MODULE = new String("Invalid module");
    }

    public void m0(String[] arg0, String arg1) {
        int saved1 = 0;
        Object reference3 = null;
        int integer4 = 0;
        Iterator reference5 = null;
        boolean saved2 = false;
        Module reference6 = null;
        boolean saved3 = false;
        boolean saved4 = false;
        saved1 = arg0.length;
        if (!((saved1 <= 1))) {
            reference3 = arg0[1];
            integer4 = 0;
            reference5 = ModuleManager.getModules().iterator();
            loop13: while (true) {
                saved2 = reference5.hasNext();
                if (!(saved2)) {
                    break loop13;
                }
                reference6 = ((Module) reference5.next());
                saved3 = reference6.getName().equalsIgnoreCase(((String) reference3));
                if (saved3) {
                    reference6.toggle();
                    saved4 = reference6.isEnabled();
                    CryptixClient.sendPrefixedMessage(("" + (saved4 ? ToggleCommand.TEXT_ENABLED : ToggleCommand.TEXT_DISABLED) + " " + reference3));
                    integer4 = 1;
                    break loop13;
                } else {
                    continue loop13;
                }
            }
            if (!((integer4 != 0))) {
                CryptixClient.sendPrefixedMessage(ToggleCommand.TEXT_INVALID_MODULE);
            }
        } else {
            CryptixClient.sendPrefixedMessage(("Usage: ." + this.f1));
        }
    }

    public Collection m1(String[] arg0) {
        int saved1 = 0;
        List reference0 = null;
        saved1 = arg0.length;
        if (!((saved1 > 1))) {
            reference0 = ModuleManager.getModules().stream().map((lambdaArg0) -> ((Module) lambdaArg0).getName()).toList();
            return ((Collection) (Object) reference0);
        } else {
            reference0 = List.of();
            return ((Collection) (Object) reference0);
        }
    }

    public ToggleCommand() {
        super(ToggleCommand.TEXT_TOGGLE_2, ToggleCommand.TEXT_TOGGLE_NAME, new String[] {ToggleCommand.TEXT_TOGGLE, ToggleCommand.TEXT_T});
    }
}
