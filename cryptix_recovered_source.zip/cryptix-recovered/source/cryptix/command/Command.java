package cryptix.command;

import java.util.Collection;
import java.util.List;

/**
 * Reconstructed from a/s.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public abstract class Command {
    public String f0;
    public String f1;
    public String[] f2;

    public abstract void m0(String[] arg0, String arg1);

    public Collection m1(String[] arg0) {
        List reference0 = null;
        reference0 = List.of();
        return ((Collection) (Object) reference0);
    }

    public Command(String arg0, String arg1, String[] arg2) {
        this.f0 = arg0;
        this.f1 = arg1;
        this.f2 = arg2;
    }
}
