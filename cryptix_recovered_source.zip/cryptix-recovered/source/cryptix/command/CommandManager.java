package cryptix.command;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * Reconstructed from a/g.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class CommandManager {
    private static final String TEXT_EMPTY;
    private static List f56;
    private static final String TEXT_EMPTY_2;

    public static Command m10(String arg0) {
        Iterator reference1 = null;
        boolean saved1 = false;
        Command reference2 = null;
        Object reference0 = arg0;
        boolean saved2 = false;
        String[] reference3 = null;
        int integer4 = 0;
        int integer5 = 0;
        Object reference6 = null;
        boolean saved3 = false;
        reference1 = CommandManager.f56.iterator();
        loop3: while (true) {
            saved1 = reference1.hasNext();
            if (!(saved1)) {
                break loop3;
            }
            reference2 = ((Command) reference1.next());
            saved2 = reference2.f0.equalsIgnoreCase(((String) reference0));
            if (saved2) {
                reference0 = reference2;
                return ((Command) reference0);
            }
            reference3 = reference2.f2;
            integer4 = reference3.length;
            integer5 = 0;
            loop27: while (true) {
                if ((integer5 >= integer4)) {
                    break loop27;
                }
                reference6 = reference3[integer5];
                saved3 = ((String) reference6).equalsIgnoreCase(((String) reference0));
                if (saved3) {
                    reference0 = reference2;
                    return ((Command) reference0);
                }
                integer5++;
                continue loop27;
            }
            continue loop3;
        }
        reference0 = null;
        return ((Command) reference0);
    }

    static {
        TEXT_EMPTY_2 = new String(".");
        TEXT_EMPTY = new String(" ");
        f56 = new ArrayList();
    }

    public static void m8() {
        CommandManager.f56.add(new BindCommand());
        CommandManager.f56.add(new HelpCommand());
        CommandManager.f56.add(new SayCommand());
        CommandManager.f56.add(new ToggleCommand());
    }

    public static void m12(String arg0) {
        boolean saved1 = false;
        String[] reference1 = null;
        int saved2 = 0;
        Object reference2 = null;
        int integer3 = 0;
        int integer4 = 0;
        Command reference5 = null;
        int integer6 = 0;
        int saved3 = 0;
        boolean saved4 = false;
        saved1 = arg0.startsWith(CommandManager.TEXT_EMPTY_2);
        if (!(saved1)) {
            return;
        } else {
            arg0 = arg0.substring(1);
            reference1 = arg0.split(CommandManager.TEXT_EMPTY);
            saved2 = reference1.length;
            if (!((saved2 <= 0))) {
                reference2 = reference1[0];
                integer3 = 0;
                integer4 = CommandManager.f56.size();
                loop25: while (true) {
                    if ((integer3 >= integer4)) {
                        break loop25;
                    }
                    reference5 = ((Command) CommandManager.f56.get(integer3));
                    integer6 = 0;
                    loop35: while (true) {
                        saved3 = reference5.f2.length;
                        if ((integer6 >= saved3)) {
                            break loop35;
                        }
                        saved4 = reference5.f2[integer6].equalsIgnoreCase(((String) reference2));
                        if (saved4) {
                            reference5.m0(reference1, arg0);
                            return;
                        }
                        integer6++;
                        continue loop35;
                    }
                    integer3++;
                    continue loop25;
                }
                return;
            } else {
                return;
            }
        }
    }

    public CommandManager() {
    }

    public static List m9() {
        return CommandManager.f56;
    }

    public static List m11() {
        ArrayList reference0 = null;
        Iterator reference1 = null;
        boolean saved1 = false;
        Command reference2 = null;
        reference0 = new ArrayList();
        reference1 = CommandManager.f56.iterator();
        loop7: while (true) {
            saved1 = reference1.hasNext();
            if (!(saved1)) {
                break loop7;
            }
            reference2 = ((Command) reference1.next());
            reference0.addAll(((Collection) (Object) Arrays.asList(reference2.f2)));
            continue loop7;
        }
        return reference0;
    }
}
