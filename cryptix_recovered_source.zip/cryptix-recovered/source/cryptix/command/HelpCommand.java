package cryptix.command;

import cryptix.CryptixClient;
import java.util.Iterator;

/**
 * Reconstructed from a/x.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class HelpCommand extends Command {
    private static final String TEXT_H;
    private static final String TEXT_HELP;
    private static final String TEXT_EMPTY;
    private static final String TEXT_AVAILABLE_COMMANDS;
    private static final String TEXT_HELP_2;
    private static final String TEXT_EMPTY_2;

    public void m0(String[] arg0, String arg1) {
        Iterator reference3 = null;
        boolean saved1 = false;
        Command reference4 = null;
        String reference5 = null;
        CryptixClient.sendPrefixedMessage(HelpCommand.TEXT_AVAILABLE_COMMANDS);
        reference3 = CommandManager.m9().iterator();
        loop5: while (true) {
            saved1 = reference3.hasNext();
            if (!(saved1)) {
                break loop5;
            }
            reference4 = ((Command) reference3.next());
            reference5 = String.join(HelpCommand.TEXT_EMPTY_2, reference4.f2);
            CryptixClient.sendPrefixedMessage(("." + reference4.f1 + " \u00a77[" + reference5 + "]"));
            continue loop5;
        }
    }

    static {
        TEXT_HELP = new String("Help");
        TEXT_HELP_2 = new String("help");
        TEXT_H = new String("h");
        TEXT_EMPTY = new String("?");
        TEXT_AVAILABLE_COMMANDS = new String("Available Commands:");
        TEXT_EMPTY_2 = new String(", ");
    }

    public HelpCommand() {
        super(HelpCommand.TEXT_HELP, HelpCommand.TEXT_HELP_2, new String[] {HelpCommand.TEXT_HELP_2, HelpCommand.TEXT_H, HelpCommand.TEXT_EMPTY});
    }
}
