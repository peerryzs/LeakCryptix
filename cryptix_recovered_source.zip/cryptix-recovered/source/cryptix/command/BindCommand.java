package cryptix.command;

import com.mojang.blaze3d.platform.InputConstants;
import cryptix.CryptixClient;
import cryptix.module.Module;
import cryptix.module.ModuleManager;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * Reconstructed from a/n.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class BindCommand extends Command {
    private static final String TEXT_BIND_NAME_KEY;
    private static final List f65;
    private static final String TEXT_NONE;
    private static final String TEXT_BIND;
    private static final String TEXT_NONE_2;
    private static final String TEXT_UNBIND;
    private static final String TEXT_BIND_2;
    private static final String TEXT_B;
    private static final String TEXT_KEY;

    public void m0(String[] arg0, String arg1) {
        int saved1 = 0;
        Object reference3 = null;
        Object reference4 = null;
        Module reference5 = null;
        Object reference6 = null;
        boolean saved2 = false;
        Module reference7 = null;
        boolean saved3 = false;
        boolean saved4 = false;
        boolean saved5 = false;
        InputConstants.Key saved6 = null;
        saved1 = arg0.length;
        if (!((saved1 <= 2))) {
            reference3 = arg0[1];
            reference4 = arg0[2];
            reference5 = null;
            reference6 = ModuleManager.getModules().iterator();
            loop17: while (true) {
                saved2 = ((Iterator) reference6).hasNext();
                if (!(saved2)) {
                    break loop17;
                }
                reference7 = ((Module) ((Iterator) reference6).next());
                saved3 = reference7.getName().equalsIgnoreCase(((String) reference3));
                if (saved3) {
                    reference5 = reference7;
                    break loop17;
                } else {
                    continue loop17;
                }
            }
            if (!((reference5 != null))) {
                CryptixClient.sendPrefixedMessage(("Invalid module: " + reference3));
                return;
            } else {
                saved4 = ((String) reference4).equalsIgnoreCase(BindCommand.TEXT_NONE_2);
                if (!(saved4)) {
                    saved5 = ((String) reference4).equalsIgnoreCase(BindCommand.TEXT_UNBIND);
                    if (saved5) {
                        reference5.setKeybind(InputConstants.UNKNOWN.getValue());
                        CryptixClient.sendPrefixedMessage(("Unbound " + reference5.getName()));
                        return;
                    } else {
                        reference6 = BindCommand.pm$5(((String) reference4));
                        saved6 = InputConstants.UNKNOWN;
                        if (!((reference6 != saved6))) {
                            CryptixClient.sendPrefixedMessage(("Invalid key: " + reference4));
                            return;
                        } else {
                            reference5.setKeybind(((InputConstants.Key) reference6).getValue());
                            CryptixClient.sendPrefixedMessage(("Bound " + reference5.getName() + " to " + ((String) reference4).toUpperCase()));
                            return;
                        }
                    }
                } else {
                    reference5.setKeybind(InputConstants.UNKNOWN.getValue());
                    CryptixClient.sendPrefixedMessage(("Unbound " + reference5.getName()));
                    return;
                }
            }
        } else {
            CryptixClient.sendPrefixedMessage(("Usage: ." + this.f1));
            return;
        }
    }

    static {
        TEXT_BIND_2 = new String("Bind");
        TEXT_BIND_NAME_KEY = new String("bind <name> <key>");
        TEXT_BIND = new String("bind");
        TEXT_B = new String("b");
        TEXT_NONE_2 = new String("none");
        TEXT_UNBIND = new String("unbind");
        TEXT_KEY = new String("KEY_");
        TEXT_NONE = new String("NONE");
        f65 = BindCommand.pm$4();
    }

    public BindCommand() {
        super(BindCommand.TEXT_BIND_2, BindCommand.TEXT_BIND_NAME_KEY, new String[] {BindCommand.TEXT_BIND, BindCommand.TEXT_B});
    }

    private static List pm$4() {
        ArrayList reference0 = null;
        Field[] reference1 = null;
        int integer2 = 0;
        int integer3 = 0;
        Object reference4 = null;
        boolean saved1 = false;
        Class saved2 = null;
        Class saved3 = null;
        String reference5 = null;
        reference0 = new ArrayList();
        reference1 = InputConstants.class.getDeclaredFields();
        integer2 = reference1.length;
        integer3 = 0;
        loop12: while (true) {
            if ((integer3 >= integer2)) {
                break loop12;
            }
            reference4 = reference1[integer3];
            saved1 = ((Field) reference4).getName().startsWith(BindCommand.TEXT_KEY);
            if (saved1) {
                saved2 = ((Field) reference4).getType();
                saved3 = Integer.TYPE;
                if (!((saved2 != saved3))) {
                    reference5 = ((Field) reference4).getName().substring(4);
                    reference0.add(reference5);
                }
            }
            integer3++;
            continue loop12;
        }
        reference0.add(BindCommand.TEXT_NONE);
        return reference0;
    }

    private static InputConstants.Key pm$5(String arg0) {
        Object reference0 = arg0;
        String reference1 = null;
        Object reference2 = null;
        Class saved1 = null;
        Class saved2 = null;
        int integer3 = 0;
        reference1 = ((String) reference0).toUpperCase();
        try {
            reference2 = InputConstants.class.getDeclaredField(("KEY_" + reference1));
            saved1 = ((Field) reference2).getType();
            saved2 = Integer.TYPE;
            if (!((saved1 == saved2))) {
                reference0 = InputConstants.UNKNOWN;
                return ((InputConstants.Key) reference0);
            }
            integer3 = ((Field) reference2).getInt(null);
            reference0 = InputConstants.Type.KEYSYM.getOrCreate(integer3);
            return ((InputConstants.Key) reference0);
        } catch (java.lang.ReflectiveOperationException caught3) {
            reference2 = caught3;
            reference0 = InputConstants.UNKNOWN;
            return ((InputConstants.Key) reference0);
        }
    }

    public Collection m1(String[] arg0) {
        int saved1 = 0;
        List reference0 = null;
        int saved2 = 0;
        saved1 = arg0.length;
        if (!((saved1 > 1))) {
            reference0 = ModuleManager.getModules().stream().map((lambdaArg0) -> ((Module) lambdaArg0).getName()).toList();
            return ((Collection) (Object) reference0);
        } else {
            saved2 = arg0.length;
            if (!((saved2 != 2))) {
                reference0 = BindCommand.f65;
                return ((Collection) (Object) reference0);
            } else {
                reference0 = List.of();
                return ((Collection) (Object) reference0);
            }
        }
    }
}
