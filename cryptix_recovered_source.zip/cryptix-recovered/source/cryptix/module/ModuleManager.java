package cryptix.module;

import cryptix.module.impl.combat.AimAssist;
import cryptix.module.impl.combat.AntiBot;
import cryptix.module.impl.combat.AutoClicker;
import cryptix.module.impl.combat.Criticals;
import cryptix.module.impl.combat.KillAura;
import cryptix.module.impl.combat.SprintReset;
import cryptix.module.impl.combat.TriggerBot;
import cryptix.module.impl.combat.Velocity;
import cryptix.module.impl.misc.AutoGG;
import cryptix.module.impl.misc.Disabler;
import cryptix.module.impl.misc.Whitelist;
import cryptix.module.impl.misc.WindCharge;
import cryptix.module.impl.movement.AntiSwim;
import cryptix.module.impl.movement.AutoWalk;
import cryptix.module.impl.movement.Flight;
import cryptix.module.impl.movement.InvMove;
import cryptix.module.impl.movement.KeepSprint;
import cryptix.module.impl.movement.LongJump;
import cryptix.module.impl.movement.MoveFix;
import cryptix.module.impl.movement.NoSlow;
import cryptix.module.impl.movement.Speed;
import cryptix.module.impl.movement.Sprint;
import cryptix.module.impl.movement.Stasis;
import cryptix.module.impl.movement.Timer;
import cryptix.module.impl.player.AutoHead;
import cryptix.module.impl.player.AutoTool;
import cryptix.module.impl.player.Backtrack;
import cryptix.module.impl.player.BedAura;
import cryptix.module.impl.player.ChestStealer;
import cryptix.module.impl.player.Eagle;
import cryptix.module.impl.player.FastMine;
import cryptix.module.impl.player.FastPlace;
import cryptix.module.impl.player.InvManager;
import cryptix.module.impl.player.LagRange;
import cryptix.module.impl.player.NoFall;
import cryptix.module.impl.player.NoJumpDelay;
import cryptix.module.impl.player.Scaffold;
import cryptix.module.impl.visual.Ambience;
import cryptix.module.impl.visual.Animations;
import cryptix.module.impl.visual.AntiFire;
import cryptix.module.impl.visual.AutoBlockIn;
import cryptix.module.impl.visual.BedPlates;
import cryptix.module.impl.visual.BreakProgress;
import cryptix.module.impl.visual.Cape;
import cryptix.module.impl.visual.ClickGUI;
import cryptix.module.impl.visual.FullBright;
import cryptix.module.impl.visual.HUD;
import cryptix.module.impl.visual.Hotbar;
import cryptix.module.impl.visual.NameTags;
import cryptix.module.impl.visual.NoHurtCam;
import cryptix.module.impl.visual.PlayerESP;
import cryptix.module.impl.visual.Scoreboard;
import cryptix.module.impl.visual.SessionInfo;
import cryptix.module.impl.visual.TargetHUD;
import cryptix.module.impl.visual.Theme;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.Holder;
import net.minecraft.sounds.SoundEvents;

/**
 * Reconstructed from a/pz.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class ModuleManager {
    public static Scaffold scaffold;
    public static BedAura bedAura;
    public static Animations animations;
    public static AntiBot antiBot;
    public static Scoreboard scoreboard;
    public static Velocity velocity;
    private static List modules;
    public static ClickGUI clickGUI;
    public static Whitelist whitelist;
    public static Hotbar hotbar;
    public static LongJump longJump;
    public static Theme theme;
    public static AntiFire antiFire;
    private static List sortedModules;
    public static KillAura killAura;
    public static HUD hUD;
    public static KeepSprint keepSprint;
    public static Cape cape;
    public static AntiSwim antiSwim;

    public static List getModulesInCategory(Category arg0) {
        ArrayList reference1 = null;
        Iterator reference2 = null;
        boolean saved1 = false;
        Module reference3 = null;
        Object reference0 = arg0;
        Category saved2 = null;
        reference1 = new ArrayList();
        reference2 = ModuleManager.modules.iterator();
        loop7: while (true) {
            saved1 = reference2.hasNext();
            if (!(saved1)) {
                break loop7;
            }
            reference3 = ((Module) reference2.next());
            saved2 = reference3.getCategory();
            if (!((saved2 != reference0))) {
                reference1.add(reference3);
            }
            continue loop7;
        }
        reference0 = reference1;
        return ((List) reference0);
    }

    public static List getModules() {
        return ModuleManager.modules;
    }

    public static void initializeSortedModules() {
        ModuleManager.sortedModules = new ArrayList(((Collection) (Object) ModuleManager.modules));
        ModuleManager.sortModulesByWidth();
    }

    public static void sortModulesByWidth() {
        ModuleManager.sortedModules.sort((lambdaArg0, lambdaArg1) -> ModuleManager.sortCallback0(((Module) lambdaArg0), ((Module) lambdaArg1)));
    }

    private static int sortCallback0(Module arg0, Module arg1) {
        int integer0 = 0;
        integer0 = Integer.compare(Minecraft.getInstance().font.width(arg1.getDisplayName()), Minecraft.getInstance().font.width(arg0.getDisplayName()));
        return integer0;
    }

    public ModuleManager() {
    }

    public static List getSortedModules() {
        return ModuleManager.sortedModules;
    }

    public static void initialize() {
        List saved1 = null;
        AntiBot saved2 = null;
        List saved3 = null;
        KillAura saved4 = null;
        List saved5 = null;
        Velocity saved6 = null;
        List saved7 = null;
        AntiSwim saved8 = null;
        List saved9 = null;
        KeepSprint saved10 = null;
        List saved11 = null;
        LongJump saved12 = null;
        List saved13 = null;
        BedAura saved14 = null;
        List saved15 = null;
        Scaffold saved16 = null;
        List saved17 = null;
        Animations saved18 = null;
        List saved19 = null;
        AntiFire saved20 = null;
        List saved21 = null;
        Cape saved22 = null;
        List saved23 = null;
        ClickGUI saved24 = null;
        List saved25 = null;
        Hotbar saved26 = null;
        List saved27 = null;
        HUD saved28 = null;
        List saved29 = null;
        Scoreboard saved30 = null;
        List saved31 = null;
        Theme saved32 = null;
        List saved33 = null;
        Whitelist saved34 = null;
        ModuleManager.modules = new ArrayList();
        ModuleManager.modules.add(new AimAssist());
        saved1 = ModuleManager.modules;
        saved2 = new AntiBot();
        ModuleManager.antiBot = saved2;
        saved1.add(saved2);
        ModuleManager.modules.add(new AutoClicker());
        ModuleManager.modules.add(new Criticals());
        saved3 = ModuleManager.modules;
        saved4 = new KillAura();
        ModuleManager.killAura = saved4;
        saved3.add(saved4);
        ModuleManager.modules.add(new SprintReset());
        ModuleManager.modules.add(new TriggerBot());
        saved5 = ModuleManager.modules;
        saved6 = new Velocity();
        ModuleManager.velocity = saved6;
        saved5.add(saved6);
        saved7 = ModuleManager.modules;
        saved8 = new AntiSwim();
        ModuleManager.antiSwim = saved8;
        saved7.add(saved8);
        ModuleManager.modules.add(new AutoWalk());
        ModuleManager.modules.add(new Flight());
        ModuleManager.modules.add(new InvMove());
        saved9 = ModuleManager.modules;
        saved10 = new KeepSprint();
        ModuleManager.keepSprint = saved10;
        saved9.add(saved10);
        saved11 = ModuleManager.modules;
        saved12 = new LongJump();
        ModuleManager.longJump = saved12;
        saved11.add(saved12);
        ModuleManager.modules.add(new MoveFix());
        ModuleManager.modules.add(new NoSlow());
        ModuleManager.modules.add(new Speed());
        ModuleManager.modules.add(new Sprint());
        ModuleManager.modules.add(new Stasis());
        ModuleManager.modules.add(new Timer());
        ModuleManager.modules.add(new AutoBlockIn());
        ModuleManager.modules.add(new AutoHead());
        ModuleManager.modules.add(new AutoTool());
        ModuleManager.modules.add(new Backtrack());
        saved13 = ModuleManager.modules;
        saved14 = new BedAura();
        ModuleManager.bedAura = saved14;
        saved13.add(saved14);
        ModuleManager.modules.add(new ChestStealer());
        ModuleManager.modules.add(new Eagle());
        ModuleManager.modules.add(new FastMine());
        ModuleManager.modules.add(new FastPlace());
        ModuleManager.modules.add(new InvManager());
        ModuleManager.modules.add(new LagRange());
        ModuleManager.modules.add(new NoFall());
        ModuleManager.modules.add(new NoJumpDelay());
        saved15 = ModuleManager.modules;
        saved16 = new Scaffold();
        ModuleManager.scaffold = saved16;
        saved15.add(saved16);
        ModuleManager.modules.add(new Ambience());
        saved17 = ModuleManager.modules;
        saved18 = new Animations();
        ModuleManager.animations = saved18;
        saved17.add(saved18);
        saved19 = ModuleManager.modules;
        saved20 = new AntiFire();
        ModuleManager.antiFire = saved20;
        saved19.add(saved20);
        ModuleManager.modules.add(new BedPlates());
        ModuleManager.modules.add(new BreakProgress());
        saved21 = ModuleManager.modules;
        saved22 = new Cape();
        ModuleManager.cape = saved22;
        saved21.add(saved22);
        saved23 = ModuleManager.modules;
        saved24 = new ClickGUI();
        ModuleManager.clickGUI = saved24;
        saved23.add(saved24);
        ModuleManager.modules.add(new FullBright());
        saved25 = ModuleManager.modules;
        saved26 = new Hotbar();
        ModuleManager.hotbar = saved26;
        saved25.add(saved26);
        saved27 = ModuleManager.modules;
        saved28 = new HUD();
        ModuleManager.hUD = saved28;
        saved27.add(saved28);
        ModuleManager.modules.add(new NameTags());
        ModuleManager.modules.add(new NoHurtCam());
        ModuleManager.modules.add(new PlayerESP());
        saved29 = ModuleManager.modules;
        saved30 = new Scoreboard();
        ModuleManager.scoreboard = saved30;
        saved29.add(saved30);
        ModuleManager.modules.add(new SessionInfo());
        ModuleManager.modules.add(new TargetHUD());
        saved31 = ModuleManager.modules;
        saved32 = new Theme();
        ModuleManager.theme = saved32;
        saved31.add(saved32);
        ModuleManager.modules.add(new AutoGG());
        ModuleManager.modules.add(new Disabler());
        saved33 = ModuleManager.modules;
        saved34 = new Whitelist();
        ModuleManager.whitelist = saved34;
        saved33.add(saved34);
        ModuleManager.modules.add(new WindCharge());
    }

    public static void playToggleSound() {
        boolean saved1 = false;
        saved1 = ModuleManager.clickGUI.moduleSound.getValue();
        if (saved1) {
            Minecraft.getInstance().getSoundManager().play(((SoundInstance) (Object) SimpleSoundInstance.forUI(((Holder) (Object) SoundEvents.UI_BUTTON_CLICK), 1.0f)));
        }
    }
}
