package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.module.ModuleManager;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.NumberSetting;
import cryptix.util.EquipmentSlotSwitchMap;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.Holder;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.equipment.Equippable;

/**
 * Reconstructed from a/zf.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class InvManager extends Module {
    private final NumberSetting delay;
    private final NumberSetting gappleSlot;
    private final BooleanSetting hypixel;
    private static final String TEXT_HYPIXEL;
    private int f570;
    private final NumberSetting swordSlot;
    private static final String TEXT_INVMANAGER;
    private static final String TEXT_BLOCK_SLOT;
    private static final String TEXT_DROP_TOOLS;
    private static final String TEXT_DELAY;
    private final NumberSetting blockSlot;
    private final BooleanSetting dropTools;
    private static final String TEXT_GAPPLE_SLOT;
    private static final String TEXT_SWORD_SLOT;

    public InvManager() {
        super(InvManager.TEXT_INVMANAGER, Category.PLAYER);
        this.delay = new NumberSetting(InvManager.TEXT_DELAY, this, 2.0, 0.0, 4.0, 1.0);
        this.swordSlot = new NumberSetting(InvManager.TEXT_SWORD_SLOT, this, 1.0, 1.0, 9.0, 1.0);
        this.blockSlot = new NumberSetting(InvManager.TEXT_BLOCK_SLOT, this, 2.0, 1.0, 9.0, 1.0);
        this.gappleSlot = new NumberSetting(InvManager.TEXT_GAPPLE_SLOT, this, 3.0, 1.0, 9.0, 1.0);
        this.dropTools = new BooleanSetting(InvManager.TEXT_DROP_TOOLS, this, false);
        this.hypixel = new BooleanSetting(InvManager.TEXT_HYPIXEL, this, false);
    }

    static {
        TEXT_INVMANAGER = new String("InvManager");
        TEXT_DELAY = new String("Delay");
        TEXT_SWORD_SLOT = new String("Sword Slot");
        TEXT_BLOCK_SLOT = new String("Block Slot");
        TEXT_GAPPLE_SLOT = new String("Gapple Slot");
        TEXT_DROP_TOOLS = new String("Drop Tools");
        TEXT_HYPIXEL = new String("Hypixel");
    }

    private void pm$103() {
        int integer1 = 0;
        int integer2 = 0;
        float floating3 = 0.0f;
        EquipmentSlot reference4 = null;
        NonNullList reference5 = null;
        int integer6 = 0;
        int saved1 = 0;
        ItemStack reference7 = null;
        boolean saved2 = false;
        Equippable reference8 = null;
        EquipmentSlot saved3 = null;
        float floating9 = 0.0f;
        int saved4 = 0;
        ItemStack reference6 = null;
        float floating7 = 0.0f;
        boolean saved5 = false;
        int saved6 = 0;
        boolean saved7 = false;
        int switchValue8 = 0;
        int integer8 = 0;
        int saved9 = 0;
        boolean saved10 = false;
        EquipmentSlot saved11 = null;
        int saved12 = 0;
        boolean saved13 = false;
        int saved14 = 0;
        boolean saved15 = false;
        int switchValue16 = 0;
        int saved17 = 0;
        boolean saved18 = false;
        EquipmentSlot saved19 = null;
        int saved20 = 0;
        boolean saved21 = false;
        int saved22 = 0;
        boolean saved23 = false;
        int switchValue24 = 0;
        int saved25 = 0;
        boolean saved26 = false;
        EquipmentSlot saved27 = null;
        int saved28 = 0;
        boolean saved29 = false;
        int saved30 = 0;
        boolean saved31 = false;
        int switchValue32 = 0;
        integer1 = 0;
        loop2: while (true) {
            if ((integer1 >= 4)) {
                break loop2;
            }
            integer2 = -1;
            floating3 = -1.0f;
            switch (integer1) {
                case 0:
                {
                    reference4 = EquipmentSlot.HEAD;
                    reference5 = InvManager.mc.player.getInventory().getNonEquipmentItems();
                    integer6 = 0;
                    loop31: while (true) {
                        saved1 = reference5.size();
                        if ((integer6 >= saved1)) {
                            break loop31;
                        }
                        reference7 = ((ItemStack) reference5.get(integer6));
                        saved2 = reference7.isEmpty();
                        if (saved2) {
                        } else {
                            reference8 = ((Equippable) reference7.get(DataComponents.EQUIPPABLE));
                            if (!((reference8 == null))) {
                                saved3 = reference8.slot();
                                if (!((saved3 == reference4))) {
                                } else {
                                    floating9 = this.getArmorProtection(reference7);
                                    saved4 = JvmSupport.fcmpl(floating9, floating3);
                                    if (!((saved4 <= 0))) {
                                        floating3 = floating9;
                                        integer2 = integer6;
                                    }
                                }
                            }
                        }
                        integer6++;
                        continue loop31;
                    }
                    if (!((integer2 != -1))) {
                        integer1++;
                        continue loop2;
                    }
                    reference6 = InvManager.mc.player.getItemBySlot(reference4);
                    floating7 = this.getArmorProtection(reference6);
                    saved5 = reference6.isEmpty();
                    if (!(saved5)) {
                        saved6 = JvmSupport.fcmpl(floating7, floating3);
                        if (!((saved6 < 0))) {
                            integer1++;
                            continue loop2;
                        }
                    }
                    saved7 = reference6.isEmpty();
                    if (!(saved7)) {
                        switch (EquipmentSlotSwitchMap.$SwitchMap$net$minecraft$world$entity$EquipmentSlot[reference4.ordinal()]) {
                            case 1:
                            {
                                switchValue8 = 5;
                                break;
                            }
                            case 2:
                            {
                                switchValue8 = 6;
                                break;
                            }
                            case 3:
                            {
                                switchValue8 = 7;
                                break;
                            }
                            case 4:
                            {
                                switchValue8 = 8;
                                break;
                            }
                            default:
                            {
                                switchValue8 = -1;
                                break;
                            }
                        }
                        integer8 = switchValue8;
                        this.f570 = 0;
                        InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer8, 0, ContainerInput.THROW, InvManager.mc.player);
                        return;
                    }
                    integer8 = (!((integer2 >= 9)) ? (integer2 + 36) : integer2);
                    this.f570 = 0;
                    InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer8, 0, ContainerInput.QUICK_MOVE, InvManager.mc.player);
                    return;
                }
                case 1:
                {
                    reference4 = EquipmentSlot.CHEST;
                    reference5 = InvManager.mc.player.getInventory().getNonEquipmentItems();
                    integer6 = 0;
                    loop31: while (true) {
                        saved9 = reference5.size();
                        if ((integer6 >= saved9)) {
                            break loop31;
                        }
                        reference7 = ((ItemStack) reference5.get(integer6));
                        saved10 = reference7.isEmpty();
                        if (saved10) {
                        } else {
                            reference8 = ((Equippable) reference7.get(DataComponents.EQUIPPABLE));
                            if (!((reference8 == null))) {
                                saved11 = reference8.slot();
                                if (!((saved11 == reference4))) {
                                } else {
                                    floating9 = this.getArmorProtection(reference7);
                                    saved12 = JvmSupport.fcmpl(floating9, floating3);
                                    if (!((saved12 <= 0))) {
                                        floating3 = floating9;
                                        integer2 = integer6;
                                    }
                                }
                            }
                        }
                        integer6++;
                        continue loop31;
                    }
                    if (!((integer2 != -1))) {
                        integer1++;
                        continue loop2;
                    }
                    reference6 = InvManager.mc.player.getItemBySlot(reference4);
                    floating7 = this.getArmorProtection(reference6);
                    saved13 = reference6.isEmpty();
                    if (!(saved13)) {
                        saved14 = JvmSupport.fcmpl(floating7, floating3);
                        if (!((saved14 < 0))) {
                            integer1++;
                            continue loop2;
                        }
                    }
                    saved15 = reference6.isEmpty();
                    if (!(saved15)) {
                        switch (EquipmentSlotSwitchMap.$SwitchMap$net$minecraft$world$entity$EquipmentSlot[reference4.ordinal()]) {
                            case 1:
                            {
                                switchValue16 = 5;
                                break;
                            }
                            case 2:
                            {
                                switchValue16 = 6;
                                break;
                            }
                            case 3:
                            {
                                switchValue16 = 7;
                                break;
                            }
                            case 4:
                            {
                                switchValue16 = 8;
                                break;
                            }
                            default:
                            {
                                switchValue16 = -1;
                                break;
                            }
                        }
                        integer8 = switchValue16;
                        this.f570 = 0;
                        InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer8, 0, ContainerInput.THROW, InvManager.mc.player);
                        return;
                    }
                    integer8 = (!((integer2 >= 9)) ? (integer2 + 36) : integer2);
                    this.f570 = 0;
                    InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer8, 0, ContainerInput.QUICK_MOVE, InvManager.mc.player);
                    return;
                }
                case 2:
                {
                    reference4 = EquipmentSlot.LEGS;
                    reference5 = InvManager.mc.player.getInventory().getNonEquipmentItems();
                    integer6 = 0;
                    loop31: while (true) {
                        saved17 = reference5.size();
                        if ((integer6 >= saved17)) {
                            break loop31;
                        }
                        reference7 = ((ItemStack) reference5.get(integer6));
                        saved18 = reference7.isEmpty();
                        if (saved18) {
                        } else {
                            reference8 = ((Equippable) reference7.get(DataComponents.EQUIPPABLE));
                            if (!((reference8 == null))) {
                                saved19 = reference8.slot();
                                if (!((saved19 == reference4))) {
                                } else {
                                    floating9 = this.getArmorProtection(reference7);
                                    saved20 = JvmSupport.fcmpl(floating9, floating3);
                                    if (!((saved20 <= 0))) {
                                        floating3 = floating9;
                                        integer2 = integer6;
                                    }
                                }
                            }
                        }
                        integer6++;
                        continue loop31;
                    }
                    if (!((integer2 != -1))) {
                        integer1++;
                        continue loop2;
                    }
                    reference6 = InvManager.mc.player.getItemBySlot(reference4);
                    floating7 = this.getArmorProtection(reference6);
                    saved21 = reference6.isEmpty();
                    if (!(saved21)) {
                        saved22 = JvmSupport.fcmpl(floating7, floating3);
                        if (!((saved22 < 0))) {
                            integer1++;
                            continue loop2;
                        }
                    }
                    saved23 = reference6.isEmpty();
                    if (!(saved23)) {
                        switch (EquipmentSlotSwitchMap.$SwitchMap$net$minecraft$world$entity$EquipmentSlot[reference4.ordinal()]) {
                            case 1:
                            {
                                switchValue24 = 5;
                                break;
                            }
                            case 2:
                            {
                                switchValue24 = 6;
                                break;
                            }
                            case 3:
                            {
                                switchValue24 = 7;
                                break;
                            }
                            case 4:
                            {
                                switchValue24 = 8;
                                break;
                            }
                            default:
                            {
                                switchValue24 = -1;
                                break;
                            }
                        }
                        integer8 = switchValue24;
                        this.f570 = 0;
                        InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer8, 0, ContainerInput.THROW, InvManager.mc.player);
                        return;
                    }
                    integer8 = (!((integer2 >= 9)) ? (integer2 + 36) : integer2);
                    this.f570 = 0;
                    InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer8, 0, ContainerInput.QUICK_MOVE, InvManager.mc.player);
                    return;
                }
                case 3:
                {
                    reference4 = EquipmentSlot.FEET;
                    reference5 = InvManager.mc.player.getInventory().getNonEquipmentItems();
                    integer6 = 0;
                    loop31: while (true) {
                        saved25 = reference5.size();
                        if ((integer6 >= saved25)) {
                            break loop31;
                        }
                        reference7 = ((ItemStack) reference5.get(integer6));
                        saved26 = reference7.isEmpty();
                        if (saved26) {
                        } else {
                            reference8 = ((Equippable) reference7.get(DataComponents.EQUIPPABLE));
                            if (!((reference8 == null))) {
                                saved27 = reference8.slot();
                                if (!((saved27 == reference4))) {
                                } else {
                                    floating9 = this.getArmorProtection(reference7);
                                    saved28 = JvmSupport.fcmpl(floating9, floating3);
                                    if (!((saved28 <= 0))) {
                                        floating3 = floating9;
                                        integer2 = integer6;
                                    }
                                }
                            }
                        }
                        integer6++;
                        continue loop31;
                    }
                    if (!((integer2 != -1))) {
                        integer1++;
                        continue loop2;
                    }
                    reference6 = InvManager.mc.player.getItemBySlot(reference4);
                    floating7 = this.getArmorProtection(reference6);
                    saved29 = reference6.isEmpty();
                    if (!(saved29)) {
                        saved30 = JvmSupport.fcmpl(floating7, floating3);
                        if (!((saved30 < 0))) {
                            integer1++;
                            continue loop2;
                        }
                    }
                    saved31 = reference6.isEmpty();
                    if (!(saved31)) {
                        switch (EquipmentSlotSwitchMap.$SwitchMap$net$minecraft$world$entity$EquipmentSlot[reference4.ordinal()]) {
                            case 1:
                            {
                                switchValue32 = 5;
                                break;
                            }
                            case 2:
                            {
                                switchValue32 = 6;
                                break;
                            }
                            case 3:
                            {
                                switchValue32 = 7;
                                break;
                            }
                            case 4:
                            {
                                switchValue32 = 8;
                                break;
                            }
                            default:
                            {
                                switchValue32 = -1;
                                break;
                            }
                        }
                        integer8 = switchValue32;
                        this.f570 = 0;
                        InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer8, 0, ContainerInput.THROW, InvManager.mc.player);
                        return;
                    }
                    integer8 = (!((integer2 >= 9)) ? (integer2 + 36) : integer2);
                    this.f570 = 0;
                    InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer8, 0, ContainerInput.QUICK_MOVE, InvManager.mc.player);
                    return;
                }
                default:
                {
                    throw JvmSupport.rethrow(((Throwable) (Object) new IllegalStateException()));
                }
            }
        }
    }

    private boolean pm$105() {
        NonNullList reference1 = null;
        int integer2 = 0;
        int saved1 = 0;
        ItemStack reference3 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        boolean saved4 = false;
        boolean saved5 = false;
        boolean saved6 = false;
        int integer4 = 0;
        int integer0 = 0;
        reference1 = InvManager.mc.player.getInventory().getNonEquipmentItems();
        integer2 = 0;
        loop7: while (true) {
            saved1 = reference1.size();
            if ((integer2 >= saved1)) {
                break loop7;
            }
            reference3 = ((ItemStack) reference1.get(integer2));
            saved2 = reference3.isEmpty();
            if (saved2) {
                integer2++;
                continue loop7;
            }
            saved3 = reference3.is(ItemTags.PICKAXES);
            if (!(saved3)) {
                saved4 = reference3.is(ItemTags.AXES);
                if (!(saved4)) {
                    saved5 = reference3.is(ItemTags.SHOVELS);
                    if (!(saved5)) {
                        saved6 = reference3.is(ItemTags.HOES);
                        if (!(saved6)) {
                            integer2++;
                            continue loop7;
                        }
                    }
                }
            }
            integer4 = (!((integer2 >= 9)) ? (integer2 + 36) : integer2);
            this.f570 = 0;
            InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer4, 0, ContainerInput.THROW, InvManager.mc.player);
            integer0 = 1;
            return (integer0 != 0);
        }
        integer0 = 0;
        return (integer0 != 0);
    }

    private static void getSwordDamageCallback0(double[] arg0, Holder arg1, AttributeModifier arg2) {
        boolean saved1 = false;
        saved1 = arg1.equals(Attributes.ATTACK_DAMAGE);
        if (saved1) {
            arg0[0] = (arg0[0] + arg2.amount());
        }
    }

    private static void getArmorProtectionCallback0(double[] arg0, Holder arg1, AttributeModifier arg2) {
        boolean saved1 = false;
        saved1 = arg1.equals(Attributes.ARMOR);
        if (saved1) {
            arg0[0] = (arg0[0] + arg2.amount());
        }
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        boolean saved4 = false;
        boolean saved5 = false;
        Screen saved6 = null;
        saved1 = Events.rotation;
        if (!((event == saved1))) {
            return;
        } else {
            saved2 = (InvManager.mc.player.containerMenu instanceof ChestMenu);
            if (saved2) {
                return;
            } else {
                saved3 = (InvManager.mc.gui.screen() instanceof InventoryScreen);
                if (saved3) {
                    this.pm$98();
                } else {
                    saved4 = this.hypixel.getValue();
                    if (saved4) {
                        saved5 = ModuleManager.scaffold.isEnabled();
                        if (!(saved5)) {
                            saved6 = InvManager.mc.gui.screen();
                            if (!((saved6 != null))) {
                                this.pm$98();
                            } else {
                                this.f570 = 0;
                            }
                        } else {
                            this.f570 = 0;
                        }
                    } else {
                        this.f570 = 0;
                    }
                }
                return;
            }
        }
    }

    private void pm$100() {
        int integer1 = 0;
        NonNullList reference2 = null;
        int integer3 = 0;
        int integer4 = 0;
        int integer5 = 0;
        int saved1 = 0;
        ItemStack reference6 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        int saved4 = 0;
        integer1 = (((int) this.blockSlot.getValue()) - 1);
        if (!((integer1 < 0))) {
            if (!((integer1 <= 8))) {
                return;
            } else {
                reference2 = InvManager.mc.player.getInventory().getNonEquipmentItems();
                integer3 = -1;
                integer4 = 0;
                integer5 = 0;
                loop24: while (true) {
                    saved1 = reference2.size();
                    if ((integer5 >= saved1)) {
                        break loop24;
                    }
                    reference6 = ((ItemStack) reference2.get(integer5));
                    saved2 = reference6.isEmpty();
                    if (saved2) {
                    } else {
                        saved3 = (reference6.getItem() instanceof BlockItem);
                        if (!(saved3)) {
                        } else {
                            saved4 = reference6.getCount();
                            if (!((saved4 <= integer4))) {
                                integer4 = reference6.getCount();
                                integer3 = integer5;
                            }
                        }
                    }
                    integer5++;
                    continue loop24;
                }
                if (!((integer3 != -1))) {
                    return;
                } else {
                    if (!((integer3 != integer1))) {
                        return;
                    } else {
                        integer5 = (!((integer3 >= 9)) ? (integer3 + 36) : integer3);
                        this.f570 = 0;
                        InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer5, integer1, ContainerInput.SWAP, InvManager.mc.player);
                        return;
                    }
                }
            }
        } else {
            return;
        }
    }

    private float getArmorProtection(ItemStack arg0) {
        boolean saved1 = false;
        float floating0 = 0.0f;
        double[] reference2 = null;
        EquipmentSlot saved3 = null;
        saved1 = arg0.isEmpty();
        if (saved1) {
            floating0 = 0.0f;
            return floating0;
        } else {
            reference2 = new double[] {0.0};
            saved3 = ((Equippable) arg0.get(DataComponents.EQUIPPABLE)).slot();
            final double[] captured2 = reference2;
            arg0.forEachModifier(saved3, (lambdaArg0, lambdaArg1) -> InvManager.getArmorProtectionCallback0(captured2, ((Holder) lambdaArg0), ((AttributeModifier) lambdaArg1)));
            floating0 = ((float) reference2[0]);
            return floating0;
        }
    }

    private void pm$102() {
        int integer1 = 0;
        NonNullList reference2 = null;
        int integer3 = 0;
        int saved1 = 0;
        ItemStack reference4 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        int integer5 = 0;
        integer1 = (((int) this.gappleSlot.getValue()) - 1);
        if (!((integer1 < 0))) {
            if (!((integer1 <= 8))) {
                return;
            } else {
                reference2 = InvManager.mc.player.getInventory().getNonEquipmentItems();
                integer3 = 0;
                loop20: while (true) {
                    saved1 = reference2.size();
                    if ((integer3 >= saved1)) {
                        break loop20;
                    }
                    reference4 = ((ItemStack) reference2.get(integer3));
                    saved2 = reference4.isEmpty();
                    if (saved2) {
                        integer3++;
                        continue loop20;
                    }
                    saved3 = reference4.is(Items.GOLDEN_APPLE);
                    if (!(saved3)) {
                        integer3++;
                        continue loop20;
                    }
                    if (!((integer3 != integer1))) {
                        integer3++;
                        continue loop20;
                    }
                    integer5 = (!((integer3 >= 9)) ? (integer3 + 36) : integer3);
                    this.f570 = 0;
                    InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer5, integer1, ContainerInput.SWAP, InvManager.mc.player);
                    return;
                }
                return;
            }
        } else {
            return;
        }
    }

    private void pm$98() {
        double number1 = 0.0;
        int saved1 = 0;
        boolean saved2 = false;
        boolean saved3 = false;
        boolean saved4 = false;
        boolean saved5 = false;
        boolean saved6 = false;
        this.f570 = (this.f570 + 1);
        number1 = Math.sqrt(((InvManager.mc.player.getDeltaMovement().x * InvManager.mc.player.getDeltaMovement().x) + (InvManager.mc.player.getDeltaMovement().z * InvManager.mc.player.getDeltaMovement().z)));
        System.out.println(number1);
        saved1 = JvmSupport.dcmpg(((double) this.f570), this.delay.getValue());
        if (!((saved1 >= 0))) {
            saved2 = this.hypixel.getValue();
            if (saved2) {
                InvManager.mc.player.closeContainer();
                return;
            } else {
                saved3 = this.dropTools.getValue();
                if (saved3) {
                    saved4 = this.pm$105();
                    if (saved4) {
                        return;
                    } else {
                        this.pm$103();
                        this.pm$99();
                        this.pm$100();
                        this.pm$102();
                        return;
                    }
                } else {
                    this.pm$103();
                    this.pm$99();
                    this.pm$100();
                    this.pm$102();
                    return;
                }
            }
        } else {
            saved5 = this.dropTools.getValue();
            if (saved5) {
                saved6 = this.pm$105();
                if (saved6) {
                    return;
                } else {
                    this.pm$103();
                    this.pm$99();
                    this.pm$100();
                    this.pm$102();
                    return;
                }
            } else {
                this.pm$103();
                this.pm$99();
                this.pm$100();
                this.pm$102();
                return;
            }
        }
    }

    private void pm$99() {
        int integer1 = 0;
        NonNullList reference2 = null;
        int integer3 = 0;
        double number4 = 0.0;
        int integer6 = 0;
        ItemStack reference7 = null;
        boolean saved1 = false;
        boolean saved2 = false;
        double number8 = 0.0;
        int saved3 = 0;
        boolean saved4 = false;
        boolean saved5 = false;
        int integer8 = 0;
        integer1 = (((int) this.swordSlot.getValue()) - 1);
        if (!((integer1 < 0))) {
            if (!((integer1 <= 8))) {
                return;
            } else {
                reference2 = InvManager.mc.player.getInventory().getNonEquipmentItems();
                integer3 = -1;
                number4 = -1.7976931348623157e+308;
                integer6 = 0;
                loop24: while (true) {
                    if ((integer6 >= 36)) {
                        break loop24;
                    }
                    reference7 = InvManager.mc.player.getInventory().getItem(integer6);
                    saved1 = reference7.isEmpty();
                    if (!(saved1)) {
                        saved2 = reference7.is(ItemTags.SWORDS);
                        if (!(saved2)) {
                        } else {
                            number8 = this.getSwordDamage(reference7);
                            saved3 = JvmSupport.dcmpl(number8, number4);
                            if (!((saved3 <= 0))) {
                                number4 = number8;
                                integer3 = integer6;
                            }
                        }
                    }
                    integer6++;
                    continue loop24;
                }
                integer6 = 0;
                loop57: while (true) {
                    if ((integer6 >= 36)) {
                        break loop57;
                    }
                    if (!((integer6 != integer3))) {
                        integer6++;
                        continue loop57;
                    }
                    reference7 = ((ItemStack) reference2.get(integer6));
                    saved4 = reference7.isEmpty();
                    if (saved4) {
                        integer6++;
                        continue loop57;
                    }
                    saved5 = reference7.is(ItemTags.SWORDS);
                    if (!(saved5)) {
                        integer6++;
                        continue loop57;
                    }
                    integer8 = (!((integer6 >= 9)) ? (integer6 + 36) : integer6);
                    this.f570 = 0;
                    InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer8, 0, ContainerInput.THROW, InvManager.mc.player);
                    return;
                }
                if (!((integer3 != -1))) {
                    return;
                } else {
                    integer6 = (!((integer3 >= 9)) ? (integer3 + 36) : integer3);
                    if (!((integer3 == integer1))) {
                        this.f570 = 0;
                        InvManager.mc.gameMode.handleContainerInput(InvManager.mc.player.containerMenu.containerId, integer6, integer1, ContainerInput.SWAP, InvManager.mc.player);
                    }
                    return;
                }
            }
        } else {
            return;
        }
    }

    private double getSwordDamage(ItemStack arg0) {
        double[] reference2 = null;
        EquipmentSlot saved2 = null;
        double number0 = 0.0;
        reference2 = new double[] {0.0};
        saved2 = EquipmentSlot.MAINHAND;
        final double[] captured1 = reference2;
        arg0.forEachModifier(saved2, (lambdaArg0, lambdaArg1) -> InvManager.getSwordDamageCallback0(captured1, ((Holder) lambdaArg0), ((AttributeModifier) lambdaArg1)));
        number0 = reference2[0];
        return number0;
    }
}
