package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.mixin.MinecraftMixin_nz;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.BooleanSetting;
import cryptix.setting.NumberSetting;
import cryptix.util.Recovered_ee;

/**
 * Reconstructed from a/xi.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class FastPlace extends Module {
    private NumberSetting delay;
    private BooleanSetting blocksOnly;
    private static final String TEXT_FASTPLACE;
    private static final String TEXT_DELAY;
    private static final String TEXT_BLOCKS_ONLY;
    private int f556;

    public FastPlace() {
        super(FastPlace.TEXT_FASTPLACE, Category.PLAYER);
        this.delay = new NumberSetting(FastPlace.TEXT_DELAY, this, 1.0, 0.0, 3.0, 1.0);
        this.blocksOnly = new BooleanSetting(FastPlace.TEXT_BLOCKS_ONLY, this, true);
    }

    static {
        TEXT_FASTPLACE = new String("FastPlace");
        TEXT_DELAY = new String("Delay");
        TEXT_BLOCKS_ONLY = new String("Blocks Only");
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        int integer2 = 0;
        int saved4 = 0;
        int saved5 = 0;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            saved2 = this.blocksOnly.getValue();
            if (saved2) {
                saved3 = Recovered_ee.m45();
                if (!(saved3)) {
                    return;
                } else {
                    integer2 = ((int) this.delay.getValue());
                    if (!((integer2 != 0))) {
                        ((MinecraftMixin_nz) (Object) FastPlace.mc).setRightClickDelay(0);
                    } else {
                        saved4 = this.f556;
                        if (!((saved4 < integer2))) {
                            ((MinecraftMixin_nz) (Object) FastPlace.mc).setRightClickDelay(0);
                            this.f556 = 0;
                        }
                        this.f556 = (this.f556 + 1);
                    }
                    return;
                }
            } else {
                integer2 = ((int) this.delay.getValue());
                if (!((integer2 != 0))) {
                    ((MinecraftMixin_nz) (Object) FastPlace.mc).setRightClickDelay(0);
                } else {
                    saved5 = this.f556;
                    if (!((saved5 < integer2))) {
                        ((MinecraftMixin_nz) (Object) FastPlace.mc).setRightClickDelay(0);
                        this.f556 = 0;
                    }
                    this.f556 = (this.f556 + 1);
                }
                return;
            }
        } else {
            return;
        }
    }
}
