package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.NumberSetting;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.ItemStack;

/**
 * Reconstructed from a/em.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class ChestStealer extends Module {
    private static final String TEXT_CHESTSTEALER;
    private final NumberSetting delay;
    private final BooleanSetting hypixelChest;
    private static final String TEXT_DELAY;
    private int f531;
    private static final String TEXT_HYPIXEL_CHEST;
    private static final String TEXT_CHEST;
    private static final String TEXT_EMPTY;

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        Object reference3 = null;
        boolean saved2 = false;
        ChestMenu reference2 = null;
        boolean saved3 = false;
        Screen saved4 = null;
        boolean saved5 = false;
        boolean saved6 = false;
        int saved7 = 0;
        int integer3 = 0;
        int integer4 = 0;
        int saved8 = 0;
        ItemStack reference5 = null;
        boolean saved9 = false;
        int saved10 = 0;
        int saved11 = 0;
        boolean saved12 = false;
        int saved13 = 0;
        int saved14 = 0;
        boolean saved15 = false;
        int saved16 = 0;
        int saved17 = 0;
        boolean saved18 = false;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            reference3 = ChestStealer.mc.player.containerMenu;
            saved2 = (reference3 instanceof ChestMenu);
            if (saved2) {
                reference2 = ((ChestMenu) reference3);
                saved3 = this.hypixelChest.getValue();
                if (saved3) {
                    saved4 = ChestStealer.mc.gui.screen();
                    if (!((saved4 == null))) {
                        reference3 = ChestStealer.mc.gui.screen().getTitle();
                        saved5 = ((Component) reference3).getString().equals(ChestStealer.TEXT_CHEST);
                        if (!(saved5)) {
                            saved6 = ((Component) reference3).getString().equals(ChestStealer.TEXT_EMPTY);
                            if (!(saved6)) {
                                this.f531 = 0;
                                return;
                            } else {
                                this.f531 = (this.f531 + 1);
                                saved7 = JvmSupport.dcmpl(((double) this.f531), this.delay.getValue());
                                if (!((saved7 <= 0))) {
                                    integer3 = 1;
                                    integer4 = 0;
                                    loop58: while (true) {
                                        saved8 = reference2.getContainer().getContainerSize();
                                        if ((integer4 >= saved8)) {
                                            break loop58;
                                        }
                                        reference5 = reference2.getSlot(integer4).getItem();
                                        saved9 = reference5.isEmpty();
                                        if (saved9) {
                                            integer4++;
                                            continue loop58;
                                        } else {
                                            ChestStealer.mc.gameMode.handleContainerInput(reference2.containerId, integer4, 0, ContainerInput.QUICK_MOVE, ChestStealer.mc.player);
                                            this.f531 = 0;
                                            integer3 = 0;
                                            break loop58;
                                        }
                                    }
                                    if (!((integer3 == 0))) {
                                        ChestStealer.mc.player.closeContainer();
                                    }
                                }
                                return;
                            }
                        } else {
                            this.f531 = (this.f531 + 1);
                            saved10 = JvmSupport.dcmpl(((double) this.f531), this.delay.getValue());
                            if (!((saved10 <= 0))) {
                                integer3 = 1;
                                integer4 = 0;
                                loop58: while (true) {
                                    saved11 = reference2.getContainer().getContainerSize();
                                    if ((integer4 >= saved11)) {
                                        break loop58;
                                    }
                                    reference5 = reference2.getSlot(integer4).getItem();
                                    saved12 = reference5.isEmpty();
                                    if (saved12) {
                                        integer4++;
                                        continue loop58;
                                    } else {
                                        ChestStealer.mc.gameMode.handleContainerInput(reference2.containerId, integer4, 0, ContainerInput.QUICK_MOVE, ChestStealer.mc.player);
                                        this.f531 = 0;
                                        integer3 = 0;
                                        break loop58;
                                    }
                                }
                                if (!((integer3 == 0))) {
                                    ChestStealer.mc.player.closeContainer();
                                }
                            }
                            return;
                        }
                    } else {
                        this.f531 = (this.f531 + 1);
                        saved13 = JvmSupport.dcmpl(((double) this.f531), this.delay.getValue());
                        if (!((saved13 <= 0))) {
                            integer3 = 1;
                            integer4 = 0;
                            loop58: while (true) {
                                saved14 = reference2.getContainer().getContainerSize();
                                if ((integer4 >= saved14)) {
                                    break loop58;
                                }
                                reference5 = reference2.getSlot(integer4).getItem();
                                saved15 = reference5.isEmpty();
                                if (saved15) {
                                    integer4++;
                                    continue loop58;
                                } else {
                                    ChestStealer.mc.gameMode.handleContainerInput(reference2.containerId, integer4, 0, ContainerInput.QUICK_MOVE, ChestStealer.mc.player);
                                    this.f531 = 0;
                                    integer3 = 0;
                                    break loop58;
                                }
                            }
                            if (!((integer3 == 0))) {
                                ChestStealer.mc.player.closeContainer();
                            }
                        }
                        return;
                    }
                } else {
                    this.f531 = (this.f531 + 1);
                    saved16 = JvmSupport.dcmpl(((double) this.f531), this.delay.getValue());
                    if (!((saved16 <= 0))) {
                        integer3 = 1;
                        integer4 = 0;
                        loop58: while (true) {
                            saved17 = reference2.getContainer().getContainerSize();
                            if ((integer4 >= saved17)) {
                                break loop58;
                            }
                            reference5 = reference2.getSlot(integer4).getItem();
                            saved18 = reference5.isEmpty();
                            if (saved18) {
                                integer4++;
                                continue loop58;
                            } else {
                                ChestStealer.mc.gameMode.handleContainerInput(reference2.containerId, integer4, 0, ContainerInput.QUICK_MOVE, ChestStealer.mc.player);
                                this.f531 = 0;
                                integer3 = 0;
                                break loop58;
                            }
                        }
                        if (!((integer3 == 0))) {
                            ChestStealer.mc.player.closeContainer();
                        }
                    }
                    return;
                }
            } else {
                this.f531 = 0;
                return;
            }
        } else {
            return;
        }
    }

    public ChestStealer() {
        super(ChestStealer.TEXT_CHESTSTEALER, Category.PLAYER);
        this.delay = new NumberSetting(ChestStealer.TEXT_DELAY, this, 2.0, 0.0, 5.0, 1.0);
        this.hypixelChest = new BooleanSetting(ChestStealer.TEXT_HYPIXEL_CHEST, this, false);
    }

    static {
        TEXT_CHESTSTEALER = new String("ChestStealer");
        TEXT_DELAY = new String("Delay");
        TEXT_HYPIXEL_CHEST = new String("Hypixel Chest");
        TEXT_CHEST = new String("Chest");
        TEXT_EMPTY = new String("");
    }
}
