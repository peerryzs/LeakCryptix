package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.MotionEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.ModeSetting;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;

/**
 * Reconstructed from a/cs.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class NoFall extends Module {
    private static final String TEXT_NOFALL;
    private static final String TEXT_MODE;
    private final ModeSetting mode;
    private static final String TEXT_NOGROUND;
    private static final String TEXT_GROUND;
    private static final String TEXT_UNIVERSAL;

    static {
        TEXT_NOFALL = new String("NoFall");
        TEXT_MODE = new String("Mode");
        TEXT_UNIVERSAL = new String("Universal");
        TEXT_GROUND = new String("Ground");
        TEXT_NOGROUND = new String("NoGround");
    }

    public void onEvent(Event event) {
        MotionEvent saved1 = null;
        String reference2 = null;
        int integer3 = 0;
        String reference4 = null;
        int saved2 = 0;
        boolean saved3 = false;
        boolean saved4 = false;
        RotationEvent saved5 = null;
        int saved6 = 0;
        boolean saved7 = false;
        saved1 = Events.motion;
        if (!((event != saved1))) {
            reference2 = this.mode.getValue();
            integer3 = -1;
            reference4 = reference2;
            saved2 = reference2.hashCode();
            if (!((saved2 != 370287304))) {
                saved3 = reference2.equals(NoFall.TEXT_NOGROUND);
                if (saved3) {
                    integer3 = 1;
                }
            } else {
                if (!((saved2 != 2141373863))) {
                    saved4 = reference2.equals(NoFall.TEXT_GROUND);
                    if (saved4) {
                        integer3 = 0;
                    }
                } else {
                }
            }
            switch (integer3) {
                case 0:
                {
                    Events.motion.setOnGround(true);
                    break;
                }
                case 1:
                {
                    Events.motion.setOnGround(false);
                    break;
                }
                default:
                {
                    break;
                }
            }
        }
        saved5 = Events.rotation;
        if (!((event != saved5))) {
            saved6 = JvmSupport.dcmpl(NoFall.mc.player.fallDistance, 3.0);
            if (!((saved6 < 0))) {
                saved7 = this.mode.is(NoFall.TEXT_UNIVERSAL);
                if (saved7) {
                    NoFall.mc.player.fallDistance = 0.0;
                    NoFall.mc.getConnection().send(((Packet) (Object) new ServerboundMovePlayerPacket.Pos(NoFall.mc.player.getX(), NoFall.mc.player.getY(), NoFall.mc.player.getZ(), true, NoFall.mc.player.horizontalCollision)));
                }
            }
        }
    }

    public NoFall() {
        super(NoFall.TEXT_NOFALL, Category.PLAYER);
        this.mode = new ModeSetting(NoFall.TEXT_MODE, this, NoFall.TEXT_UNIVERSAL, new String[] {NoFall.TEXT_UNIVERSAL, NoFall.TEXT_GROUND, NoFall.TEXT_NOGROUND});
    }
}
