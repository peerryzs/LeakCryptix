package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.KeybindEvent;
import cryptix.event.impl.MotionEvent;
import cryptix.event.impl.MouseButtonEvent;
import cryptix.event.impl.PostInputEvent;
import cryptix.event.impl.PostMotionEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;
import cryptix.util.PlacementData;
import cryptix.util.Recovered_hp;
import cryptix.util.Recovered_it;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Reconstructed from a/wq.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Scaffold extends Module {
    private static final String TEXT_OFFSET;
    private int f634;
    private final BooleanSetting tellyRMB;
    private static final String TEXT_TELLY_RMB;
    private static final String TEXT_SILENT_SWING;
    private final BlockPos.MutableBlockPos f643;
    private static final String TEXT_ROTATIONS;
    private float f626;
    private final ModeSetting fastMode;
    private static final String TEXT_ROTATION_SPEED;
    public final BooleanSetting blockCount;
    private final NumberSetting sneakDelay;
    private static final String TEXT_WATCHDOG;
    private static final String TEXT_TELLY;
    private final BooleanSetting keepY;
    private final NumberSetting rotationSpeed;
    private final ModeSetting tower;
    private boolean f632;
    private static final String TEXT_TIMER_TICKS;
    private static final String TEXT_FAST_MODE;
    private final float[] f639;
    private static final String TEXT_SNEAK_DELAY;
    private boolean f631;
    private boolean f633;
    private static final String TEXT_BACKWARD;
    private static final String TEXT_RAYCAST;
    private static final String TEXT_HITVEC;
    private static final String TEXT_SCAFFOLD;
    private static final String TEXT_BLOCK_COUNT;
    private int f636;
    private float f625;
    private float f628;
    private final BooleanSetting sneak;
    private static final String TEXT_WATCHDOG_LOW;
    private int f635;
    private float f627;
    private final float[] f640;
    private static final String TEXT_WATCHDOG3;
    private static final String TEXT_DISABLED;
    private static final String TEXT_KEEP_Y;
    private final ModeSetting rotations;
    private float f624;
    private static final String TEXT_RAYCAST2;
    private static final String TEXT_TOWER;
    private static final String TEXT_SNEAK;
    private final PlacementData f623;
    private final BooleanSetting silentSwing;
    private static final String TEXT_WATCHDOG2;
    private int f638;
    private final NumberSetting timerTicks;
    private int f637;
    private boolean f642;
    private final float[] f641;
    private boolean f630;
    private boolean f629;

    private void pm$111(BlockHitResult arg0) {
        Vec3 reference2 = null;
        Vec3 reference3 = null;
        double number4 = 0.0;
        double number6 = 0.0;
        double number8 = 0.0;
        double number10 = 0.0;
        float floating12 = 0.0f;
        String reference13 = null;
        int integer14 = 0;
        String reference16 = null;
        int saved1 = 0;
        boolean saved2 = false;
        boolean saved3 = false;
        boolean saved4 = false;
        boolean saved5 = false;
        boolean saved6 = false;
        float floating15 = 0.0f;
        reference2 = Scaffold.mc.player.getEyePosition();
        reference3 = arg0.getLocation();
        number4 = (reference3.x - reference2.x);
        number6 = (reference3.y - reference2.y);
        number8 = (reference3.z - reference2.z);
        number10 = Math.sqrt(((number4 * number4) + (number8 * number8)));
        floating12 = ((float) (-Math.toDegrees(Math.atan2(number6, number10))));
        reference13 = this.rotations.getValue();
        integer14 = -1;
        reference16 = reference13;
        saved1 = reference13.hashCode();
        if (!((saved1 != -2133157087))) {
            saved2 = reference13.equals(Scaffold.TEXT_HITVEC);
            if (saved2) {
                integer14 = 4;
            }
        } else {
            if (!((saved1 != -2108346365))) {
                saved3 = reference13.equals(Scaffold.TEXT_BACKWARD);
                if (saved3) {
                    integer14 = 0;
                }
            } else {
                if (!((saved1 != -1935912781))) {
                    saved4 = reference13.equals(Scaffold.TEXT_OFFSET);
                    if (saved4) {
                        integer14 = 1;
                    }
                } else {
                    if (!((saved1 != -1642289591))) {
                        saved5 = reference13.equals(Scaffold.TEXT_RAYCAST);
                        if (saved5) {
                            integer14 = 2;
                        }
                    } else {
                        if (!((saved1 != 628630281))) {
                            saved6 = reference13.equals(Scaffold.TEXT_RAYCAST2);
                            if (saved6) {
                                integer14 = 3;
                            }
                        } else {
                        }
                    }
                }
            }
        }
        switch (integer14) {
            case 0:
            {
                this.f639[0] = (Recovered_it.m50() - 180.0f);
                this.f639[1] = floating12;
                break;
            }
            case 1:
            {
                this.f639[0] = this.getMouseSensitivityStep();
                this.f639[1] = 83.0f;
                break;
            }
            case 2:
            {
                this.pm$112(arg0, (Recovered_it.m50() - 180.0f));
                break;
            }
            case 3:
            {
                this.pm$112(arg0, this.f626);
                break;
            }
            case 4:
            default:
            {
                floating15 = (((float) Math.toDegrees(Math.atan2(number8, number4))) - 90.0f);
                this.f639[0] = floating15;
                this.f639[1] = floating12;
                break;
            }
        }
    }

    private BlockHitResult rayTraceBlock(float arg0, float arg1, float arg2) {
        Vec3 reference4 = null;
        Object reference0 = this;
        Vec3 reference5 = null;
        Vec3 reference6 = null;
        reference4 = Scaffold.mc.getCameraEntity().getEyePosition(1.0f);
        reference5 = ((Scaffold) reference0).getLookVector(arg0, arg1);
        reference6 = reference4.add((reference5.x * ((double) arg2)), (reference5.y * ((double) arg2)), (reference5.z * ((double) arg2)));
        reference0 = Scaffold.mc.level.clip(new ClipContext(reference4, reference6, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, Scaffold.mc.getCameraEntity()));
        return ((BlockHitResult) reference0);
    }

    private float getMouseSensitivityStep() {
        float floating1 = 0.0f;
        float floating2 = 0.0f;
        int saved1 = 0;
        float floating0 = 0.0f;
        floating1 = Recovered_it.m50();
        floating2 = floating1;
        saved1 = JvmSupport.fcmpg((floating1 % 90.0f), 45.0f);
        if (!((saved1 > 0))) {
            floating2 = (floating2 + 45.0f);
        } else {
            floating2 = (floating2 - 45.0f);
        }
        floating0 = (floating2 - 180.0f);
        return floating0;
    }

    private Vec3 getLookVector(float arg0, float arg1) {
        float floating3 = 0.0f;
        float floating4 = 0.0f;
        float floating5 = 0.0f;
        float floating6 = 0.0f;
        Vec3 reference0 = null;
        floating3 = Mth.cos(((double) (((-arg0) * 0.017453292f) - 3.1415927f)));
        floating4 = Mth.sin(((double) (((-arg0) * 0.017453292f) - 3.1415927f)));
        floating5 = (-Mth.cos(((double) ((-arg1) * 0.017453292f))));
        floating6 = Mth.sin(((double) ((-arg1) * 0.017453292f)));
        reference0 = new Vec3(((double) (floating4 * floating5)), ((double) floating6), ((double) (floating3 * floating5)));
        return reference0;
    }

    static {
        TEXT_SCAFFOLD = new String("Scaffold");
        TEXT_ROTATIONS = new String("Rotations");
        TEXT_HITVEC = new String("HitVec");
        TEXT_BACKWARD = new String("Backward");
        TEXT_OFFSET = new String("Offset");
        TEXT_RAYCAST = new String("Raycast");
        TEXT_RAYCAST2 = new String("Raycast2");
        TEXT_ROTATION_SPEED = new String("Rotation Speed");
        TEXT_FAST_MODE = new String("Fast Mode");
        TEXT_DISABLED = new String("Disabled");
        TEXT_TELLY = new String("Telly");
        TEXT_WATCHDOG = new String("Watchdog");
        TEXT_WATCHDOG2 = new String("Watchdog2");
        TEXT_WATCHDOG3 = new String("Watchdog3");
        TEXT_TELLY_RMB = new String("Telly RMB");
        TEXT_KEEP_Y = new String("Keep Y");
        TEXT_TOWER = new String("Tower");
        TEXT_WATCHDOG_LOW = new String("Watchdog Low");
        TEXT_BLOCK_COUNT = new String("Block Count");
        TEXT_SILENT_SWING = new String("Silent Swing");
        TEXT_SNEAK = new String("Sneak");
        TEXT_SNEAK_DELAY = new String("Sneak Delay");
        TEXT_TIMER_TICKS = new String("Timer Ticks");
    }

    private void pm$108() {
        boolean saved1 = false;
        saved1 = this.silentSwing.getValue();
        if (saved1) {
            Scaffold.mc.getConnection().send(((Packet) (Object) new ServerboundSwingPacket(InteractionHand.MAIN_HAND)));
        } else {
            Scaffold.mc.player.swing(InteractionHand.MAIN_HAND);
        }
    }

    private void pm$110(float arg0, float arg1) {
        boolean saved1 = false;
        float floating3 = 0.0f;
        boolean saved2 = false;
        boolean saved3 = false;
        boolean saved4 = false;
        boolean saved5 = false;
        boolean saved6 = false;
        boolean saved7 = false;
        float floating4 = 0.0f;
        float floating5 = 0.0f;
        float floating6 = 0.0f;
        int saved8 = 0;
        int saved9 = 0;
        boolean saved10 = false;
        saved1 = this.f630;
        if (saved1) {
            return;
        } else {
            this.f630 = true;
            floating3 = ((float) ((this.rotationSpeed.getValue() * 20.0) - Math.random()));
            saved2 = this.f631;
            if (saved2) {
                saved3 = this.fastMode.is(Scaffold.TEXT_WATCHDOG);
                if (saved3) {
                    floating3 = ((float) (89.0 - Math.random()));
                }
            }
            saved4 = this.f642;
            if (saved4) {
                floating3 = ((float) (129.0 - Math.random()));
                this.f642 = false;
            } else {
                saved5 = this.fastMode.is(Scaffold.TEXT_WATCHDOG2);
                if (saved5) {
                    floating3 = 34.0f;
                }
            }
            saved6 = this.f631;
            if (saved6) {
                saved7 = this.fastMode.is(Scaffold.TEXT_WATCHDOG2);
                if (saved7) {
                    this.f642 = true;
                }
            }
            floating4 = Mth.wrapDegrees((arg0 - this.f624));
            floating5 = Mth.wrapDegrees((arg1 - this.f625));
            floating4 = Math.clamp(floating4, (-floating3), floating3);
            floating5 = Math.clamp(floating5, (-floating3), floating3);
            this.f624 = (this.f624 + floating4);
            floating6 = Scaffold.mc.player.getYRot();
            this.f624 = (floating6 + Mth.wrapDegrees((this.f624 - floating6)));
            this.f625 = (this.f625 + floating5);
            saved8 = JvmSupport.dcmpl(((double) Math.abs(Mth.wrapDegrees((this.f624 - arg0)))), 0.1);
            if (!((saved8 > 0))) {
                saved9 = JvmSupport.dcmpl(((double) Math.abs(Mth.wrapDegrees((this.f625 - arg1)))), 0.1);
                if (!((saved9 <= 0))) {
                    this.f629 = false;
                } else {
                    this.f629 = true;
                }
            } else {
                this.f629 = false;
            }
            saved10 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
            if (saved10) {
                this.f624 = arg0;
                this.f629 = true;
            }
            return;
        }
    }

    public Scaffold() {
        super(Scaffold.TEXT_SCAFFOLD, Category.PLAYER);
        this.rotations = new ModeSetting(Scaffold.TEXT_ROTATIONS, this, Scaffold.TEXT_HITVEC, new String[] {Scaffold.TEXT_HITVEC, Scaffold.TEXT_BACKWARD, Scaffold.TEXT_OFFSET, Scaffold.TEXT_RAYCAST, Scaffold.TEXT_RAYCAST2});
        this.rotationSpeed = new NumberSetting(Scaffold.TEXT_ROTATION_SPEED, this, 2.0, 0.5, 10.0, 0.5);
        this.fastMode = new ModeSetting(Scaffold.TEXT_FAST_MODE, this, Scaffold.TEXT_DISABLED, new String[] {Scaffold.TEXT_DISABLED, Scaffold.TEXT_TELLY, Scaffold.TEXT_WATCHDOG, Scaffold.TEXT_WATCHDOG2, Scaffold.TEXT_WATCHDOG3});
        this.tellyRMB = new BooleanSetting(Scaffold.TEXT_TELLY_RMB, this, false);
        this.keepY = new BooleanSetting(Scaffold.TEXT_KEEP_Y, this, false);
        this.tower = new ModeSetting(Scaffold.TEXT_TOWER, this, Scaffold.TEXT_DISABLED, new String[] {Scaffold.TEXT_DISABLED, Scaffold.TEXT_WATCHDOG, Scaffold.TEXT_WATCHDOG_LOW});
        this.blockCount = new BooleanSetting(Scaffold.TEXT_BLOCK_COUNT, this, true);
        this.silentSwing = new BooleanSetting(Scaffold.TEXT_SILENT_SWING, this, false);
        this.sneak = new BooleanSetting(Scaffold.TEXT_SNEAK, this, false);
        this.sneakDelay = new NumberSetting(Scaffold.TEXT_SNEAK_DELAY, this, 0.0, 0.0, 25.0, 1.0);
        this.timerTicks = new NumberSetting(Scaffold.TEXT_TIMER_TICKS, this, 10.0, 2.0, 15.0, 1.0);
        this.f623 = new PlacementData();
        this.f635 = -1;
        this.f638 = -1;
        this.f639 = new float[2];
        this.f640 = new float[] {0.0f, -1.0f, 1.0f, -2.0f, 2.0f, -3.0f, 3.0f, -4.0f, 4.0f, -5.0f, 5.0f, -6.0f, 6.0f, -7.0f, 7.0f, -8.0f, 8.0f, -9.0f, 9.0f, -10.0f, 10.0f, -11.0f, 11.0f, -12.0f, 12.0f, -13.0f, 13.0f, -14.0f, 14.0f, -15.0f, 15.0f, -16.0f, 16.0f, -17.0f, 17.0f, -18.0f, 18.0f, -19.0f, 19.0f, -20.0f, 20.0f, -22.0f, 22.0f, -24.0f, 24.0f, -26.0f, 26.0f, -28.0f, 28.0f, -30.0f, 30.0f, -32.0f, 32.0f, -34.0f, 34.0f, -36.0f, 36.0f, -38.0f, 38.0f, -40.0f, 40.0f, -42.0f, 42.0f, -44.0f, 44.0f, -46.0f, 46.0f, -48.0f, 48.0f, -50.0f, 50.0f, -52.0f, 52.0f, -54.0f, 54.0f, -56.0f, 56.0f, -58.0f, 58.0f, -60.0f, 60.0f, -62.0f, 62.0f, -64.0f, 64.0f, -66.0f, 66.0f, -68.0f, 68.0f, -70.0f, 70.0f, -72.0f, 72.0f, -74.0f, 74.0f, -76.0f, 76.0f, -78.0f, 78.0f, -80.0f, 80.0f, -82.0f, 82.0f, -84.0f, 84.0f, -86.0f, 86.0f, -88.0f, 88.0f, -90.0f, 90.0f, -92.0f, 92.0f, -94.0f, 94.0f, -96.0f, 96.0f, -98.0f, 98.0f, -100.0f, 100.0f, -102.0f, 102.0f, -104.0f, 104.0f, -106.0f, 106.0f, -108.0f, 108.0f, -110.0f, 110.0f, -112.0f, 112.0f, -114.0f, 114.0f, -116.0f, 116.0f, -118.0f, 118.0f, -120.0f, 120.0f, -122.0f, 122.0f, -124.0f, 124.0f, -126.0f, 126.0f, -128.0f, 128.0f, -130.0f, 130.0f, -132.0f, 132.0f, -134.0f, 134.0f, -136.0f, 136.0f, -138.0f, 138.0f, -140.0f, 140.0f, -142.0f, 142.0f, -144.0f, 144.0f, -146.0f, 146.0f, -148.0f, 148.0f, -150.0f, 150.0f, -152.0f, 152.0f, -154.0f, 154.0f, -156.0f, 156.0f, -158.0f, 158.0f, -160.0f, 160.0f, -162.0f, 162.0f, -164.0f, 164.0f, -166.0f, 166.0f, -168.0f, 168.0f, -170.0f, 170.0f, -172.0f, 172.0f, -174.0f, 174.0f, -176.0f, 176.0f, -178.0f, 178.0f, -180.0f, 180.0f};
        this.f641 = new float[] {0.0f, -1.0f, 1.0f, -2.0f, 2.0f, -3.0f, 3.0f, -4.0f, 4.0f, -5.0f, 5.0f, -6.0f, 6.0f, -7.0f, 7.0f, -8.0f, 8.0f, -9.0f, 9.0f, -10.0f, 10.0f, -11.0f, 11.0f, -12.0f, 12.0f, -13.0f, 13.0f, -14.0f, 14.0f, -15.0f, 15.0f, -16.0f, 16.0f, -17.0f, 17.0f, -18.0f, 18.0f, -19.0f, 19.0f, -20.0f, 20.0f, -22.0f, 22.0f, -24.0f, 24.0f, -26.0f, 26.0f, -28.0f, 28.0f, -30.0f, 30.0f, -32.0f, 32.0f, -34.0f, 34.0f, -36.0f, 36.0f, -38.0f, 38.0f, -40.0f, 40.0f, -42.0f, 42.0f, -44.0f, 44.0f, -46.0f, 46.0f, -48.0f, 48.0f, -50.0f, 50.0f, -52.0f, 52.0f, -54.0f, 54.0f, -56.0f, 56.0f, -58.0f, 58.0f, -60.0f, 60.0f, -62.0f, 62.0f, -64.0f, 64.0f, -66.0f, 66.0f, -68.0f, 68.0f, -70.0f, 70.0f, -72.0f, 72.0f, -74.0f, 74.0f, -76.0f, 76.0f, -78.0f, 78.0f, -80.0f, 80.0f, -82.0f, 82.0f, -84.0f, 84.0f, -86.0f, 86.0f, -88.0f, 88.0f, -90.0f, 90.0f};
        this.f643 = new BlockPos.MutableBlockPos();
    }

    private int pm$109() {
        int integer1 = 0;
        int integer2 = 0;
        int integer3 = 0;
        ItemStack reference4 = null;
        boolean saved1 = false;
        int saved2 = 0;
        int integer0 = 0;
        integer1 = -1;
        integer2 = 0;
        integer3 = 0;
        loop6: while (true) {
            if ((integer3 >= 9)) {
                break loop6;
            }
            reference4 = Scaffold.mc.player.getInventory().getItem(integer3);
            saved1 = (reference4.getItem() instanceof BlockItem);
            if (!(saved1)) {
            } else {
                saved2 = reference4.getCount();
                if (!((saved2 <= integer2))) {
                    integer2 = reference4.getCount();
                    integer1 = integer3;
                }
            }
            integer3++;
            continue loop6;
        }
        integer0 = integer1;
        return integer0;
    }

    public void onEnable() {
        boolean saved1 = false;
        this.f634 = ((int) (Scaffold.mc.player.getY() - 1.0));
        this.f635 = Scaffold.mc.player.getInventory().getSelectedSlot();
        this.f624 = Scaffold.mc.player.getYRot();
        saved1 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
        if (saved1) {
            this.f624 = Scaffold.mc.player.getYRot();
            this.f628 = (this.f624 - 150.0f);
        }
        this.f625 = Scaffold.mc.player.getXRot();
        this.f626 = (Recovered_it.m50() - 180.0f);
        this.f627 = 83.0f;
        this.f625 = 83.0f;
        this.f631 = false;
    }

    public void onDisable() {
        Scaffold.mc.player.getInventory().setSelectedSlot(this.f635);
        Recovered_hp.m59(1.0f);
        this.f633 = false;
    }

    private void pm$112(BlockHitResult arg0, float arg1) {
        int integer3 = 0;
        float floating4 = 0.0f;
        float floating5 = 0.0f;
        float floating6 = 0.0f;
        float floating7 = 0.0f;
        float[] reference8 = null;
        int integer9 = 0;
        int integer10 = 0;
        float floating11 = 0.0f;
        float[] reference12 = null;
        int integer13 = 0;
        int integer14 = 0;
        float floating15 = 0.0f;
        float floating16 = 0.0f;
        float floating17 = 0.0f;
        BlockHitResult reference18 = null;
        boolean saved1 = false;
        Direction saved2 = null;
        Direction saved3 = null;
        float floating19 = 0.0f;
        int saved4 = 0;
        int saved5 = 0;
        int saved6 = 0;
        integer3 = (this.fastMode.is(Scaffold.TEXT_WATCHDOG3) ? 1 : 0);
        if (!((integer3 == 0))) {
            arg1 = Recovered_it.m50();
        }
        floating4 = 0.0f;
        floating5 = 0.0f;
        floating6 = 0.0f;
        floating7 = 0.0f;
        reference8 = this.f640;
        integer9 = reference8.length;
        integer10 = 0;
        loop25: while (true) {
            if ((integer10 >= integer9)) {
                break loop25;
            }
            floating11 = reference8[integer10];
            reference12 = this.f641;
            integer13 = reference12.length;
            integer14 = 0;
            loop40: while (true) {
                if ((integer14 >= integer13)) {
                    break loop40;
                }
                floating15 = reference12[integer14];
                floating16 = (arg1 + floating11);
                floating17 = Mth.clamp((floating4 + floating15), -90.0f, 90.0f);
                reference18 = this.rayTraceBlock(floating16, floating17, 4.5f);
                saved1 = reference18.getBlockPos().equals(arg0.getBlockPos());
                if (!(saved1)) {
                    integer14++;
                    continue loop40;
                }
                saved2 = reference18.getDirection();
                saved3 = arg0.getDirection();
                if (!((saved2 == saved3))) {
                    integer14++;
                    continue loop40;
                }
                if (!((integer3 == 0))) {
                    floating19 = Math.abs(Mth.wrapDegrees(((floating16 - Recovered_it.m50()) + 180.0f)));
                    saved4 = JvmSupport.fcmpl(floating19, floating7);
                    if (!((saved4 <= 0))) {
                        floating7 = floating19;
                        floating5 = floating16;
                        floating6 = floating17;
                    }
                    saved5 = JvmSupport.fcmpl(floating19, 90.0f);
                    if (!((saved5 <= 0))) {
                        integer14++;
                        continue loop40;
                    }
                }
                this.f639[0] = floating16;
                this.f639[1] = floating17;
                return;
            }
            integer10++;
            continue loop25;
        }
        if (!((integer3 == 0))) {
            saved6 = JvmSupport.fcmpl(floating7, 0.0f);
            if (!((saved6 == 0))) {
                this.f639[0] = floating5;
                this.f639[1] = floating6;
                return;
            } else {
                this.f629 = false;
                this.f630 = true;
                this.f639[0] = this.f626;
                this.f639[1] = this.f627;
                return;
            }
        } else {
            this.f629 = false;
            this.f630 = true;
            this.f639[0] = this.f626;
            this.f639[1] = this.f627;
            return;
        }
    }

    private PlacementData getPlaceData(BlockPos arg0) {
        boolean saved1 = false;
        Object reference0 = this;
        int integer2 = 0;
        int integer3 = 0;
        int integer4 = 0;
        double number5 = 0.0;
        double number7 = 0.0;
        double number9 = 0.0;
        double number11 = 0.0;
        int integer13 = 0;
        int integer14 = 0;
        int integer15 = 0;
        Direction reference16 = null;
        int integer17 = 0;
        int integer18 = 0;
        int integer19 = 0;
        int integer20 = 0;
        int integer21 = 0;
        int integer22 = 0;
        boolean saved2 = false;
        int saved3 = 0;
        int saved4 = 0;
        int saved5 = 0;
        int saved6 = 0;
        Direction reference23 = null;
        int saved7 = 0;
        int saved8 = 0;
        int saved9 = 0;
        int saved10 = 0;
        int saved11 = 0;
        int saved12 = 0;
        int saved13 = 0;
        int saved14 = 0;
        Direction saved15 = null;
        double number24 = 0.0;
        double number26 = 0.0;
        double number28 = 0.0;
        double number30 = 0.0;
        int saved16 = 0;
        saved1 = Scaffold.mc.level.getBlockState(arg0).canBeReplaced();
        if (!(saved1)) {
            reference0 = null;
            return ((PlacementData) reference0);
        } else {
            integer2 = arg0.getX();
            integer3 = arg0.getY();
            integer4 = arg0.getZ();
            number5 = Scaffold.mc.player.getX();
            number7 = Scaffold.mc.player.getY();
            number9 = Scaffold.mc.player.getZ();
            number11 = 1.7976931348623157e+308;
            integer13 = 0;
            integer14 = 0;
            integer15 = 0;
            reference16 = null;
            integer17 = -4;
            loop43: while (true) {
                if ((integer17 > 4)) {
                    break loop43;
                }
                integer18 = (integer2 + integer17);
                integer19 = -2;
                loop52: while (true) {
                    if ((integer19 > 0)) {
                        break loop52;
                    }
                    integer20 = (integer3 + integer19);
                    integer21 = -4;
                    loop60: while (true) {
                        if ((integer21 > 4)) {
                            break loop60;
                        }
                        integer22 = (integer4 + integer21);
                        ((Scaffold) reference0).f643.set(integer18, integer20, integer22);
                        saved2 = Scaffold.mc.level.isEmptyBlock(((BlockPos) (Object) ((Scaffold) reference0).f643));
                        if (saved2) {
                        } else {
                            saved3 = Math.abs(integer17);
                            saved4 = Math.abs(integer19);
                            if (!((saved3 < saved4))) {
                                saved5 = Math.abs(integer17);
                                saved6 = Math.abs(integer21);
                                if (!((saved5 < saved6))) {
                                    reference23 = (!((integer17 >= 0)) ? Direction.EAST : Direction.WEST);
                                } else {
                                    saved7 = Math.abs(integer19);
                                    saved8 = Math.abs(integer17);
                                    if (!((saved7 < saved8))) {
                                        saved9 = Math.abs(integer19);
                                        saved10 = Math.abs(integer21);
                                        if (!((saved9 < saved10))) {
                                            reference23 = (!((integer19 >= 0)) ? Direction.UP : Direction.DOWN);
                                        } else {
                                            reference23 = (!((integer21 >= 0)) ? Direction.SOUTH : Direction.NORTH);
                                        }
                                    } else {
                                        reference23 = (!((integer21 >= 0)) ? Direction.SOUTH : Direction.NORTH);
                                    }
                                }
                            } else {
                                saved11 = Math.abs(integer19);
                                saved12 = Math.abs(integer17);
                                if (!((saved11 < saved12))) {
                                    saved13 = Math.abs(integer19);
                                    saved14 = Math.abs(integer21);
                                    if (!((saved13 < saved14))) {
                                        reference23 = (!((integer19 >= 0)) ? Direction.UP : Direction.DOWN);
                                    } else {
                                        reference23 = (!((integer21 >= 0)) ? Direction.SOUTH : Direction.NORTH);
                                    }
                                } else {
                                    reference23 = (!((integer21 >= 0)) ? Direction.SOUTH : Direction.NORTH);
                                }
                            }
                            if (!((reference23 == null))) {
                                saved15 = Direction.DOWN;
                                if (!((reference23 != saved15))) {
                                } else {
                                    number24 = (number5 - (((double) integer18) + 0.5));
                                    number26 = (number7 - (((double) integer20) + 0.5));
                                    number28 = (number9 - (((double) integer22) + 0.5));
                                    number30 = (((number24 * number24) + (number26 * number26)) + (number28 * number28));
                                    saved16 = JvmSupport.dcmpg(number30, number11);
                                    if (!((saved16 >= 0))) {
                                        number11 = number30;
                                        integer13 = ((Scaffold) reference0).f643.getX();
                                        integer14 = ((Scaffold) reference0).f643.getY();
                                        integer15 = ((Scaffold) reference0).f643.getZ();
                                        reference16 = reference23;
                                    }
                                }
                            }
                        }
                        integer21++;
                        continue loop60;
                    }
                    integer19++;
                    continue loop52;
                }
                integer17++;
                continue loop43;
            }
            if (!((reference16 != null))) {
                reference0 = null;
                return ((PlacementData) reference0);
            } else {
                ((Scaffold) reference0).f623.set(new BlockPos(integer13, integer14, integer15), reference16);
                reference0 = ((Scaffold) reference0).f623;
                return ((PlacementData) reference0);
            }
        }
    }

    public void onEvent(Event event) {
        MouseButtonEvent saved1 = null;
        Screen saved2 = null;
        int saved3 = 0;
        RotationEvent saved4 = null;
        int integer2 = 0;
        boolean saved5 = false;
        boolean saved6 = false;
        int saved7 = 0;
        boolean saved8 = false;
        boolean saved9 = false;
        boolean saved10 = false;
        boolean saved11 = false;
        boolean saved12 = false;
        boolean saved13 = false;
        float floating3 = 0.0f;
        BlockPos reference3 = null;
        boolean saved14 = false;
        boolean saved15 = false;
        int saved16 = 0;
        PlacementData reference4 = null;
        Vec3 reference5 = null;
        BlockHitResult reference6 = null;
        boolean saved17 = false;
        boolean saved18 = false;
        boolean saved19 = false;
        boolean saved20 = false;
        boolean saved21 = false;
        float floating4 = 0.0f;
        float floating5 = 0.0f;
        float floating6 = 0.0f;
        int saved22 = 0;
        int saved23 = 0;
        int saved24 = 0;
        int saved25 = 0;
        boolean saved26 = false;
        boolean saved27 = false;
        boolean saved28 = false;
        boolean saved29 = false;
        boolean saved30 = false;
        boolean saved31 = false;
        boolean saved32 = false;
        boolean saved33 = false;
        boolean saved34 = false;
        int saved35 = 0;
        boolean saved36 = false;
        int saved37 = 0;
        boolean saved38 = false;
        boolean saved39 = false;
        boolean saved40 = false;
        boolean saved41 = false;
        boolean saved42 = false;
        boolean saved43 = false;
        boolean saved44 = false;
        int saved45 = 0;
        boolean saved46 = false;
        boolean saved47 = false;
        boolean saved48 = false;
        boolean saved49 = false;
        boolean saved50 = false;
        int saved51 = 0;
        int saved52 = 0;
        int saved53 = 0;
        int saved54 = 0;
        boolean saved55 = false;
        boolean saved56 = false;
        boolean saved57 = false;
        boolean saved58 = false;
        boolean saved59 = false;
        boolean saved60 = false;
        boolean saved61 = false;
        boolean saved62 = false;
        boolean saved63 = false;
        int saved64 = 0;
        boolean saved65 = false;
        int saved66 = 0;
        boolean saved67 = false;
        boolean saved68 = false;
        boolean saved69 = false;
        boolean saved70 = false;
        boolean saved71 = false;
        boolean saved72 = false;
        boolean saved73 = false;
        int saved74 = 0;
        boolean saved75 = false;
        boolean saved76 = false;
        boolean saved77 = false;
        boolean saved78 = false;
        boolean saved79 = false;
        int saved80 = 0;
        int saved81 = 0;
        int saved82 = 0;
        int saved83 = 0;
        boolean saved84 = false;
        boolean saved85 = false;
        boolean saved86 = false;
        boolean saved87 = false;
        boolean saved88 = false;
        boolean saved89 = false;
        boolean saved90 = false;
        boolean saved91 = false;
        boolean saved92 = false;
        int saved93 = 0;
        boolean saved94 = false;
        int saved95 = 0;
        boolean saved96 = false;
        boolean saved97 = false;
        boolean saved98 = false;
        boolean saved99 = false;
        boolean saved100 = false;
        boolean saved101 = false;
        boolean saved102 = false;
        boolean saved103 = false;
        boolean saved104 = false;
        boolean saved105 = false;
        int saved106 = 0;
        boolean saved107 = false;
        boolean saved108 = false;
        boolean saved109 = false;
        boolean saved110 = false;
        boolean saved111 = false;
        int saved112 = 0;
        int saved113 = 0;
        int saved114 = 0;
        int saved115 = 0;
        boolean saved116 = false;
        boolean saved117 = false;
        boolean saved118 = false;
        boolean saved119 = false;
        boolean saved120 = false;
        boolean saved121 = false;
        boolean saved122 = false;
        boolean saved123 = false;
        boolean saved124 = false;
        int saved125 = 0;
        boolean saved126 = false;
        int saved127 = 0;
        boolean saved128 = false;
        boolean saved129 = false;
        boolean saved130 = false;
        boolean saved131 = false;
        boolean saved132 = false;
        boolean saved133 = false;
        boolean saved134 = false;
        int saved135 = 0;
        boolean saved136 = false;
        boolean saved137 = false;
        boolean saved138 = false;
        boolean saved139 = false;
        boolean saved140 = false;
        int saved141 = 0;
        int saved142 = 0;
        int saved143 = 0;
        int saved144 = 0;
        boolean saved145 = false;
        boolean saved146 = false;
        boolean saved147 = false;
        boolean saved148 = false;
        boolean saved149 = false;
        boolean saved150 = false;
        boolean saved151 = false;
        boolean saved152 = false;
        boolean saved153 = false;
        int saved154 = 0;
        boolean saved155 = false;
        int saved156 = 0;
        boolean saved157 = false;
        boolean saved158 = false;
        boolean saved159 = false;
        boolean saved160 = false;
        boolean saved161 = false;
        boolean saved162 = false;
        boolean saved163 = false;
        boolean saved164 = false;
        boolean saved165 = false;
        boolean saved166 = false;
        int saved167 = 0;
        boolean saved168 = false;
        boolean saved169 = false;
        boolean saved170 = false;
        boolean saved171 = false;
        boolean saved172 = false;
        int saved173 = 0;
        int saved174 = 0;
        int saved175 = 0;
        int saved176 = 0;
        boolean saved177 = false;
        boolean saved178 = false;
        boolean saved179 = false;
        boolean saved180 = false;
        boolean saved181 = false;
        boolean saved182 = false;
        boolean saved183 = false;
        boolean saved184 = false;
        boolean saved185 = false;
        int saved186 = 0;
        boolean saved187 = false;
        int saved188 = 0;
        boolean saved189 = false;
        boolean saved190 = false;
        boolean saved191 = false;
        boolean saved192 = false;
        boolean saved193 = false;
        boolean saved194 = false;
        boolean saved195 = false;
        int saved196 = 0;
        boolean saved197 = false;
        boolean saved198 = false;
        boolean saved199 = false;
        boolean saved200 = false;
        boolean saved201 = false;
        int saved202 = 0;
        int saved203 = 0;
        int saved204 = 0;
        int saved205 = 0;
        boolean saved206 = false;
        boolean saved207 = false;
        boolean saved208 = false;
        boolean saved209 = false;
        boolean saved210 = false;
        boolean saved211 = false;
        boolean saved212 = false;
        boolean saved213 = false;
        boolean saved214 = false;
        int saved215 = 0;
        boolean saved216 = false;
        int saved217 = 0;
        boolean saved218 = false;
        boolean saved219 = false;
        boolean saved220 = false;
        boolean saved221 = false;
        boolean saved222 = false;
        PostMotionEvent saved223 = null;
        boolean saved224 = false;
        MotionEvent saved225 = null;
        boolean saved226 = false;
        int saved227 = 0;
        boolean saved228 = false;
        KeybindEvent saved229 = null;
        int saved230 = 0;
        int saved231 = 0;
        int saved232 = 0;
        PostInputEvent saved233 = null;
        boolean saved234 = false;
        boolean saved235 = false;
        int saved236 = 0;
        boolean saved237 = false;
        boolean saved238 = false;
        boolean saved239 = false;
        int saved240 = 0;
        int saved241 = 0;
        boolean saved242 = false;
        boolean saved243 = false;
        boolean saved244 = false;
        boolean saved245 = false;
        int saved246 = 0;
        int saved247 = 0;
        boolean saved248 = false;
        boolean saved249 = false;
        boolean saved250 = false;
        boolean saved251 = false;
        int saved252 = 0;
        int saved253 = 0;
        boolean saved254 = false;
        boolean saved255 = false;
        boolean saved256 = false;
        boolean saved257 = false;
        boolean saved258 = false;
        Input reference2 = null;
        int saved259 = 0;
        saved1 = Events.mouseButton;
        if (!((event != saved1))) {
            saved2 = Scaffold.mc.gui.screen();
            if (!((saved2 != null))) {
                event.setCancelled(true);
            }
            saved3 = Events.mouseButton.m13();
            if (!((saved3 != 1))) {
                this.f632 = Events.mouseButton.m16();
            }
            return;
        } else {
            saved4 = Events.rotation;
            if (!((event != saved4))) {
                integer2 = 1;
                saved5 = this.keepY.getValue();
                if (saved5) {
                    saved6 = Scaffold.mc.options.keyJump.isDown();
                    if (saved6) {
                        this.f634 = (((int) Scaffold.mc.player.getY()) - 1);
                    }
                }
                saved7 = this.f636;
                if (!((saved7 <= 0))) {
                    this.f636 = (this.f636 - 1);
                }
                saved8 = this.fastMode.is(Scaffold.TEXT_WATCHDOG);
                if (!(saved8)) {
                    saved9 = this.fastMode.is(Scaffold.TEXT_WATCHDOG2);
                    if (!(saved9)) {
                        saved10 = this.fastMode.is(Scaffold.TEXT_TELLY);
                        if (saved10) {
                            saved11 = Scaffold.mc.player.onGround();
                            if (saved11) {
                                saved12 = this.tellyRMB.getValue();
                                if (saved12) {
                                    saved13 = this.f632;
                                    if (saved13) {
                                        floating3 = Recovered_it.m50();
                                        Events.rotation.setYaw(floating3);
                                        this.f624 = floating3;
                                        this.f631 = Scaffold.mc.player.onGround();
                                        return;
                                    } else {
                                        this.f630 = false;
                                        reference3 = Scaffold.mc.player.blockPosition().below();
                                        saved14 = this.keepY.getValue();
                                        if (saved14) {
                                            reference3 = reference3.atY(this.f634);
                                        }
                                        saved15 = Scaffold.mc.level.isEmptyBlock(reference3);
                                        if (saved15) {
                                            if (!((integer2 == 0))) {
                                                this.f638 = this.pm$109();
                                                saved16 = this.f638;
                                                if (!((saved16 == -1))) {
                                                    reference4 = this.getPlaceData(reference3);
                                                    if (!((reference4 == null))) {
                                                        reference5 = Vec3.atCenterOf(((Vec3i) (Object) reference4.position));
                                                        reference6 = new BlockHitResult(reference5, reference4.face, reference4.position, false);
                                                        this.pm$111(reference6);
                                                        this.pm$110(this.f639[0], this.f639[1]);
                                                        this.f626 = this.f639[0];
                                                        this.f627 = this.f639[1];
                                                        saved17 = this.tower.is(Scaffold.TEXT_DISABLED);
                                                        if (!(saved17)) {
                                                            saved18 = Scaffold.mc.options.keyJump.isDown();
                                                            if (saved18) {
                                                                saved19 = Scaffold.mc.player.onGround();
                                                                if (saved19) {
                                                                    this.f629 = false;
                                                                }
                                                            }
                                                        }
                                                        saved20 = this.f629;
                                                        if (saved20) {
                                                            Scaffold.mc.gameMode.useItemOn(Scaffold.mc.player, InteractionHand.MAIN_HAND, reference6);
                                                            this.pm$108();
                                                            this.f636 = 10;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        saved21 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                                        if (saved21) {
                                            floating4 = Recovered_it.m50();
                                            floating5 = (floating4 + 45.0f);
                                            floating6 = Math.abs(Mth.wrapDegrees((floating5 - this.f624)));
                                            saved22 = this.f636;
                                            if (!((saved22 != 10))) {
                                                this.f628 = this.f624;
                                            }
                                            saved23 = this.f636;
                                            saved24 = JvmSupport.fcmpl(floating6, 60.0f);
                                            saved25 = (!((saved24 <= 0)) ? 8 : 9);
                                            if (!((saved23 != saved25))) {
                                                saved26 = Scaffold.mc.options.keyJump.isDown();
                                                if (!(saved26)) {
                                                    saved27 = this.f631;
                                                    if (saved27) {
                                                        saved28 = Scaffold.mc.player.onGround();
                                                        if (saved28) {
                                                            this.f624 = (floating4 + 45.0f);
                                                        }
                                                    }
                                                }
                                            }
                                            saved29 = Scaffold.mc.player.onGround();
                                            if (saved29) {
                                                this.f634 = ((int) (Scaffold.mc.player.getY() - 1.0));
                                            }
                                        } else {
                                            this.pm$110(this.f626, this.f627);
                                        }
                                        saved30 = this.tower.is(Scaffold.TEXT_DISABLED);
                                        if (!(saved30)) {
                                            floating4 = Recovered_it.m50();
                                            saved31 = Scaffold.mc.player.onGround();
                                            if (saved31) {
                                                saved32 = Scaffold.mc.options.keyJump.isDown();
                                                if (saved32) {
                                                    this.f624 = floating4;
                                                }
                                            }
                                            saved33 = this.tower.is(Scaffold.TEXT_WATCHDOG_LOW);
                                            if (saved33) {
                                                saved34 = Scaffold.mc.player.onGround();
                                                if (!(saved34)) {
                                                    saved35 = JvmSupport.dcmpg(Scaffold.mc.player.getDeltaMovement().y, -0.1);
                                                    if (!((saved35 >= 0))) {
                                                        saved36 = Scaffold.mc.options.keyJump.isDown();
                                                        if (saved36) {
                                                            saved37 = JvmSupport.dcmpg(((double) this.f637), this.timerTicks.getValue());
                                                            if (!((saved37 >= 0))) {
                                                                Recovered_hp.m59(2.0f);
                                                                this.f637 = (this.f637 + 1);
                                                                this.f633 = true;
                                                            } else {
                                                                saved38 = this.f633;
                                                                if (saved38) {
                                                                    Recovered_hp.m59(1.0f);
                                                                    this.f633 = false;
                                                                }
                                                            }
                                                        } else {
                                                            saved39 = this.f633;
                                                            if (saved39) {
                                                                Recovered_hp.m59(1.0f);
                                                                this.f633 = false;
                                                            }
                                                        }
                                                    } else {
                                                        saved40 = this.f633;
                                                        if (saved40) {
                                                            Recovered_hp.m59(1.0f);
                                                            this.f633 = false;
                                                        }
                                                    }
                                                } else {
                                                    saved41 = this.f633;
                                                    if (saved41) {
                                                        Recovered_hp.m59(1.0f);
                                                        this.f633 = false;
                                                    }
                                                }
                                            }
                                        }
                                        Events.rotation.setYaw(this.f624);
                                        Events.rotation.setPitch(this.f625);
                                        saved42 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                                        if (!(saved42)) {
                                            this.f631 = Scaffold.mc.player.onGround();
                                        }
                                        return;
                                    }
                                } else {
                                    floating3 = Recovered_it.m50();
                                    Events.rotation.setYaw(floating3);
                                    this.f624 = floating3;
                                    this.f631 = Scaffold.mc.player.onGround();
                                    return;
                                }
                            } else {
                                this.f630 = false;
                                reference3 = Scaffold.mc.player.blockPosition().below();
                                saved43 = this.keepY.getValue();
                                if (saved43) {
                                    reference3 = reference3.atY(this.f634);
                                }
                                saved44 = Scaffold.mc.level.isEmptyBlock(reference3);
                                if (saved44) {
                                    if (!((integer2 == 0))) {
                                        this.f638 = this.pm$109();
                                        saved45 = this.f638;
                                        if (!((saved45 == -1))) {
                                            reference4 = this.getPlaceData(reference3);
                                            if (!((reference4 == null))) {
                                                reference5 = Vec3.atCenterOf(((Vec3i) (Object) reference4.position));
                                                reference6 = new BlockHitResult(reference5, reference4.face, reference4.position, false);
                                                this.pm$111(reference6);
                                                this.pm$110(this.f639[0], this.f639[1]);
                                                this.f626 = this.f639[0];
                                                this.f627 = this.f639[1];
                                                saved46 = this.tower.is(Scaffold.TEXT_DISABLED);
                                                if (!(saved46)) {
                                                    saved47 = Scaffold.mc.options.keyJump.isDown();
                                                    if (saved47) {
                                                        saved48 = Scaffold.mc.player.onGround();
                                                        if (saved48) {
                                                            this.f629 = false;
                                                        }
                                                    }
                                                }
                                                saved49 = this.f629;
                                                if (saved49) {
                                                    Scaffold.mc.gameMode.useItemOn(Scaffold.mc.player, InteractionHand.MAIN_HAND, reference6);
                                                    this.pm$108();
                                                    this.f636 = 10;
                                                }
                                            }
                                        }
                                    }
                                }
                                saved50 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                                if (saved50) {
                                    floating4 = Recovered_it.m50();
                                    floating5 = (floating4 + 45.0f);
                                    floating6 = Math.abs(Mth.wrapDegrees((floating5 - this.f624)));
                                    saved51 = this.f636;
                                    if (!((saved51 != 10))) {
                                        this.f628 = this.f624;
                                    }
                                    saved52 = this.f636;
                                    saved53 = JvmSupport.fcmpl(floating6, 60.0f);
                                    saved54 = (!((saved53 <= 0)) ? 8 : 9);
                                    if (!((saved52 != saved54))) {
                                        saved55 = Scaffold.mc.options.keyJump.isDown();
                                        if (!(saved55)) {
                                            saved56 = this.f631;
                                            if (saved56) {
                                                saved57 = Scaffold.mc.player.onGround();
                                                if (saved57) {
                                                    this.f624 = (floating4 + 45.0f);
                                                }
                                            }
                                        }
                                    }
                                    saved58 = Scaffold.mc.player.onGround();
                                    if (saved58) {
                                        this.f634 = ((int) (Scaffold.mc.player.getY() - 1.0));
                                    }
                                } else {
                                    this.pm$110(this.f626, this.f627);
                                }
                                saved59 = this.tower.is(Scaffold.TEXT_DISABLED);
                                if (!(saved59)) {
                                    floating4 = Recovered_it.m50();
                                    saved60 = Scaffold.mc.player.onGround();
                                    if (saved60) {
                                        saved61 = Scaffold.mc.options.keyJump.isDown();
                                        if (saved61) {
                                            this.f624 = floating4;
                                        }
                                    }
                                    saved62 = this.tower.is(Scaffold.TEXT_WATCHDOG_LOW);
                                    if (saved62) {
                                        saved63 = Scaffold.mc.player.onGround();
                                        if (!(saved63)) {
                                            saved64 = JvmSupport.dcmpg(Scaffold.mc.player.getDeltaMovement().y, -0.1);
                                            if (!((saved64 >= 0))) {
                                                saved65 = Scaffold.mc.options.keyJump.isDown();
                                                if (saved65) {
                                                    saved66 = JvmSupport.dcmpg(((double) this.f637), this.timerTicks.getValue());
                                                    if (!((saved66 >= 0))) {
                                                        Recovered_hp.m59(2.0f);
                                                        this.f637 = (this.f637 + 1);
                                                        this.f633 = true;
                                                    } else {
                                                        saved67 = this.f633;
                                                        if (saved67) {
                                                            Recovered_hp.m59(1.0f);
                                                            this.f633 = false;
                                                        }
                                                    }
                                                } else {
                                                    saved68 = this.f633;
                                                    if (saved68) {
                                                        Recovered_hp.m59(1.0f);
                                                        this.f633 = false;
                                                    }
                                                }
                                            } else {
                                                saved69 = this.f633;
                                                if (saved69) {
                                                    Recovered_hp.m59(1.0f);
                                                    this.f633 = false;
                                                }
                                            }
                                        } else {
                                            saved70 = this.f633;
                                            if (saved70) {
                                                Recovered_hp.m59(1.0f);
                                                this.f633 = false;
                                            }
                                        }
                                    }
                                }
                                Events.rotation.setYaw(this.f624);
                                Events.rotation.setPitch(this.f625);
                                saved71 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                                if (!(saved71)) {
                                    this.f631 = Scaffold.mc.player.onGround();
                                }
                                return;
                            }
                        } else {
                            this.f630 = false;
                            reference3 = Scaffold.mc.player.blockPosition().below();
                            saved72 = this.keepY.getValue();
                            if (saved72) {
                                reference3 = reference3.atY(this.f634);
                            }
                            saved73 = Scaffold.mc.level.isEmptyBlock(reference3);
                            if (saved73) {
                                if (!((integer2 == 0))) {
                                    this.f638 = this.pm$109();
                                    saved74 = this.f638;
                                    if (!((saved74 == -1))) {
                                        reference4 = this.getPlaceData(reference3);
                                        if (!((reference4 == null))) {
                                            reference5 = Vec3.atCenterOf(((Vec3i) (Object) reference4.position));
                                            reference6 = new BlockHitResult(reference5, reference4.face, reference4.position, false);
                                            this.pm$111(reference6);
                                            this.pm$110(this.f639[0], this.f639[1]);
                                            this.f626 = this.f639[0];
                                            this.f627 = this.f639[1];
                                            saved75 = this.tower.is(Scaffold.TEXT_DISABLED);
                                            if (!(saved75)) {
                                                saved76 = Scaffold.mc.options.keyJump.isDown();
                                                if (saved76) {
                                                    saved77 = Scaffold.mc.player.onGround();
                                                    if (saved77) {
                                                        this.f629 = false;
                                                    }
                                                }
                                            }
                                            saved78 = this.f629;
                                            if (saved78) {
                                                Scaffold.mc.gameMode.useItemOn(Scaffold.mc.player, InteractionHand.MAIN_HAND, reference6);
                                                this.pm$108();
                                                this.f636 = 10;
                                            }
                                        }
                                    }
                                }
                            }
                            saved79 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                            if (saved79) {
                                floating4 = Recovered_it.m50();
                                floating5 = (floating4 + 45.0f);
                                floating6 = Math.abs(Mth.wrapDegrees((floating5 - this.f624)));
                                saved80 = this.f636;
                                if (!((saved80 != 10))) {
                                    this.f628 = this.f624;
                                }
                                saved81 = this.f636;
                                saved82 = JvmSupport.fcmpl(floating6, 60.0f);
                                saved83 = (!((saved82 <= 0)) ? 8 : 9);
                                if (!((saved81 != saved83))) {
                                    saved84 = Scaffold.mc.options.keyJump.isDown();
                                    if (!(saved84)) {
                                        saved85 = this.f631;
                                        if (saved85) {
                                            saved86 = Scaffold.mc.player.onGround();
                                            if (saved86) {
                                                this.f624 = (floating4 + 45.0f);
                                            }
                                        }
                                    }
                                }
                                saved87 = Scaffold.mc.player.onGround();
                                if (saved87) {
                                    this.f634 = ((int) (Scaffold.mc.player.getY() - 1.0));
                                }
                            } else {
                                this.pm$110(this.f626, this.f627);
                            }
                            saved88 = this.tower.is(Scaffold.TEXT_DISABLED);
                            if (!(saved88)) {
                                floating4 = Recovered_it.m50();
                                saved89 = Scaffold.mc.player.onGround();
                                if (saved89) {
                                    saved90 = Scaffold.mc.options.keyJump.isDown();
                                    if (saved90) {
                                        this.f624 = floating4;
                                    }
                                }
                                saved91 = this.tower.is(Scaffold.TEXT_WATCHDOG_LOW);
                                if (saved91) {
                                    saved92 = Scaffold.mc.player.onGround();
                                    if (!(saved92)) {
                                        saved93 = JvmSupport.dcmpg(Scaffold.mc.player.getDeltaMovement().y, -0.1);
                                        if (!((saved93 >= 0))) {
                                            saved94 = Scaffold.mc.options.keyJump.isDown();
                                            if (saved94) {
                                                saved95 = JvmSupport.dcmpg(((double) this.f637), this.timerTicks.getValue());
                                                if (!((saved95 >= 0))) {
                                                    Recovered_hp.m59(2.0f);
                                                    this.f637 = (this.f637 + 1);
                                                    this.f633 = true;
                                                } else {
                                                    saved96 = this.f633;
                                                    if (saved96) {
                                                        Recovered_hp.m59(1.0f);
                                                        this.f633 = false;
                                                    }
                                                }
                                            } else {
                                                saved97 = this.f633;
                                                if (saved97) {
                                                    Recovered_hp.m59(1.0f);
                                                    this.f633 = false;
                                                }
                                            }
                                        } else {
                                            saved98 = this.f633;
                                            if (saved98) {
                                                Recovered_hp.m59(1.0f);
                                                this.f633 = false;
                                            }
                                        }
                                    } else {
                                        saved99 = this.f633;
                                        if (saved99) {
                                            Recovered_hp.m59(1.0f);
                                            this.f633 = false;
                                        }
                                    }
                                }
                            }
                            Events.rotation.setYaw(this.f624);
                            Events.rotation.setPitch(this.f625);
                            saved100 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                            if (!(saved100)) {
                                this.f631 = Scaffold.mc.player.onGround();
                            }
                            return;
                        }
                    } else {
                        saved101 = Scaffold.mc.player.onGround();
                        if (saved101) {
                            saved102 = this.tellyRMB.getValue();
                            if (saved102) {
                                saved103 = this.f632;
                                if (saved103) {
                                    floating3 = Recovered_it.m50();
                                    Events.rotation.setYaw(floating3);
                                    this.f624 = floating3;
                                    this.f631 = Scaffold.mc.player.onGround();
                                    return;
                                } else {
                                    this.f630 = false;
                                    reference3 = Scaffold.mc.player.blockPosition().below();
                                    saved104 = this.keepY.getValue();
                                    if (saved104) {
                                        reference3 = reference3.atY(this.f634);
                                    }
                                    saved105 = Scaffold.mc.level.isEmptyBlock(reference3);
                                    if (saved105) {
                                        if (!((integer2 == 0))) {
                                            this.f638 = this.pm$109();
                                            saved106 = this.f638;
                                            if (!((saved106 == -1))) {
                                                reference4 = this.getPlaceData(reference3);
                                                if (!((reference4 == null))) {
                                                    reference5 = Vec3.atCenterOf(((Vec3i) (Object) reference4.position));
                                                    reference6 = new BlockHitResult(reference5, reference4.face, reference4.position, false);
                                                    this.pm$111(reference6);
                                                    this.pm$110(this.f639[0], this.f639[1]);
                                                    this.f626 = this.f639[0];
                                                    this.f627 = this.f639[1];
                                                    saved107 = this.tower.is(Scaffold.TEXT_DISABLED);
                                                    if (!(saved107)) {
                                                        saved108 = Scaffold.mc.options.keyJump.isDown();
                                                        if (saved108) {
                                                            saved109 = Scaffold.mc.player.onGround();
                                                            if (saved109) {
                                                                this.f629 = false;
                                                            }
                                                        }
                                                    }
                                                    saved110 = this.f629;
                                                    if (saved110) {
                                                        Scaffold.mc.gameMode.useItemOn(Scaffold.mc.player, InteractionHand.MAIN_HAND, reference6);
                                                        this.pm$108();
                                                        this.f636 = 10;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    saved111 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                                    if (saved111) {
                                        floating4 = Recovered_it.m50();
                                        floating5 = (floating4 + 45.0f);
                                        floating6 = Math.abs(Mth.wrapDegrees((floating5 - this.f624)));
                                        saved112 = this.f636;
                                        if (!((saved112 != 10))) {
                                            this.f628 = this.f624;
                                        }
                                        saved113 = this.f636;
                                        saved114 = JvmSupport.fcmpl(floating6, 60.0f);
                                        saved115 = (!((saved114 <= 0)) ? 8 : 9);
                                        if (!((saved113 != saved115))) {
                                            saved116 = Scaffold.mc.options.keyJump.isDown();
                                            if (!(saved116)) {
                                                saved117 = this.f631;
                                                if (saved117) {
                                                    saved118 = Scaffold.mc.player.onGround();
                                                    if (saved118) {
                                                        this.f624 = (floating4 + 45.0f);
                                                    }
                                                }
                                            }
                                        }
                                        saved119 = Scaffold.mc.player.onGround();
                                        if (saved119) {
                                            this.f634 = ((int) (Scaffold.mc.player.getY() - 1.0));
                                        }
                                    } else {
                                        this.pm$110(this.f626, this.f627);
                                    }
                                    saved120 = this.tower.is(Scaffold.TEXT_DISABLED);
                                    if (!(saved120)) {
                                        floating4 = Recovered_it.m50();
                                        saved121 = Scaffold.mc.player.onGround();
                                        if (saved121) {
                                            saved122 = Scaffold.mc.options.keyJump.isDown();
                                            if (saved122) {
                                                this.f624 = floating4;
                                            }
                                        }
                                        saved123 = this.tower.is(Scaffold.TEXT_WATCHDOG_LOW);
                                        if (saved123) {
                                            saved124 = Scaffold.mc.player.onGround();
                                            if (!(saved124)) {
                                                saved125 = JvmSupport.dcmpg(Scaffold.mc.player.getDeltaMovement().y, -0.1);
                                                if (!((saved125 >= 0))) {
                                                    saved126 = Scaffold.mc.options.keyJump.isDown();
                                                    if (saved126) {
                                                        saved127 = JvmSupport.dcmpg(((double) this.f637), this.timerTicks.getValue());
                                                        if (!((saved127 >= 0))) {
                                                            Recovered_hp.m59(2.0f);
                                                            this.f637 = (this.f637 + 1);
                                                            this.f633 = true;
                                                        } else {
                                                            saved128 = this.f633;
                                                            if (saved128) {
                                                                Recovered_hp.m59(1.0f);
                                                                this.f633 = false;
                                                            }
                                                        }
                                                    } else {
                                                        saved129 = this.f633;
                                                        if (saved129) {
                                                            Recovered_hp.m59(1.0f);
                                                            this.f633 = false;
                                                        }
                                                    }
                                                } else {
                                                    saved130 = this.f633;
                                                    if (saved130) {
                                                        Recovered_hp.m59(1.0f);
                                                        this.f633 = false;
                                                    }
                                                }
                                            } else {
                                                saved131 = this.f633;
                                                if (saved131) {
                                                    Recovered_hp.m59(1.0f);
                                                    this.f633 = false;
                                                }
                                            }
                                        }
                                    }
                                    Events.rotation.setYaw(this.f624);
                                    Events.rotation.setPitch(this.f625);
                                    saved132 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                                    if (!(saved132)) {
                                        this.f631 = Scaffold.mc.player.onGround();
                                    }
                                    return;
                                }
                            } else {
                                floating3 = Recovered_it.m50();
                                Events.rotation.setYaw(floating3);
                                this.f624 = floating3;
                                this.f631 = Scaffold.mc.player.onGround();
                                return;
                            }
                        } else {
                            this.f630 = false;
                            reference3 = Scaffold.mc.player.blockPosition().below();
                            saved133 = this.keepY.getValue();
                            if (saved133) {
                                reference3 = reference3.atY(this.f634);
                            }
                            saved134 = Scaffold.mc.level.isEmptyBlock(reference3);
                            if (saved134) {
                                if (!((integer2 == 0))) {
                                    this.f638 = this.pm$109();
                                    saved135 = this.f638;
                                    if (!((saved135 == -1))) {
                                        reference4 = this.getPlaceData(reference3);
                                        if (!((reference4 == null))) {
                                            reference5 = Vec3.atCenterOf(((Vec3i) (Object) reference4.position));
                                            reference6 = new BlockHitResult(reference5, reference4.face, reference4.position, false);
                                            this.pm$111(reference6);
                                            this.pm$110(this.f639[0], this.f639[1]);
                                            this.f626 = this.f639[0];
                                            this.f627 = this.f639[1];
                                            saved136 = this.tower.is(Scaffold.TEXT_DISABLED);
                                            if (!(saved136)) {
                                                saved137 = Scaffold.mc.options.keyJump.isDown();
                                                if (saved137) {
                                                    saved138 = Scaffold.mc.player.onGround();
                                                    if (saved138) {
                                                        this.f629 = false;
                                                    }
                                                }
                                            }
                                            saved139 = this.f629;
                                            if (saved139) {
                                                Scaffold.mc.gameMode.useItemOn(Scaffold.mc.player, InteractionHand.MAIN_HAND, reference6);
                                                this.pm$108();
                                                this.f636 = 10;
                                            }
                                        }
                                    }
                                }
                            }
                            saved140 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                            if (saved140) {
                                floating4 = Recovered_it.m50();
                                floating5 = (floating4 + 45.0f);
                                floating6 = Math.abs(Mth.wrapDegrees((floating5 - this.f624)));
                                saved141 = this.f636;
                                if (!((saved141 != 10))) {
                                    this.f628 = this.f624;
                                }
                                saved142 = this.f636;
                                saved143 = JvmSupport.fcmpl(floating6, 60.0f);
                                saved144 = (!((saved143 <= 0)) ? 8 : 9);
                                if (!((saved142 != saved144))) {
                                    saved145 = Scaffold.mc.options.keyJump.isDown();
                                    if (!(saved145)) {
                                        saved146 = this.f631;
                                        if (saved146) {
                                            saved147 = Scaffold.mc.player.onGround();
                                            if (saved147) {
                                                this.f624 = (floating4 + 45.0f);
                                            }
                                        }
                                    }
                                }
                                saved148 = Scaffold.mc.player.onGround();
                                if (saved148) {
                                    this.f634 = ((int) (Scaffold.mc.player.getY() - 1.0));
                                }
                            } else {
                                this.pm$110(this.f626, this.f627);
                            }
                            saved149 = this.tower.is(Scaffold.TEXT_DISABLED);
                            if (!(saved149)) {
                                floating4 = Recovered_it.m50();
                                saved150 = Scaffold.mc.player.onGround();
                                if (saved150) {
                                    saved151 = Scaffold.mc.options.keyJump.isDown();
                                    if (saved151) {
                                        this.f624 = floating4;
                                    }
                                }
                                saved152 = this.tower.is(Scaffold.TEXT_WATCHDOG_LOW);
                                if (saved152) {
                                    saved153 = Scaffold.mc.player.onGround();
                                    if (!(saved153)) {
                                        saved154 = JvmSupport.dcmpg(Scaffold.mc.player.getDeltaMovement().y, -0.1);
                                        if (!((saved154 >= 0))) {
                                            saved155 = Scaffold.mc.options.keyJump.isDown();
                                            if (saved155) {
                                                saved156 = JvmSupport.dcmpg(((double) this.f637), this.timerTicks.getValue());
                                                if (!((saved156 >= 0))) {
                                                    Recovered_hp.m59(2.0f);
                                                    this.f637 = (this.f637 + 1);
                                                    this.f633 = true;
                                                } else {
                                                    saved157 = this.f633;
                                                    if (saved157) {
                                                        Recovered_hp.m59(1.0f);
                                                        this.f633 = false;
                                                    }
                                                }
                                            } else {
                                                saved158 = this.f633;
                                                if (saved158) {
                                                    Recovered_hp.m59(1.0f);
                                                    this.f633 = false;
                                                }
                                            }
                                        } else {
                                            saved159 = this.f633;
                                            if (saved159) {
                                                Recovered_hp.m59(1.0f);
                                                this.f633 = false;
                                            }
                                        }
                                    } else {
                                        saved160 = this.f633;
                                        if (saved160) {
                                            Recovered_hp.m59(1.0f);
                                            this.f633 = false;
                                        }
                                    }
                                }
                            }
                            Events.rotation.setYaw(this.f624);
                            Events.rotation.setPitch(this.f625);
                            saved161 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                            if (!(saved161)) {
                                this.f631 = Scaffold.mc.player.onGround();
                            }
                            return;
                        }
                    }
                } else {
                    saved162 = Scaffold.mc.player.onGround();
                    if (saved162) {
                        saved163 = this.tellyRMB.getValue();
                        if (saved163) {
                            saved164 = this.f632;
                            if (saved164) {
                                floating3 = Recovered_it.m50();
                                Events.rotation.setYaw(floating3);
                                this.f624 = floating3;
                                this.f631 = Scaffold.mc.player.onGround();
                                return;
                            } else {
                                this.f630 = false;
                                reference3 = Scaffold.mc.player.blockPosition().below();
                                saved165 = this.keepY.getValue();
                                if (saved165) {
                                    reference3 = reference3.atY(this.f634);
                                }
                                saved166 = Scaffold.mc.level.isEmptyBlock(reference3);
                                if (saved166) {
                                    if (!((integer2 == 0))) {
                                        this.f638 = this.pm$109();
                                        saved167 = this.f638;
                                        if (!((saved167 == -1))) {
                                            reference4 = this.getPlaceData(reference3);
                                            if (!((reference4 == null))) {
                                                reference5 = Vec3.atCenterOf(((Vec3i) (Object) reference4.position));
                                                reference6 = new BlockHitResult(reference5, reference4.face, reference4.position, false);
                                                this.pm$111(reference6);
                                                this.pm$110(this.f639[0], this.f639[1]);
                                                this.f626 = this.f639[0];
                                                this.f627 = this.f639[1];
                                                saved168 = this.tower.is(Scaffold.TEXT_DISABLED);
                                                if (!(saved168)) {
                                                    saved169 = Scaffold.mc.options.keyJump.isDown();
                                                    if (saved169) {
                                                        saved170 = Scaffold.mc.player.onGround();
                                                        if (saved170) {
                                                            this.f629 = false;
                                                        }
                                                    }
                                                }
                                                saved171 = this.f629;
                                                if (saved171) {
                                                    Scaffold.mc.gameMode.useItemOn(Scaffold.mc.player, InteractionHand.MAIN_HAND, reference6);
                                                    this.pm$108();
                                                    this.f636 = 10;
                                                }
                                            }
                                        }
                                    }
                                }
                                saved172 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                                if (saved172) {
                                    floating4 = Recovered_it.m50();
                                    floating5 = (floating4 + 45.0f);
                                    floating6 = Math.abs(Mth.wrapDegrees((floating5 - this.f624)));
                                    saved173 = this.f636;
                                    if (!((saved173 != 10))) {
                                        this.f628 = this.f624;
                                    }
                                    saved174 = this.f636;
                                    saved175 = JvmSupport.fcmpl(floating6, 60.0f);
                                    saved176 = (!((saved175 <= 0)) ? 8 : 9);
                                    if (!((saved174 != saved176))) {
                                        saved177 = Scaffold.mc.options.keyJump.isDown();
                                        if (!(saved177)) {
                                            saved178 = this.f631;
                                            if (saved178) {
                                                saved179 = Scaffold.mc.player.onGround();
                                                if (saved179) {
                                                    this.f624 = (floating4 + 45.0f);
                                                }
                                            }
                                        }
                                    }
                                    saved180 = Scaffold.mc.player.onGround();
                                    if (saved180) {
                                        this.f634 = ((int) (Scaffold.mc.player.getY() - 1.0));
                                    }
                                } else {
                                    this.pm$110(this.f626, this.f627);
                                }
                                saved181 = this.tower.is(Scaffold.TEXT_DISABLED);
                                if (!(saved181)) {
                                    floating4 = Recovered_it.m50();
                                    saved182 = Scaffold.mc.player.onGround();
                                    if (saved182) {
                                        saved183 = Scaffold.mc.options.keyJump.isDown();
                                        if (saved183) {
                                            this.f624 = floating4;
                                        }
                                    }
                                    saved184 = this.tower.is(Scaffold.TEXT_WATCHDOG_LOW);
                                    if (saved184) {
                                        saved185 = Scaffold.mc.player.onGround();
                                        if (!(saved185)) {
                                            saved186 = JvmSupport.dcmpg(Scaffold.mc.player.getDeltaMovement().y, -0.1);
                                            if (!((saved186 >= 0))) {
                                                saved187 = Scaffold.mc.options.keyJump.isDown();
                                                if (saved187) {
                                                    saved188 = JvmSupport.dcmpg(((double) this.f637), this.timerTicks.getValue());
                                                    if (!((saved188 >= 0))) {
                                                        Recovered_hp.m59(2.0f);
                                                        this.f637 = (this.f637 + 1);
                                                        this.f633 = true;
                                                    } else {
                                                        saved189 = this.f633;
                                                        if (saved189) {
                                                            Recovered_hp.m59(1.0f);
                                                            this.f633 = false;
                                                        }
                                                    }
                                                } else {
                                                    saved190 = this.f633;
                                                    if (saved190) {
                                                        Recovered_hp.m59(1.0f);
                                                        this.f633 = false;
                                                    }
                                                }
                                            } else {
                                                saved191 = this.f633;
                                                if (saved191) {
                                                    Recovered_hp.m59(1.0f);
                                                    this.f633 = false;
                                                }
                                            }
                                        } else {
                                            saved192 = this.f633;
                                            if (saved192) {
                                                Recovered_hp.m59(1.0f);
                                                this.f633 = false;
                                            }
                                        }
                                    }
                                }
                                Events.rotation.setYaw(this.f624);
                                Events.rotation.setPitch(this.f625);
                                saved193 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                                if (!(saved193)) {
                                    this.f631 = Scaffold.mc.player.onGround();
                                }
                                return;
                            }
                        } else {
                            floating3 = Recovered_it.m50();
                            Events.rotation.setYaw(floating3);
                            this.f624 = floating3;
                            this.f631 = Scaffold.mc.player.onGround();
                            return;
                        }
                    } else {
                        this.f630 = false;
                        reference3 = Scaffold.mc.player.blockPosition().below();
                        saved194 = this.keepY.getValue();
                        if (saved194) {
                            reference3 = reference3.atY(this.f634);
                        }
                        saved195 = Scaffold.mc.level.isEmptyBlock(reference3);
                        if (saved195) {
                            if (!((integer2 == 0))) {
                                this.f638 = this.pm$109();
                                saved196 = this.f638;
                                if (!((saved196 == -1))) {
                                    reference4 = this.getPlaceData(reference3);
                                    if (!((reference4 == null))) {
                                        reference5 = Vec3.atCenterOf(((Vec3i) (Object) reference4.position));
                                        reference6 = new BlockHitResult(reference5, reference4.face, reference4.position, false);
                                        this.pm$111(reference6);
                                        this.pm$110(this.f639[0], this.f639[1]);
                                        this.f626 = this.f639[0];
                                        this.f627 = this.f639[1];
                                        saved197 = this.tower.is(Scaffold.TEXT_DISABLED);
                                        if (!(saved197)) {
                                            saved198 = Scaffold.mc.options.keyJump.isDown();
                                            if (saved198) {
                                                saved199 = Scaffold.mc.player.onGround();
                                                if (saved199) {
                                                    this.f629 = false;
                                                }
                                            }
                                        }
                                        saved200 = this.f629;
                                        if (saved200) {
                                            Scaffold.mc.gameMode.useItemOn(Scaffold.mc.player, InteractionHand.MAIN_HAND, reference6);
                                            this.pm$108();
                                            this.f636 = 10;
                                        }
                                    }
                                }
                            }
                        }
                        saved201 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                        if (saved201) {
                            floating4 = Recovered_it.m50();
                            floating5 = (floating4 + 45.0f);
                            floating6 = Math.abs(Mth.wrapDegrees((floating5 - this.f624)));
                            saved202 = this.f636;
                            if (!((saved202 != 10))) {
                                this.f628 = this.f624;
                            }
                            saved203 = this.f636;
                            saved204 = JvmSupport.fcmpl(floating6, 60.0f);
                            saved205 = (!((saved204 <= 0)) ? 8 : 9);
                            if (!((saved203 != saved205))) {
                                saved206 = Scaffold.mc.options.keyJump.isDown();
                                if (!(saved206)) {
                                    saved207 = this.f631;
                                    if (saved207) {
                                        saved208 = Scaffold.mc.player.onGround();
                                        if (saved208) {
                                            this.f624 = (floating4 + 45.0f);
                                        }
                                    }
                                }
                            }
                            saved209 = Scaffold.mc.player.onGround();
                            if (saved209) {
                                this.f634 = ((int) (Scaffold.mc.player.getY() - 1.0));
                            }
                        } else {
                            this.pm$110(this.f626, this.f627);
                        }
                        saved210 = this.tower.is(Scaffold.TEXT_DISABLED);
                        if (!(saved210)) {
                            floating4 = Recovered_it.m50();
                            saved211 = Scaffold.mc.player.onGround();
                            if (saved211) {
                                saved212 = Scaffold.mc.options.keyJump.isDown();
                                if (saved212) {
                                    this.f624 = floating4;
                                }
                            }
                            saved213 = this.tower.is(Scaffold.TEXT_WATCHDOG_LOW);
                            if (saved213) {
                                saved214 = Scaffold.mc.player.onGround();
                                if (!(saved214)) {
                                    saved215 = JvmSupport.dcmpg(Scaffold.mc.player.getDeltaMovement().y, -0.1);
                                    if (!((saved215 >= 0))) {
                                        saved216 = Scaffold.mc.options.keyJump.isDown();
                                        if (saved216) {
                                            saved217 = JvmSupport.dcmpg(((double) this.f637), this.timerTicks.getValue());
                                            if (!((saved217 >= 0))) {
                                                Recovered_hp.m59(2.0f);
                                                this.f637 = (this.f637 + 1);
                                                this.f633 = true;
                                            } else {
                                                saved218 = this.f633;
                                                if (saved218) {
                                                    Recovered_hp.m59(1.0f);
                                                    this.f633 = false;
                                                }
                                            }
                                        } else {
                                            saved219 = this.f633;
                                            if (saved219) {
                                                Recovered_hp.m59(1.0f);
                                                this.f633 = false;
                                            }
                                        }
                                    } else {
                                        saved220 = this.f633;
                                        if (saved220) {
                                            Recovered_hp.m59(1.0f);
                                            this.f633 = false;
                                        }
                                    }
                                } else {
                                    saved221 = this.f633;
                                    if (saved221) {
                                        Recovered_hp.m59(1.0f);
                                        this.f633 = false;
                                    }
                                }
                            }
                        }
                        Events.rotation.setYaw(this.f624);
                        Events.rotation.setPitch(this.f625);
                        saved222 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                        if (!(saved222)) {
                            this.f631 = Scaffold.mc.player.onGround();
                        }
                        return;
                    }
                }
            } else {
                saved223 = Events.postMotion;
                if (!((event != saved223))) {
                    saved224 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                    if (saved224) {
                        Scaffold.mc.player.yHeadRot = this.f628;
                        Scaffold.mc.player.yBodyRot = Recovered_it.m52(this.f628, Scaffold.mc.player.yBodyRot);
                    }
                } else {
                    saved225 = Events.motion;
                    if (!((event != saved225))) {
                        saved226 = Scaffold.mc.options.keyJump.isDown();
                        if (!(saved226)) {
                            saved227 = this.f637;
                            if (!((saved227 <= 0))) {
                                this.f637 = (this.f637 - 1);
                                Recovered_hp.m59(0.5f);
                                this.f633 = true;
                            } else {
                                saved228 = this.f633;
                                if (saved228) {
                                    Recovered_hp.m59(1.0f);
                                    this.f633 = false;
                                }
                            }
                        }
                    } else {
                        saved229 = Events.keybind;
                        if (!((event != saved229))) {
                            saved230 = this.f638;
                            if (!((saved230 == -1))) {
                                saved231 = Scaffold.mc.player.getInventory().getSelectedSlot();
                                saved232 = this.f638;
                                if (!((saved231 == saved232))) {
                                    Scaffold.mc.player.getInventory().setSelectedSlot(this.f638);
                                }
                            }
                        } else {
                            saved233 = Events.postInput;
                            if (!((event != saved233))) {
                                saved234 = this.fastMode.is(Scaffold.TEXT_WATCHDOG3);
                                if (saved234) {
                                    saved235 = this.f631;
                                    if (!(saved235)) {
                                        saved236 = this.f636;
                                        if (!((saved236 == 10))) {
                                            Scaffold.mc.player.input.makeJump();
                                            this.f631 = true;
                                        }
                                    }
                                }
                                saved237 = this.fastMode.is(Scaffold.TEXT_TELLY);
                                if (!(saved237)) {
                                    saved238 = this.fastMode.is(Scaffold.TEXT_WATCHDOG);
                                    if (!(saved238)) {
                                        saved239 = this.fastMode.is(Scaffold.TEXT_WATCHDOG2);
                                        if (saved239) {
                                            saved240 = JvmSupport.fcmpl(Scaffold.mc.player.input.getMoveVector().x, 0.0f);
                                            if (!((saved240 != 0))) {
                                                saved241 = JvmSupport.fcmpl(Scaffold.mc.player.input.getMoveVector().y, 0.0f);
                                                if (!((saved241 == 0))) {
                                                    saved242 = this.tellyRMB.getValue();
                                                    if (saved242) {
                                                        saved243 = this.f632;
                                                        if (saved243) {
                                                            Scaffold.mc.player.input.makeJump();
                                                        }
                                                    } else {
                                                        Scaffold.mc.player.input.makeJump();
                                                    }
                                                }
                                            } else {
                                                saved244 = this.tellyRMB.getValue();
                                                if (saved244) {
                                                    saved245 = this.f632;
                                                    if (saved245) {
                                                        Scaffold.mc.player.input.makeJump();
                                                    }
                                                } else {
                                                    Scaffold.mc.player.input.makeJump();
                                                }
                                            }
                                        }
                                    } else {
                                        saved246 = JvmSupport.fcmpl(Scaffold.mc.player.input.getMoveVector().x, 0.0f);
                                        if (!((saved246 != 0))) {
                                            saved247 = JvmSupport.fcmpl(Scaffold.mc.player.input.getMoveVector().y, 0.0f);
                                            if (!((saved247 == 0))) {
                                                saved248 = this.tellyRMB.getValue();
                                                if (saved248) {
                                                    saved249 = this.f632;
                                                    if (saved249) {
                                                        Scaffold.mc.player.input.makeJump();
                                                    }
                                                } else {
                                                    Scaffold.mc.player.input.makeJump();
                                                }
                                            }
                                        } else {
                                            saved250 = this.tellyRMB.getValue();
                                            if (saved250) {
                                                saved251 = this.f632;
                                                if (saved251) {
                                                    Scaffold.mc.player.input.makeJump();
                                                }
                                            } else {
                                                Scaffold.mc.player.input.makeJump();
                                            }
                                        }
                                    }
                                } else {
                                    saved252 = JvmSupport.fcmpl(Scaffold.mc.player.input.getMoveVector().x, 0.0f);
                                    if (!((saved252 != 0))) {
                                        saved253 = JvmSupport.fcmpl(Scaffold.mc.player.input.getMoveVector().y, 0.0f);
                                        if (!((saved253 == 0))) {
                                            saved254 = this.tellyRMB.getValue();
                                            if (saved254) {
                                                saved255 = this.f632;
                                                if (saved255) {
                                                    Scaffold.mc.player.input.makeJump();
                                                }
                                            } else {
                                                Scaffold.mc.player.input.makeJump();
                                            }
                                        }
                                    } else {
                                        saved256 = this.tellyRMB.getValue();
                                        if (saved256) {
                                            saved257 = this.f632;
                                            if (saved257) {
                                                Scaffold.mc.player.input.makeJump();
                                            }
                                        } else {
                                            Scaffold.mc.player.input.makeJump();
                                        }
                                    }
                                }
                                saved258 = this.sneak.getValue();
                                if (saved258) {
                                    reference2 = Scaffold.mc.player.input.keyPresses;
                                    saved259 = (Scaffold.mc.player.tickCount % ((int) (this.sneakDelay.getValue() + 1.0)));
                                    if (!((saved259 != 0))) {
                                        Scaffold.mc.player.input.keyPresses = new Input(reference2.forward(), reference2.backward(), reference2.left(), reference2.right(), reference2.jump(), true, reference2.sprint());
                                    }
                                }
                            }
                        }
                    }
                }
                return;
            }
        }
    }
}
