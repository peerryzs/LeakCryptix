package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.MovementInputEvent;
import cryptix.mixin.LivingEntityMixin_zr;
import cryptix.module.Category;
import cryptix.module.Module;

/**
 * Reconstructed from a/aj.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class NoJumpDelay extends Module {
    private static final String TEXT_NOJUMPDELAY;

    public void onEvent(Event event) {
        MovementInputEvent saved1 = null;
        saved1 = Events.movementInput;
        if (!((event != saved1))) {
            ((LivingEntityMixin_zr) (Object) NoJumpDelay.mc.player).setNoJumpDelay(0);
        }
    }

    static {
        TEXT_NOJUMPDELAY = new String("NoJumpDelay");
    }

    public NoJumpDelay() {
        super(NoJumpDelay.TEXT_NOJUMPDELAY, Category.PLAYER);
    }
}
