package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.NumberSetting;
import cryptix.util.Recovered_ee;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import org.lwjgl.glfw.GLFW;

/**
 * Reconstructed from a/dx.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Eagle extends Module {
    private static final String TEXT_PITCH_CHECK;
    private static final String TEXT_BLOCK_CHECK;
    private static final String TEXT_FORWARD_CHECK;
    private final BooleanSetting blockCheck;
    private final NumberSetting delay;
    private final BooleanSetting forwardCheck;
    private final BooleanSetting pitchCheck;
    private boolean f543;
    private static final String TEXT_FIX_DOUBLE_SNEAK;
    private static final String TEXT_EAGLE;
    private static final String TEXT_DELAY;
    private final BooleanSetting fixDoubleSneak;
    private int f544;
    private int f545;

    private void pm$96(BlockState arg0) {
        boolean saved1 = false;
        boolean saved2 = false;
        boolean saved3 = false;
        int saved4 = 0;
        boolean saved5 = false;
        int saved6 = 0;
        saved1 = arg0.isAir();
        if (saved1) {
            saved2 = Eagle.mc.player.onGround();
            if (saved2) {
                Eagle.mc.options.keyShift.setDown(true);
                this.f543 = true;
            } else {
                saved3 = this.f543;
                if (saved3) {
                    this.f545 = (this.f545 + 1);
                    saved4 = JvmSupport.dcmpl(((double) this.f545), this.delay.getValue());
                    if (!((saved4 < 0))) {
                        this.pm$97();
                    }
                }
            }
        } else {
            saved5 = this.f543;
            if (saved5) {
                this.f545 = (this.f545 + 1);
                saved6 = JvmSupport.dcmpl(((double) this.f545), this.delay.getValue());
                if (!((saved6 < 0))) {
                    this.pm$97();
                }
            }
        }
    }

    public Eagle() {
        super(Eagle.TEXT_EAGLE, Category.PLAYER);
        this.blockCheck = new BooleanSetting(Eagle.TEXT_BLOCK_CHECK, this, true);
        this.pitchCheck = new BooleanSetting(Eagle.TEXT_PITCH_CHECK, this, true);
        this.forwardCheck = new BooleanSetting(Eagle.TEXT_FORWARD_CHECK, this, true);
        this.fixDoubleSneak = new BooleanSetting(Eagle.TEXT_FIX_DOUBLE_SNEAK, this, false);
        this.delay = new NumberSetting(Eagle.TEXT_DELAY, this, 1.0, 0.0, 4.0, 1.0);
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        boolean saved4 = false;
        int saved5 = 0;
        boolean saved6 = false;
        boolean saved7 = false;
        double number2 = 0.0;
        double number4 = 0.0;
        double number6 = 0.0;
        BlockState reference8 = null;
        boolean saved8 = false;
        int saved9 = 0;
        boolean saved10 = false;
        int saved11 = 0;
        boolean saved12 = false;
        boolean saved13 = false;
        boolean saved14 = false;
        int saved15 = 0;
        boolean saved16 = false;
        int saved17 = 0;
        boolean saved18 = false;
        int saved19 = 0;
        boolean saved20 = false;
        boolean saved21 = false;
        boolean saved22 = false;
        int saved23 = 0;
        boolean saved24 = false;
        int saved25 = 0;
        boolean saved26 = false;
        boolean saved27 = false;
        boolean saved28 = false;
        int saved29 = 0;
        boolean saved30 = false;
        int saved31 = 0;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            saved2 = this.blockCheck.getValue();
            if (saved2) {
                saved3 = Recovered_ee.m45();
                if (!(saved3)) {
                    this.pm$97();
                    return;
                } else {
                    saved4 = this.pitchCheck.getValue();
                    if (saved4) {
                        saved5 = JvmSupport.fcmpg(Eagle.mc.player.getXRot(), 70.0f);
                        if (!((saved5 >= 0))) {
                            this.pm$97();
                            return;
                        } else {
                            saved6 = this.forwardCheck.getValue();
                            if (saved6) {
                                saved7 = Eagle.mc.options.keyDown.isDown();
                                if (!(saved7)) {
                                    this.pm$97();
                                    return;
                                } else {
                                    number2 = Eagle.mc.player.getX();
                                    number4 = (Eagle.mc.player.getY() - 0.05);
                                    number6 = Eagle.mc.player.getZ();
                                    reference8 = Eagle.mc.level.getBlockState(BlockPos.containing(number2, number4, number6));
                                    saved8 = this.fixDoubleSneak.getValue();
                                    if (!(saved8)) {
                                        this.pm$96(reference8);
                                    } else {
                                        this.f544 = (this.f544 + 1);
                                        saved9 = this.f544;
                                        if (!((saved9 < 4))) {
                                            this.pm$96(reference8);
                                        } else {
                                            this.pm$97();
                                        }
                                    }
                                    return;
                                }
                            } else {
                                number2 = Eagle.mc.player.getX();
                                number4 = (Eagle.mc.player.getY() - 0.05);
                                number6 = Eagle.mc.player.getZ();
                                reference8 = Eagle.mc.level.getBlockState(BlockPos.containing(number2, number4, number6));
                                saved10 = this.fixDoubleSneak.getValue();
                                if (!(saved10)) {
                                    this.pm$96(reference8);
                                } else {
                                    this.f544 = (this.f544 + 1);
                                    saved11 = this.f544;
                                    if (!((saved11 < 4))) {
                                        this.pm$96(reference8);
                                    } else {
                                        this.pm$97();
                                    }
                                }
                                return;
                            }
                        }
                    } else {
                        saved12 = this.forwardCheck.getValue();
                        if (saved12) {
                            saved13 = Eagle.mc.options.keyDown.isDown();
                            if (!(saved13)) {
                                this.pm$97();
                                return;
                            } else {
                                number2 = Eagle.mc.player.getX();
                                number4 = (Eagle.mc.player.getY() - 0.05);
                                number6 = Eagle.mc.player.getZ();
                                reference8 = Eagle.mc.level.getBlockState(BlockPos.containing(number2, number4, number6));
                                saved14 = this.fixDoubleSneak.getValue();
                                if (!(saved14)) {
                                    this.pm$96(reference8);
                                } else {
                                    this.f544 = (this.f544 + 1);
                                    saved15 = this.f544;
                                    if (!((saved15 < 4))) {
                                        this.pm$96(reference8);
                                    } else {
                                        this.pm$97();
                                    }
                                }
                                return;
                            }
                        } else {
                            number2 = Eagle.mc.player.getX();
                            number4 = (Eagle.mc.player.getY() - 0.05);
                            number6 = Eagle.mc.player.getZ();
                            reference8 = Eagle.mc.level.getBlockState(BlockPos.containing(number2, number4, number6));
                            saved16 = this.fixDoubleSneak.getValue();
                            if (!(saved16)) {
                                this.pm$96(reference8);
                            } else {
                                this.f544 = (this.f544 + 1);
                                saved17 = this.f544;
                                if (!((saved17 < 4))) {
                                    this.pm$96(reference8);
                                } else {
                                    this.pm$97();
                                }
                            }
                            return;
                        }
                    }
                }
            } else {
                saved18 = this.pitchCheck.getValue();
                if (saved18) {
                    saved19 = JvmSupport.fcmpg(Eagle.mc.player.getXRot(), 70.0f);
                    if (!((saved19 >= 0))) {
                        this.pm$97();
                        return;
                    } else {
                        saved20 = this.forwardCheck.getValue();
                        if (saved20) {
                            saved21 = Eagle.mc.options.keyDown.isDown();
                            if (!(saved21)) {
                                this.pm$97();
                                return;
                            } else {
                                number2 = Eagle.mc.player.getX();
                                number4 = (Eagle.mc.player.getY() - 0.05);
                                number6 = Eagle.mc.player.getZ();
                                reference8 = Eagle.mc.level.getBlockState(BlockPos.containing(number2, number4, number6));
                                saved22 = this.fixDoubleSneak.getValue();
                                if (!(saved22)) {
                                    this.pm$96(reference8);
                                } else {
                                    this.f544 = (this.f544 + 1);
                                    saved23 = this.f544;
                                    if (!((saved23 < 4))) {
                                        this.pm$96(reference8);
                                    } else {
                                        this.pm$97();
                                    }
                                }
                                return;
                            }
                        } else {
                            number2 = Eagle.mc.player.getX();
                            number4 = (Eagle.mc.player.getY() - 0.05);
                            number6 = Eagle.mc.player.getZ();
                            reference8 = Eagle.mc.level.getBlockState(BlockPos.containing(number2, number4, number6));
                            saved24 = this.fixDoubleSneak.getValue();
                            if (!(saved24)) {
                                this.pm$96(reference8);
                            } else {
                                this.f544 = (this.f544 + 1);
                                saved25 = this.f544;
                                if (!((saved25 < 4))) {
                                    this.pm$96(reference8);
                                } else {
                                    this.pm$97();
                                }
                            }
                            return;
                        }
                    }
                } else {
                    saved26 = this.forwardCheck.getValue();
                    if (saved26) {
                        saved27 = Eagle.mc.options.keyDown.isDown();
                        if (!(saved27)) {
                            this.pm$97();
                            return;
                        } else {
                            number2 = Eagle.mc.player.getX();
                            number4 = (Eagle.mc.player.getY() - 0.05);
                            number6 = Eagle.mc.player.getZ();
                            reference8 = Eagle.mc.level.getBlockState(BlockPos.containing(number2, number4, number6));
                            saved28 = this.fixDoubleSneak.getValue();
                            if (!(saved28)) {
                                this.pm$96(reference8);
                            } else {
                                this.f544 = (this.f544 + 1);
                                saved29 = this.f544;
                                if (!((saved29 < 4))) {
                                    this.pm$96(reference8);
                                } else {
                                    this.pm$97();
                                }
                            }
                            return;
                        }
                    } else {
                        number2 = Eagle.mc.player.getX();
                        number4 = (Eagle.mc.player.getY() - 0.05);
                        number6 = Eagle.mc.player.getZ();
                        reference8 = Eagle.mc.level.getBlockState(BlockPos.containing(number2, number4, number6));
                        saved30 = this.fixDoubleSneak.getValue();
                        if (!(saved30)) {
                            this.pm$96(reference8);
                        } else {
                            this.f544 = (this.f544 + 1);
                            saved31 = this.f544;
                            if (!((saved31 < 4))) {
                                this.pm$96(reference8);
                            } else {
                                this.pm$97();
                            }
                        }
                        return;
                    }
                }
            }
        } else {
            return;
        }
    }

    static {
        TEXT_EAGLE = new String("Eagle");
        TEXT_BLOCK_CHECK = new String("Block Check");
        TEXT_PITCH_CHECK = new String("Pitch Check");
        TEXT_FORWARD_CHECK = new String("Forward Check");
        TEXT_FIX_DOUBLE_SNEAK = new String("Fix Double Sneak");
        TEXT_DELAY = new String("Delay");
    }

    private void pm$97() {
        boolean saved1 = false;
        long local1 = 0L;
        int saved2 = 0;
        int saved3 = 0;
        int branchValue4 = 0;
        int integer3 = 0;
        saved1 = this.f543;
        if (saved1) {
            this.f544 = 0;
            this.f545 = 0;
            local1 = Eagle.mc.getWindow().handle();
            saved2 = GLFW.glfwGetKey(local1, 340);
            if (!((saved2 == 1))) {
                saved3 = GLFW.glfwGetKey(local1, 344);
                branchValue4 = (!((saved3 != 1)) ? 1 : 0);
            } else {
                branchValue4 = 1;
            }
            integer3 = branchValue4;
            if (!((integer3 != 0))) {
                Eagle.mc.options.keyShift.setDown(false);
            }
            this.f543 = false;
        }
    }
}
