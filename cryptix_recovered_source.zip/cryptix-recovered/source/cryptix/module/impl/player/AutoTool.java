package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Reconstructed from a/sq.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class AutoTool extends Module {
    private int f488;
    private static final String TEXT_SWAP_BACK;
    private static final String TEXT_AUTOTOOL;
    private final BooleanSetting swapBack;

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        int saved4 = 0;
        Object reference3 = null;
        boolean saved5 = false;
        BlockHitResult reference2 = null;
        BlockState reference4 = null;
        boolean saved6 = false;
        int integer5 = 0;
        float floating6 = 0.0f;
        int integer7 = 0;
        ItemStack reference8 = null;
        boolean saved7 = false;
        float floating9 = 0.0f;
        int saved8 = 0;
        int saved9 = 0;
        int saved10 = 0;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            saved2 = AutoTool.mc.gameMode.isDestroying();
            if (!(saved2)) {
                saved3 = this.swapBack.getValue();
                if (saved3) {
                    saved4 = this.f488;
                    if (!((saved4 == -1))) {
                        AutoTool.mc.player.getInventory().setSelectedSlot(this.f488);
                        this.f488 = -1;
                    }
                }
                return;
            } else {
                reference3 = AutoTool.mc.hitResult;
                saved5 = (reference3 instanceof BlockHitResult);
                if (saved5) {
                    reference2 = ((BlockHitResult) reference3);
                    reference3 = reference2.getBlockPos();
                    reference4 = AutoTool.mc.level.getBlockState(((BlockPos) reference3));
                    saved6 = reference4.isAir();
                    if (saved6) {
                        return;
                    } else {
                        integer5 = -1;
                        floating6 = 1.0f;
                        integer7 = 0;
                        loop54: while (true) {
                            if ((integer7 >= 9)) {
                                break loop54;
                            }
                            reference8 = AutoTool.mc.player.getInventory().getItem(integer7);
                            saved7 = reference8.isEmpty();
                            if (saved7) {
                            } else {
                                floating9 = reference8.getDestroySpeed(reference4);
                                saved8 = JvmSupport.fcmpl(floating9, floating6);
                                if (!((saved8 <= 0))) {
                                    floating6 = floating9;
                                    integer5 = integer7;
                                }
                            }
                            integer7++;
                            continue loop54;
                        }
                        if (!((integer5 == -1))) {
                            saved9 = AutoTool.mc.player.getInventory().getSelectedSlot();
                            if (!((integer5 == saved9))) {
                                saved10 = this.f488;
                                if (!((saved10 != -1))) {
                                    this.f488 = AutoTool.mc.player.getInventory().getSelectedSlot();
                                }
                                AutoTool.mc.player.getInventory().setSelectedSlot(integer5);
                            }
                        }
                        return;
                    }
                } else {
                    return;
                }
            }
        } else {
            return;
        }
    }

    public AutoTool() {
        super(AutoTool.TEXT_AUTOTOOL, Category.PLAYER);
        this.swapBack = new BooleanSetting(AutoTool.TEXT_SWAP_BACK, this, true);
        this.f488 = -1;
    }

    static {
        TEXT_AUTOTOOL = new String("AutoTool");
        TEXT_SWAP_BACK = new String("Swap Back");
    }
}
