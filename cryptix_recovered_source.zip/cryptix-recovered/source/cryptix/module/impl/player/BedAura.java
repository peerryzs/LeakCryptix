package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.HudRenderEvent;
import cryptix.event.impl.MotionEvent;
import cryptix.event.impl.MouseButtonEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.mixin.MultiPlayerGameModeMixin;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.module.ModuleManager;
import cryptix.recovery.JvmSupport;
import cryptix.render.ProjectionUtils;
import cryptix.setting.BooleanSetting;
import cryptix.setting.NumberSetting;
import cryptix.util.Recovered_eg;
import java.util.Iterator;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.Vec3;

/**
 * Reconstructed from a/lx.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class BedAura extends Module {
    private final BooleanSetting surrounding;
    private int f522;
    public boolean f25;
    private final BooleanSetting groundSpoof;
    private int f518;
    private static final String TEXT_SURROUNDING;
    private static final String TEXT_SILENT_SWING;
    private static final String TEXT_GROUND_SPOOF;
    private final NumberSetting speed;
    private final BooleanSetting onlySSRotate;
    private static final String TEXT_BEDAURA;
    private int f520;
    private static final String TEXT_ALLOW_KILLAURA;
    private int f521;
    private static final String TEXT_RANGE;
    private static final String TEXT_ONLY_S_S_ROTATE;
    private final BooleanSetting allowKillAura;
    private final BooleanSetting silentSwing;
    private static final String TEXT_BREAK_DELAY;
    private final NumberSetting breakDelay;
    private final BlockPos.MutableBlockPos f523;
    private final NumberSetting range;
    private final BooleanSetting watchdogMode;
    public int f26;
    private static final String TEXT_SPEED;
    private static final String TEXT_WATCHDOG_MODE;
    public float f23;
    private BlockPos f519;
    private float f517;
    public BlockPos f24;

    private Packet resetCallback0(Direction arg0, int arg1) {
        Object reference0 = this;
        reference0 = new ServerboundPlayerActionPacket(ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, ((BedAura) reference0).f24, arg0, arg1);
        return ((Packet) reference0);
    }

    private Packet breakBedCallback0(Direction arg0, int arg1) {
        Object reference0 = this;
        reference0 = new ServerboundPlayerActionPacket(ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, ((BedAura) reference0).f24, arg0, arg1);
        return ((Packet) reference0);
    }

    static {
        TEXT_BEDAURA = new String("BedAura");
        TEXT_RANGE = new String("Range");
        TEXT_SPEED = new String("Speed");
        TEXT_BREAK_DELAY = new String("Break Delay");
        TEXT_SURROUNDING = new String("Surrounding");
        TEXT_ALLOW_KILLAURA = new String("Allow KillAura");
        TEXT_ONLY_S_S_ROTATE = new String("Only S/S Rotate");
        TEXT_WATCHDOG_MODE = new String("Watchdog Mode");
        TEXT_SILENT_SWING = new String("Silent Swing");
        TEXT_GROUND_SPOOF = new String("Ground Spoof");
    }

    private void breakBed(BlockPos arg0, BlockState arg1) {
        boolean saved1 = false;
        Object reference3 = null;
        Direction reference4 = null;
        BedPart reference5 = null;
        BedPart saved2 = null;
        BlockPos reference6 = null;
        int integer7 = 0;
        Object reference8 = null;
        boolean saved3 = false;
        Direction reference9 = null;
        BlockPos reference10 = null;
        BlockPos reference11 = null;
        Object reference12 = null;
        BlockState reference13 = null;
        Block saved4 = null;
        Block saved5 = null;
        Block saved6 = null;
        Block saved7 = null;
        boolean saved8 = false;
        int integer9 = 0;
        float floating10 = 0.0f;
        int integer11 = 0;
        float floating13 = 0.0f;
        int saved9 = 0;
        int saved10 = 0;
        BlockPos saved11 = null;
        boolean saved12 = false;
        int saved13 = 0;
        MultiPlayerGameModeMixin saved15 = null;
        ClientLevel saved16 = null;
        double number3 = 0.0;
        double number5 = 0.0;
        double number7 = 0.0;
        double number9 = 0.0;
        double number11 = 0.0;
        double number13 = 0.0;
        double number15 = 0.0;
        float floating17 = 0.0f;
        float floating18 = 0.0f;
        boolean saved18 = false;
        int saved19 = 0;
        int saved20 = 0;
        float floating19 = 0.0f;
        boolean saved21 = false;
        boolean saved22 = false;
        boolean saved23 = false;
        boolean saved24 = false;
        float floating20 = 0.0f;
        boolean saved25 = false;
        boolean saved26 = false;
        int saved27 = 0;
        int saved28 = 0;
        Object reference21 = null;
        Direction reference22 = null;
        int saved29 = 0;
        MultiPlayerGameModeMixin saved31 = null;
        ClientLevel saved32 = null;
        int saved34 = 0;
        MultiPlayerGameModeMixin saved36 = null;
        ClientLevel saved37 = null;
        boolean saved39 = false;
        int saved40 = 0;
        int saved41 = 0;
        boolean saved42 = false;
        boolean saved43 = false;
        boolean saved44 = false;
        boolean saved45 = false;
        boolean saved46 = false;
        boolean saved47 = false;
        int saved48 = 0;
        int saved49 = 0;
        int saved50 = 0;
        MultiPlayerGameModeMixin saved52 = null;
        ClientLevel saved53 = null;
        int saved55 = 0;
        MultiPlayerGameModeMixin saved57 = null;
        ClientLevel saved58 = null;
        saved1 = this.surrounding.getValue();
        if (saved1) {
            reference3 = arg0.above();
            reference4 = ((Direction) (Object) arg1.getValue(((Property) (Object) BedBlock.FACING)));
            reference5 = ((BedPart) (Object) arg1.getValue(((Property) (Object) BedBlock.PART)));
            saved2 = BedPart.HEAD;
            reference6 = (!((reference5 != saved2)) ? arg0.relative(reference4.getOpposite()) : arg0.relative(reference4));
            integer7 = 0;
            reference8 = Direction.Plane.HORIZONTAL.iterator();
            loop34: while (true) {
                saved3 = ((Iterator) reference8).hasNext();
                if (!(saved3)) {
                    break loop34;
                }
                reference9 = ((Direction) ((Iterator) reference8).next());
                reference10 = arg0.relative(reference9);
                reference11 = reference6.relative(reference9);
                reference12 = BedAura.mc.level.getBlockState(reference10);
                reference13 = BedAura.mc.level.getBlockState(reference11);
                saved4 = ((BlockState) reference12).getBlock();
                saved5 = Blocks.AIR;
                if (!((saved4 != saved5))) {
                    integer7 = 1;
                    break loop34;
                } else {
                    saved6 = reference13.getBlock();
                    saved7 = Blocks.AIR;
                    if (!((saved6 != saved7))) {
                        integer7 = 1;
                        break loop34;
                    } else {
                        continue loop34;
                    }
                }
            }
            if (!((integer7 != 0))) {
                reference8 = BedAura.mc.level.getBlockState(((BlockPos) reference3));
                saved8 = ((BlockState) reference8).isAir();
                if (!(saved8)) {
                    arg0 = ((BlockPos) reference3);
                    arg1 = ((BlockState) reference8);
                    integer9 = -1;
                    floating10 = 1.0f;
                    integer11 = 0;
                    loop94: while (true) {
                        if ((integer11 >= 9)) {
                            break loop94;
                        }
                        reference12 = BedAura.mc.player.getInventory().getItem(integer11);
                        floating13 = ((ItemStack) reference12).getDestroySpeed(arg1);
                        saved9 = JvmSupport.fcmpl(floating13, floating10);
                        if (!((saved9 <= 0))) {
                            floating10 = floating13;
                            integer9 = integer11;
                        }
                        integer11++;
                        continue loop94;
                    }
                    if (!((integer9 == -1))) {
                        saved10 = BedAura.mc.player.getInventory().getSelectedSlot();
                        if (!((saved10 == integer9))) {
                            this.f518 = BedAura.mc.player.getInventory().getSelectedSlot();
                            BedAura.mc.player.getInventory().setSelectedSlot(integer9);
                        }
                    }
                }
            }
        }
        saved11 = this.f24;
        if (!((saved11 == null))) {
            saved12 = this.f24.equals(arg0);
            if (!(saved12)) {
                saved13 = JvmSupport.fcmpl(this.f23, 0.0f);
                if (!((saved13 <= 0))) {
                    reference3 = this.pm$94(Events.rotation.getYaw(), Events.rotation.getPitch());
                    saved15 = ((MultiPlayerGameModeMixin) (Object) BedAura.mc.gameMode);
                    saved16 = BedAura.mc.level;
                    final BedAura captured14 = this;
                    final Direction captured17 = ((Direction) reference3);
                    saved15.invokeStartPrediction(saved16, (lambdaArg0) -> captured14.breakBedCallback0(captured17, lambdaArg0));
                    BedAura.mc.level.destroyBlockProgress(BedAura.mc.player.getId(), this.f24, -1);
                }
                this.f24 = null;
                this.f517 = this.f23;
                this.f23 = 0.0f;
                return;
            } else {
                number3 = (((double) arg0.getX()) + 0.5);
                number5 = (((double) arg0.getY()) + 0.5);
                number7 = (((double) arg0.getZ()) + 0.5);
                number9 = (number3 - BedAura.mc.player.getX());
                number11 = (number5 - BedAura.mc.player.getEyeY());
                number13 = (number7 - BedAura.mc.player.getZ());
                number15 = Math.sqrt(((number9 * number9) + (number13 * number13)));
                floating17 = (((float) Math.toDegrees(Math.atan2(number13, number9))) - 90.0f);
                floating18 = ((float) (-Math.toDegrees(Math.atan2(number11, number15))));
                saved18 = this.onlySSRotate.getValue();
                if (saved18) {
                    saved19 = JvmSupport.fcmpl(this.f23, 0.0f);
                    if (!((saved19 == 0))) {
                        saved20 = JvmSupport.fcmpl(this.f23, 1.0f);
                        if (!((saved20 < 0))) {
                            Events.rotation.setYaw(floating17);
                            Events.rotation.setPitch(floating18);
                            this.f25 = true;
                        }
                    } else {
                        Events.rotation.setYaw(floating17);
                        Events.rotation.setPitch(floating18);
                        this.f25 = true;
                    }
                } else {
                    Events.rotation.setYaw(floating17);
                    Events.rotation.setPitch(floating18);
                    this.f25 = true;
                }
                floating19 = ((float) (((double) arg1.getDestroyProgress(BedAura.mc.player, ((BlockGetter) (Object) BedAura.mc.player.level()), arg0)) * this.speed.getValue()));
                saved21 = Events.motion.isOnGround();
                if (saved21) {
                    saved22 = BedAura.mc.player.onGround();
                    if (!(saved22)) {
                        floating19 = (floating19 * 5.0f);
                    }
                }
                saved23 = BedAura.mc.player.isEyeInFluid(FluidTags.WATER);
                if (saved23) {
                    saved24 = this.watchdogMode.getValue();
                    if (saved24) {
                        floating19 = (floating19 * 5.0f);
                    }
                }
                floating20 = 1.0f;
                saved25 = BedAura.mc.player.onGround();
                if (!(saved25)) {
                    saved26 = this.watchdogMode.getValue();
                    if (saved26) {
                        floating19 = (floating19 * 5.0f);
                        floating20 = 5.0f;
                    }
                }
                saved27 = JvmSupport.fcmpg(floating19, 0.0f);
                if (!((saved27 >= 0))) {
                    return;
                } else {
                    saved28 = (BedAura.mc.player.tickCount % 4);
                    if (!((saved28 != 0))) {
                        reference21 = arg1.getSoundType();
                        BedAura.mc.getSoundManager().play(((SoundInstance) (Object) new SimpleSoundInstance(((SoundType) reference21).getHitSound(), SoundSource.BLOCKS, ((((SoundType) reference21).getVolume() + 1.0f) * 0.125f), (((SoundType) reference21).getPitch() * 0.5f), SoundInstance.createUnseededRandom(), arg0)));
                    }
                    reference21 = arg0;
                    reference22 = this.pm$94(floating17, floating18);
                    saved29 = JvmSupport.fcmpl(this.f23, 0.0f);
                    if (!((saved29 != 0))) {
                        saved31 = ((MultiPlayerGameModeMixin) (Object) BedAura.mc.gameMode);
                        saved32 = BedAura.mc.level;
                        final BlockPos captured30 = ((BlockPos) reference21);
                        final Direction captured33 = reference22;
                        saved31.invokeStartPrediction(saved32, (lambdaArg0) -> BedAura.breakBedCallback1(captured30, captured33, lambdaArg0));
                    }
                    saved34 = JvmSupport.fcmpl(this.f23, (floating20 + floating19));
                    if (!((saved34 < 0))) {
                        saved36 = ((MultiPlayerGameModeMixin) (Object) BedAura.mc.gameMode);
                        saved37 = BedAura.mc.level;
                        final BlockPos captured35 = ((BlockPos) reference21);
                        final Direction captured38 = reference22;
                        saved36.invokeStartPrediction(saved37, (lambdaArg0) -> BedAura.breakBedCallback2(captured35, captured38, lambdaArg0));
                        this.pm$95();
                        this.f23 = 0.0f;
                        BedAura.mc.gameMode.destroyBlock(arg0);
                        BedAura.mc.level.destroyBlockProgress(BedAura.mc.player.getId(), arg0, -1);
                        this.reset();
                        this.f520 = ((int) this.breakDelay.getValue());
                        return;
                    } else {
                        BedAura.mc.level.destroyBlockProgress(BedAura.mc.player.getId(), arg0, Math.min(9, ((int) ((this.f23 * 10.0f) / floating20))));
                        this.f517 = this.f23;
                        this.f23 = (this.f23 + floating19);
                        this.pm$95();
                        this.f24 = arg0;
                        return;
                    }
                }
            }
        } else {
            number3 = (((double) arg0.getX()) + 0.5);
            number5 = (((double) arg0.getY()) + 0.5);
            number7 = (((double) arg0.getZ()) + 0.5);
            number9 = (number3 - BedAura.mc.player.getX());
            number11 = (number5 - BedAura.mc.player.getEyeY());
            number13 = (number7 - BedAura.mc.player.getZ());
            number15 = Math.sqrt(((number9 * number9) + (number13 * number13)));
            floating17 = (((float) Math.toDegrees(Math.atan2(number13, number9))) - 90.0f);
            floating18 = ((float) (-Math.toDegrees(Math.atan2(number11, number15))));
            saved39 = this.onlySSRotate.getValue();
            if (saved39) {
                saved40 = JvmSupport.fcmpl(this.f23, 0.0f);
                if (!((saved40 == 0))) {
                    saved41 = JvmSupport.fcmpl(this.f23, 1.0f);
                    if (!((saved41 < 0))) {
                        Events.rotation.setYaw(floating17);
                        Events.rotation.setPitch(floating18);
                        this.f25 = true;
                    }
                } else {
                    Events.rotation.setYaw(floating17);
                    Events.rotation.setPitch(floating18);
                    this.f25 = true;
                }
            } else {
                Events.rotation.setYaw(floating17);
                Events.rotation.setPitch(floating18);
                this.f25 = true;
            }
            floating19 = ((float) (((double) arg1.getDestroyProgress(BedAura.mc.player, ((BlockGetter) (Object) BedAura.mc.player.level()), arg0)) * this.speed.getValue()));
            saved42 = Events.motion.isOnGround();
            if (saved42) {
                saved43 = BedAura.mc.player.onGround();
                if (!(saved43)) {
                    floating19 = (floating19 * 5.0f);
                }
            }
            saved44 = BedAura.mc.player.isEyeInFluid(FluidTags.WATER);
            if (saved44) {
                saved45 = this.watchdogMode.getValue();
                if (saved45) {
                    floating19 = (floating19 * 5.0f);
                }
            }
            floating20 = 1.0f;
            saved46 = BedAura.mc.player.onGround();
            if (!(saved46)) {
                saved47 = this.watchdogMode.getValue();
                if (saved47) {
                    floating19 = (floating19 * 5.0f);
                    floating20 = 5.0f;
                }
            }
            saved48 = JvmSupport.fcmpg(floating19, 0.0f);
            if (!((saved48 >= 0))) {
                return;
            } else {
                saved49 = (BedAura.mc.player.tickCount % 4);
                if (!((saved49 != 0))) {
                    reference21 = arg1.getSoundType();
                    BedAura.mc.getSoundManager().play(((SoundInstance) (Object) new SimpleSoundInstance(((SoundType) reference21).getHitSound(), SoundSource.BLOCKS, ((((SoundType) reference21).getVolume() + 1.0f) * 0.125f), (((SoundType) reference21).getPitch() * 0.5f), SoundInstance.createUnseededRandom(), arg0)));
                }
                reference21 = arg0;
                reference22 = this.pm$94(floating17, floating18);
                saved50 = JvmSupport.fcmpl(this.f23, 0.0f);
                if (!((saved50 != 0))) {
                    saved52 = ((MultiPlayerGameModeMixin) (Object) BedAura.mc.gameMode);
                    saved53 = BedAura.mc.level;
                    final BlockPos captured51 = ((BlockPos) reference21);
                    final Direction captured54 = reference22;
                    saved52.invokeStartPrediction(saved53, (lambdaArg0) -> BedAura.breakBedCallback1(captured51, captured54, lambdaArg0));
                }
                saved55 = JvmSupport.fcmpl(this.f23, (floating20 + floating19));
                if (!((saved55 < 0))) {
                    saved57 = ((MultiPlayerGameModeMixin) (Object) BedAura.mc.gameMode);
                    saved58 = BedAura.mc.level;
                    final BlockPos captured56 = ((BlockPos) reference21);
                    final Direction captured59 = reference22;
                    saved57.invokeStartPrediction(saved58, (lambdaArg0) -> BedAura.breakBedCallback2(captured56, captured59, lambdaArg0));
                    this.pm$95();
                    this.f23 = 0.0f;
                    BedAura.mc.gameMode.destroyBlock(arg0);
                    BedAura.mc.level.destroyBlockProgress(BedAura.mc.player.getId(), arg0, -1);
                    this.reset();
                    this.f520 = ((int) this.breakDelay.getValue());
                    return;
                } else {
                    BedAura.mc.level.destroyBlockProgress(BedAura.mc.player.getId(), arg0, Math.min(9, ((int) ((this.f23 * 10.0f) / floating20))));
                    this.f517 = this.f23;
                    this.f23 = (this.f23 + floating19);
                    this.pm$95();
                    this.f24 = arg0;
                    return;
                }
            }
        }
    }

    public void onEvent(Event event) {
        MouseButtonEvent saved1 = null;
        Screen saved2 = null;
        BlockPos saved3 = null;
        MotionEvent saved4 = null;
        boolean saved5 = false;
        BlockPos saved6 = null;
        RotationEvent saved7 = null;
        BlockPos saved8 = null;
        int saved9 = 0;
        float branchValue10 = 0.0f;
        float floating2 = 0.0f;
        Screen saved11 = null;
        Entity saved12 = null;
        boolean saved13 = false;
        boolean saved14 = false;
        boolean saved15 = false;
        int saved16 = 0;
        BlockPos reference3 = null;
        BlockPos saved17 = null;
        BlockState reference4 = null;
        BlockState reference5 = null;
        int saved18 = 0;
        Block saved19 = null;
        Block saved20 = null;
        HudRenderEvent saved21 = null;
        int saved22 = 0;
        int saved23 = 0;
        float floating3 = 0.0f;
        float floating4 = 0.0f;
        float floating5 = 0.0f;
        boolean saved24 = false;
        boolean saved25 = false;
        float branchValue26 = 0.0f;
        float floating6 = 0.0f;
        float floating7 = 0.0f;
        float floating8 = 0.0f;
        float floating9 = 0.0f;
        int integer10 = 0;
        int integer11 = 0;
        int integer12 = 0;
        int integer13 = 0;
        boolean saved27 = false;
        boolean saved28 = false;
        float branchValue29 = 0.0f;
        HudRenderEvent saved30 = null;
        int saved31 = 0;
        int saved32 = 0;
        boolean saved33 = false;
        boolean saved34 = false;
        float branchValue35 = 0.0f;
        boolean saved36 = false;
        boolean saved37 = false;
        float branchValue38 = 0.0f;
        int saved39 = 0;
        Block saved40 = null;
        Block saved41 = null;
        HudRenderEvent saved42 = null;
        int saved43 = 0;
        int saved44 = 0;
        boolean saved45 = false;
        boolean saved46 = false;
        float branchValue47 = 0.0f;
        boolean saved48 = false;
        boolean saved49 = false;
        float branchValue50 = 0.0f;
        HudRenderEvent saved51 = null;
        int saved52 = 0;
        int saved53 = 0;
        boolean saved54 = false;
        boolean saved55 = false;
        float branchValue56 = 0.0f;
        boolean saved57 = false;
        boolean saved58 = false;
        float branchValue59 = 0.0f;
        int saved60 = 0;
        Block saved61 = null;
        Block saved62 = null;
        HudRenderEvent saved63 = null;
        int saved64 = 0;
        int saved65 = 0;
        boolean saved66 = false;
        boolean saved67 = false;
        float branchValue68 = 0.0f;
        boolean saved69 = false;
        boolean saved70 = false;
        float branchValue71 = 0.0f;
        HudRenderEvent saved72 = null;
        int saved73 = 0;
        int saved74 = 0;
        boolean saved75 = false;
        boolean saved76 = false;
        float branchValue77 = 0.0f;
        boolean saved78 = false;
        boolean saved79 = false;
        float branchValue80 = 0.0f;
        boolean saved81 = false;
        int saved82 = 0;
        BlockPos saved83 = null;
        int saved84 = 0;
        Block saved85 = null;
        Block saved86 = null;
        HudRenderEvent saved87 = null;
        int saved88 = 0;
        int saved89 = 0;
        boolean saved90 = false;
        boolean saved91 = false;
        float branchValue92 = 0.0f;
        boolean saved93 = false;
        boolean saved94 = false;
        float branchValue95 = 0.0f;
        HudRenderEvent saved96 = null;
        int saved97 = 0;
        int saved98 = 0;
        boolean saved99 = false;
        boolean saved100 = false;
        float branchValue101 = 0.0f;
        boolean saved102 = false;
        boolean saved103 = false;
        float branchValue104 = 0.0f;
        int saved105 = 0;
        Block saved106 = null;
        Block saved107 = null;
        HudRenderEvent saved108 = null;
        int saved109 = 0;
        int saved110 = 0;
        boolean saved111 = false;
        boolean saved112 = false;
        float branchValue113 = 0.0f;
        boolean saved114 = false;
        boolean saved115 = false;
        float branchValue116 = 0.0f;
        HudRenderEvent saved117 = null;
        int saved118 = 0;
        int saved119 = 0;
        boolean saved120 = false;
        boolean saved121 = false;
        float branchValue122 = 0.0f;
        boolean saved123 = false;
        boolean saved124 = false;
        float branchValue125 = 0.0f;
        int saved126 = 0;
        Block saved127 = null;
        Block saved128 = null;
        HudRenderEvent saved129 = null;
        int saved130 = 0;
        int saved131 = 0;
        boolean saved132 = false;
        boolean saved133 = false;
        float branchValue134 = 0.0f;
        boolean saved135 = false;
        boolean saved136 = false;
        float branchValue137 = 0.0f;
        HudRenderEvent saved138 = null;
        int saved139 = 0;
        int saved140 = 0;
        boolean saved141 = false;
        boolean saved142 = false;
        float branchValue143 = 0.0f;
        boolean saved144 = false;
        boolean saved145 = false;
        float branchValue146 = 0.0f;
        boolean saved147 = false;
        boolean saved148 = false;
        int saved149 = 0;
        BlockPos saved150 = null;
        int saved151 = 0;
        Block saved152 = null;
        Block saved153 = null;
        HudRenderEvent saved154 = null;
        int saved155 = 0;
        int saved156 = 0;
        boolean saved157 = false;
        boolean saved158 = false;
        float branchValue159 = 0.0f;
        boolean saved160 = false;
        boolean saved161 = false;
        float branchValue162 = 0.0f;
        HudRenderEvent saved163 = null;
        int saved164 = 0;
        int saved165 = 0;
        boolean saved166 = false;
        boolean saved167 = false;
        float branchValue168 = 0.0f;
        boolean saved169 = false;
        boolean saved170 = false;
        float branchValue171 = 0.0f;
        int saved172 = 0;
        Block saved173 = null;
        Block saved174 = null;
        HudRenderEvent saved175 = null;
        int saved176 = 0;
        int saved177 = 0;
        boolean saved178 = false;
        boolean saved179 = false;
        float branchValue180 = 0.0f;
        boolean saved181 = false;
        boolean saved182 = false;
        float branchValue183 = 0.0f;
        HudRenderEvent saved184 = null;
        int saved185 = 0;
        int saved186 = 0;
        boolean saved187 = false;
        boolean saved188 = false;
        float branchValue189 = 0.0f;
        boolean saved190 = false;
        boolean saved191 = false;
        float branchValue192 = 0.0f;
        int saved193 = 0;
        Block saved194 = null;
        Block saved195 = null;
        HudRenderEvent saved196 = null;
        int saved197 = 0;
        int saved198 = 0;
        boolean saved199 = false;
        boolean saved200 = false;
        float branchValue201 = 0.0f;
        boolean saved202 = false;
        boolean saved203 = false;
        float branchValue204 = 0.0f;
        HudRenderEvent saved205 = null;
        int saved206 = 0;
        int saved207 = 0;
        boolean saved208 = false;
        boolean saved209 = false;
        float branchValue210 = 0.0f;
        boolean saved211 = false;
        boolean saved212 = false;
        float branchValue213 = 0.0f;
        HudRenderEvent saved214 = null;
        int saved215 = 0;
        int saved216 = 0;
        boolean saved217 = false;
        boolean saved218 = false;
        float branchValue219 = 0.0f;
        boolean saved220 = false;
        boolean saved221 = false;
        float branchValue222 = 0.0f;
        saved1 = Events.mouseButton;
        if (!((event != saved1))) {
            saved2 = BedAura.mc.gui.screen();
            if (!((saved2 != null))) {
                saved3 = this.f519;
                if (!((saved3 == null))) {
                    event.setCancelled(true);
                }
            }
        }
        saved4 = Events.motion;
        if (!((event != saved4))) {
            saved5 = this.groundSpoof.getValue();
            if (saved5) {
                saved6 = this.f519;
                if (!((saved6 == null))) {
                    Events.motion.setOnGround(true);
                }
            }
        }
        saved7 = Events.rotation;
        if (!((event != saved7))) {
            this.f25 = false;
            saved8 = this.f519;
            if (!((saved8 != null))) {
                saved9 = this.f520;
                branchValue10 = (!((saved9 >= 0)) ? 255.0f : 0.0f);
            } else {
                branchValue10 = 255.0f;
            }
            floating2 = branchValue10;
            this.f522 = this.f521;
            this.f521 = ((int) Mth.lerp(0.5f, ((float) this.f521), floating2));
            saved11 = BedAura.mc.gui.screen();
            if (!((saved11 == null))) {
                this.reset();
                return;
            } else {
                saved12 = ModuleManager.killAura.f18;
                if (!((saved12 != null))) {
                    saved13 = ModuleManager.killAura.f17;
                    if (saved13) {
                        saved14 = this.allowKillAura.getValue();
                        if (saved14) {
                            saved15 = ModuleManager.scaffold.isEnabled();
                            if (saved15) {
                                this.reset();
                                return;
                            } else {
                                saved16 = this.f520;
                                if (!((saved16 >= 0))) {
                                    this.reset();
                                    return;
                                } else {
                                    reference3 = this.pm$91();
                                    if (!((reference3 == null))) {
                                        saved17 = this.f519;
                                        if (!((saved17 == null))) {
                                            reference4 = BedAura.mc.level.getBlockState(reference3);
                                            reference5 = BedAura.mc.level.getBlockState(this.f519);
                                            if (!((reference4 == reference5))) {
                                                this.reset();
                                                return;
                                            } else {
                                                if (!((reference3 == null))) {
                                                    saved18 = JvmSupport.dcmpl(BedAura.mc.player.distanceToSqr((((double) reference3.getX()) + 0.5), (((double) reference3.getY()) + 0.5), (((double) reference3.getZ()) + 0.5)), (this.range.getValue() * this.range.getValue()));
                                                    if (!((saved18 <= 0))) {
                                                        this.reset();
                                                        return;
                                                    } else {
                                                        reference4 = BedAura.mc.level.getBlockState(reference3);
                                                        saved19 = reference4.getBlock();
                                                        saved20 = Blocks.AIR;
                                                        if (!((saved19 != saved20))) {
                                                            this.reset();
                                                            return;
                                                        } else {
                                                            this.breakBed(reference3, reference4);
                                                            this.f519 = reference3;
                                                            saved21 = Events.hudRender;
                                                            if (!((event != saved21))) {
                                                                saved22 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                                if (!((saved22 > 0))) {
                                                                    saved23 = this.f521;
                                                                    if (!((saved23 <= 5))) {
                                                                        floating2 = 100.0f;
                                                                        floating3 = 4.0f;
                                                                        floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                                        floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                                        saved24 = BedAura.mc.player.onGround();
                                                                        if (!(saved24)) {
                                                                            saved25 = this.watchdogMode.getValue();
                                                                            branchValue26 = (saved25 ? 5.0f : 1.0f);
                                                                        } else {
                                                                            branchValue26 = 1.0f;
                                                                        }
                                                                        floating6 = branchValue26;
                                                                        floating7 = Events.hudRender.getPartialTick();
                                                                        floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                                        floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                                        integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                                        integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                                        integer12 = (integer10 << 24);
                                                                        integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                                        ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                                    }
                                                                } else {
                                                                    floating2 = 100.0f;
                                                                    floating3 = 4.0f;
                                                                    floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                                    floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                                    saved27 = BedAura.mc.player.onGround();
                                                                    if (!(saved27)) {
                                                                        saved28 = this.watchdogMode.getValue();
                                                                        branchValue29 = (saved28 ? 5.0f : 1.0f);
                                                                    } else {
                                                                        branchValue29 = 1.0f;
                                                                    }
                                                                    floating6 = branchValue29;
                                                                    floating7 = Events.hudRender.getPartialTick();
                                                                    floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                                    floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                                    integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                                    integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                                    integer12 = (integer10 << 24);
                                                                    integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                                    ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                                }
                                                            }
                                                            return;
                                                        }
                                                    }
                                                } else {
                                                    this.reset();
                                                    this.f519 = reference3;
                                                    saved30 = Events.hudRender;
                                                    if (!((event != saved30))) {
                                                        saved31 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                        if (!((saved31 > 0))) {
                                                            saved32 = this.f521;
                                                            if (!((saved32 <= 5))) {
                                                                floating2 = 100.0f;
                                                                floating3 = 4.0f;
                                                                floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                                floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                                saved33 = BedAura.mc.player.onGround();
                                                                if (!(saved33)) {
                                                                    saved34 = this.watchdogMode.getValue();
                                                                    branchValue35 = (saved34 ? 5.0f : 1.0f);
                                                                } else {
                                                                    branchValue35 = 1.0f;
                                                                }
                                                                floating6 = branchValue35;
                                                                floating7 = Events.hudRender.getPartialTick();
                                                                floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                                floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                                integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                                integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                                integer12 = (integer10 << 24);
                                                                integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                                ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                            }
                                                        } else {
                                                            floating2 = 100.0f;
                                                            floating3 = 4.0f;
                                                            floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                            floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                            saved36 = BedAura.mc.player.onGround();
                                                            if (!(saved36)) {
                                                                saved37 = this.watchdogMode.getValue();
                                                                branchValue38 = (saved37 ? 5.0f : 1.0f);
                                                            } else {
                                                                branchValue38 = 1.0f;
                                                            }
                                                            floating6 = branchValue38;
                                                            floating7 = Events.hudRender.getPartialTick();
                                                            floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                            floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                            integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                            integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                            integer12 = (integer10 << 24);
                                                            integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                            ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                        }
                                                    }
                                                    return;
                                                }
                                            }
                                        } else {
                                            if (!((reference3 == null))) {
                                                saved39 = JvmSupport.dcmpl(BedAura.mc.player.distanceToSqr((((double) reference3.getX()) + 0.5), (((double) reference3.getY()) + 0.5), (((double) reference3.getZ()) + 0.5)), (this.range.getValue() * this.range.getValue()));
                                                if (!((saved39 <= 0))) {
                                                    this.reset();
                                                    return;
                                                } else {
                                                    reference4 = BedAura.mc.level.getBlockState(reference3);
                                                    saved40 = reference4.getBlock();
                                                    saved41 = Blocks.AIR;
                                                    if (!((saved40 != saved41))) {
                                                        this.reset();
                                                        return;
                                                    } else {
                                                        this.breakBed(reference3, reference4);
                                                        this.f519 = reference3;
                                                        saved42 = Events.hudRender;
                                                        if (!((event != saved42))) {
                                                            saved43 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                            if (!((saved43 > 0))) {
                                                                saved44 = this.f521;
                                                                if (!((saved44 <= 5))) {
                                                                    floating2 = 100.0f;
                                                                    floating3 = 4.0f;
                                                                    floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                                    floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                                    saved45 = BedAura.mc.player.onGround();
                                                                    if (!(saved45)) {
                                                                        saved46 = this.watchdogMode.getValue();
                                                                        branchValue47 = (saved46 ? 5.0f : 1.0f);
                                                                    } else {
                                                                        branchValue47 = 1.0f;
                                                                    }
                                                                    floating6 = branchValue47;
                                                                    floating7 = Events.hudRender.getPartialTick();
                                                                    floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                                    floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                                    integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                                    integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                                    integer12 = (integer10 << 24);
                                                                    integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                                    ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                                }
                                                            } else {
                                                                floating2 = 100.0f;
                                                                floating3 = 4.0f;
                                                                floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                                floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                                saved48 = BedAura.mc.player.onGround();
                                                                if (!(saved48)) {
                                                                    saved49 = this.watchdogMode.getValue();
                                                                    branchValue50 = (saved49 ? 5.0f : 1.0f);
                                                                } else {
                                                                    branchValue50 = 1.0f;
                                                                }
                                                                floating6 = branchValue50;
                                                                floating7 = Events.hudRender.getPartialTick();
                                                                floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                                floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                                integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                                integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                                integer12 = (integer10 << 24);
                                                                integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                                ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                            }
                                                        }
                                                        return;
                                                    }
                                                }
                                            } else {
                                                this.reset();
                                                this.f519 = reference3;
                                                saved51 = Events.hudRender;
                                                if (!((event != saved51))) {
                                                    saved52 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                    if (!((saved52 > 0))) {
                                                        saved53 = this.f521;
                                                        if (!((saved53 <= 5))) {
                                                            floating2 = 100.0f;
                                                            floating3 = 4.0f;
                                                            floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                            floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                            saved54 = BedAura.mc.player.onGround();
                                                            if (!(saved54)) {
                                                                saved55 = this.watchdogMode.getValue();
                                                                branchValue56 = (saved55 ? 5.0f : 1.0f);
                                                            } else {
                                                                branchValue56 = 1.0f;
                                                            }
                                                            floating6 = branchValue56;
                                                            floating7 = Events.hudRender.getPartialTick();
                                                            floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                            floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                            integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                            integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                            integer12 = (integer10 << 24);
                                                            integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                            ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                        }
                                                    } else {
                                                        floating2 = 100.0f;
                                                        floating3 = 4.0f;
                                                        floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                        floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                        saved57 = BedAura.mc.player.onGround();
                                                        if (!(saved57)) {
                                                            saved58 = this.watchdogMode.getValue();
                                                            branchValue59 = (saved58 ? 5.0f : 1.0f);
                                                        } else {
                                                            branchValue59 = 1.0f;
                                                        }
                                                        floating6 = branchValue59;
                                                        floating7 = Events.hudRender.getPartialTick();
                                                        floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                        floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                        integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                        integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                        integer12 = (integer10 << 24);
                                                        integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                        ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                    }
                                                }
                                                return;
                                            }
                                        }
                                    } else {
                                        if (!((reference3 == null))) {
                                            saved60 = JvmSupport.dcmpl(BedAura.mc.player.distanceToSqr((((double) reference3.getX()) + 0.5), (((double) reference3.getY()) + 0.5), (((double) reference3.getZ()) + 0.5)), (this.range.getValue() * this.range.getValue()));
                                            if (!((saved60 <= 0))) {
                                                this.reset();
                                                return;
                                            } else {
                                                reference4 = BedAura.mc.level.getBlockState(reference3);
                                                saved61 = reference4.getBlock();
                                                saved62 = Blocks.AIR;
                                                if (!((saved61 != saved62))) {
                                                    this.reset();
                                                    return;
                                                } else {
                                                    this.breakBed(reference3, reference4);
                                                    this.f519 = reference3;
                                                    saved63 = Events.hudRender;
                                                    if (!((event != saved63))) {
                                                        saved64 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                        if (!((saved64 > 0))) {
                                                            saved65 = this.f521;
                                                            if (!((saved65 <= 5))) {
                                                                floating2 = 100.0f;
                                                                floating3 = 4.0f;
                                                                floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                                floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                                saved66 = BedAura.mc.player.onGround();
                                                                if (!(saved66)) {
                                                                    saved67 = this.watchdogMode.getValue();
                                                                    branchValue68 = (saved67 ? 5.0f : 1.0f);
                                                                } else {
                                                                    branchValue68 = 1.0f;
                                                                }
                                                                floating6 = branchValue68;
                                                                floating7 = Events.hudRender.getPartialTick();
                                                                floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                                floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                                integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                                integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                                integer12 = (integer10 << 24);
                                                                integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                                ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                            }
                                                        } else {
                                                            floating2 = 100.0f;
                                                            floating3 = 4.0f;
                                                            floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                            floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                            saved69 = BedAura.mc.player.onGround();
                                                            if (!(saved69)) {
                                                                saved70 = this.watchdogMode.getValue();
                                                                branchValue71 = (saved70 ? 5.0f : 1.0f);
                                                            } else {
                                                                branchValue71 = 1.0f;
                                                            }
                                                            floating6 = branchValue71;
                                                            floating7 = Events.hudRender.getPartialTick();
                                                            floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                            floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                            integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                            integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                            integer12 = (integer10 << 24);
                                                            integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                            ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                        }
                                                    }
                                                    return;
                                                }
                                            }
                                        } else {
                                            this.reset();
                                            this.f519 = reference3;
                                            saved72 = Events.hudRender;
                                            if (!((event != saved72))) {
                                                saved73 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                if (!((saved73 > 0))) {
                                                    saved74 = this.f521;
                                                    if (!((saved74 <= 5))) {
                                                        floating2 = 100.0f;
                                                        floating3 = 4.0f;
                                                        floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                        floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                        saved75 = BedAura.mc.player.onGround();
                                                        if (!(saved75)) {
                                                            saved76 = this.watchdogMode.getValue();
                                                            branchValue77 = (saved76 ? 5.0f : 1.0f);
                                                        } else {
                                                            branchValue77 = 1.0f;
                                                        }
                                                        floating6 = branchValue77;
                                                        floating7 = Events.hudRender.getPartialTick();
                                                        floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                        floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                        integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                        integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                        integer12 = (integer10 << 24);
                                                        integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                        ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                    }
                                                } else {
                                                    floating2 = 100.0f;
                                                    floating3 = 4.0f;
                                                    floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                    floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                    saved78 = BedAura.mc.player.onGround();
                                                    if (!(saved78)) {
                                                        saved79 = this.watchdogMode.getValue();
                                                        branchValue80 = (saved79 ? 5.0f : 1.0f);
                                                    } else {
                                                        branchValue80 = 1.0f;
                                                    }
                                                    floating6 = branchValue80;
                                                    floating7 = Events.hudRender.getPartialTick();
                                                    floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                    floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                    integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                    integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                    integer12 = (integer10 << 24);
                                                    integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                    ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                }
                                            }
                                            return;
                                        }
                                    }
                                }
                            }
                        } else {
                            this.reset();
                            return;
                        }
                    } else {
                        saved81 = ModuleManager.scaffold.isEnabled();
                        if (saved81) {
                            this.reset();
                            return;
                        } else {
                            saved82 = this.f520;
                            if (!((saved82 >= 0))) {
                                this.reset();
                                return;
                            } else {
                                reference3 = this.pm$91();
                                if (!((reference3 == null))) {
                                    saved83 = this.f519;
                                    if (!((saved83 == null))) {
                                        reference4 = BedAura.mc.level.getBlockState(reference3);
                                        reference5 = BedAura.mc.level.getBlockState(this.f519);
                                        if (!((reference4 == reference5))) {
                                            this.reset();
                                            return;
                                        } else {
                                            if (!((reference3 == null))) {
                                                saved84 = JvmSupport.dcmpl(BedAura.mc.player.distanceToSqr((((double) reference3.getX()) + 0.5), (((double) reference3.getY()) + 0.5), (((double) reference3.getZ()) + 0.5)), (this.range.getValue() * this.range.getValue()));
                                                if (!((saved84 <= 0))) {
                                                    this.reset();
                                                    return;
                                                } else {
                                                    reference4 = BedAura.mc.level.getBlockState(reference3);
                                                    saved85 = reference4.getBlock();
                                                    saved86 = Blocks.AIR;
                                                    if (!((saved85 != saved86))) {
                                                        this.reset();
                                                        return;
                                                    } else {
                                                        this.breakBed(reference3, reference4);
                                                        this.f519 = reference3;
                                                        saved87 = Events.hudRender;
                                                        if (!((event != saved87))) {
                                                            saved88 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                            if (!((saved88 > 0))) {
                                                                saved89 = this.f521;
                                                                if (!((saved89 <= 5))) {
                                                                    floating2 = 100.0f;
                                                                    floating3 = 4.0f;
                                                                    floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                                    floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                                    saved90 = BedAura.mc.player.onGround();
                                                                    if (!(saved90)) {
                                                                        saved91 = this.watchdogMode.getValue();
                                                                        branchValue92 = (saved91 ? 5.0f : 1.0f);
                                                                    } else {
                                                                        branchValue92 = 1.0f;
                                                                    }
                                                                    floating6 = branchValue92;
                                                                    floating7 = Events.hudRender.getPartialTick();
                                                                    floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                                    floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                                    integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                                    integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                                    integer12 = (integer10 << 24);
                                                                    integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                                    ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                                }
                                                            } else {
                                                                floating2 = 100.0f;
                                                                floating3 = 4.0f;
                                                                floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                                floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                                saved93 = BedAura.mc.player.onGround();
                                                                if (!(saved93)) {
                                                                    saved94 = this.watchdogMode.getValue();
                                                                    branchValue95 = (saved94 ? 5.0f : 1.0f);
                                                                } else {
                                                                    branchValue95 = 1.0f;
                                                                }
                                                                floating6 = branchValue95;
                                                                floating7 = Events.hudRender.getPartialTick();
                                                                floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                                floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                                integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                                integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                                integer12 = (integer10 << 24);
                                                                integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                                ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                            }
                                                        }
                                                        return;
                                                    }
                                                }
                                            } else {
                                                this.reset();
                                                this.f519 = reference3;
                                                saved96 = Events.hudRender;
                                                if (!((event != saved96))) {
                                                    saved97 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                    if (!((saved97 > 0))) {
                                                        saved98 = this.f521;
                                                        if (!((saved98 <= 5))) {
                                                            floating2 = 100.0f;
                                                            floating3 = 4.0f;
                                                            floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                            floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                            saved99 = BedAura.mc.player.onGround();
                                                            if (!(saved99)) {
                                                                saved100 = this.watchdogMode.getValue();
                                                                branchValue101 = (saved100 ? 5.0f : 1.0f);
                                                            } else {
                                                                branchValue101 = 1.0f;
                                                            }
                                                            floating6 = branchValue101;
                                                            floating7 = Events.hudRender.getPartialTick();
                                                            floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                            floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                            integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                            integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                            integer12 = (integer10 << 24);
                                                            integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                            ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                        }
                                                    } else {
                                                        floating2 = 100.0f;
                                                        floating3 = 4.0f;
                                                        floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                        floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                        saved102 = BedAura.mc.player.onGround();
                                                        if (!(saved102)) {
                                                            saved103 = this.watchdogMode.getValue();
                                                            branchValue104 = (saved103 ? 5.0f : 1.0f);
                                                        } else {
                                                            branchValue104 = 1.0f;
                                                        }
                                                        floating6 = branchValue104;
                                                        floating7 = Events.hudRender.getPartialTick();
                                                        floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                        floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                        integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                        integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                        integer12 = (integer10 << 24);
                                                        integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                        ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                    }
                                                }
                                                return;
                                            }
                                        }
                                    } else {
                                        if (!((reference3 == null))) {
                                            saved105 = JvmSupport.dcmpl(BedAura.mc.player.distanceToSqr((((double) reference3.getX()) + 0.5), (((double) reference3.getY()) + 0.5), (((double) reference3.getZ()) + 0.5)), (this.range.getValue() * this.range.getValue()));
                                            if (!((saved105 <= 0))) {
                                                this.reset();
                                                return;
                                            } else {
                                                reference4 = BedAura.mc.level.getBlockState(reference3);
                                                saved106 = reference4.getBlock();
                                                saved107 = Blocks.AIR;
                                                if (!((saved106 != saved107))) {
                                                    this.reset();
                                                    return;
                                                } else {
                                                    this.breakBed(reference3, reference4);
                                                    this.f519 = reference3;
                                                    saved108 = Events.hudRender;
                                                    if (!((event != saved108))) {
                                                        saved109 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                        if (!((saved109 > 0))) {
                                                            saved110 = this.f521;
                                                            if (!((saved110 <= 5))) {
                                                                floating2 = 100.0f;
                                                                floating3 = 4.0f;
                                                                floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                                floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                                saved111 = BedAura.mc.player.onGround();
                                                                if (!(saved111)) {
                                                                    saved112 = this.watchdogMode.getValue();
                                                                    branchValue113 = (saved112 ? 5.0f : 1.0f);
                                                                } else {
                                                                    branchValue113 = 1.0f;
                                                                }
                                                                floating6 = branchValue113;
                                                                floating7 = Events.hudRender.getPartialTick();
                                                                floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                                floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                                integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                                integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                                integer12 = (integer10 << 24);
                                                                integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                                ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                            }
                                                        } else {
                                                            floating2 = 100.0f;
                                                            floating3 = 4.0f;
                                                            floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                            floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                            saved114 = BedAura.mc.player.onGround();
                                                            if (!(saved114)) {
                                                                saved115 = this.watchdogMode.getValue();
                                                                branchValue116 = (saved115 ? 5.0f : 1.0f);
                                                            } else {
                                                                branchValue116 = 1.0f;
                                                            }
                                                            floating6 = branchValue116;
                                                            floating7 = Events.hudRender.getPartialTick();
                                                            floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                            floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                            integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                            integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                            integer12 = (integer10 << 24);
                                                            integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                            ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                        }
                                                    }
                                                    return;
                                                }
                                            }
                                        } else {
                                            this.reset();
                                            this.f519 = reference3;
                                            saved117 = Events.hudRender;
                                            if (!((event != saved117))) {
                                                saved118 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                if (!((saved118 > 0))) {
                                                    saved119 = this.f521;
                                                    if (!((saved119 <= 5))) {
                                                        floating2 = 100.0f;
                                                        floating3 = 4.0f;
                                                        floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                        floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                        saved120 = BedAura.mc.player.onGround();
                                                        if (!(saved120)) {
                                                            saved121 = this.watchdogMode.getValue();
                                                            branchValue122 = (saved121 ? 5.0f : 1.0f);
                                                        } else {
                                                            branchValue122 = 1.0f;
                                                        }
                                                        floating6 = branchValue122;
                                                        floating7 = Events.hudRender.getPartialTick();
                                                        floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                        floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                        integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                        integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                        integer12 = (integer10 << 24);
                                                        integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                        ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                    }
                                                } else {
                                                    floating2 = 100.0f;
                                                    floating3 = 4.0f;
                                                    floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                    floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                    saved123 = BedAura.mc.player.onGround();
                                                    if (!(saved123)) {
                                                        saved124 = this.watchdogMode.getValue();
                                                        branchValue125 = (saved124 ? 5.0f : 1.0f);
                                                    } else {
                                                        branchValue125 = 1.0f;
                                                    }
                                                    floating6 = branchValue125;
                                                    floating7 = Events.hudRender.getPartialTick();
                                                    floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                    floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                    integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                    integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                    integer12 = (integer10 << 24);
                                                    integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                    ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                }
                                            }
                                            return;
                                        }
                                    }
                                } else {
                                    if (!((reference3 == null))) {
                                        saved126 = JvmSupport.dcmpl(BedAura.mc.player.distanceToSqr((((double) reference3.getX()) + 0.5), (((double) reference3.getY()) + 0.5), (((double) reference3.getZ()) + 0.5)), (this.range.getValue() * this.range.getValue()));
                                        if (!((saved126 <= 0))) {
                                            this.reset();
                                            return;
                                        } else {
                                            reference4 = BedAura.mc.level.getBlockState(reference3);
                                            saved127 = reference4.getBlock();
                                            saved128 = Blocks.AIR;
                                            if (!((saved127 != saved128))) {
                                                this.reset();
                                                return;
                                            } else {
                                                this.breakBed(reference3, reference4);
                                                this.f519 = reference3;
                                                saved129 = Events.hudRender;
                                                if (!((event != saved129))) {
                                                    saved130 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                    if (!((saved130 > 0))) {
                                                        saved131 = this.f521;
                                                        if (!((saved131 <= 5))) {
                                                            floating2 = 100.0f;
                                                            floating3 = 4.0f;
                                                            floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                            floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                            saved132 = BedAura.mc.player.onGround();
                                                            if (!(saved132)) {
                                                                saved133 = this.watchdogMode.getValue();
                                                                branchValue134 = (saved133 ? 5.0f : 1.0f);
                                                            } else {
                                                                branchValue134 = 1.0f;
                                                            }
                                                            floating6 = branchValue134;
                                                            floating7 = Events.hudRender.getPartialTick();
                                                            floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                            floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                            integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                            integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                            integer12 = (integer10 << 24);
                                                            integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                            ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                        }
                                                    } else {
                                                        floating2 = 100.0f;
                                                        floating3 = 4.0f;
                                                        floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                        floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                        saved135 = BedAura.mc.player.onGround();
                                                        if (!(saved135)) {
                                                            saved136 = this.watchdogMode.getValue();
                                                            branchValue137 = (saved136 ? 5.0f : 1.0f);
                                                        } else {
                                                            branchValue137 = 1.0f;
                                                        }
                                                        floating6 = branchValue137;
                                                        floating7 = Events.hudRender.getPartialTick();
                                                        floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                        floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                        integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                        integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                        integer12 = (integer10 << 24);
                                                        integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                        ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                    }
                                                }
                                                return;
                                            }
                                        }
                                    } else {
                                        this.reset();
                                        this.f519 = reference3;
                                        saved138 = Events.hudRender;
                                        if (!((event != saved138))) {
                                            saved139 = JvmSupport.fcmpl(this.f23, 0.0f);
                                            if (!((saved139 > 0))) {
                                                saved140 = this.f521;
                                                if (!((saved140 <= 5))) {
                                                    floating2 = 100.0f;
                                                    floating3 = 4.0f;
                                                    floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                    floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                    saved141 = BedAura.mc.player.onGround();
                                                    if (!(saved141)) {
                                                        saved142 = this.watchdogMode.getValue();
                                                        branchValue143 = (saved142 ? 5.0f : 1.0f);
                                                    } else {
                                                        branchValue143 = 1.0f;
                                                    }
                                                    floating6 = branchValue143;
                                                    floating7 = Events.hudRender.getPartialTick();
                                                    floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                    floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                    integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                    integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                    integer12 = (integer10 << 24);
                                                    integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                    ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                }
                                            } else {
                                                floating2 = 100.0f;
                                                floating3 = 4.0f;
                                                floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                saved144 = BedAura.mc.player.onGround();
                                                if (!(saved144)) {
                                                    saved145 = this.watchdogMode.getValue();
                                                    branchValue146 = (saved145 ? 5.0f : 1.0f);
                                                } else {
                                                    branchValue146 = 1.0f;
                                                }
                                                floating6 = branchValue146;
                                                floating7 = Events.hudRender.getPartialTick();
                                                floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                integer12 = (integer10 << 24);
                                                integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                            }
                                        }
                                        return;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    saved147 = this.allowKillAura.getValue();
                    if (saved147) {
                        saved148 = ModuleManager.scaffold.isEnabled();
                        if (saved148) {
                            this.reset();
                            return;
                        } else {
                            saved149 = this.f520;
                            if (!((saved149 >= 0))) {
                                this.reset();
                                return;
                            } else {
                                reference3 = this.pm$91();
                                if (!((reference3 == null))) {
                                    saved150 = this.f519;
                                    if (!((saved150 == null))) {
                                        reference4 = BedAura.mc.level.getBlockState(reference3);
                                        reference5 = BedAura.mc.level.getBlockState(this.f519);
                                        if (!((reference4 == reference5))) {
                                            this.reset();
                                            return;
                                        } else {
                                            if (!((reference3 == null))) {
                                                saved151 = JvmSupport.dcmpl(BedAura.mc.player.distanceToSqr((((double) reference3.getX()) + 0.5), (((double) reference3.getY()) + 0.5), (((double) reference3.getZ()) + 0.5)), (this.range.getValue() * this.range.getValue()));
                                                if (!((saved151 <= 0))) {
                                                    this.reset();
                                                    return;
                                                } else {
                                                    reference4 = BedAura.mc.level.getBlockState(reference3);
                                                    saved152 = reference4.getBlock();
                                                    saved153 = Blocks.AIR;
                                                    if (!((saved152 != saved153))) {
                                                        this.reset();
                                                        return;
                                                    } else {
                                                        this.breakBed(reference3, reference4);
                                                        this.f519 = reference3;
                                                        saved154 = Events.hudRender;
                                                        if (!((event != saved154))) {
                                                            saved155 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                            if (!((saved155 > 0))) {
                                                                saved156 = this.f521;
                                                                if (!((saved156 <= 5))) {
                                                                    floating2 = 100.0f;
                                                                    floating3 = 4.0f;
                                                                    floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                                    floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                                    saved157 = BedAura.mc.player.onGround();
                                                                    if (!(saved157)) {
                                                                        saved158 = this.watchdogMode.getValue();
                                                                        branchValue159 = (saved158 ? 5.0f : 1.0f);
                                                                    } else {
                                                                        branchValue159 = 1.0f;
                                                                    }
                                                                    floating6 = branchValue159;
                                                                    floating7 = Events.hudRender.getPartialTick();
                                                                    floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                                    floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                                    integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                                    integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                                    integer12 = (integer10 << 24);
                                                                    integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                                    ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                                }
                                                            } else {
                                                                floating2 = 100.0f;
                                                                floating3 = 4.0f;
                                                                floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                                floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                                saved160 = BedAura.mc.player.onGround();
                                                                if (!(saved160)) {
                                                                    saved161 = this.watchdogMode.getValue();
                                                                    branchValue162 = (saved161 ? 5.0f : 1.0f);
                                                                } else {
                                                                    branchValue162 = 1.0f;
                                                                }
                                                                floating6 = branchValue162;
                                                                floating7 = Events.hudRender.getPartialTick();
                                                                floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                                floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                                integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                                integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                                integer12 = (integer10 << 24);
                                                                integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                                ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                            }
                                                        }
                                                        return;
                                                    }
                                                }
                                            } else {
                                                this.reset();
                                                this.f519 = reference3;
                                                saved163 = Events.hudRender;
                                                if (!((event != saved163))) {
                                                    saved164 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                    if (!((saved164 > 0))) {
                                                        saved165 = this.f521;
                                                        if (!((saved165 <= 5))) {
                                                            floating2 = 100.0f;
                                                            floating3 = 4.0f;
                                                            floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                            floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                            saved166 = BedAura.mc.player.onGround();
                                                            if (!(saved166)) {
                                                                saved167 = this.watchdogMode.getValue();
                                                                branchValue168 = (saved167 ? 5.0f : 1.0f);
                                                            } else {
                                                                branchValue168 = 1.0f;
                                                            }
                                                            floating6 = branchValue168;
                                                            floating7 = Events.hudRender.getPartialTick();
                                                            floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                            floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                            integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                            integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                            integer12 = (integer10 << 24);
                                                            integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                            ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                        }
                                                    } else {
                                                        floating2 = 100.0f;
                                                        floating3 = 4.0f;
                                                        floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                        floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                        saved169 = BedAura.mc.player.onGround();
                                                        if (!(saved169)) {
                                                            saved170 = this.watchdogMode.getValue();
                                                            branchValue171 = (saved170 ? 5.0f : 1.0f);
                                                        } else {
                                                            branchValue171 = 1.0f;
                                                        }
                                                        floating6 = branchValue171;
                                                        floating7 = Events.hudRender.getPartialTick();
                                                        floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                        floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                        integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                        integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                        integer12 = (integer10 << 24);
                                                        integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                        ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                    }
                                                }
                                                return;
                                            }
                                        }
                                    } else {
                                        if (!((reference3 == null))) {
                                            saved172 = JvmSupport.dcmpl(BedAura.mc.player.distanceToSqr((((double) reference3.getX()) + 0.5), (((double) reference3.getY()) + 0.5), (((double) reference3.getZ()) + 0.5)), (this.range.getValue() * this.range.getValue()));
                                            if (!((saved172 <= 0))) {
                                                this.reset();
                                                return;
                                            } else {
                                                reference4 = BedAura.mc.level.getBlockState(reference3);
                                                saved173 = reference4.getBlock();
                                                saved174 = Blocks.AIR;
                                                if (!((saved173 != saved174))) {
                                                    this.reset();
                                                    return;
                                                } else {
                                                    this.breakBed(reference3, reference4);
                                                    this.f519 = reference3;
                                                    saved175 = Events.hudRender;
                                                    if (!((event != saved175))) {
                                                        saved176 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                        if (!((saved176 > 0))) {
                                                            saved177 = this.f521;
                                                            if (!((saved177 <= 5))) {
                                                                floating2 = 100.0f;
                                                                floating3 = 4.0f;
                                                                floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                                floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                                saved178 = BedAura.mc.player.onGround();
                                                                if (!(saved178)) {
                                                                    saved179 = this.watchdogMode.getValue();
                                                                    branchValue180 = (saved179 ? 5.0f : 1.0f);
                                                                } else {
                                                                    branchValue180 = 1.0f;
                                                                }
                                                                floating6 = branchValue180;
                                                                floating7 = Events.hudRender.getPartialTick();
                                                                floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                                floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                                integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                                integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                                integer12 = (integer10 << 24);
                                                                integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                                ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                            }
                                                        } else {
                                                            floating2 = 100.0f;
                                                            floating3 = 4.0f;
                                                            floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                            floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                            saved181 = BedAura.mc.player.onGround();
                                                            if (!(saved181)) {
                                                                saved182 = this.watchdogMode.getValue();
                                                                branchValue183 = (saved182 ? 5.0f : 1.0f);
                                                            } else {
                                                                branchValue183 = 1.0f;
                                                            }
                                                            floating6 = branchValue183;
                                                            floating7 = Events.hudRender.getPartialTick();
                                                            floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                            floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                            integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                            integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                            integer12 = (integer10 << 24);
                                                            integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                            ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                        }
                                                    }
                                                    return;
                                                }
                                            }
                                        } else {
                                            this.reset();
                                            this.f519 = reference3;
                                            saved184 = Events.hudRender;
                                            if (!((event != saved184))) {
                                                saved185 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                if (!((saved185 > 0))) {
                                                    saved186 = this.f521;
                                                    if (!((saved186 <= 5))) {
                                                        floating2 = 100.0f;
                                                        floating3 = 4.0f;
                                                        floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                        floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                        saved187 = BedAura.mc.player.onGround();
                                                        if (!(saved187)) {
                                                            saved188 = this.watchdogMode.getValue();
                                                            branchValue189 = (saved188 ? 5.0f : 1.0f);
                                                        } else {
                                                            branchValue189 = 1.0f;
                                                        }
                                                        floating6 = branchValue189;
                                                        floating7 = Events.hudRender.getPartialTick();
                                                        floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                        floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                        integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                        integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                        integer12 = (integer10 << 24);
                                                        integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                        ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                    }
                                                } else {
                                                    floating2 = 100.0f;
                                                    floating3 = 4.0f;
                                                    floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                    floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                    saved190 = BedAura.mc.player.onGround();
                                                    if (!(saved190)) {
                                                        saved191 = this.watchdogMode.getValue();
                                                        branchValue192 = (saved191 ? 5.0f : 1.0f);
                                                    } else {
                                                        branchValue192 = 1.0f;
                                                    }
                                                    floating6 = branchValue192;
                                                    floating7 = Events.hudRender.getPartialTick();
                                                    floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                    floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                    integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                    integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                    integer12 = (integer10 << 24);
                                                    integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                    ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                }
                                            }
                                            return;
                                        }
                                    }
                                } else {
                                    if (!((reference3 == null))) {
                                        saved193 = JvmSupport.dcmpl(BedAura.mc.player.distanceToSqr((((double) reference3.getX()) + 0.5), (((double) reference3.getY()) + 0.5), (((double) reference3.getZ()) + 0.5)), (this.range.getValue() * this.range.getValue()));
                                        if (!((saved193 <= 0))) {
                                            this.reset();
                                            return;
                                        } else {
                                            reference4 = BedAura.mc.level.getBlockState(reference3);
                                            saved194 = reference4.getBlock();
                                            saved195 = Blocks.AIR;
                                            if (!((saved194 != saved195))) {
                                                this.reset();
                                                return;
                                            } else {
                                                this.breakBed(reference3, reference4);
                                                this.f519 = reference3;
                                                saved196 = Events.hudRender;
                                                if (!((event != saved196))) {
                                                    saved197 = JvmSupport.fcmpl(this.f23, 0.0f);
                                                    if (!((saved197 > 0))) {
                                                        saved198 = this.f521;
                                                        if (!((saved198 <= 5))) {
                                                            floating2 = 100.0f;
                                                            floating3 = 4.0f;
                                                            floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                            floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                            saved199 = BedAura.mc.player.onGround();
                                                            if (!(saved199)) {
                                                                saved200 = this.watchdogMode.getValue();
                                                                branchValue201 = (saved200 ? 5.0f : 1.0f);
                                                            } else {
                                                                branchValue201 = 1.0f;
                                                            }
                                                            floating6 = branchValue201;
                                                            floating7 = Events.hudRender.getPartialTick();
                                                            floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                            floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                            integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                            integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                            integer12 = (integer10 << 24);
                                                            integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                            ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                        }
                                                    } else {
                                                        floating2 = 100.0f;
                                                        floating3 = 4.0f;
                                                        floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                        floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                        saved202 = BedAura.mc.player.onGround();
                                                        if (!(saved202)) {
                                                            saved203 = this.watchdogMode.getValue();
                                                            branchValue204 = (saved203 ? 5.0f : 1.0f);
                                                        } else {
                                                            branchValue204 = 1.0f;
                                                        }
                                                        floating6 = branchValue204;
                                                        floating7 = Events.hudRender.getPartialTick();
                                                        floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                        floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                        integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                        integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                        integer12 = (integer10 << 24);
                                                        integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                        ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                    }
                                                }
                                                return;
                                            }
                                        }
                                    } else {
                                        this.reset();
                                        this.f519 = reference3;
                                        saved205 = Events.hudRender;
                                        if (!((event != saved205))) {
                                            saved206 = JvmSupport.fcmpl(this.f23, 0.0f);
                                            if (!((saved206 > 0))) {
                                                saved207 = this.f521;
                                                if (!((saved207 <= 5))) {
                                                    floating2 = 100.0f;
                                                    floating3 = 4.0f;
                                                    floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                    floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                    saved208 = BedAura.mc.player.onGround();
                                                    if (!(saved208)) {
                                                        saved209 = this.watchdogMode.getValue();
                                                        branchValue210 = (saved209 ? 5.0f : 1.0f);
                                                    } else {
                                                        branchValue210 = 1.0f;
                                                    }
                                                    floating6 = branchValue210;
                                                    floating7 = Events.hudRender.getPartialTick();
                                                    floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                    floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                    integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                    integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                    integer12 = (integer10 << 24);
                                                    integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                    ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                                }
                                            } else {
                                                floating2 = 100.0f;
                                                floating3 = 4.0f;
                                                floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                                                floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                                                saved211 = BedAura.mc.player.onGround();
                                                if (!(saved211)) {
                                                    saved212 = this.watchdogMode.getValue();
                                                    branchValue213 = (saved212 ? 5.0f : 1.0f);
                                                } else {
                                                    branchValue213 = 1.0f;
                                                }
                                                floating6 = branchValue213;
                                                floating7 = Events.hudRender.getPartialTick();
                                                floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                                                floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                                                integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                                                integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                                                integer12 = (integer10 << 24);
                                                integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                                                ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                                            }
                                        }
                                        return;
                                    }
                                }
                            }
                        }
                    } else {
                        this.reset();
                        return;
                    }
                }
            }
        } else {
            saved214 = Events.hudRender;
            if (!((event != saved214))) {
                saved215 = JvmSupport.fcmpl(this.f23, 0.0f);
                if (!((saved215 > 0))) {
                    saved216 = this.f521;
                    if (!((saved216 <= 5))) {
                        floating2 = 100.0f;
                        floating3 = 4.0f;
                        floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                        floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                        saved217 = BedAura.mc.player.onGround();
                        if (!(saved217)) {
                            saved218 = this.watchdogMode.getValue();
                            branchValue219 = (saved218 ? 5.0f : 1.0f);
                        } else {
                            branchValue219 = 1.0f;
                        }
                        floating6 = branchValue219;
                        floating7 = Events.hudRender.getPartialTick();
                        floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                        floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                        integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                        integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                        integer12 = (integer10 << 24);
                        integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                        ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                    }
                } else {
                    floating2 = 100.0f;
                    floating3 = 4.0f;
                    floating4 = ((((float) BedAura.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                    floating5 = ((((float) BedAura.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                    saved220 = BedAura.mc.player.onGround();
                    if (!(saved220)) {
                        saved221 = this.watchdogMode.getValue();
                        branchValue222 = (saved221 ? 5.0f : 1.0f);
                    } else {
                        branchValue222 = 1.0f;
                    }
                    floating6 = branchValue222;
                    floating7 = Events.hudRender.getPartialTick();
                    floating8 = (this.f517 + ((this.f23 - this.f517) * floating7));
                    floating9 = ((float) Math.min(((double) (floating8 / floating6)), 1.0));
                    integer10 = ((int) (((float) this.f522) + (((float) (this.f521 - this.f522)) * floating7)));
                    integer11 = ((Recovered_eg.m31() & 16777215) | (integer10 << 24));
                    integer12 = (integer10 << 24);
                    integer13 = ((((int) (((float) integer10) * 0.5f)) << 24) | 6316128);
                    ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), ((double) floating9), integer12, integer13, integer11);
                }
            }
            return;
        }
    }

    public void onDisable() {
        this.f25 = false;
    }

    private void reset() {
        int saved1 = 0;
        BlockPos saved2 = null;
        Direction reference1 = null;
        MultiPlayerGameModeMixin saved4 = null;
        ClientLevel saved5 = null;
        int saved7 = 0;
        int saved8 = 0;
        saved1 = JvmSupport.fcmpl(this.f23, 0.0f);
        if (!((saved1 <= 0))) {
            saved2 = this.f24;
            if (!((saved2 == null))) {
                reference1 = this.pm$94(Events.rotation.getYaw(), Events.rotation.getPitch());
                saved4 = ((MultiPlayerGameModeMixin) (Object) BedAura.mc.gameMode);
                saved5 = BedAura.mc.level;
                final BedAura captured3 = this;
                final Direction captured6 = reference1;
                saved4.invokeStartPrediction(saved5, (lambdaArg0) -> captured3.resetCallback0(captured6, lambdaArg0));
                BedAura.mc.level.destroyBlockProgress(BedAura.mc.player.getId(), this.f24, -1);
                this.f24 = null;
            }
        }
        this.f517 = this.f23;
        this.f23 = 0.0f;
        saved7 = this.f518;
        if (!((saved7 == -1))) {
            BedAura.mc.player.getInventory().setSelectedSlot(this.f518);
            this.f518 = -1;
        }
        saved8 = this.f520;
        if (!((saved8 >= 0))) {
            this.f520 = (this.f520 + 1);
        }
        this.f26 = 0;
        this.f519 = null;
    }

    public BedAura() {
        super(BedAura.TEXT_BEDAURA, Category.PLAYER);
        this.range = new NumberSetting(BedAura.TEXT_RANGE, this, 5.0, 1.0, 8.0, 0.5);
        this.speed = new NumberSetting(BedAura.TEXT_SPEED, this, 1.0, 1.0, 2.0, 0.05);
        this.breakDelay = new NumberSetting(BedAura.TEXT_BREAK_DELAY, this, 2.0, 1.0, 4.0, 1.0);
        this.surrounding = new BooleanSetting(BedAura.TEXT_SURROUNDING, this, false);
        this.allowKillAura = new BooleanSetting(BedAura.TEXT_ALLOW_KILLAURA, this, false);
        this.onlySSRotate = new BooleanSetting(BedAura.TEXT_ONLY_S_S_ROTATE, this, false);
        this.watchdogMode = new BooleanSetting(BedAura.TEXT_WATCHDOG_MODE, this, false);
        this.silentSwing = new BooleanSetting(BedAura.TEXT_SILENT_SWING, this, false);
        this.groundSpoof = new BooleanSetting(BedAura.TEXT_GROUND_SPOOF, this, false);
        this.f518 = -1;
        this.f523 = new BlockPos.MutableBlockPos();
    }

    private Direction pm$94(float arg0, float arg1) {
        Vec3 reference3 = null;
        double number4 = 0.0;
        double number6 = 0.0;
        double number8 = 0.0;
        int saved1 = 0;
        int saved2 = 0;
        int saved3 = 0;
        Direction reference0 = null;
        int saved4 = 0;
        int saved5 = 0;
        int saved6 = 0;
        int saved7 = 0;
        int saved8 = 0;
        int saved9 = 0;
        reference3 = Vec3.directionFromRotation(arg1, arg0);
        number4 = Math.abs(reference3.x);
        number6 = Math.abs(reference3.y);
        number8 = Math.abs(reference3.z);
        saved1 = JvmSupport.dcmpl(number6, number4);
        if (!((saved1 <= 0))) {
            saved2 = JvmSupport.dcmpl(number6, number8);
            if (!((saved2 <= 0))) {
                saved3 = JvmSupport.dcmpl(reference3.y, 0.0);
                reference0 = (!((saved3 <= 0)) ? Direction.DOWN : Direction.UP);
                return reference0;
            } else {
                saved4 = JvmSupport.dcmpl(number4, number8);
                if (!((saved4 <= 0))) {
                    saved5 = JvmSupport.dcmpl(reference3.x, 0.0);
                    reference0 = (!((saved5 <= 0)) ? Direction.WEST : Direction.EAST);
                    return reference0;
                } else {
                    saved6 = JvmSupport.dcmpl(reference3.z, 0.0);
                    reference0 = (!((saved6 <= 0)) ? Direction.NORTH : Direction.SOUTH);
                    return reference0;
                }
            }
        } else {
            saved7 = JvmSupport.dcmpl(number4, number8);
            if (!((saved7 <= 0))) {
                saved8 = JvmSupport.dcmpl(reference3.x, 0.0);
                reference0 = (!((saved8 <= 0)) ? Direction.WEST : Direction.EAST);
                return reference0;
            } else {
                saved9 = JvmSupport.dcmpl(reference3.z, 0.0);
                reference0 = (!((saved9 <= 0)) ? Direction.NORTH : Direction.SOUTH);
                return reference0;
            }
        }
    }

    private BlockPos pm$91() {
        boolean saved1 = false;
        Object reference0 = this;
        Vec3 reference1 = null;
        boolean saved2 = false;
        int saved3 = 0;
        BlockPos saved4 = null;
        boolean saved5 = false;
        BlockPos reference2 = null;
        int integer3 = 0;
        int integer4 = 0;
        int integer5 = 0;
        int integer6 = 0;
        int integer7 = 0;
        int saved6 = 0;
        int integer8 = 0;
        int saved7 = 0;
        int integer9 = 0;
        int saved8 = 0;
        BlockState reference10 = null;
        boolean saved9 = false;
        int saved10 = 0;
        int saved11 = 0;
        int saved12 = 0;
        boolean saved13 = false;
        BlockPos saved14 = null;
        boolean saved15 = false;
        int saved16 = 0;
        int saved17 = 0;
        int saved18 = 0;
        boolean saved19 = false;
        int saved20 = 0;
        int saved21 = 0;
        int saved22 = 0;
        boolean saved23 = false;
        BlockPos saved24 = null;
        boolean saved25 = false;
        int saved26 = 0;
        int saved27 = 0;
        int saved28 = 0;
        boolean saved29 = false;
        int saved30 = 0;
        int saved31 = 0;
        int saved32 = 0;
        boolean saved33 = false;
        saved1 = BedAura.mc.player.isUsingItem();
        if (saved1) {
            reference0 = null;
            return ((BlockPos) reference0);
        } else {
            reference1 = ModuleManager.whitelist.f21;
            if (!((reference1 == null))) {
                saved2 = ModuleManager.whitelist.f20;
                if (saved2) {
                    saved3 = JvmSupport.dcmpg(BedAura.mc.player.distanceToSqr(reference1), 600.0);
                    if (!((saved3 >= 0))) {
                        reference0 = null;
                        return ((BlockPos) reference0);
                    } else {
                        saved4 = ((BedAura) reference0).f519;
                        if (!((saved4 == null))) {
                            saved5 = (BedAura.mc.level.getBlockState(((BedAura) reference0).f519).getBlock() instanceof BedBlock);
                            if (saved5) {
                                reference0 = ((BedAura) reference0).f519;
                                return ((BlockPos) reference0);
                            } else {
                                reference2 = BedAura.mc.player.blockPosition();
                                integer3 = reference2.getX();
                                integer4 = reference2.getY();
                                integer5 = reference2.getZ();
                                integer6 = ((int) ((BedAura) reference0).range.getValue());
                                integer7 = (integer3 - integer6);
                                loop65: while (true) {
                                    saved6 = (integer3 + integer6);
                                    if ((integer7 > saved6)) {
                                        break loop65;
                                    }
                                    integer8 = (integer4 - integer6);
                                    loop74: while (true) {
                                        saved7 = (integer4 + integer6);
                                        if ((integer8 > saved7)) {
                                            break loop74;
                                        }
                                        integer9 = (integer5 - integer6);
                                        loop83: while (true) {
                                            saved8 = (integer5 + integer6);
                                            if ((integer9 > saved8)) {
                                                break loop83;
                                            }
                                            ((BedAura) reference0).f523.set(integer7, integer8, integer9);
                                            reference10 = BedAura.mc.level.getBlockState(((BlockPos) (Object) ((BedAura) reference0).f523));
                                            saved9 = (reference10.getBlock() instanceof BedBlock);
                                            if (saved9) {
                                                reference0 = new BlockPos(((Vec3i) (Object) ((BedAura) reference0).f523));
                                                return ((BlockPos) reference0);
                                            }
                                            integer9++;
                                            continue loop83;
                                        }
                                        integer8++;
                                        continue loop74;
                                    }
                                    integer7++;
                                    continue loop65;
                                }
                                reference0 = null;
                                return ((BlockPos) reference0);
                            }
                        } else {
                            reference2 = BedAura.mc.player.blockPosition();
                            integer3 = reference2.getX();
                            integer4 = reference2.getY();
                            integer5 = reference2.getZ();
                            integer6 = ((int) ((BedAura) reference0).range.getValue());
                            integer7 = (integer3 - integer6);
                            loop65: while (true) {
                                saved10 = (integer3 + integer6);
                                if ((integer7 > saved10)) {
                                    break loop65;
                                }
                                integer8 = (integer4 - integer6);
                                loop74: while (true) {
                                    saved11 = (integer4 + integer6);
                                    if ((integer8 > saved11)) {
                                        break loop74;
                                    }
                                    integer9 = (integer5 - integer6);
                                    loop83: while (true) {
                                        saved12 = (integer5 + integer6);
                                        if ((integer9 > saved12)) {
                                            break loop83;
                                        }
                                        ((BedAura) reference0).f523.set(integer7, integer8, integer9);
                                        reference10 = BedAura.mc.level.getBlockState(((BlockPos) (Object) ((BedAura) reference0).f523));
                                        saved13 = (reference10.getBlock() instanceof BedBlock);
                                        if (saved13) {
                                            reference0 = new BlockPos(((Vec3i) (Object) ((BedAura) reference0).f523));
                                            return ((BlockPos) reference0);
                                        }
                                        integer9++;
                                        continue loop83;
                                    }
                                    integer8++;
                                    continue loop74;
                                }
                                integer7++;
                                continue loop65;
                            }
                            reference0 = null;
                            return ((BlockPos) reference0);
                        }
                    }
                } else {
                    saved14 = ((BedAura) reference0).f519;
                    if (!((saved14 == null))) {
                        saved15 = (BedAura.mc.level.getBlockState(((BedAura) reference0).f519).getBlock() instanceof BedBlock);
                        if (saved15) {
                            reference0 = ((BedAura) reference0).f519;
                            return ((BlockPos) reference0);
                        } else {
                            reference2 = BedAura.mc.player.blockPosition();
                            integer3 = reference2.getX();
                            integer4 = reference2.getY();
                            integer5 = reference2.getZ();
                            integer6 = ((int) ((BedAura) reference0).range.getValue());
                            integer7 = (integer3 - integer6);
                            loop65: while (true) {
                                saved16 = (integer3 + integer6);
                                if ((integer7 > saved16)) {
                                    break loop65;
                                }
                                integer8 = (integer4 - integer6);
                                loop74: while (true) {
                                    saved17 = (integer4 + integer6);
                                    if ((integer8 > saved17)) {
                                        break loop74;
                                    }
                                    integer9 = (integer5 - integer6);
                                    loop83: while (true) {
                                        saved18 = (integer5 + integer6);
                                        if ((integer9 > saved18)) {
                                            break loop83;
                                        }
                                        ((BedAura) reference0).f523.set(integer7, integer8, integer9);
                                        reference10 = BedAura.mc.level.getBlockState(((BlockPos) (Object) ((BedAura) reference0).f523));
                                        saved19 = (reference10.getBlock() instanceof BedBlock);
                                        if (saved19) {
                                            reference0 = new BlockPos(((Vec3i) (Object) ((BedAura) reference0).f523));
                                            return ((BlockPos) reference0);
                                        }
                                        integer9++;
                                        continue loop83;
                                    }
                                    integer8++;
                                    continue loop74;
                                }
                                integer7++;
                                continue loop65;
                            }
                            reference0 = null;
                            return ((BlockPos) reference0);
                        }
                    } else {
                        reference2 = BedAura.mc.player.blockPosition();
                        integer3 = reference2.getX();
                        integer4 = reference2.getY();
                        integer5 = reference2.getZ();
                        integer6 = ((int) ((BedAura) reference0).range.getValue());
                        integer7 = (integer3 - integer6);
                        loop65: while (true) {
                            saved20 = (integer3 + integer6);
                            if ((integer7 > saved20)) {
                                break loop65;
                            }
                            integer8 = (integer4 - integer6);
                            loop74: while (true) {
                                saved21 = (integer4 + integer6);
                                if ((integer8 > saved21)) {
                                    break loop74;
                                }
                                integer9 = (integer5 - integer6);
                                loop83: while (true) {
                                    saved22 = (integer5 + integer6);
                                    if ((integer9 > saved22)) {
                                        break loop83;
                                    }
                                    ((BedAura) reference0).f523.set(integer7, integer8, integer9);
                                    reference10 = BedAura.mc.level.getBlockState(((BlockPos) (Object) ((BedAura) reference0).f523));
                                    saved23 = (reference10.getBlock() instanceof BedBlock);
                                    if (saved23) {
                                        reference0 = new BlockPos(((Vec3i) (Object) ((BedAura) reference0).f523));
                                        return ((BlockPos) reference0);
                                    }
                                    integer9++;
                                    continue loop83;
                                }
                                integer8++;
                                continue loop74;
                            }
                            integer7++;
                            continue loop65;
                        }
                        reference0 = null;
                        return ((BlockPos) reference0);
                    }
                }
            } else {
                saved24 = ((BedAura) reference0).f519;
                if (!((saved24 == null))) {
                    saved25 = (BedAura.mc.level.getBlockState(((BedAura) reference0).f519).getBlock() instanceof BedBlock);
                    if (saved25) {
                        reference0 = ((BedAura) reference0).f519;
                        return ((BlockPos) reference0);
                    } else {
                        reference2 = BedAura.mc.player.blockPosition();
                        integer3 = reference2.getX();
                        integer4 = reference2.getY();
                        integer5 = reference2.getZ();
                        integer6 = ((int) ((BedAura) reference0).range.getValue());
                        integer7 = (integer3 - integer6);
                        loop65: while (true) {
                            saved26 = (integer3 + integer6);
                            if ((integer7 > saved26)) {
                                break loop65;
                            }
                            integer8 = (integer4 - integer6);
                            loop74: while (true) {
                                saved27 = (integer4 + integer6);
                                if ((integer8 > saved27)) {
                                    break loop74;
                                }
                                integer9 = (integer5 - integer6);
                                loop83: while (true) {
                                    saved28 = (integer5 + integer6);
                                    if ((integer9 > saved28)) {
                                        break loop83;
                                    }
                                    ((BedAura) reference0).f523.set(integer7, integer8, integer9);
                                    reference10 = BedAura.mc.level.getBlockState(((BlockPos) (Object) ((BedAura) reference0).f523));
                                    saved29 = (reference10.getBlock() instanceof BedBlock);
                                    if (saved29) {
                                        reference0 = new BlockPos(((Vec3i) (Object) ((BedAura) reference0).f523));
                                        return ((BlockPos) reference0);
                                    }
                                    integer9++;
                                    continue loop83;
                                }
                                integer8++;
                                continue loop74;
                            }
                            integer7++;
                            continue loop65;
                        }
                        reference0 = null;
                        return ((BlockPos) reference0);
                    }
                } else {
                    reference2 = BedAura.mc.player.blockPosition();
                    integer3 = reference2.getX();
                    integer4 = reference2.getY();
                    integer5 = reference2.getZ();
                    integer6 = ((int) ((BedAura) reference0).range.getValue());
                    integer7 = (integer3 - integer6);
                    loop65: while (true) {
                        saved30 = (integer3 + integer6);
                        if ((integer7 > saved30)) {
                            break loop65;
                        }
                        integer8 = (integer4 - integer6);
                        loop74: while (true) {
                            saved31 = (integer4 + integer6);
                            if ((integer8 > saved31)) {
                                break loop74;
                            }
                            integer9 = (integer5 - integer6);
                            loop83: while (true) {
                                saved32 = (integer5 + integer6);
                                if ((integer9 > saved32)) {
                                    break loop83;
                                }
                                ((BedAura) reference0).f523.set(integer7, integer8, integer9);
                                reference10 = BedAura.mc.level.getBlockState(((BlockPos) (Object) ((BedAura) reference0).f523));
                                saved33 = (reference10.getBlock() instanceof BedBlock);
                                if (saved33) {
                                    reference0 = new BlockPos(((Vec3i) (Object) ((BedAura) reference0).f523));
                                    return ((BlockPos) reference0);
                                }
                                integer9++;
                                continue loop83;
                            }
                            integer8++;
                            continue loop74;
                        }
                        integer7++;
                        continue loop65;
                    }
                    reference0 = null;
                    return ((BlockPos) reference0);
                }
            }
        }
    }

    private void pm$95() {
        boolean saved1 = false;
        saved1 = this.silentSwing.getValue();
        if (saved1) {
            BedAura.mc.getConnection().send(((Packet) (Object) new ServerboundSwingPacket(InteractionHand.MAIN_HAND)));
        } else {
            BedAura.mc.player.swing(InteractionHand.MAIN_HAND);
        }
    }

    private static Packet breakBedCallback1(BlockPos arg0, Direction arg1, int arg2) {
        Object reference0 = arg0;
        reference0 = new ServerboundPlayerActionPacket(ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, ((BlockPos) reference0), arg1, arg2);
        return ((Packet) reference0);
    }

    private static Packet breakBedCallback2(BlockPos arg0, Direction arg1, int arg2) {
        Object reference0 = arg0;
        reference0 = new ServerboundPlayerActionPacket(ServerboundPlayerActionPacket.Action.STOP_DESTROY_BLOCK, ((BlockPos) reference0), arg1, arg2);
        return ((Packet) reference0);
    }
}
