package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.PacketReceiveEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.NumberSetting;
import cryptix.util.QueuedPacket;
import cryptix.util.TargetingUtils;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.PacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.common.ClientboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ClientboundPingPacket;
import net.minecraft.network.protocol.game.ClientboundStartConfigurationPacket;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Reconstructed from a/lk.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Backtrack extends Module {
    private boolean f495;
    private int f497;
    private static final String TEXT_TICKS;
    private Vec3 f496;
    private final NumberSetting ticks;
    private final NumberSetting range;
    private final Queue f494;
    private static final String TEXT_BACKTRACK;
    private static final String TEXT_RANGE;

    private void pm$90() {
        boolean saved1 = false;
        QueuedPacket reference1 = null;
        loop0: while (true) {
            saved1 = this.f494.isEmpty();
            if (saved1) {
                break loop0;
            }
            reference1 = ((QueuedPacket) this.f494.peek());
            this.f494.poll();
            reference1.packet.handle(((PacketListener) (Object) Backtrack.mc.getConnection()));
            continue loop0;
        }
    }

    public Backtrack() {
        super(Backtrack.TEXT_BACKTRACK, Category.PLAYER);
        this.range = new NumberSetting(Backtrack.TEXT_RANGE, this, 6.0, 4.0, 8.0, 0.5);
        this.ticks = new NumberSetting(Backtrack.TEXT_TICKS, this, 2.0, 1.0, 10.0, 1.0);
        this.f494 = ((Queue) (Object) new ConcurrentLinkedQueue());
    }

    public void onEvent(Event event) {
        PacketReceiveEvent saved1 = null;
        Object reference2 = null;
        Object reference3 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        boolean saved4 = false;
        boolean saved5 = false;
        boolean saved6 = false;
        ClientLevel saved7 = null;
        ClientLevel saved8 = null;
        RotationEvent saved9 = null;
        boolean saved10 = false;
        int saved11 = 0;
        int saved12 = 0;
        RotationEvent saved13 = null;
        boolean saved14 = false;
        int saved15 = 0;
        int saved16 = 0;
        saved1 = Events.packetReceive;
        if (!((event != saved1))) {
            reference2 = ((PacketReceiveEvent) (Object) event);
            reference3 = ((PacketReceiveEvent) reference2).getPacket();
            saved2 = (reference3 instanceof ClientboundStartConfigurationPacket);
            if (!(saved2)) {
                saved3 = (reference3 instanceof ClientboundDisconnectPacket);
                if (saved3) {
                    this.pm$90();
                    return;
                } else {
                    saved4 = this.f495;
                    if (saved4) {
                        saved5 = (reference3 instanceof ClientboundPingPacket);
                        if (!(saved5)) {
                            saved6 = (reference3 instanceof ClientboundKeepAlivePacket);
                            if (saved6) {
                                saved7 = Backtrack.mc.level;
                                if (!((saved7 == null))) {
                                    ((PacketReceiveEvent) reference2).setCancelled(true);
                                    this.f494.add(new QueuedPacket(((Packet) reference3), Backtrack.mc.level.getGameTime()));
                                }
                            }
                        } else {
                            saved8 = Backtrack.mc.level;
                            if (!((saved8 == null))) {
                                ((PacketReceiveEvent) reference2).setCancelled(true);
                                this.f494.add(new QueuedPacket(((Packet) reference3), Backtrack.mc.level.getGameTime()));
                            }
                        }
                    }
                    saved9 = Events.rotation;
                    if (!((event != saved9))) {
                        reference2 = TargetingUtils.findTarget(this.range.getValue(), true);
                        if (!((reference2 == null))) {
                            reference3 = ((LivingEntity) reference2).position();
                            saved10 = this.f495;
                            if (!(saved10)) {
                                this.f496 = new Vec3(((Vec3) reference3).x, ((Vec3) reference3).y, ((Vec3) reference3).z);
                            }
                            saved11 = JvmSupport.dcmpg(this.f496.distanceTo(Backtrack.mc.player.position()), ((LivingEntity) reference2).position().distanceTo(Backtrack.mc.player.position()));
                            if (!((saved11 >= 0))) {
                                this.pm$90();
                            }
                            saved12 = JvmSupport.dcmpl(((double) this.f497), this.ticks.getValue());
                            if (!((saved12 < 0))) {
                                this.pm$90();
                                this.f497 = 0;
                            }
                            this.f495 = true;
                            this.f497 = (this.f497 + 1);
                        } else {
                            this.f497 = 0;
                            this.f496 = null;
                            this.f495 = false;
                            this.pm$90();
                        }
                    }
                    return;
                }
            } else {
                this.pm$90();
                return;
            }
        } else {
            saved13 = Events.rotation;
            if (!((event != saved13))) {
                reference2 = TargetingUtils.findTarget(this.range.getValue(), true);
                if (!((reference2 == null))) {
                    reference3 = ((LivingEntity) reference2).position();
                    saved14 = this.f495;
                    if (!(saved14)) {
                        this.f496 = new Vec3(((Vec3) reference3).x, ((Vec3) reference3).y, ((Vec3) reference3).z);
                    }
                    saved15 = JvmSupport.dcmpg(this.f496.distanceTo(Backtrack.mc.player.position()), ((LivingEntity) reference2).position().distanceTo(Backtrack.mc.player.position()));
                    if (!((saved15 >= 0))) {
                        this.pm$90();
                    }
                    saved16 = JvmSupport.dcmpl(((double) this.f497), this.ticks.getValue());
                    if (!((saved16 < 0))) {
                        this.pm$90();
                        this.f497 = 0;
                    }
                    this.f495 = true;
                    this.f497 = (this.f497 + 1);
                } else {
                    this.f497 = 0;
                    this.f496 = null;
                    this.f495 = false;
                    this.pm$90();
                }
            }
            return;
        }
    }

    static {
        TEXT_BACKTRACK = new String("Backtrack");
        TEXT_RANGE = new String("Range");
        TEXT_TICKS = new String("Ticks");
    }
}
