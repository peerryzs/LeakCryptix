package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.NumberSetting;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

/**
 * Reconstructed from a/fm.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class AutoHead extends Module {
    private static final String TEXT_AUTOHEAD;
    private static final String TEXT_HEALTH;
    private int f483;
    private final NumberSetting health;
    private boolean f484;

    static {
        TEXT_AUTOHEAD = new String("AutoHead");
        TEXT_HEALTH = new String("Health");
    }

    public AutoHead() {
        super(AutoHead.TEXT_AUTOHEAD, Category.PLAYER);
        this.health = new NumberSetting(AutoHead.TEXT_HEALTH, this, 4.0, 1.0, 15.0, 1.0);
        this.f483 = -1;
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        int saved2 = 0;
        boolean saved3 = false;
        int saved4 = 0;
        int integer2 = 0;
        boolean saved5 = false;
        boolean saved6 = false;
        int saved7 = 0;
        boolean saved8 = false;
        boolean saved9 = false;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            saved2 = this.f483;
            if (!((saved2 == -1))) {
                saved3 = this.f484;
                if (!(saved3)) {
                    AutoHead.mc.player.getInventory().setSelectedSlot(this.f483);
                    this.f483 = -1;
                    return;
                } else {
                    saved4 = JvmSupport.dcmpl(((double) AutoHead.mc.player.getHealth()), this.health.getValue());
                    if (!((saved4 <= 0))) {
                        return;
                    } else {
                        integer2 = 0;
                        loop32: while (true) {
                            if ((integer2 >= 9)) {
                                break loop32;
                            }
                            System.out.println(AutoHead.mc.player.getInventory().getItem(integer2));
                            saved5 = AutoHead.mc.player.getInventory().getItem(integer2).is(Items.HONEY_BOTTLE);
                            if (saved5) {
                                this.f483 = AutoHead.mc.player.getInventory().getSelectedSlot();
                                saved6 = this.f484;
                                if (!(saved6)) {
                                    this.f484 = true;
                                    return;
                                }
                                AutoHead.mc.player.getInventory().setSelectedSlot(integer2);
                                AutoHead.mc.getConnection().send(((Packet) (Object) new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, 0, Events.rotation.getYaw(), Events.rotation.getPitch())));
                                this.f484 = false;
                            }
                            integer2++;
                            continue loop32;
                        }
                        return;
                    }
                }
            } else {
                saved7 = JvmSupport.dcmpl(((double) AutoHead.mc.player.getHealth()), this.health.getValue());
                if (!((saved7 <= 0))) {
                    return;
                } else {
                    integer2 = 0;
                    loop32: while (true) {
                        if ((integer2 >= 9)) {
                            break loop32;
                        }
                        System.out.println(AutoHead.mc.player.getInventory().getItem(integer2));
                        saved8 = AutoHead.mc.player.getInventory().getItem(integer2).is(Items.HONEY_BOTTLE);
                        if (saved8) {
                            this.f483 = AutoHead.mc.player.getInventory().getSelectedSlot();
                            saved9 = this.f484;
                            if (!(saved9)) {
                                this.f484 = true;
                                return;
                            }
                            AutoHead.mc.player.getInventory().setSelectedSlot(integer2);
                            AutoHead.mc.getConnection().send(((Packet) (Object) new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, 0, Events.rotation.getYaw(), Events.rotation.getPitch())));
                            this.f484 = false;
                        }
                        integer2++;
                        continue loop32;
                    }
                    return;
                }
            }
        } else {
            return;
        }
    }
}
