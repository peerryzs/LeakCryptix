package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.mixin.MultiPlayerGameModeMixin;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.NumberSetting;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;

/**
 * Reconstructed from a/vw.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class FastMine extends Module {
    private static final String TEXT_FASTMINE;
    private final BooleanSetting removeDelay;
    private static final String TEXT_SPEED;
    private final NumberSetting speed;
    private static final String TEXT_REMOVE_DELAY;

    static {
        TEXT_FASTMINE = new String("FastMine");
        TEXT_SPEED = new String("Speed");
        TEXT_REMOVE_DELAY = new String("Remove Delay");
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        MultiPlayerGameMode saved2 = null;
        MultiPlayerGameModeMixin reference2 = null;
        boolean saved3 = false;
        float floating3 = 0.0f;
        int saved4 = 0;
        int saved5 = 0;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            saved2 = FastMine.mc.gameMode;
            if (!((saved2 != null))) {
                return;
            } else {
                reference2 = ((MultiPlayerGameModeMixin) (Object) FastMine.mc.gameMode);
                saved3 = this.removeDelay.getValue();
                if (saved3) {
                    reference2.setDestroyDelay(0);
                }
                floating3 = reference2.getDestroyProgress();
                saved4 = JvmSupport.fcmpl(floating3, 0.0f);
                if (!((saved4 <= 0))) {
                    saved5 = JvmSupport.fcmpg(floating3, 0.99f);
                    if (!((saved5 >= 0))) {
                        reference2.setDestroyProgress(((float) (((double) floating3) * this.speed.getValue())));
                    }
                }
                return;
            }
        } else {
            return;
        }
    }

    public FastMine() {
        super(FastMine.TEXT_FASTMINE, Category.PLAYER);
        this.speed = new NumberSetting(FastMine.TEXT_SPEED, this, 1.5, 1.0, 5.0, 0.1);
        this.removeDelay = new BooleanSetting(FastMine.TEXT_REMOVE_DELAY, this, true);
    }
}
