package cryptix.module.impl.player;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.PacketSendEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.network.PacketBuffer;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.NumberSetting;
import cryptix.util.TargetingUtils;
import java.util.Objects;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Reconstructed from a/ho.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class LagRange extends Module {
    private int f579;
    private boolean f578;
    private static final String TEXT_RANGE;
    private final BooleanSetting lagWhenClose;
    private final NumberSetting blinkTicks;
    private double f582;
    private static final String TEXT_BLINK_TICKS;
    private static final String TEXT_LAG_WHEN_CLOSE;
    private static final String TEXT_LAGRANGE;
    private final NumberSetting range;
    private Vec3 f580;
    private String f581;

    public void onDisable() {
        this.pm$106();
    }

    public void onEnable() {
    }

    private void pm$107() {
        double number1 = 0.0;
        int saved1 = 0;
        number1 = this.blinkTicks.getValue();
        saved1 = JvmSupport.dcmpl(number1, this.f582);
        if (!((saved1 != 0))) {
            return;
        } else {
            this.f582 = number1;
            this.setSuffix(("" + ((int) (number1 * 50.0)) + " ms"));
            return;
        }
    }

    public void onEvent(Event event) {
        PacketSendEvent saved1 = null;
        Object reference3 = null;
        boolean saved2 = false;
        Object reference2 = null;
        boolean saved3 = false;
        int saved4 = 0;
        RotationEvent saved5 = null;
        Vec3 saved6 = null;
        int saved7 = 0;
        int saved8 = 0;
        int saved9 = 0;
        Vec3 reference4 = null;
        RotationEvent saved10 = null;
        Vec3 saved11 = null;
        int saved12 = 0;
        int saved13 = 0;
        int saved14 = 0;
        RotationEvent saved15 = null;
        Vec3 saved16 = null;
        int saved17 = 0;
        int saved18 = 0;
        int saved19 = 0;
        RotationEvent saved20 = null;
        Vec3 saved21 = null;
        int saved22 = 0;
        int saved23 = 0;
        int saved24 = 0;
        saved1 = Events.packetSend;
        if (!((event != saved1))) {
            reference3 = Events.packetSend.getPacket();
            saved2 = (reference3 instanceof ServerboundAttackPacket);
            if (saved2) {
                reference2 = ((ServerboundAttackPacket) reference3);
                saved3 = this.lagWhenClose.getValue();
                if (saved3) {
                    saved4 = JvmSupport.fcmpg(LagRange.mc.player.distanceTo(((Entity) Objects.requireNonNull(LagRange.mc.level.getEntity(((ServerboundAttackPacket) reference2).entityId())))), 2.0f);
                    if (!((saved4 >= 0))) {
                        return;
                    } else {
                        this.pm$106();
                        saved5 = Events.rotation;
                        if (!((event != saved5))) {
                            this.pm$107();
                            reference2 = TargetingUtils.findTarget(this.range.getValue(), true);
                            if (!((reference2 == null))) {
                                PacketBuffer.startBuffering();
                                this.f578 = true;
                                this.f579 = (this.f579 + 1);
                                reference3 = ((Entity) reference2).position();
                                saved6 = this.f580;
                                if (!((saved6 == null))) {
                                    saved7 = JvmSupport.dcmpg(this.f580.distanceTo(((Vec3) reference3)), LagRange.mc.player.position().distanceTo(((Vec3) reference3)));
                                    if (!((saved7 > 0))) {
                                        this.pm$106();
                                    } else {
                                        saved8 = JvmSupport.dcmpl(((double) this.f579), this.blinkTicks.getValue());
                                        if (!((saved8 <= 0))) {
                                            this.pm$106();
                                        }
                                    }
                                } else {
                                    saved9 = JvmSupport.dcmpl(((double) this.f579), this.blinkTicks.getValue());
                                    if (!((saved9 <= 0))) {
                                        this.pm$106();
                                    }
                                }
                                reference4 = LagRange.mc.player.position();
                                this.f580 = new Vec3(reference4.x, reference4.y, reference4.z);
                            } else {
                                this.pm$106();
                            }
                        }
                        return;
                    }
                } else {
                    this.pm$106();
                    saved10 = Events.rotation;
                    if (!((event != saved10))) {
                        this.pm$107();
                        reference2 = TargetingUtils.findTarget(this.range.getValue(), true);
                        if (!((reference2 == null))) {
                            PacketBuffer.startBuffering();
                            this.f578 = true;
                            this.f579 = (this.f579 + 1);
                            reference3 = ((Entity) reference2).position();
                            saved11 = this.f580;
                            if (!((saved11 == null))) {
                                saved12 = JvmSupport.dcmpg(this.f580.distanceTo(((Vec3) reference3)), LagRange.mc.player.position().distanceTo(((Vec3) reference3)));
                                if (!((saved12 > 0))) {
                                    this.pm$106();
                                } else {
                                    saved13 = JvmSupport.dcmpl(((double) this.f579), this.blinkTicks.getValue());
                                    if (!((saved13 <= 0))) {
                                        this.pm$106();
                                    }
                                }
                            } else {
                                saved14 = JvmSupport.dcmpl(((double) this.f579), this.blinkTicks.getValue());
                                if (!((saved14 <= 0))) {
                                    this.pm$106();
                                }
                            }
                            reference4 = LagRange.mc.player.position();
                            this.f580 = new Vec3(reference4.x, reference4.y, reference4.z);
                        } else {
                            this.pm$106();
                        }
                    }
                    return;
                }
            } else {
                saved15 = Events.rotation;
                if (!((event != saved15))) {
                    this.pm$107();
                    reference2 = TargetingUtils.findTarget(this.range.getValue(), true);
                    if (!((reference2 == null))) {
                        PacketBuffer.startBuffering();
                        this.f578 = true;
                        this.f579 = (this.f579 + 1);
                        reference3 = ((Entity) reference2).position();
                        saved16 = this.f580;
                        if (!((saved16 == null))) {
                            saved17 = JvmSupport.dcmpg(this.f580.distanceTo(((Vec3) reference3)), LagRange.mc.player.position().distanceTo(((Vec3) reference3)));
                            if (!((saved17 > 0))) {
                                this.pm$106();
                            } else {
                                saved18 = JvmSupport.dcmpl(((double) this.f579), this.blinkTicks.getValue());
                                if (!((saved18 <= 0))) {
                                    this.pm$106();
                                }
                            }
                        } else {
                            saved19 = JvmSupport.dcmpl(((double) this.f579), this.blinkTicks.getValue());
                            if (!((saved19 <= 0))) {
                                this.pm$106();
                            }
                        }
                        reference4 = LagRange.mc.player.position();
                        this.f580 = new Vec3(reference4.x, reference4.y, reference4.z);
                    } else {
                        this.pm$106();
                    }
                }
                return;
            }
        } else {
            saved20 = Events.rotation;
            if (!((event != saved20))) {
                this.pm$107();
                reference2 = TargetingUtils.findTarget(this.range.getValue(), true);
                if (!((reference2 == null))) {
                    PacketBuffer.startBuffering();
                    this.f578 = true;
                    this.f579 = (this.f579 + 1);
                    reference3 = ((Entity) reference2).position();
                    saved21 = this.f580;
                    if (!((saved21 == null))) {
                        saved22 = JvmSupport.dcmpg(this.f580.distanceTo(((Vec3) reference3)), LagRange.mc.player.position().distanceTo(((Vec3) reference3)));
                        if (!((saved22 > 0))) {
                            this.pm$106();
                        } else {
                            saved23 = JvmSupport.dcmpl(((double) this.f579), this.blinkTicks.getValue());
                            if (!((saved23 <= 0))) {
                                this.pm$106();
                            }
                        }
                    } else {
                        saved24 = JvmSupport.dcmpl(((double) this.f579), this.blinkTicks.getValue());
                        if (!((saved24 <= 0))) {
                            this.pm$106();
                        }
                    }
                    reference4 = LagRange.mc.player.position();
                    this.f580 = new Vec3(reference4.x, reference4.y, reference4.z);
                } else {
                    this.pm$106();
                }
            }
            return;
        }
    }

    public LagRange() {
        super(LagRange.TEXT_LAGRANGE, Category.PLAYER);
        this.range = new NumberSetting(LagRange.TEXT_RANGE, this, 6.0, 4.0, 8.0, 0.5);
        this.blinkTicks = new NumberSetting(LagRange.TEXT_BLINK_TICKS, this, 5.0, 2.0, 10.0, 1.0);
        this.lagWhenClose = new BooleanSetting(LagRange.TEXT_LAG_WHEN_CLOSE, this, false);
        this.f582 = Double.NaN;
    }

    private void pm$106() {
        boolean saved1 = false;
        saved1 = this.f578;
        if (saved1) {
            this.f578 = false;
            PacketBuffer.stopAndFlush();
        }
        this.f580 = null;
        this.f579 = 0;
    }

    static {
        TEXT_LAGRANGE = new String("LagRange");
        TEXT_RANGE = new String("Range");
        TEXT_BLINK_TICKS = new String("Blink Ticks");
        TEXT_LAG_WHEN_CLOSE = new String("Lag When Close");
    }
}
