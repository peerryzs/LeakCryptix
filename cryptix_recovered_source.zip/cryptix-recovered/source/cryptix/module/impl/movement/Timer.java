package cryptix.module.impl.movement;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.NumberSetting;
import cryptix.util.Recovered_hp;

/**
 * Reconstructed from a/fl.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Timer extends Module {
    private static final String TEXT_TIMER;
    private final NumberSetting speed;
    private static final String TEXT_SPEED;

    public Timer() {
        super(Timer.TEXT_TIMER, Category.MOVEMENT);
        this.speed = new NumberSetting(Timer.TEXT_SPEED, this, 1.0, 0.1, 5.0, 0.1);
    }

    public void onDisable() {
        Recovered_hp.m59(1.0f);
    }

    static {
        TEXT_TIMER = new String("Timer");
        TEXT_SPEED = new String("Speed");
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            Recovered_hp.m59(((float) this.speed.getValue()));
        }
    }
}
