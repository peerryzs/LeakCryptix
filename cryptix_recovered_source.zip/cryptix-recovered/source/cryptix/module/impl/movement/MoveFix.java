package cryptix.module.impl.movement;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.PostInputEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.mixin.ClientInputMixin;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.ModeSetting;
import net.minecraft.client.player.ClientInput;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.Vec2;

/**
 * Reconstructed from a/uu.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class MoveFix extends Module {
    private static final String TEXT_USE_PREVYAW;
    private static final String TEXT_MOVEFIX;
    private final ModeSetting mode;
    private static final String TEXT_MODE;
    private static final String TEXT_SILENT;
    private static final String TEXT_STRICT;
    private final BooleanSetting usePrevYaw;

    private float pm$88(float arg0, float arg1, float arg2) {
        int saved1 = 0;
        int saved2 = 0;
        float floating0 = 0.0f;
        double number4 = 0.0;
        double number6 = 0.0;
        double number8 = 0.0;
        double number10 = 0.0;
        double number12 = 0.0;
        saved1 = JvmSupport.fcmpl(arg1, 0.0f);
        if (!((saved1 != 0))) {
            saved2 = JvmSupport.fcmpl(arg2, 0.0f);
            if (!((saved2 != 0))) {
                floating0 = ((float) Math.toRadians(((double) arg0)));
                return floating0;
            } else {
                number4 = Math.toRadians(((double) arg0));
                number6 = Math.sin(number4);
                number8 = Math.cos(number4);
                number10 = ((((double) arg1) * number8) - (((double) arg2) * number6));
                number12 = ((((double) arg1) * number6) + (((double) arg2) * number8));
                floating0 = ((float) Math.atan2(number12, number10));
                return floating0;
            }
        } else {
            number4 = Math.toRadians(((double) arg0));
            number6 = Math.sin(number4);
            number8 = Math.cos(number4);
            number10 = ((((double) arg1) * number8) - (((double) arg2) * number6));
            number12 = ((((double) arg1) * number6) + (((double) arg2) * number8));
            floating0 = ((float) Math.atan2(number12, number10));
            return floating0;
        }
    }

    public MoveFix() {
        super(MoveFix.TEXT_MOVEFIX, Category.MOVEMENT);
        this.mode = new ModeSetting(MoveFix.TEXT_MODE, this, MoveFix.TEXT_SILENT, new String[] {MoveFix.TEXT_SILENT, MoveFix.TEXT_STRICT});
        this.usePrevYaw = new BooleanSetting(MoveFix.TEXT_USE_PREVYAW, this, true);
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        boolean saved2 = false;
        PostInputEvent saved3 = null;
        boolean saved4 = false;
        ClientInputMixin reference2 = null;
        float floating3 = 0.0f;
        float floating4 = 0.0f;
        int saved5 = 0;
        int saved6 = 0;
        double number5 = 0.0;
        float floating7 = 0.0f;
        float floating8 = 0.0f;
        float floating9 = 0.0f;
        float floating10 = 0.0f;
        int saved7 = 0;
        float floating11 = 0.0f;
        int saved8 = 0;
        int saved9 = 0;
        int saved10 = 0;
        double number12 = 0.0;
        double number14 = 0.0;
        int saved11 = 0;
        int saved12 = 0;
        Vec2 reference10 = null;
        int saved13 = 0;
        ClientInput saved14 = null;
        int saved15 = 0;
        int saved16 = 0;
        int saved17 = 0;
        int saved18 = 0;
        int saved19 = 0;
        int saved20 = 0;
        int saved21 = 0;
        int saved22 = 0;
        int saved23 = 0;
        int saved24 = 0;
        int saved25 = 0;
        int saved26 = 0;
        int saved27 = 0;
        int saved28 = 0;
        ClientInput saved29 = null;
        int saved30 = 0;
        int saved31 = 0;
        int saved32 = 0;
        int saved33 = 0;
        int saved34 = 0;
        int saved35 = 0;
        int saved36 = 0;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            this.setSuffix(this.mode.getValue());
            Events.rotation.m86(true);
            saved2 = this.usePrevYaw.getValue();
            if (!(saved2)) {
                Events.rotation.m88(false);
            }
        }
        saved3 = Events.postInput;
        if (!((event != saved3))) {
            saved4 = this.mode.is(MoveFix.TEXT_SILENT);
            if (saved4) {
                reference2 = ((ClientInputMixin) (Object) MoveFix.mc.player.input);
                floating3 = reference2.getMoveVector().y;
                floating4 = reference2.getMoveVector().x;
                saved5 = JvmSupport.fcmpl(floating3, 0.0f);
                if (!((saved5 != 0))) {
                    saved6 = JvmSupport.fcmpl(floating4, 0.0f);
                    if (!((saved6 != 0))) {
                        return;
                    } else {
                        number5 = Mth.wrapDegrees(Math.toDegrees(((double) this.pm$88(Events.rotation.getYaw(), floating3, floating4))));
                        floating7 = 0.0f;
                        floating8 = 0.0f;
                        floating9 = 3.4028235e+38f;
                        floating10 = -1.0f;
                        loop66: while (true) {
                            saved7 = JvmSupport.fcmpg(floating10, 1.0f);
                            if ((saved7 > 0)) {
                                break loop66;
                            }
                            floating11 = -1.0f;
                            loop72: while (true) {
                                saved8 = JvmSupport.fcmpg(floating11, 1.0f);
                                if ((saved8 > 0)) {
                                    break loop72;
                                }
                                saved9 = JvmSupport.fcmpl(floating11, 0.0f);
                                if (!((saved9 != 0))) {
                                    saved10 = JvmSupport.fcmpl(floating10, 0.0f);
                                    if (!((saved10 != 0))) {
                                    } else {
                                        number12 = Mth.wrapDegrees(Math.toDegrees(((double) this.pm$88(MoveFix.mc.player.getYRot(), floating10, floating11))));
                                        number14 = Math.abs((number5 - number12));
                                        saved11 = JvmSupport.dcmpg(number14, ((double) floating9));
                                        if (!((saved11 >= 0))) {
                                            floating9 = ((float) number14);
                                            floating7 = floating10;
                                            floating8 = floating11;
                                        }
                                    }
                                } else {
                                    number12 = Mth.wrapDegrees(Math.toDegrees(((double) this.pm$88(MoveFix.mc.player.getYRot(), floating10, floating11))));
                                    number14 = Math.abs((number5 - number12));
                                    saved12 = JvmSupport.dcmpg(number14, ((double) floating9));
                                    if (!((saved12 >= 0))) {
                                        floating9 = ((float) number14);
                                        floating7 = floating10;
                                        floating8 = floating11;
                                    }
                                }
                                floating11 = (floating11 + 1.0f);
                                continue loop72;
                            }
                            floating10 = (floating10 + 1.0f);
                            continue loop66;
                        }
                        reference10 = new Vec2(floating8, floating7);
                        saved13 = JvmSupport.fcmpl(reference10.length(), 1.0f);
                        if (!((saved13 <= 0))) {
                            reference10 = reference10.normalized();
                        }
                        reference2.setMoveVector(reference10);
                        saved14 = MoveFix.mc.player.input;
                        saved15 = JvmSupport.fcmpl(floating7, 0.0f);
                        saved16 = (!((saved15 <= 0)) ? 1 : 0);
                        saved17 = JvmSupport.fcmpg(floating7, 0.0f);
                        saved18 = (!((saved17 >= 0)) ? 1 : 0);
                        saved19 = JvmSupport.fcmpl(floating8, 0.0f);
                        saved20 = (!((saved19 <= 0)) ? 1 : 0);
                        saved21 = JvmSupport.fcmpg(floating8, 0.0f);
                        saved14.keyPresses = new Input((saved16 != 0), (saved18 != 0), (saved20 != 0), ((!((saved21 >= 0)) ? 1 : 0) != 0), MoveFix.mc.player.input.keyPresses.jump(), MoveFix.mc.player.input.keyPresses.shift(), MoveFix.mc.player.input.keyPresses.sprint());
                        return;
                    }
                } else {
                    number5 = Mth.wrapDegrees(Math.toDegrees(((double) this.pm$88(Events.rotation.getYaw(), floating3, floating4))));
                    floating7 = 0.0f;
                    floating8 = 0.0f;
                    floating9 = 3.4028235e+38f;
                    floating10 = -1.0f;
                    loop66: while (true) {
                        saved22 = JvmSupport.fcmpg(floating10, 1.0f);
                        if ((saved22 > 0)) {
                            break loop66;
                        }
                        floating11 = -1.0f;
                        loop72: while (true) {
                            saved23 = JvmSupport.fcmpg(floating11, 1.0f);
                            if ((saved23 > 0)) {
                                break loop72;
                            }
                            saved24 = JvmSupport.fcmpl(floating11, 0.0f);
                            if (!((saved24 != 0))) {
                                saved25 = JvmSupport.fcmpl(floating10, 0.0f);
                                if (!((saved25 != 0))) {
                                } else {
                                    number12 = Mth.wrapDegrees(Math.toDegrees(((double) this.pm$88(MoveFix.mc.player.getYRot(), floating10, floating11))));
                                    number14 = Math.abs((number5 - number12));
                                    saved26 = JvmSupport.dcmpg(number14, ((double) floating9));
                                    if (!((saved26 >= 0))) {
                                        floating9 = ((float) number14);
                                        floating7 = floating10;
                                        floating8 = floating11;
                                    }
                                }
                            } else {
                                number12 = Mth.wrapDegrees(Math.toDegrees(((double) this.pm$88(MoveFix.mc.player.getYRot(), floating10, floating11))));
                                number14 = Math.abs((number5 - number12));
                                saved27 = JvmSupport.dcmpg(number14, ((double) floating9));
                                if (!((saved27 >= 0))) {
                                    floating9 = ((float) number14);
                                    floating7 = floating10;
                                    floating8 = floating11;
                                }
                            }
                            floating11 = (floating11 + 1.0f);
                            continue loop72;
                        }
                        floating10 = (floating10 + 1.0f);
                        continue loop66;
                    }
                    reference10 = new Vec2(floating8, floating7);
                    saved28 = JvmSupport.fcmpl(reference10.length(), 1.0f);
                    if (!((saved28 <= 0))) {
                        reference10 = reference10.normalized();
                    }
                    reference2.setMoveVector(reference10);
                    saved29 = MoveFix.mc.player.input;
                    saved30 = JvmSupport.fcmpl(floating7, 0.0f);
                    saved31 = (!((saved30 <= 0)) ? 1 : 0);
                    saved32 = JvmSupport.fcmpg(floating7, 0.0f);
                    saved33 = (!((saved32 >= 0)) ? 1 : 0);
                    saved34 = JvmSupport.fcmpl(floating8, 0.0f);
                    saved35 = (!((saved34 <= 0)) ? 1 : 0);
                    saved36 = JvmSupport.fcmpg(floating8, 0.0f);
                    saved29.keyPresses = new Input((saved31 != 0), (saved33 != 0), (saved35 != 0), ((!((saved36 >= 0)) ? 1 : 0) != 0), MoveFix.mc.player.input.keyPresses.jump(), MoveFix.mc.player.input.keyPresses.shift(), MoveFix.mc.player.input.keyPresses.sprint());
                    return;
                }
            } else {
                return;
            }
        } else {
            return;
        }
    }

    static {
        TEXT_MOVEFIX = new String("MoveFix");
        TEXT_MODE = new String("Mode");
        TEXT_SILENT = new String("Silent");
        TEXT_STRICT = new String("Strict");
        TEXT_USE_PREVYAW = new String("Use PrevYaw");
    }
}
