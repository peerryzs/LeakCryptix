package cryptix.module.impl.movement;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.HudRenderEvent;
import cryptix.event.impl.PacketReceiveEvent;
import cryptix.event.impl.PostInputEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.mixin.MultiPlayerGameModeMixin;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.module.ModuleManager;
import cryptix.recovery.JvmSupport;
import cryptix.render.ProjectionUtils;
import cryptix.setting.BooleanSetting;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;
import cryptix.util.Recovered_eg;
import cryptix.util.Recovered_jd;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.network.PacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

/**
 * Reconstructed from a/ap.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class LongJump extends Module {
    private double f426;
    private int f424;
    private double f427;
    private static final String TEXT_SHOW_PROGRESS;
    private BooleanSetting showProgress;
    private int f429;
    private static final String TEXT_FIREBALL;
    private NumberSetting fireballDelay;
    private int f423;
    private static final String TEXT_MODE;
    private boolean f425;
    private static final String TEXT_FIREBALL2;
    private static final String TEXT_LONGJUMP;
    private static final String TEXT_FIREBALL_DELAY;
    private int f428;
    private ModeSetting mode;
    private int f422;
    public final List f22;

    private static Packet onEventCallback1(int arg0) {
        ServerboundUseItemPacket reference0 = null;
        reference0 = new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, arg0, Events.rotation.getYaw(), Events.rotation.getPitch());
        return ((Packet) (Object) reference0);
    }

    static {
        TEXT_LONGJUMP = new String("LongJump");
        TEXT_MODE = new String("Mode");
        TEXT_FIREBALL = new String("Fireball");
        TEXT_FIREBALL2 = new String("Fireball2");
        TEXT_FIREBALL_DELAY = new String("Fireball Delay");
        TEXT_SHOW_PROGRESS = new String("Show Progress");
    }

    public void onEnable() {
        this.f423 = 0;
        this.f422 = -1;
        this.f424 = 0;
        this.f425 = false;
        this.f427 = 0.0;
        this.f426 = 0.0;
        this.f429 = 0;
        this.f428 = 0;
    }

    private static void releaseCallback0(Recovered_jd arg0) {
        arg0.f48.handle(((PacketListener) (Object) LongJump.mc.getConnection()));
    }

    private int pm$87() {
        int integer1 = 0;
        boolean saved1 = false;
        int integer0 = 0;
        integer1 = 0;
        loop2: while (true) {
            if ((integer1 >= 9)) {
                break loop2;
            }
            saved1 = LongJump.mc.player.getInventory().getItem(integer1).is(Items.FIRE_CHARGE);
            if (saved1) {
                integer0 = integer1;
                return integer0;
            }
            integer1++;
            continue loop2;
        }
        integer0 = -1;
        return integer0;
    }

    private void release() {
        boolean saved1 = false;
        int saved2 = 0;
        boolean saved3 = false;
        boolean saved4 = false;
        int integer1 = 0;
        List saved5 = null;
        List reference2 = null;
        Iterator reference3 = null;
        boolean saved6 = false;
        Recovered_jd reference4 = null;
        boolean saved7 = false;
        boolean saved8 = false;
        Minecraft saved10 = null;
        this.f427 = this.f426;
        saved1 = this.f425;
        if (saved1) {
            this.f424 = (this.f424 + 1);
            this.f426 = ((double) ((((float) this.f424) * 50.0f) / ((float) this.fireballDelay.getValue())));
        }
        saved2 = JvmSupport.dcmpl(((double) (this.f424 * 50)), this.fireballDelay.getValue());
        if (!((saved2 > 0))) {
            saved3 = this.f425;
            if (!(saved3)) {
                this.f424 = 0;
                this.f426 = 0.0;
                this.f425 = false;
            }
        } else {
            this.f424 = 0;
            this.f426 = 0.0;
            this.f425 = false;
        }
        saved4 = this.f425;
        integer1 = (saved4 ? 255 : 0);
        this.f429 = this.f428;
        this.f428 = ((int) Mth.lerp(0.5f, ((float) this.f428), ((float) integer1)));
        saved5 = this.f22;
        reference2 = saved5;
        synchronized (saved5) {
            reference3 = this.f22.iterator();
            loop78: while (true) {
                saved6 = reference3.hasNext();
                if (!(saved6)) {
                    break loop78;
                }
                reference4 = ((Recovered_jd) reference3.next());
                saved7 = reference4.m245();
                if (!(saved7)) {
                    saved8 = this.f425;
                    if (saved8) {
                        continue loop78;
                    }
                }
                reference3.remove();
                saved10 = LongJump.mc;
                final Recovered_jd captured9 = reference4;
                saved10.execute(() -> LongJump.releaseCallback0(captured9));
                continue loop78;
            }
        }
    }

    public void onEvent(Event event) {
        HudRenderEvent saved1 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        int saved4 = 0;
        float floating2 = 0.0f;
        float floating3 = 0.0f;
        float floating4 = 0.0f;
        float floating5 = 0.0f;
        float floating6 = 0.0f;
        double number7 = 0.0;
        int integer9 = 0;
        int integer10 = 0;
        int integer11 = 0;
        int integer12 = 0;
        RotationEvent saved5 = null;
        boolean saved6 = false;
        int integer2 = 0;
        boolean saved7 = false;
        boolean saved8 = false;
        boolean saved9 = false;
        int saved10 = 0;
        PostInputEvent saved11 = null;
        int saved12 = 0;
        boolean saved13 = false;
        int saved14 = 0;
        PacketReceiveEvent saved15 = null;
        Object reference3 = null;
        boolean saved16 = false;
        ClientboundSetEntityMotionPacket reference2 = null;
        int saved17 = 0;
        int saved18 = 0;
        List saved19 = null;
        List saved20 = null;
        boolean saved21 = false;
        boolean saved22 = false;
        List saved23 = null;
        List saved24 = null;
        Packet saved25 = null;
        boolean saved26 = false;
        saved1 = Events.hudRender;
        if (!((event != saved1))) {
            saved2 = this.showProgress.getValue();
            if (saved2) {
                saved3 = this.f425;
                if (!(saved3)) {
                    saved4 = this.f428;
                    if (!((saved4 <= 5))) {
                        floating2 = 100.0f;
                        floating3 = 4.0f;
                        floating4 = ((((float) LongJump.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                        floating5 = ((((float) LongJump.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                        floating6 = Events.hudRender.getPartialTick();
                        number7 = (this.f427 + ((this.f426 - this.f427) * ((double) floating6)));
                        integer9 = ((int) (((float) this.f429) + (((float) (this.f428 - this.f429)) * floating6)));
                        integer10 = ((Recovered_eg.m31() & 16777215) | (integer9 << 24));
                        integer11 = (integer9 << 24);
                        integer12 = ((((int) (((float) integer9) * 0.5f)) << 24) | 6316128);
                        ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), number7, integer11, integer12, integer10);
                    } else {
                        this.f427 = 0.0;
                    }
                } else {
                    floating2 = 100.0f;
                    floating3 = 4.0f;
                    floating4 = ((((float) LongJump.mc.getWindow().getGuiScaledWidth()) * 0.5f) - (floating2 * 0.5f));
                    floating5 = ((((float) LongJump.mc.getWindow().getGuiScaledHeight()) * 0.5f) + 20.0f);
                    floating6 = Events.hudRender.getPartialTick();
                    number7 = (this.f427 + ((this.f426 - this.f427) * ((double) floating6)));
                    integer9 = ((int) (((float) this.f429) + (((float) (this.f428 - this.f429)) * floating6)));
                    integer10 = ((Recovered_eg.m31() & 16777215) | (integer9 << 24));
                    integer11 = (integer9 << 24);
                    integer12 = ((((int) (((float) integer9) * 0.5f)) << 24) | 6316128);
                    ProjectionUtils.m49(Events.hudRender, ((int) floating4), ((int) floating5), ((int) floating2), ((int) floating3), number7, integer11, integer12, integer10);
                }
            }
        }
        saved5 = Events.rotation;
        if (!((event != saved5))) {
            this.setSuffix(this.mode.getValue());
            saved6 = ModuleManager.scaffold.isEnabled();
            if (saved6) {
                ModuleManager.scaffold.toggle();
            }
            integer2 = this.pm$87();
            if (!((integer2 == -1))) {
                Events.rotation.setPitch(90.0f);
                switch (this.f423) {
                    case 0:
                    {
                        this.f422 = LongJump.mc.player.getInventory().getSelectedSlot();
                        LongJump.mc.player.getInventory().setSelectedSlot(integer2);
                        break;
                    }
                    case 1:
                    {
                        ((MultiPlayerGameModeMixin) (Object) LongJump.mc.gameMode).invokeStartPrediction(LongJump.mc.level, (lambdaArg0) -> LongJump.onEventCallback0(lambdaArg0));
                        break;
                    }
                    case 2:
                    {
                        saved7 = this.mode.is(LongJump.TEXT_FIREBALL);
                        if (saved7) {
                            LongJump.mc.player.getInventory().setSelectedSlot(this.f422);
                        }
                        break;
                    }
                    case 15:
                    {
                        saved8 = this.mode.is(LongJump.TEXT_FIREBALL2);
                        if (saved8) {
                            ((MultiPlayerGameModeMixin) (Object) LongJump.mc.gameMode).invokeStartPrediction(LongJump.mc.level, (lambdaArg0) -> LongJump.onEventCallback1(lambdaArg0));
                        }
                        break;
                    }
                    case 16:
                    {
                        LongJump.mc.player.getInventory().setSelectedSlot(this.f422);
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                this.f423 = (this.f423 + 1);
            } else {
                this.f423 = (this.f423 + 1);
            }
            this.release();
            saved9 = LongJump.mc.player.onGround();
            if (saved9) {
                saved10 = this.f423;
                if (!((saved10 <= 20))) {
                    this.toggle();
                }
            }
        }
        saved11 = Events.postInput;
        if (!((event != saved11))) {
            saved12 = this.f423;
            saved13 = this.mode.is(LongJump.TEXT_FIREBALL);
            saved14 = (saved13 ? 4 : 20);
            if (!((saved12 != saved14))) {
                LongJump.mc.player.input.makeJump();
            }
        }
        saved15 = Events.packetReceive;
        if (!((event != saved15))) {
            reference3 = Events.packetReceive.getPacket();
            saved16 = (reference3 instanceof ClientboundSetEntityMotionPacket);
            if (saved16) {
                reference2 = ((ClientboundSetEntityMotionPacket) reference3);
                saved17 = reference2.id();
                saved18 = LongJump.mc.player.getId();
                if (!((saved17 != saved18))) {
                    saved19 = this.f22;
                    reference3 = saved19;
                    synchronized (saved19) {
                        saved20 = this.f22;
                        saved21 = this.mode.is(LongJump.TEXT_FIREBALL);
                        saved20.add(new Recovered_jd(((Packet) (Object) reference2), (saved21 ? ((long) this.fireballDelay.getValue()) : (((long) this.fireballDelay.getValue()) + 800L))));
                        event.setCancelled(true);
                    }
                    this.f425 = true;
                }
            } else {
                saved22 = this.f425;
                if (saved22) {
                    saved23 = this.f22;
                    reference3 = saved23;
                    synchronized (saved23) {
                        saved24 = this.f22;
                        saved25 = Events.packetReceive.getPacket();
                        saved26 = this.mode.is(LongJump.TEXT_FIREBALL);
                        saved24.add(new Recovered_jd(saved25, (saved26 ? ((long) this.fireballDelay.getValue()) : (((long) this.fireballDelay.getValue()) + 800L))));
                        event.setCancelled(true);
                    }
                }
            }
        }
    }

    public void onDisable() {
        List saved1 = null;
        List reference1 = null;
        Iterator reference2 = null;
        boolean saved2 = false;
        Recovered_jd reference3 = null;
        Minecraft saved4 = null;
        saved1 = this.f22;
        reference1 = saved1;
        synchronized (saved1) {
            reference2 = this.f22.iterator();
            loop9: while (true) {
                saved2 = reference2.hasNext();
                if (!(saved2)) {
                    break loop9;
                }
                reference3 = ((Recovered_jd) reference2.next());
                saved4 = LongJump.mc;
                final Recovered_jd captured3 = reference3;
                saved4.execute(() -> LongJump.onDisableCallback0(captured3));
                continue loop9;
            }
            this.f22.clear();
            this.f425 = false;
        }
        this.f423 = 0;
        this.f422 = -1;
        this.f424 = 0;
    }

    public LongJump() {
        super(LongJump.TEXT_LONGJUMP, Category.MOVEMENT);
        this.mode = new ModeSetting(LongJump.TEXT_MODE, this, LongJump.TEXT_FIREBALL, new String[] {LongJump.TEXT_FIREBALL, LongJump.TEXT_FIREBALL2});
        this.fireballDelay = new NumberSetting(LongJump.TEXT_FIREBALL_DELAY, this, 200.0, 100.0, 1000.0, 50.0);
        this.showProgress = new BooleanSetting(LongJump.TEXT_SHOW_PROGRESS, this, false);
        this.f22 = new ArrayList();
        this.f422 = -1;
    }

    private static Packet onEventCallback0(int arg0) {
        ServerboundUseItemPacket reference0 = null;
        reference0 = new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, arg0, Events.rotation.getYaw(), Events.rotation.getPitch());
        return ((Packet) (Object) reference0);
    }

    private static void onDisableCallback0(Recovered_jd arg0) {
        arg0.f48.handle(((PacketListener) (Object) LongJump.mc.getConnection()));
    }
}
