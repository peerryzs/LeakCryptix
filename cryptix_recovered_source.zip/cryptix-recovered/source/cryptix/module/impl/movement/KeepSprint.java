package cryptix.module.impl.movement;

import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.NumberSetting;

/**
 * Reconstructed from a/nx.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class KeepSprint extends Module {
    private static final String TEXT_SPEED;
    private static final String TEXT_KEEPSPRINT;
    private NumberSetting speed;

    static {
        TEXT_KEEPSPRINT = new String("KeepSprint");
        TEXT_SPEED = new String("Speed");
    }

    public KeepSprint() {
        super(KeepSprint.TEXT_KEEPSPRINT, Category.MOVEMENT);
        this.speed = new NumberSetting(KeepSprint.TEXT_SPEED, this, 0.6, 0.6, 1.0, 0.05);
    }

    public double m161() {
        boolean saved1 = false;
        double number0 = 0.0;
        saved1 = this.isEnabled();
        if (!(saved1)) {
            number0 = 0.6;
            return number0;
        } else {
            number0 = this.speed.getValue();
            return number0;
        }
    }
}
