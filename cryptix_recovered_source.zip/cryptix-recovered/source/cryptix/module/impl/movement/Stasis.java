package cryptix.module.impl.movement;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.mixin.LocalPlayerMixin_kv;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.NumberSetting;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;

/**
 * Reconstructed from a/mx.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Stasis extends Module {
    private float f468;
    private static final String TEXT_STASIS;
    private int f467;
    private final NumberSetting delay;
    private float f469;
    private static final String TEXT_ROTATE;
    private final BooleanSetting rotate;
    private static final String TEXT_DELAY;

    static {
        TEXT_STASIS = new String("Stasis");
        TEXT_DELAY = new String("Delay");
        TEXT_ROTATE = new String("Rotate");
    }

    public void onEnable() {
        this.f467 = 0;
        this.f468 = Stasis.mc.player.getYRot();
        this.f469 = Stasis.mc.player.getXRot();
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        int saved2 = 0;
        float floating2 = 0.0f;
        float floating3 = 0.0f;
        int saved3 = 0;
        int integer4 = 0;
        int saved4 = 0;
        int integer5 = 0;
        int integer6 = 0;
        boolean saved5 = false;
        LocalPlayerMixin_kv reference7 = null;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            this.f467 = (this.f467 + 1);
            saved2 = JvmSupport.dcmpl(((double) this.f467), this.delay.getValue());
            if (!((saved2 < 0))) {
                this.f467 = 0;
                return;
            } else {
                event.setCancelled(true);
                Events.motion.update(Stasis.mc.player.getX(), Stasis.mc.player.getY(), Stasis.mc.player.getZ(), Stasis.mc.player.horizontalCollision, Stasis.mc.player.onGround());
                Events.motion.dispatch();
                floating2 = Events.rotation.getYaw();
                floating3 = Events.rotation.getPitch();
                saved3 = JvmSupport.fcmpl(floating2, this.f468);
                integer4 = (!((saved3 == 0)) ? 1 : 0);
                saved4 = JvmSupport.fcmpl(floating3, this.f469);
                integer5 = (!((saved4 == 0)) ? 1 : 0);
                integer6 = (!((integer5 != 0)) ? (!((integer4 == 0)) ? 1 : 0) : 1);
                saved5 = this.rotate.getValue();
                if (saved5) {
                    if (!((integer6 == 0))) {
                        Stasis.mc.getConnection().send(((Packet) (Object) new ServerboundMovePlayerPacket.Rot(floating2, floating3, Stasis.mc.player.onGround(), Stasis.mc.player.horizontalCollision)));
                    }
                    Stasis.mc.player.yBodyRot = floating2;
                    Stasis.mc.player.yBodyRotO = this.f468;
                    reference7 = ((LocalPlayerMixin_kv) (Object) Stasis.mc.player);
                    reference7.setXRotLast(floating3);
                    reference7.setYRotLast(floating2);
                    Stasis.mc.player.yHeadRot = floating2;
                    Stasis.mc.player.yHeadRotO = this.f468;
                }
                this.f468 = floating2;
                this.f469 = floating3;
                return;
            }
        } else {
            return;
        }
    }

    public int getEventPriority(Event arg0) {
        RotationEvent saved1 = null;
        int integer0 = 0;
        saved1 = Events.rotation;
        if (!((arg0 != saved1))) {
            integer0 = 1;
            return integer0;
        } else {
            integer0 = 0;
            return integer0;
        }
    }

    public Stasis() {
        super(Stasis.TEXT_STASIS, Category.MOVEMENT);
        this.delay = new NumberSetting(Stasis.TEXT_DELAY, this, 15.0, 10.0, 50.0, 1.0);
        this.rotate = new BooleanSetting(Stasis.TEXT_ROTATE, this, false);
    }
}
