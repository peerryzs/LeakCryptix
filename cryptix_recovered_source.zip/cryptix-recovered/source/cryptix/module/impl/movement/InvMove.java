package cryptix.module.impl.movement;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.NumberSetting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.phys.Vec3;

/**
 * Reconstructed from a/qa.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class InvMove extends Module {
    private static final String TEXT_MOTION;
    private NumberSetting motion;
    private static final String TEXT_INVMOVE;

    private void pm$85() {
        Vec3 reference1 = null;
        reference1 = InvMove.mc.player.getDeltaMovement();
        InvMove.mc.player.setDeltaMovement((reference1.x * this.motion.getValue()), reference1.y, (reference1.z * this.motion.getValue()));
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        Screen saved2 = null;
        boolean saved3 = false;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            saved2 = InvMove.mc.gui.screen();
            if (!((saved2 == null))) {
                saved3 = (InvMove.mc.gui.screen() instanceof ChatScreen);
                if (!(saved3)) {
                    KeyMapping.setAll();
                    this.pm$85();
                }
            }
        }
    }

    public InvMove() {
        super(InvMove.TEXT_INVMOVE, Category.MOVEMENT);
        this.motion = new NumberSetting(InvMove.TEXT_MOTION, this, 1.0, 0.1, 1.0, 0.1);
    }

    static {
        TEXT_INVMOVE = new String("InvMove");
        TEXT_MOTION = new String("Motion");
    }
}
