package cryptix.module.impl.movement;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.BooleanSetting;
import cryptix.util.TargetingUtils;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.entity.Entity;

/**
 * Reconstructed from a/qu.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class AutoWalk extends Module {
    private BooleanSetting rotateToEntity;
    private static final String TEXT_AUTOWALK;
    private static final String TEXT_ROTATE_TO_ENTITY;

    public AutoWalk() {
        super(AutoWalk.TEXT_AUTOWALK, Category.MOVEMENT);
        this.rotateToEntity = new BooleanSetting(AutoWalk.TEXT_ROTATE_TO_ENTITY, this, false);
    }

    public void onDisable() {
        AutoWalk.mc.options.keyUp.setDown(false);
    }

    static {
        TEXT_AUTOWALK = new String("AutoWalk");
        TEXT_ROTATE_TO_ENTITY = new String("Rotate to Entity");
    }

    private void pm$84(Entity arg0) {
        double number2 = 0.0;
        double number4 = 0.0;
        float floating6 = 0.0f;
        number2 = (arg0.getX() - AutoWalk.mc.player.getX());
        number4 = (arg0.getZ() - AutoWalk.mc.player.getZ());
        floating6 = (((float) Math.toDegrees(Math.atan2(number4, number2))) - 90.0f);
        AutoWalk.mc.player.setYRot(floating6);
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        Screen saved2 = null;
        boolean saved3 = false;
        Entity reference2 = null;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            saved2 = AutoWalk.mc.gui.screen();
            if (!((saved2 != null))) {
                AutoWalk.mc.options.keyUp.setDown(true);
                saved3 = this.rotateToEntity.getValue();
                if (saved3) {
                    reference2 = TargetingUtils.m56();
                    if (!((reference2 == null))) {
                        this.pm$84(reference2);
                    }
                }
            }
        }
    }
}
