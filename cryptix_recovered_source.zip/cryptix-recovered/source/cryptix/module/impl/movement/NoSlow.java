package cryptix.module.impl.movement;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.ItemUseSlowdownEvent;
import cryptix.event.impl.MotionEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.event.impl.SprintEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.InteractionHand;

/**
 * Reconstructed from a/va.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class NoSlow extends Module {
    private static final String TEXT_SECONDTICK;
    private static final String TEXT_SPEED;
    private static final String TEXT_FORCE_SPRINTING;
    private static final String TEXT_ROTATE;
    private static final String TEXT_ALWAYS;
    private static final String TEXT_BLOCK;
    private NumberSetting speed;
    private BooleanSetting rotate;
    private static final String TEXT_NOGROUND;
    private double f455;
    private BooleanSetting forceSprinting;
    private static final String TEXT_FIRSTTICK;
    private static final String TEXT_DISABLED;
    private ModeSetting block;
    private int f454;
    private ModeSetting swap;
    private static final String TEXT_NOSLOW;
    private static final String TEXT_SWAP;
    private BooleanSetting noGround;

    public void onEvent(Event event) {
        ItemUseSlowdownEvent saved1 = null;
        SprintEvent saved2 = null;
        boolean saved3 = false;
        RotationEvent saved4 = null;
        double number2 = 0.0;
        int saved5 = 0;
        boolean saved6 = false;
        boolean saved7 = false;
        int integer4 = 0;
        boolean saved8 = false;
        int integer5 = 0;
        boolean saved9 = false;
        boolean saved10 = false;
        boolean saved11 = false;
        boolean saved12 = false;
        boolean saved13 = false;
        int saved14 = 0;
        boolean saved15 = false;
        int integer6 = 0;
        boolean saved16 = false;
        int saved17 = 0;
        boolean saved18 = false;
        MotionEvent saved19 = null;
        boolean saved20 = false;
        boolean saved21 = false;
        saved1 = Events.itemUseSlowdown;
        if (!((event != saved1))) {
            Events.itemUseSlowdown.setMultiplier(((float) this.speed.getValue()));
        }
        saved2 = Events.sprint;
        if (!((event != saved2))) {
            saved3 = this.forceSprinting.getValue();
            if (saved3) {
                Events.sprint.m98(1);
                Events.sprint.m100(true);
            }
        }
        saved4 = Events.rotation;
        if (!((event != saved4))) {
            number2 = this.speed.getValue();
            saved5 = JvmSupport.dcmpl(number2, this.f455);
            if (!((saved5 == 0))) {
                this.f455 = number2;
                this.setSuffix(("" + number2));
            }
            saved6 = NoSlow.mc.player.isUsingItem();
            if (saved6) {
                saved7 = this.swap.is(NoSlow.TEXT_SECONDTICK);
                integer4 = (saved7 ? 2 : 1);
                saved8 = this.block.is(NoSlow.TEXT_SECONDTICK);
                integer5 = (saved8 ? 2 : 1);
                this.f454 = (this.f454 + 1);
                saved9 = NoSlow.mc.options.keyJump.isDown();
                if (saved9) {
                    saved10 = NoSlow.mc.player.onGround();
                    if (!(saved10)) {
                        saved11 = this.rotate.getValue();
                        if (saved11) {
                            Events.rotation.setYaw((NoSlow.mc.player.getYRot() + 45.0f));
                        }
                    }
                } else {
                    saved12 = this.rotate.getValue();
                    if (saved12) {
                        Events.rotation.setYaw((NoSlow.mc.player.getYRot() + 45.0f));
                    }
                }
                saved13 = this.swap.is(NoSlow.TEXT_DISABLED);
                if (!(saved13)) {
                    saved14 = this.f454;
                    if (!((saved14 == integer4))) {
                        saved15 = this.swap.is(NoSlow.TEXT_ALWAYS);
                        if (saved15) {
                            integer6 = NoSlow.mc.player.getInventory().getSelectedSlot();
                            NoSlow.mc.player.connection.send(((Packet) (Object) new ServerboundSetCarriedItemPacket(((integer6 % 8) + 1))));
                            NoSlow.mc.player.connection.send(((Packet) (Object) new ServerboundSetCarriedItemPacket(integer6)));
                        }
                    } else {
                        integer6 = NoSlow.mc.player.getInventory().getSelectedSlot();
                        NoSlow.mc.player.connection.send(((Packet) (Object) new ServerboundSetCarriedItemPacket(((integer6 % 8) + 1))));
                        NoSlow.mc.player.connection.send(((Packet) (Object) new ServerboundSetCarriedItemPacket(integer6)));
                    }
                }
                saved16 = this.block.is(NoSlow.TEXT_DISABLED);
                if (!(saved16)) {
                    saved17 = this.f454;
                    if (!((saved17 == integer5))) {
                        saved18 = this.block.is(NoSlow.TEXT_ALWAYS);
                        if (saved18) {
                            NoSlow.mc.getConnection().send(((Packet) (Object) new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, 0, NoSlow.mc.player.getYRot(), NoSlow.mc.player.getXRot())));
                        }
                    } else {
                        NoSlow.mc.getConnection().send(((Packet) (Object) new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, 0, NoSlow.mc.player.getYRot(), NoSlow.mc.player.getXRot())));
                    }
                }
            } else {
                this.f454 = 0;
            }
        }
        saved19 = Events.motion;
        if (!((event != saved19))) {
            saved20 = NoSlow.mc.player.isUsingItem();
            if (saved20) {
                saved21 = this.noGround.getValue();
                if (saved21) {
                    Events.motion.setOnGround(false);
                }
            }
        }
    }

    static {
        TEXT_NOSLOW = new String("NoSlow");
        TEXT_SPEED = new String("Speed");
        TEXT_FORCE_SPRINTING = new String("Force Sprinting");
        TEXT_ROTATE = new String("Rotate");
        TEXT_NOGROUND = new String("NoGround");
        TEXT_SWAP = new String("Swap");
        TEXT_DISABLED = new String("Disabled");
        TEXT_ALWAYS = new String("Always");
        TEXT_FIRSTTICK = new String("FirstTick");
        TEXT_SECONDTICK = new String("SecondTick");
        TEXT_BLOCK = new String("Block");
    }

    public NoSlow() {
        super(NoSlow.TEXT_NOSLOW, Category.MOVEMENT);
        this.speed = new NumberSetting(NoSlow.TEXT_SPEED, this, 0.2, 0.2, 1.0, 0.1);
        this.forceSprinting = new BooleanSetting(NoSlow.TEXT_FORCE_SPRINTING, this, false);
        this.rotate = new BooleanSetting(NoSlow.TEXT_ROTATE, this, false);
        this.noGround = new BooleanSetting(NoSlow.TEXT_NOGROUND, this, false);
        this.swap = new ModeSetting(NoSlow.TEXT_SWAP, this, NoSlow.TEXT_DISABLED, new String[] {NoSlow.TEXT_DISABLED, NoSlow.TEXT_ALWAYS, NoSlow.TEXT_FIRSTTICK, NoSlow.TEXT_SECONDTICK});
        this.block = new ModeSetting(NoSlow.TEXT_BLOCK, this, NoSlow.TEXT_DISABLED, new String[] {NoSlow.TEXT_DISABLED, NoSlow.TEXT_ALWAYS, NoSlow.TEXT_FIRSTTICK, NoSlow.TEXT_SECONDTICK});
    }
}
