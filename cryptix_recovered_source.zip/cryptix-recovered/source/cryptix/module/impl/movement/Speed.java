package cryptix.module.impl.movement;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.PostInputEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.BooleanSetting;

/**
 * Reconstructed from a/kd.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Speed extends Module {
    private static final String TEXT_JUMP;
    private static final String TEXT_SPEED;
    private BooleanSetting rotate;
    private BooleanSetting jump;
    private static final String TEXT_ROTATE;

    public int getEventPriority(Event arg0) {
        RotationEvent saved1 = null;
        int integer0 = 0;
        saved1 = Events.rotation;
        if (!((arg0 != saved1))) {
            integer0 = -3;
            return integer0;
        } else {
            integer0 = 0;
            return integer0;
        }
    }

    public Speed() {
        super(Speed.TEXT_SPEED, Category.MOVEMENT);
        this.rotate = new BooleanSetting(Speed.TEXT_ROTATE, this, false);
        this.jump = new BooleanSetting(Speed.TEXT_JUMP, this, false);
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        boolean saved4 = false;
        boolean saved5 = false;
        boolean saved6 = false;
        boolean saved7 = false;
        PostInputEvent saved8 = null;
        boolean saved9 = false;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            saved2 = this.rotate.getValue();
            if (saved2) {
                saved3 = Speed.mc.options.keyRight.isDown();
                if (!(saved3)) {
                    saved4 = Speed.mc.options.keyLeft.isDown();
                    if (!(saved4)) {
                        saved5 = Speed.mc.player.onGround();
                        if (saved5) {
                            saved6 = Speed.mc.options.keyJump.isDown();
                            if (!(saved6)) {
                                saved7 = this.jump.getValue();
                                if (!(saved7)) {
                                    Events.rotation.setYaw((Speed.mc.player.getYRot() + 45.0f));
                                }
                            }
                        } else {
                            Events.rotation.setYaw((Speed.mc.player.getYRot() + 45.0f));
                        }
                    }
                }
            }
        }
        saved8 = Events.postInput;
        if (!((event != saved8))) {
            saved9 = this.jump.getValue();
            if (saved9) {
                Speed.mc.player.input.makeJump();
            }
        }
    }

    static {
        TEXT_SPEED = new String("Speed");
        TEXT_ROTATE = new String("Rotate");
        TEXT_JUMP = new String("Jump");
    }
}
