package cryptix.module.impl.movement;

import cryptix.module.Category;
import cryptix.module.Module;

/**
 * Reconstructed from a/ct.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class AntiSwim extends Module {
    private static final String TEXT_ANTISWIM;

    static {
        TEXT_ANTISWIM = new String("AntiSwim");
    }

    public AntiSwim() {
        super(AntiSwim.TEXT_ANTISWIM, Category.MOVEMENT);
    }
}
