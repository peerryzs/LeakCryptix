package cryptix.module.impl.movement;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;

/**
 * Reconstructed from a/ag.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Sprint extends Module {
    private static final String TEXT_SPRINT;

    static {
        TEXT_SPRINT = new String("Sprint");
    }

    public Sprint() {
        super(Sprint.TEXT_SPRINT, Category.MOVEMENT);
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            Sprint.mc.options.keySprint.setDown(true);
        }
    }

    public void onDisable() {
        Sprint.mc.options.keySprint.setDown(false);
    }
}
