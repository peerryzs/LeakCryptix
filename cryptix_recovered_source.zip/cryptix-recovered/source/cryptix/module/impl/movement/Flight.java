package cryptix.module.impl.movement;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.MotionEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.NumberSetting;

/**
 * Reconstructed from a/si.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Flight extends Module {
    private static final String TEXT_SPEED;
    private NumberSetting speed;
    private static final String TEXT_FLIGHT;

    public Flight() {
        super(Flight.TEXT_FLIGHT, Category.MOVEMENT);
        this.speed = new NumberSetting(Flight.TEXT_SPEED, this, 1.0, 1.0, 10.0, 0.5);
    }

    public void onEvent(Event event) {
        MotionEvent saved1 = null;
        saved1 = Events.motion;
        if (!((event != saved1))) {
            Flight.mc.player.getAbilities().flying = true;
            Flight.mc.player.getAbilities().setFlyingSpeed((((float) this.speed.getValue()) * 0.1f));
        }
    }

    static {
        TEXT_FLIGHT = new String("Flight");
        TEXT_SPEED = new String("Speed");
    }
}
