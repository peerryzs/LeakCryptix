package cryptix.module.impl.visual;

import cryptix.gui.Recovered_ej;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.BooleanSetting;

/**
 * Reconstructed from a/ln.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class ClickGUI extends Module {
    private static final String TEXT_MODULE_SOUND;
    private static final String TEXT_CLICKGUI;
    public final BooleanSetting moduleSound;
    private Recovered_ej f713;

    public void onEnable() {
        Recovered_ej saved1 = null;
        saved1 = this.f713;
        if (!((saved1 != null))) {
            this.f713 = new Recovered_ej();
        }
        ClickGUI.mc.gui.setScreen(this.f713);
        this.setEnabled(false);
    }

    static {
        TEXT_CLICKGUI = new String("ClickGUI");
        TEXT_MODULE_SOUND = new String("Module Sound");
    }

    public ClickGUI() {
        super(ClickGUI.TEXT_CLICKGUI, 344, Category.VISUAL);
        this.moduleSound = new BooleanSetting(ClickGUI.TEXT_MODULE_SOUND, this, true);
    }
}
