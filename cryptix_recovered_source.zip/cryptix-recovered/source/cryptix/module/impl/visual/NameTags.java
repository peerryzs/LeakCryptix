package cryptix.module.impl.visual;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.NameTagRenderEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.NumberSetting;

/**
 * Reconstructed from a/up.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class NameTags extends Module {
    private NumberSetting scale;
    private static final String TEXT_NAMETAGS;
    private static final String TEXT_Y;
    private static final String TEXT_SCALE;
    private NumberSetting y;

    public void onEvent(Event event) {
        NameTagRenderEvent saved1 = null;
        float floating2 = 0.0f;
        saved1 = Events.nameTagRender;
        if (!((event != saved1))) {
            Events.nameTagRender.m36(true);
            Events.nameTagRender.m35(15728880);
            floating2 = ((float) this.scale.getValue());
            Events.nameTagRender.m29().scale(floating2, floating2, floating2);
            Events.nameTagRender.m29().translate(0.0, this.y.getValue(), 0.0);
        }
    }

    public NameTags() {
        super(NameTags.TEXT_NAMETAGS, Category.VISUAL);
        this.scale = new NumberSetting(NameTags.TEXT_SCALE, this, 1.0, 0.1, 2.0, 0.1);
        this.y = new NumberSetting(NameTags.TEXT_Y, this, 0.0, -10.0, 10.0, 0.1);
    }

    static {
        TEXT_NAMETAGS = new String("NameTags");
        TEXT_SCALE = new String("Scale");
        TEXT_Y = new String("Y");
    }
}
