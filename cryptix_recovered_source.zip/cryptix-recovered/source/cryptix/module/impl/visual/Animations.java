package cryptix.module.impl.visual;

import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.BooleanSetting;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;

/**
 * Reconstructed from a/cw.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Animations extends Module {
    public NumberSetting y;
    private static final String TEXT_OLD_BODY_YAW;
    private static final String TEXT_ONLY_WHILE_BLOCKING;
    public NumberSetting z;
    public ModeSetting mode;
    private static final String TEXT_EXHIBITION;
    private static final String TEXT_NONE;
    private static final String TEXT_Y;
    public NumberSetting scale;
    public NumberSetting swingTime;
    private static final String TEXT_ANIMATIONS;
    private static final String TEXT_SWING_TIME;
    public BooleanSetting onlyWhileBlocking;
    private static final String TEXT_SCALE;
    public BooleanSetting oldBodyYaw;
    private static final String TEXT_REMOVE_SNEAK_ANIM;
    private static final String TEXT_1_7;
    private static final String TEXT_Z;
    public NumberSetting x;
    public BooleanSetting removeSneakAnim;
    private static final String TEXT_MODE;
    private static final String TEXT_X;

    public Animations() {
        super(Animations.TEXT_ANIMATIONS, Category.VISUAL);
        this.mode = new ModeSetting(Animations.TEXT_MODE, this, Animations.TEXT_NONE, new String[] {Animations.TEXT_NONE, Animations.TEXT_1_7, Animations.TEXT_EXHIBITION});
        this.scale = new NumberSetting(Animations.TEXT_SCALE, this, 1.0, 0.1, 2.0, 0.1);
        this.x = new NumberSetting(Animations.TEXT_X, this, 0.0, -2.0, 2.0, 0.05);
        this.y = new NumberSetting(Animations.TEXT_Y, this, 0.0, -2.0, 2.0, 0.05);
        this.z = new NumberSetting(Animations.TEXT_Z, this, 0.0, -2.0, 2.0, 0.05);
        this.swingTime = new NumberSetting(Animations.TEXT_SWING_TIME, this, 1.0, 0.5, 5.0, 0.1);
        this.onlyWhileBlocking = new BooleanSetting(Animations.TEXT_ONLY_WHILE_BLOCKING, this, false);
        this.removeSneakAnim = new BooleanSetting(Animations.TEXT_REMOVE_SNEAK_ANIM, this, false);
        this.oldBodyYaw = new BooleanSetting(Animations.TEXT_OLD_BODY_YAW, this, false);
    }

    static {
        TEXT_ANIMATIONS = new String("Animations");
        TEXT_MODE = new String("Mode");
        TEXT_NONE = new String("None");
        TEXT_1_7 = new String("1.7");
        TEXT_EXHIBITION = new String("Exhibition");
        TEXT_SCALE = new String("Scale");
        TEXT_X = new String("X");
        TEXT_Y = new String("Y");
        TEXT_Z = new String("Z");
        TEXT_SWING_TIME = new String("Swing Time");
        TEXT_ONLY_WHILE_BLOCKING = new String("Only While Blocking");
        TEXT_REMOVE_SNEAK_ANIM = new String("Remove Sneak Anim");
        TEXT_OLD_BODY_YAW = new String("Old Body Yaw");
    }
}
