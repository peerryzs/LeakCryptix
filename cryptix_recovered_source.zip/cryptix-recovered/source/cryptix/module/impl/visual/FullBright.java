package cryptix.module.impl.visual;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.mixin.OptionInstanceMixin;
import cryptix.module.Category;
import cryptix.module.Module;

/**
 * Reconstructed from a/vl.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class FullBright extends Module {
    private static final String TEXT_FULLBRIGHT;
    private double f715;

    public void onEnable() {
        this.f715 = ((Double) FullBright.mc.options.gamma().get()).doubleValue();
        ((OptionInstanceMixin) (Object) FullBright.mc.options.gamma()).setValue(Double.valueOf(100.0));
    }

    public void onDisable() {
        FullBright.mc.options.gamma().set(Double.valueOf(this.f715));
    }

    static {
        TEXT_FULLBRIGHT = new String("FullBright");
    }

    public FullBright() {
        super(FullBright.TEXT_FULLBRIGHT, Category.VISUAL);
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            ((OptionInstanceMixin) (Object) FullBright.mc.options.gamma()).setValue(Double.valueOf(100.0));
        }
    }
}
