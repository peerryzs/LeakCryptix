package cryptix.module.impl.visual;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.HurtCameraEvent;
import cryptix.module.Category;
import cryptix.module.Module;

/**
 * Reconstructed from a/ai.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class NoHurtCam extends Module {
    private static final String TEXT_NOHURTCAM;

    public NoHurtCam() {
        super(NoHurtCam.TEXT_NOHURTCAM, Category.VISUAL);
    }

    static {
        TEXT_NOHURTCAM = new String("NoHurtCam");
    }

    public void onEvent(Event event) {
        HurtCameraEvent saved1 = null;
        saved1 = Events.hurtCamera;
        if (!((event != saved1))) {
            event.setCancelled(true);
        }
    }
}
