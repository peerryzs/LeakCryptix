package cryptix.module.impl.visual;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.PacketReceiveEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.event.impl.SoundPlayEvent;
import cryptix.mixin.ClientClockManagerMixin;
import cryptix.mixin.ssMixin;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.BooleanSetting;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;
import java.util.Optional;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.Holder;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import net.minecraft.resources.Identifier;
import net.minecraft.world.clock.WorldClocks;

/**
 * Reconstructed from a/to.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Ambience extends Module {
    private static final Identifier f670;
    private static final Identifier f669;
    private static final String TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_CRIT;
    private static final String TEXT_CLEAR;
    private static final Identifier f671;
    private static final Identifier f674;
    private int f667;
    private static final String TEXT_WEATHER;
    private static final String TEXT_AMBIENCE;
    private static final Identifier f672;
    private static final String TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_STRONG;
    private static final String TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_KNOCKBACK;
    private final ModeSetting weather;
    private static final String TEXT_TIME;
    private static final String TEXT_THUNDER;
    private static final String TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_NODAMAGE;
    public final NumberSetting time;
    private static final String TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_WEAK;
    private static final Identifier f673;
    private static final String TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_SWEEP;
    private static final String TEXT_CANCEL_HIT_SOUND;
    private final BooleanSetting cancelHitSound;
    private static final String TEXT_RAIN;
    private ClientLevel f668;

    static {
        TEXT_AMBIENCE = new String("Ambience");
        TEXT_WEATHER = new String("Weather");
        TEXT_CLEAR = new String("Clear");
        TEXT_RAIN = new String("Rain");
        TEXT_THUNDER = new String("Thunder");
        TEXT_CANCEL_HIT_SOUND = new String("Cancel Hit Sound");
        TEXT_TIME = new String("Time");
        TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_NODAMAGE = new String("minecraft:entity.player.attack.nodamage");
        TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_WEAK = new String("minecraft:entity.player.attack.weak");
        TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_CRIT = new String("minecraft:entity.player.attack.crit");
        TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_STRONG = new String("minecraft:entity.player.attack.strong");
        TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_KNOCKBACK = new String("minecraft:entity.player.attack.knockback");
        TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_SWEEP = new String("minecraft:entity.player.attack.sweep");
        f669 = Identifier.parse(Ambience.TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_NODAMAGE);
        f670 = Identifier.parse(Ambience.TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_WEAK);
        f671 = Identifier.parse(Ambience.TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_CRIT);
        f672 = Identifier.parse(Ambience.TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_STRONG);
        f673 = Identifier.parse(Ambience.TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_KNOCKBACK);
        f674 = Identifier.parse(Ambience.TEXT_MINECRAFT_ENTITY_PLAYER_ATTACK_SWEEP);
    }

    private static void onEventCallback0(ClientClockManagerMixin arg0, int arg1, Holder.Reference arg2) {
        Object reference3 = null;
        reference3 = arg0.getClocks().get(arg2);
        if (!((reference3 == null))) {
            ((ssMixin) reference3).setTotalTicks(((long) arg1));
        }
    }

    public Ambience() {
        super(Ambience.TEXT_AMBIENCE, Category.VISUAL);
        this.weather = new ModeSetting(Ambience.TEXT_WEATHER, this, Ambience.TEXT_CLEAR, new String[] {Ambience.TEXT_CLEAR, Ambience.TEXT_RAIN, Ambience.TEXT_THUNDER});
        this.cancelHitSound = new BooleanSetting(Ambience.TEXT_CANCEL_HIT_SOUND, this, false);
        this.time = new NumberSetting(Ambience.TEXT_TIME, this, 6000.0, 0.0, 24000.0, 100.0);
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        int integer2 = 0;
        ClientLevel reference3 = null;
        String reference4 = null;
        int saved2 = 0;
        ClientLevel saved3 = null;
        ClientClockManagerMixin reference5 = null;
        Optional saved5 = null;
        Optional saved8 = null;
        boolean saved10 = false;
        boolean saved11 = false;
        PacketReceiveEvent saved12 = null;
        boolean saved13 = false;
        SoundPlayEvent saved14 = null;
        boolean saved15 = false;
        Identifier reference2 = null;
        boolean saved16 = false;
        boolean saved17 = false;
        boolean saved18 = false;
        boolean saved19 = false;
        boolean saved20 = false;
        boolean saved21 = false;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            integer2 = ((int) this.time.getValue());
            reference3 = Ambience.mc.level;
            reference4 = this.weather.getValue();
            saved2 = this.f667;
            if (!((integer2 != saved2))) {
                saved3 = this.f668;
                if (!((reference3 == saved3))) {
                    reference5 = ((ClientClockManagerMixin) (Object) reference3.clockManager());
                    saved5 = reference3.registryAccess().get(WorldClocks.OVERWORLD);
                    final ClientClockManagerMixin captured4 = reference5;
                    final int captured6 = integer2;
                    saved5.ifPresent((lambdaArg0) -> Ambience.onEventCallback0(captured4, captured6, ((Holder.Reference) lambdaArg0)));
                }
            } else {
                reference5 = ((ClientClockManagerMixin) (Object) reference3.clockManager());
                saved8 = reference3.registryAccess().get(WorldClocks.OVERWORLD);
                final ClientClockManagerMixin captured7 = reference5;
                final int captured9 = integer2;
                saved8.ifPresent((lambdaArg0) -> Ambience.onEventCallback0(captured7, captured9, ((Holder.Reference) lambdaArg0)));
            }
            saved10 = reference4.equals(Ambience.TEXT_RAIN);
            if (saved10) {
                reference3.setRainLevel(1.0f);
                reference3.setThunderLevel(0.0f);
            } else {
                saved11 = reference4.equals(Ambience.TEXT_THUNDER);
                if (saved11) {
                    reference3.setRainLevel(1.0f);
                    reference3.setThunderLevel(1.0f);
                } else {
                    reference3.setRainLevel(0.0f);
                    reference3.setThunderLevel(0.0f);
                }
            }
            this.f667 = integer2;
            this.f668 = Ambience.mc.level;
        }
        saved12 = Events.packetReceive;
        if (!((event != saved12))) {
            saved13 = (Events.packetReceive.getPacket() instanceof ClientboundSetTimePacket);
            if (saved13) {
                event.setCancelled(true);
            }
        }
        saved14 = Events.soundPlay;
        if (!((event != saved14))) {
            saved15 = this.cancelHitSound.getValue();
            if (saved15) {
                reference2 = Events.soundPlay.getSoundIdentifier();
                saved16 = reference2.equals(Ambience.f669);
                if (!(saved16)) {
                    saved17 = reference2.equals(Ambience.f670);
                    if (!(saved17)) {
                        saved18 = reference2.equals(Ambience.f671);
                        if (!(saved18)) {
                            saved19 = reference2.equals(Ambience.f672);
                            if (!(saved19)) {
                                saved20 = reference2.equals(Ambience.f673);
                                if (!(saved20)) {
                                    saved21 = reference2.equals(Ambience.f674);
                                    if (saved21) {
                                        event.setCancelled(true);
                                    }
                                } else {
                                    event.setCancelled(true);
                                }
                            } else {
                                event.setCancelled(true);
                            }
                        } else {
                            event.setCancelled(true);
                        }
                    } else {
                        event.setCancelled(true);
                    }
                } else {
                    event.setCancelled(true);
                }
            }
        }
    }
}
