package cryptix.module.impl.visual;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.HudRenderEvent;
import cryptix.gui.Recovered_zg;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.module.ModuleManager;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;
import cryptix.setting.PositionSetting;
import cryptix.util.Recovered_eg;
import cryptix.util.Recovered_uf;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;

/**
 * Reconstructed from a/vr.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class HUD extends Module {
    private static int f746;
    private static final String TEXT_SHOW_VERSION;
    private static final String TEXT_EMPTY;
    private static final String f744 = null;
    private static final String TEXT_FULL;
    private static final String TEXT_FADE_DISTANCE;
    private final BooleanSetting background;
    private static final String TEXT_1_0_8;
    private static final String TEXT_SHOW_FPS;
    private final BooleanSetting animation;
    private static final String TEXT_BACKGROUND;
    private final BooleanSetting showFPS;
    private static final String f743;
    private static final String TEXT_DISABLED;
    private static final String TEXT_WATERMARK;
    private static final String TEXT_EDIT_POSITION;
    private String f750;
    private static int f749;
    private final NumberSetting fadeDistance;
    private static final String TEXT_RIGHT;
    private static final String TEXT_ANIMATION;
    private static final String TEXT_1_0_8_2;
    private final ModeSetting outline;
    private static int f748;
    private static final String TEXT_HUD;
    private static final String TEXT_FPS;
    public final PositionSetting f42;
    private final BooleanSetting watermark;
    private final BooleanSetting showVersion;
    private static final String TEXT_OUTLINE;
    private static final String f742;
    private static final String TEXT_LEFT;
    private static final String TEXT_CRYPTIX;
    private static int f747;
    private int f751;
    private static final String f745 = null;
    private static final String TEXT_FPS_2;
    private static final long f752 = 150000000L;
    private static final float f753 = 6.6666668e-09f;

    public void onEnable() {
        int saved1 = 0;
        int saved2 = 0;
        int saved3 = 0;
        int saved4 = 0;
        saved1 = HUD.f746;
        if (!((saved1 == 0))) {
            saved2 = HUD.f747;
            if (!((saved2 == 0))) {
                saved3 = HUD.f748;
                if (!((saved3 == 0))) {
                    saved4 = HUD.f749;
                    if (!((saved4 != 0))) {
                        HUD.f746 = HUD.mc.font.width(HUD.f742);
                        HUD.f747 = HUD.mc.font.width(HUD.f743);
                        HUD.f748 = HUD.mc.font.width(HUD.TEXT_1_0_8_2);
                        HUD.f749 = HUD.mc.font.width(HUD.TEXT_1_0_8);
                    }
                } else {
                    HUD.f746 = HUD.mc.font.width(HUD.f742);
                    HUD.f747 = HUD.mc.font.width(HUD.f743);
                    HUD.f748 = HUD.mc.font.width(HUD.TEXT_1_0_8_2);
                    HUD.f749 = HUD.mc.font.width(HUD.TEXT_1_0_8);
                }
            } else {
                HUD.f746 = HUD.mc.font.width(HUD.f742);
                HUD.f747 = HUD.mc.font.width(HUD.f743);
                HUD.f748 = HUD.mc.font.width(HUD.TEXT_1_0_8_2);
                HUD.f749 = HUD.mc.font.width(HUD.TEXT_1_0_8);
            }
        } else {
            HUD.f746 = HUD.mc.font.width(HUD.f742);
            HUD.f747 = HUD.mc.font.width(HUD.f743);
            HUD.f748 = HUD.mc.font.width(HUD.TEXT_1_0_8_2);
            HUD.f749 = HUD.mc.font.width(HUD.TEXT_1_0_8);
        }
    }

    public void onEvent(Event event) {
        HudRenderEvent saved1 = null;
        Screen saved2 = null;
        Screen saved3 = null;
        HudRenderEvent reference2 = null;
        GuiGraphicsExtractor reference3 = null;
        saved1 = Events.hudRender;
        if (!((event != saved1))) {
            saved2 = HUD.mc.gui.screen();
            saved3 = this.f42.getEditorScreen();
            if (!((saved2 != saved3))) {
                return;
            } else {
                reference2 = Events.hudRender;
                reference3 = reference2.getGraphics();
                this.m205(reference3);
                return;
            }
        } else {
            return;
        }
    }

    public void m205(GuiGraphicsExtractor arg0) {
        int integer2 = 0;
        int integer3 = 0;
        Font reference4 = null;
        boolean saved1 = false;
        int integer5 = 0;
        int integer6 = 0;
        int saved2 = 0;
        String reference6 = null;
        int integer7 = 0;
        int integer8 = 0;
        int integer9 = 0;
        int integer10 = 0;
        int integer11 = 0;
        int integer12 = 0;
        int integer13 = 0;
        String reference14 = null;
        int integer15 = 0;
        boolean saved3 = false;
        int integer16 = 0;
        int integer17 = 0;
        List reference18 = null;
        float floating19 = 0.0f;
        int integer20 = 0;
        int integer21 = 0;
        long local22 = 0L;
        int integer24 = 0;
        int integer25 = 0;
        Module reference26 = null;
        boolean saved4 = false;
        long local27 = 0L;
        boolean saved5 = false;
        int saved6 = 0;
        String reference29 = null;
        int integer30 = 0;
        float floating31 = 0.0f;
        int saved7 = 0;
        boolean saved8 = false;
        int integer32 = 0;
        int integer33 = 0;
        int integer34 = 0;
        int integer35 = 0;
        int integer36 = 0;
        int integer37 = 0;
        String reference38 = null;
        int integer39 = 0;
        String reference41 = null;
        int saved9 = 0;
        boolean saved10 = false;
        boolean saved11 = false;
        boolean saved12 = false;
        int integer40 = 0;
        int saved13 = 0;
        boolean saved14 = false;
        int saved15 = 0;
        boolean saved16 = false;
        boolean saved17 = false;
        boolean saved18 = false;
        integer2 = (this.watermark.getValue() ? 1 : 0);
        integer3 = (this.showVersion.getValue() ? 1 : 0);
        reference4 = HUD.mc.font;
        if (!((integer2 == 0))) {
            arg0.text(reference4, HUD.f742, 5, 5, Recovered_eg.m31());
            arg0.text(reference4, HUD.f743, (5 + HUD.f746), 5, -1);
        }
        saved1 = this.showFPS.getValue();
        if (saved1) {
            integer5 = (!((integer2 == 0)) ? ((HUD.f746 + HUD.f747) + 5) : 5);
            if (!((integer3 == 0))) {
                integer5 = (integer5 + (!((integer2 == 0)) ? HUD.f748 : HUD.f749));
            }
            integer6 = HUD.mc.getFps();
            saved2 = this.f751;
            if (!((integer6 == saved2))) {
                this.f750 = ("" + (!((integer2 != 0)) ? (!((integer3 == 0)) ? HUD.TEXT_FPS_2 : HUD.TEXT_FPS) : HUD.TEXT_FPS_2) + integer6);
                this.f751 = integer6;
            }
            arg0.text(reference4, this.f750, integer5, 5, -1);
        }
        if (!((integer3 == 0))) {
            integer5 = (!((integer2 == 0)) ? ((HUD.f746 + HUD.f747) + 5) : 5);
            reference6 = (!((integer2 == 0)) ? HUD.TEXT_1_0_8_2 : HUD.TEXT_1_0_8);
            arg0.text(reference4, reference6, integer5, 5, -1);
        }
        integer5 = this.f42.getX();
        integer6 = this.f42.getY();
        integer7 = (integer6 + 5);
        integer8 = HUD.mc.getWindow().getGuiScaledWidth();
        integer9 = -1;
        integer10 = 0;
        integer11 = 0;
        Objects.requireNonNull(reference4);
        integer12 = 10;
        integer13 = ((integer8 - 5) + integer5);
        reference14 = this.outline.getValue();
        integer15 = (this.background.getValue() ? 1 : 0);
        saved3 = reference14.equals(HUD.TEXT_DISABLED);
        integer16 = (!(saved3) ? 1 : 0);
        integer17 = (reference14.equals(HUD.TEXT_FULL) ? 1 : 0);
        reference18 = ModuleManager.getSortedModules();
        floating19 = ((float) this.fadeDistance.getValue());
        integer20 = (this.animation.getValue() ? 1 : 0);
        integer21 = 0;
        local22 = System.nanoTime();
        integer24 = 0;
        integer25 = reference18.size();
        loop180: while (true) {
            if ((integer24 >= integer25)) {
                break loop180;
            }
            reference26 = ((Module) reference18.get(integer24));
            saved4 = reference26.isHidden();
            if (saved4) {
            } else {
                local27 = (local22 - reference26.getToggleTime());
                if (!((integer20 != 0))) {
                    local27 = 150000000L;
                }
                saved5 = reference26.isEnabled();
                if (!(saved5)) {
                    saved6 = JvmSupport.lcmp(local27, 150000000L);
                    if (!((saved6 < 0))) {
                    } else {
                        integer10++;
                        reference29 = reference26.getDisplayName();
                        integer30 = reference26.getDisplayWidth();
                        integer11 = integer30;
                        if (!((integer10 != 1))) {
                            this.f42.setWidth(integer30);
                        }
                        floating31 = (((float) local27) * 6.6666668e-09f);
                        saved7 = JvmSupport.fcmpl(floating31, 1.0f);
                        if (!((saved7 <= 0))) {
                            floating31 = 1.0f;
                        }
                        saved8 = reference26.isEnabled();
                        if (!(saved8)) {
                            floating31 = (1.0f - floating31);
                        }
                        floating31 = (1.0f - ((1.0f - floating31) * (1.0f - floating31)));
                        integer32 = ((int) ((1.0f - floating31) * ((float) (integer30 + 5))));
                        integer33 = ((int) ((1.0f - floating31) * 12.0f));
                        if (!((integer20 != 0))) {
                            integer32 = 0;
                            integer33 = 0;
                        }
                        integer34 = (integer13 - integer30);
                        integer35 = (integer34 + integer32);
                        integer36 = integer7;
                        integer7 = (integer7 - integer33);
                        if (!((integer15 == 0))) {
                            arg0.fill((integer34 - 3), ((integer7 - 2) + integer33), ((integer8 - 2) + integer5), (integer7 + integer12), -2147483648);
                        }
                        integer37 = Recovered_uf.m58(((int) (((float) ((integer10 - 1) * 6)) * floating19)));
                        integer21 = integer37;
                        if (!((integer16 == 0))) {
                            reference38 = reference14;
                            integer39 = -1;
                            reference41 = reference38;
                            saved9 = reference38.hashCode();
                            if (!((saved9 != 2201263))) {
                                saved10 = reference38.equals(HUD.TEXT_FULL);
                                if (saved10) {
                                    integer39 = 2;
                                }
                            } else {
                                if (!((saved9 != 2364455))) {
                                    saved11 = reference38.equals(HUD.TEXT_LEFT);
                                    if (saved11) {
                                        integer39 = 0;
                                    }
                                } else {
                                    if (!((saved9 != 78959100))) {
                                        saved12 = reference38.equals(HUD.TEXT_RIGHT);
                                        if (saved12) {
                                            integer39 = 1;
                                        }
                                    } else {
                                    }
                                }
                            }
                            switch (integer39) {
                                case 0:
                                {
                                    arg0.fill((integer34 - 4), (integer36 - 2), (integer34 - 2), (integer7 + integer12), integer37);
                                    break;
                                }
                                case 1:
                                {
                                    arg0.fill(((integer8 - 2) + integer5), (integer7 - 2), (integer8 + integer5), (integer7 + integer12), integer37);
                                    break;
                                }
                                case 2:
                                {
                                    if (!((integer10 != 1))) {
                                        arg0.fill((integer35 - 4), (integer7 - 3), ((integer8 - 2) + integer5), (integer7 - 2), integer37);
                                    }
                                    if (!((integer9 == -1))) {
                                        integer40 = (integer30 - integer9);
                                        arg0.fill((integer34 - 3), (integer36 - 3), ((integer34 + integer40) - 3), (integer36 - 2), integer37);
                                    }
                                    arg0.fill((integer34 - 4), (integer36 - 2), (integer34 - 3), (integer7 + integer12), integer37);
                                    arg0.fill((integer13 + 2), (integer7 - 2), (integer13 + 3), (integer7 + 10), integer37);
                                    break;
                                }
                                default:
                                {
                                    break;
                                }
                            }
                        }
                        arg0.text(reference4, reference29, integer35, integer7, integer37);
                        integer7 += 12;
                        integer9 = integer30;
                    }
                } else {
                    integer10++;
                    reference29 = reference26.getDisplayName();
                    integer30 = reference26.getDisplayWidth();
                    integer11 = integer30;
                    if (!((integer10 != 1))) {
                        this.f42.setWidth(integer30);
                    }
                    floating31 = (((float) local27) * 6.6666668e-09f);
                    saved13 = JvmSupport.fcmpl(floating31, 1.0f);
                    if (!((saved13 <= 0))) {
                        floating31 = 1.0f;
                    }
                    saved14 = reference26.isEnabled();
                    if (!(saved14)) {
                        floating31 = (1.0f - floating31);
                    }
                    floating31 = (1.0f - ((1.0f - floating31) * (1.0f - floating31)));
                    integer32 = ((int) ((1.0f - floating31) * ((float) (integer30 + 5))));
                    integer33 = ((int) ((1.0f - floating31) * 12.0f));
                    if (!((integer20 != 0))) {
                        integer32 = 0;
                        integer33 = 0;
                    }
                    integer34 = (integer13 - integer30);
                    integer35 = (integer34 + integer32);
                    integer36 = integer7;
                    integer7 = (integer7 - integer33);
                    if (!((integer15 == 0))) {
                        arg0.fill((integer34 - 3), ((integer7 - 2) + integer33), ((integer8 - 2) + integer5), (integer7 + integer12), -2147483648);
                    }
                    integer37 = Recovered_uf.m58(((int) (((float) ((integer10 - 1) * 6)) * floating19)));
                    integer21 = integer37;
                    if (!((integer16 == 0))) {
                        reference38 = reference14;
                        integer39 = -1;
                        reference41 = reference38;
                        saved15 = reference38.hashCode();
                        if (!((saved15 != 2201263))) {
                            saved16 = reference38.equals(HUD.TEXT_FULL);
                            if (saved16) {
                                integer39 = 2;
                            }
                        } else {
                            if (!((saved15 != 2364455))) {
                                saved17 = reference38.equals(HUD.TEXT_LEFT);
                                if (saved17) {
                                    integer39 = 0;
                                }
                            } else {
                                if (!((saved15 != 78959100))) {
                                    saved18 = reference38.equals(HUD.TEXT_RIGHT);
                                    if (saved18) {
                                        integer39 = 1;
                                    }
                                } else {
                                }
                            }
                        }
                        switch (integer39) {
                            case 0:
                            {
                                arg0.fill((integer34 - 4), (integer36 - 2), (integer34 - 2), (integer7 + integer12), integer37);
                                break;
                            }
                            case 1:
                            {
                                arg0.fill(((integer8 - 2) + integer5), (integer7 - 2), (integer8 + integer5), (integer7 + integer12), integer37);
                                break;
                            }
                            case 2:
                            {
                                if (!((integer10 != 1))) {
                                    arg0.fill((integer35 - 4), (integer7 - 3), ((integer8 - 2) + integer5), (integer7 - 2), integer37);
                                }
                                if (!((integer9 == -1))) {
                                    integer40 = (integer30 - integer9);
                                    arg0.fill((integer34 - 3), (integer36 - 3), ((integer34 + integer40) - 3), (integer36 - 2), integer37);
                                }
                                arg0.fill((integer34 - 4), (integer36 - 2), (integer34 - 3), (integer7 + integer12), integer37);
                                arg0.fill((integer13 + 2), (integer7 - 2), (integer13 + 3), (integer7 + 10), integer37);
                                break;
                            }
                            default:
                            {
                                break;
                            }
                        }
                    }
                    arg0.text(reference4, reference29, integer35, integer7, integer37);
                    integer7 += 12;
                    integer9 = integer30;
                }
            }
            integer24++;
            continue loop180;
        }
        this.f42.setHeight(((integer7 - integer6) - 4));
        if (!((integer17 == 0))) {
            if (!((integer11 == 0))) {
                integer24 = (((integer8 - integer11) - 5) + integer5);
                integer25 = integer12;
                arg0.fill((integer24 - 4), ((integer7 + integer25) - 12), ((integer8 - 2) + integer5), ((integer7 + integer25) - 11), integer21);
            }
        }
    }

    static {
        TEXT_HUD = new String("HUD");
        TEXT_OUTLINE = new String("Outline");
        TEXT_DISABLED = new String("Disabled");
        TEXT_LEFT = new String("Left");
        TEXT_RIGHT = new String("Right");
        TEXT_FULL = new String("Full");
        TEXT_FADE_DISTANCE = new String("Fade Distance");
        TEXT_EDIT_POSITION = new String("Edit Position");
        TEXT_BACKGROUND = new String("Background");
        TEXT_WATERMARK = new String("Watermark");
        TEXT_SHOW_FPS = new String("Show FPS");
        TEXT_SHOW_VERSION = new String("Show Version");
        TEXT_ANIMATION = new String("Animation");
        TEXT_EMPTY = new String("");
        TEXT_1_0_8_2 = new String(" | 1.0.8");
        TEXT_1_0_8 = new String("1.0.8");
        TEXT_FPS_2 = new String(" | FPS: ");
        TEXT_FPS = new String("FPS: ");
        TEXT_CRYPTIX = new String("Cryptix");
        f742 = HUD.TEXT_CRYPTIX.substring(0, 1);
        f743 = HUD.TEXT_CRYPTIX.substring(1);
    }

    public HUD() {
        super(HUD.TEXT_HUD, Category.VISUAL);
        this.outline = new ModeSetting(HUD.TEXT_OUTLINE, this, HUD.TEXT_DISABLED, new String[] {HUD.TEXT_DISABLED, HUD.TEXT_LEFT, HUD.TEXT_RIGHT, HUD.TEXT_FULL});
        this.fadeDistance = new NumberSetting(HUD.TEXT_FADE_DISTANCE, this, 1.0, 0.2, 2.0, 0.1);
        this.f42 = new PositionSetting(HUD.TEXT_EDIT_POSITION, this, 0, 0, 0, 0, new Recovered_zg(this));
        this.background = new BooleanSetting(HUD.TEXT_BACKGROUND, this, false);
        this.watermark = new BooleanSetting(HUD.TEXT_WATERMARK, this, false);
        this.showFPS = new BooleanSetting(HUD.TEXT_SHOW_FPS, this, false);
        this.showVersion = new BooleanSetting(HUD.TEXT_SHOW_VERSION, this, false);
        this.animation = new BooleanSetting(HUD.TEXT_ANIMATION, this, false);
        this.f750 = HUD.TEXT_EMPTY;
        this.f751 = -1;
    }
}
