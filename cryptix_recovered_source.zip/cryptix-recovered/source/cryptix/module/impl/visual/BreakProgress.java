package cryptix.module.impl.visual;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.HudRenderEvent;
import cryptix.mixin.MultiPlayerGameModeMixin;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.module.ModuleManager;
import cryptix.module.impl.player.BedAura;
import cryptix.recovery.JvmSupport;
import cryptix.render.ProjectionUtils;
import cryptix.setting.BooleanSetting;
import cryptix.util.Recovered_dl;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;

/**
 * Reconstructed from a/zx.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class BreakProgress extends Module {
    private final Recovered_dl f702;
    private String f704;
    private int f703;
    private final BooleanSetting bedAuraOnly;
    private int f705;
    private static final String TEXT_0;
    private static final String TEXT_BREAKPROGRESS;
    private static final String TEXT_BEDAURA_ONLY;

    public BreakProgress() {
        super(BreakProgress.TEXT_BREAKPROGRESS, Category.VISUAL);
        this.bedAuraOnly = new BooleanSetting(BreakProgress.TEXT_BEDAURA_ONLY, this, false);
        this.f702 = new Recovered_dl();
        this.f703 = -1;
        this.f704 = BreakProgress.TEXT_0;
    }

    public void onEvent(Event event) {
        HudRenderEvent saved1 = null;
        HudRenderEvent reference2 = null;
        GuiGraphicsExtractor reference3 = null;
        MultiPlayerGameModeMixin reference4 = null;
        BedAura reference5 = null;
        BlockPos reference6 = null;
        BlockPos reference7 = null;
        float floating8 = 0.0f;
        int saved2 = 0;
        Recovered_dl reference9 = null;
        int integer10 = 0;
        int saved3 = 0;
        boolean saved4 = false;
        boolean saved5 = false;
        int saved6 = 0;
        int saved7 = 0;
        saved1 = Events.hudRender;
        if (!((event == saved1))) {
            return;
        } else {
            reference2 = Events.hudRender;
            reference3 = reference2.getGraphics();
            reference4 = ((MultiPlayerGameModeMixin) (Object) BreakProgress.mc.gameMode);
            reference5 = ModuleManager.bedAura;
            reference6 = reference5.f24;
            if (!((reference6 == null))) {
                reference7 = reference6;
                if (!((reference7 != null))) {
                    return;
                } else {
                    floating8 = reference4.getDestroyProgress();
                    if (!((reference7 != reference6))) {
                        floating8 = reference5.f23;
                        floating8 = Mth.clamp(floating8, 0.0f, 1.0f);
                    }
                    saved2 = JvmSupport.fcmpl(floating8, 0.0f);
                    if (!((saved2 != 0))) {
                        return;
                    } else {
                        reference9 = ProjectionUtils.projectToScreen((((double) reference7.getX()) + 0.5), (((double) reference7.getY()) + 0.5), (((double) reference7.getZ()) + 0.5), this.f702);
                        if (!((reference9 != null))) {
                            return;
                        } else {
                            integer10 = ((int) (floating8 * 100.0f));
                            saved3 = this.f703;
                            if (!((integer10 == saved3))) {
                                this.f703 = integer10;
                                this.f704 = ("" + integer10 + "%");
                                this.f705 = (BreakProgress.mc.font.width(this.f704) >> 1);
                            }
                            reference3.text(BreakProgress.mc.font, this.f704, (((int) reference9.f49) - this.f705), ((int) reference9.f50), -1);
                            return;
                        }
                    }
                }
            } else {
                saved4 = this.bedAuraOnly.getValue();
                if (!(saved4)) {
                    saved5 = reference4.isDestroying();
                    reference7 = (saved5 ? reference4.getDestroyBlockPos() : null);
                    if (!((reference7 != null))) {
                        return;
                    } else {
                        floating8 = reference4.getDestroyProgress();
                        if (!((reference7 != reference6))) {
                            floating8 = reference5.f23;
                            floating8 = Mth.clamp(floating8, 0.0f, 1.0f);
                        }
                        saved6 = JvmSupport.fcmpl(floating8, 0.0f);
                        if (!((saved6 != 0))) {
                            return;
                        } else {
                            reference9 = ProjectionUtils.projectToScreen((((double) reference7.getX()) + 0.5), (((double) reference7.getY()) + 0.5), (((double) reference7.getZ()) + 0.5), this.f702);
                            if (!((reference9 != null))) {
                                return;
                            } else {
                                integer10 = ((int) (floating8 * 100.0f));
                                saved7 = this.f703;
                                if (!((integer10 == saved7))) {
                                    this.f703 = integer10;
                                    this.f704 = ("" + integer10 + "%");
                                    this.f705 = (BreakProgress.mc.font.width(this.f704) >> 1);
                                }
                                reference3.text(BreakProgress.mc.font, this.f704, (((int) reference9.f49) - this.f705), ((int) reference9.f50), -1);
                                return;
                            }
                        }
                    }
                } else {
                    return;
                }
            }
        }
    }

    static {
        TEXT_BREAKPROGRESS = new String("BreakProgress");
        TEXT_BEDAURA_ONLY = new String("BedAura Only");
        TEXT_0 = new String("0%");
    }
}
