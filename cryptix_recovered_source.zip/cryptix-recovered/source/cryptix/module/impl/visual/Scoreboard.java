package cryptix.module.impl.visual;

import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.NumberSetting;

/**
 * Reconstructed from a/xl.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Scoreboard extends Module {
    private static final String TEXT_Y;
    public final NumberSetting y;
    public final NumberSetting x;
    private static final String TEXT_X;
    private static final String TEXT_SCOREBOARD;

    public Scoreboard() {
        super(Scoreboard.TEXT_SCOREBOARD, Category.VISUAL);
        this.x = new NumberSetting(Scoreboard.TEXT_X, this, 0.0, 0.0, 1000.0, 1.0);
        this.y = new NumberSetting(Scoreboard.TEXT_Y, this, 0.0, -500.0, 500.0, 1.0);
    }

    static {
        TEXT_SCOREBOARD = new String("Scoreboard");
        TEXT_X = new String("X");
        TEXT_Y = new String("Y");
    }
}
