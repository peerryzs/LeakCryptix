package cryptix.module.impl.visual;

import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.ModeSetting;

/**
 * Reconstructed from a/ca.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Cape extends Module {
    public final ModeSetting cape;
    private static final String TEXT_PUSHY;
    private static final String TEXT_CAT;
    private static final String TEXT_CRYPTIX;
    private static final String TEXT_SKY;
    private static final String TEXT_CAPE;

    public Cape() {
        super(Cape.TEXT_CAPE, Category.VISUAL);
        this.cape = new ModeSetting(Cape.TEXT_CAPE, this, Cape.TEXT_CRYPTIX, new String[] {Cape.TEXT_CRYPTIX, Cape.TEXT_CAT, Cape.TEXT_PUSHY, Cape.TEXT_SKY});
    }

    static {
        TEXT_CAPE = new String("Cape");
        TEXT_CRYPTIX = new String("Cryptix");
        TEXT_CAT = new String("Cat");
        TEXT_PUSHY = new String("Pushy");
        TEXT_SKY = new String("Sky");
    }
}
