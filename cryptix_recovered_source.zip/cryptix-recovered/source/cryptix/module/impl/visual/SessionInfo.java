package cryptix.module.impl.visual;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.HudRenderEvent;
import cryptix.event.impl.PacketReceiveEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.util.Recovered_eg;
import net.minecraft.client.User;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;

/**
 * Reconstructed from a/gh.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class SessionInfo extends Module {
    private static final String TEXT_00_00_00;
    private static final String TEXT_KILLS_0;
    private int f811;
    private static final String TEXT_SESSION;
    private static final String TEXT_VICTORY;
    private static final String TEXT_VICTORY_2;
    private final StringBuilder f801;
    private long f808;
    private static final String TEXT_6_LVICTORY;
    private static final double f799 = 0.0002777777777777778;
    private static final double f800 = 0.016666666666666666;
    private User f807;
    private int f812;
    private String f805;
    private int f809;
    private long f806;
    private static final String TEXT_WINS_0;
    private String f816;
    private static final String TEXT_TIME;
    private String f815;
    private String f804;
    private static final String TEXT_SESSIONINFO;
    private String f803;
    private final int f813;
    private final int f814;
    private int f810;
    private String f802;

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        long local2 = 0L;
        User saved2 = null;
        User saved3 = null;
        User saved4 = null;
        String reference4 = null;
        long local4 = 0L;
        int saved5 = 0;
        long local6 = 0L;
        long local8 = 0L;
        long local10 = 0L;
        long local12 = 0L;
        int saved6 = 0;
        int saved7 = 0;
        int saved8 = 0;
        PacketReceiveEvent saved9 = null;
        Object reference2 = null;
        boolean saved10 = false;
        Object reference3 = null;
        boolean saved11 = false;
        boolean saved12 = false;
        boolean saved13 = false;
        boolean saved14 = false;
        boolean saved15 = false;
        boolean saved16 = false;
        HudRenderEvent saved17 = null;
        int integer4 = 0;
        int integer5 = 0;
        int integer6 = 0;
        int integer7 = 0;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            local2 = System.currentTimeMillis();
            saved2 = SessionInfo.mc.getUser();
            saved3 = this.f807;
            if (!((saved2 == saved3))) {
                this.f808 = local2;
                this.f809 = 0;
                this.f810 = 0;
                this.f803 = SessionInfo.TEXT_KILLS_0;
                this.f804 = SessionInfo.TEXT_WINS_0;
                this.f807 = SessionInfo.mc.getUser();
                saved4 = this.f807;
                if (!((saved4 == null))) {
                    reference4 = this.f807.getName();
                    this.f815 = ("void by " + reference4);
                    this.f816 = ("killed by " + reference4);
                }
            }
            local4 = ((local2 - this.f808) / 1000L);
            saved5 = JvmSupport.lcmp(local4, this.f806);
            if (!((saved5 == 0))) {
                this.f806 = local4;
                local6 = ((long) (((double) local4) * 0.0002777777777777778));
                local8 = (local4 - (local6 * 3600L));
                local10 = ((long) (((double) local8) * 0.016666666666666666));
                local12 = (local8 - (local10 * 60L));
                this.f801.setLength(0);
                this.f801.append(SessionInfo.TEXT_TIME);
                saved6 = JvmSupport.lcmp(local6, 10L);
                if (!((saved6 >= 0))) {
                    this.f801.append(((char) 48));
                }
                this.f801.append(local6).append(((char) 58));
                saved7 = JvmSupport.lcmp(local10, 10L);
                if (!((saved7 >= 0))) {
                    this.f801.append(((char) 48));
                }
                this.f801.append(local10).append(((char) 58));
                saved8 = JvmSupport.lcmp(local12, 10L);
                if (!((saved8 >= 0))) {
                    this.f801.append(((char) 48));
                }
                this.f801.append(local12);
                this.f802 = this.f801.toString();
            }
        }
        saved9 = Events.packetReceive;
        if (!((event != saved9))) {
            reference2 = Events.packetReceive.getPacket();
            saved10 = (reference2 instanceof ClientboundSystemChatPacket);
            if (saved10) {
                reference3 = ((ClientboundSystemChatPacket) reference2);
                reference4 = ((ClientboundSystemChatPacket) reference3).content().getString();
                saved11 = reference4.contains(this.f815);
                if (!(saved11)) {
                    saved12 = reference4.contains(this.f816);
                    if (saved12) {
                        this.f809 = (this.f809 + 1);
                        this.f803 = ("Kills: " + this.f809);
                    }
                } else {
                    this.f809 = (this.f809 + 1);
                    this.f803 = ("Kills: " + this.f809);
                }
            }
            saved13 = (reference2 instanceof ClientboundSetTitleTextPacket);
            if (saved13) {
                reference3 = ((ClientboundSetTitleTextPacket) reference2);
                reference4 = ((ClientboundSetTitleTextPacket) reference3).text().getString();
                saved14 = reference4.contains(SessionInfo.TEXT_VICTORY);
                if (!(saved14)) {
                    saved15 = reference4.contains(SessionInfo.TEXT_VICTORY_2);
                    if (!(saved15)) {
                        saved16 = reference4.equals(SessionInfo.TEXT_6_LVICTORY);
                        if (saved16) {
                            this.f810 = (this.f810 + 1);
                            this.f804 = ("Wins: " + this.f810);
                        }
                    } else {
                        this.f810 = (this.f810 + 1);
                        this.f804 = ("Wins: " + this.f810);
                    }
                } else {
                    this.f810 = (this.f810 + 1);
                    this.f804 = ("Wins: " + this.f810);
                }
            }
        }
        saved17 = Events.hudRender;
        if (!((event != saved17))) {
            reference2 = Events.hudRender.getGraphics();
            reference3 = SessionInfo.mc.font;
            integer4 = Recovered_eg.m31();
            integer5 = 20;
            integer6 = 53;
            integer7 = 5;
            ((GuiGraphicsExtractor) reference2).fill(integer7, integer5, (integer7 + 75), (integer5 + integer6), -2147483648);
            ((GuiGraphicsExtractor) reference2).outline(integer7, integer5, 75, integer6, integer4);
            ((GuiGraphicsExtractor) reference2).text(((Font) reference3), this.f805, ((integer7 + 37) - this.f812), 25, integer4);
            ((GuiGraphicsExtractor) reference2).text(((Font) reference3), this.f802, 10, 37, -1);
            ((GuiGraphicsExtractor) reference2).text(((Font) reference3), this.f803, 10, 49, -1);
            ((GuiGraphicsExtractor) reference2).text(((Font) reference3), this.f804, 10, 61, -1);
        }
    }

    static {
        TEXT_SESSIONINFO = new String("SessionInfo");
        TEXT_00_00_00 = new String("00:00:00");
        TEXT_KILLS_0 = new String("Kills: 0");
        TEXT_WINS_0 = new String("Wins: 0");
        TEXT_SESSION = new String("Session");
        TEXT_TIME = new String("Time: ");
        TEXT_VICTORY = new String("Victory!");
        TEXT_VICTORY_2 = new String("Victory");
        TEXT_6_LVICTORY = new String("\u00a76\u00a7lVICTORY!");
    }

    public SessionInfo() {
        super(SessionInfo.TEXT_SESSIONINFO, Category.VISUAL);
        this.f801 = new StringBuilder(14);
        this.f802 = SessionInfo.TEXT_00_00_00;
        this.f803 = SessionInfo.TEXT_KILLS_0;
        this.f804 = SessionInfo.TEXT_WINS_0;
        this.f805 = SessionInfo.TEXT_SESSION;
        this.f806 = -1L;
        this.f808 = 0L;
        this.f811 = -1;
        this.f812 = -1;
        this.f813 = 75;
        this.f814 = 37;
    }

    public void onEnable() {
        int saved1 = 0;
        int saved2 = 0;
        saved1 = this.f811;
        if (!((saved1 == -1))) {
            saved2 = this.f812;
            if (!((saved2 != -1))) {
                this.f811 = SessionInfo.mc.font.width(this.f805);
                this.f812 = ((int) (((double) this.f811) * 0.5));
            }
        } else {
            this.f811 = SessionInfo.mc.font.width(this.f805);
            this.f812 = ((int) (((double) this.f811) * 0.5));
        }
    }
}
