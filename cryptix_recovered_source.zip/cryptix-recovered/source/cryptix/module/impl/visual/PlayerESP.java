package cryptix.module.impl.visual;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.EntityColorEvent;
import cryptix.event.impl.HudRenderEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.module.ModuleManager;
import cryptix.recovery.JvmSupport;
import cryptix.render.ProjectionUtils;
import cryptix.setting.BooleanSetting;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;
import cryptix.util.Recovered_dl;
import cryptix.util.Recovered_eg;
import java.awt.Color;
import java.util.Iterator;
import java.util.Optional;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Team;
import net.minecraft.world.scores.TeamColor;

/**
 * Reconstructed from a/dn.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class PlayerESP extends Module {
    private final NumberSetting blue;
    private int f783;
    private static final String TEXT_GREEN;
    private boolean f786;
    private int f784;
    private final BooleanSetting outline;
    private final BooleanSetting value2D;
    private static final String TEXT_TEAM;
    private static final String TEXT_RED;
    private final NumberSetting red;
    private int f781;
    private static final String TEXT_THEME;
    private final ModeSetting color;
    private static final String TEXT_BLUE;
    private boolean f785;
    private static final String TEXT_PLAYERESP;
    private final NumberSetting green;
    private static final String TEXT_2D;
    private int f782;
    private static final String TEXT_HEALTH_BAR;
    private final BooleanSetting healthBar;
    private final Recovered_dl f780;
    private static final String TEXT_COLOR;
    private static final String TEXT_CUSTOM;
    private static final String TEXT_OUTLINE;

    public PlayerESP() {
        super(PlayerESP.TEXT_PLAYERESP, Category.VISUAL);
        this.value2D = new BooleanSetting(PlayerESP.TEXT_2D, this, false);
        this.healthBar = new BooleanSetting(PlayerESP.TEXT_HEALTH_BAR, this, false);
        this.outline = new BooleanSetting(PlayerESP.TEXT_OUTLINE, this, false);
        this.color = new ModeSetting(PlayerESP.TEXT_COLOR, this, PlayerESP.TEXT_THEME, new String[] {PlayerESP.TEXT_THEME, PlayerESP.TEXT_TEAM, PlayerESP.TEXT_CUSTOM});
        this.red = new NumberSetting(PlayerESP.TEXT_RED, this, 255.0, 0.0, 255.0, 1.0);
        this.green = new NumberSetting(PlayerESP.TEXT_GREEN, this, 255.0, 0.0, 255.0, 1.0);
        this.blue = new NumberSetting(PlayerESP.TEXT_BLUE, this, 255.0, 0.0, 255.0, 1.0);
        this.f780 = new Recovered_dl();
        this.f782 = -1;
        this.f783 = -1;
        this.f784 = -1;
    }

    private int pm$118(Player arg0) {
        PlayerTeam reference2 = null;
        int integer0 = 0;
        Optional reference3 = null;
        boolean saved1 = false;
        reference2 = arg0.getTeam();
        if (!((reference2 != null))) {
            integer0 = Color.WHITE.getRGB();
            return integer0;
        } else {
            reference3 = ((Team) (Object) reference2).getColor();
            saved1 = reference3.isPresent();
            integer0 = (saved1 ? ((TeamColor) reference3.get()).rgb() : -1);
            return integer0;
        }
    }

    private void draw2DBox(GuiGraphicsExtractor arg0, Player arg1, int arg2, float arg3, Recovered_dl arg4) {
        boolean saved1 = false;
        double number6 = 0.0;
        double number8 = 0.0;
        double number10 = 0.0;
        double number12 = 0.0;
        double number14 = 0.0;
        double number16 = 0.0;
        double number18 = 0.0;
        double number20 = 0.0;
        double number22 = 0.0;
        double number24 = 0.0;
        double number26 = 0.0;
        double number28 = 0.0;
        double number30 = 0.0;
        double number32 = 0.0;
        double number34 = 0.0;
        Recovered_dl reference36 = null;
        int integer37 = 0;
        int integer38 = 0;
        int integer39 = 0;
        int integer40 = 0;
        int integer41 = 0;
        boolean saved2 = false;
        int integer42 = 0;
        boolean saved3 = false;
        double number42 = 0.0;
        int integer44 = 0;
        int integer45 = 0;
        int saved4 = 0;
        int integer46 = 0;
        int integer47 = 0;
        int integer48 = 0;
        int integer49 = 0;
        saved1 = this.f786;
        if (saved1) {
            arg2 = this.pm$118(arg1);
        }
        number6 = 1.7976931348623157e+308;
        number8 = 1.7976931348623157e+308;
        number10 = -1.7976931348623157e+308;
        number12 = -1.7976931348623157e+308;
        number14 = (arg1.xOld + ((arg1.getX() - arg1.xOld) * ((double) arg3)));
        number16 = (arg1.yOld + ((arg1.getY() - arg1.yOld) * ((double) arg3)));
        number18 = (arg1.zOld + ((arg1.getZ() - arg1.zOld) * ((double) arg3)));
        number20 = (((double) arg1.getBbWidth()) * 0.5);
        number22 = ((double) arg1.getBbHeight());
        number24 = (number14 - number20);
        number26 = (number14 + number20);
        number28 = number16;
        number30 = ((number16 + number22) + 0.15);
        number32 = (number18 - number20);
        number34 = (number18 + number20);
        reference36 = ProjectionUtils.projectToScreen(number24, number28, number32, arg4);
        if (!((reference36 != null))) {
            return;
        } else {
            number6 = Math.min(number6, reference36.f49);
            number8 = Math.min(number8, reference36.f50);
            number10 = Math.max(number10, reference36.f49);
            number12 = Math.max(number12, reference36.f50);
            reference36 = ProjectionUtils.projectToScreen(number24, number28, number34, arg4);
            if (!((reference36 != null))) {
                return;
            } else {
                number6 = Math.min(number6, reference36.f49);
                number8 = Math.min(number8, reference36.f50);
                number10 = Math.max(number10, reference36.f49);
                number12 = Math.max(number12, reference36.f50);
                reference36 = ProjectionUtils.projectToScreen(number26, number28, number32, arg4);
                if (!((reference36 != null))) {
                    return;
                } else {
                    number6 = Math.min(number6, reference36.f49);
                    number8 = Math.min(number8, reference36.f50);
                    number10 = Math.max(number10, reference36.f49);
                    number12 = Math.max(number12, reference36.f50);
                    reference36 = ProjectionUtils.projectToScreen(number26, number28, number34, arg4);
                    if (!((reference36 != null))) {
                        return;
                    } else {
                        number6 = Math.min(number6, reference36.f49);
                        number8 = Math.min(number8, reference36.f50);
                        number10 = Math.max(number10, reference36.f49);
                        number12 = Math.max(number12, reference36.f50);
                        reference36 = ProjectionUtils.projectToScreen(number24, number30, number32, arg4);
                        if (!((reference36 != null))) {
                            return;
                        } else {
                            number6 = Math.min(number6, reference36.f49);
                            number8 = Math.min(number8, reference36.f50);
                            number10 = Math.max(number10, reference36.f49);
                            number12 = Math.max(number12, reference36.f50);
                            reference36 = ProjectionUtils.projectToScreen(number24, number30, number34, arg4);
                            if (!((reference36 != null))) {
                                return;
                            } else {
                                number6 = Math.min(number6, reference36.f49);
                                number8 = Math.min(number8, reference36.f50);
                                number10 = Math.max(number10, reference36.f49);
                                number12 = Math.max(number12, reference36.f50);
                                reference36 = ProjectionUtils.projectToScreen(number26, number30, number32, arg4);
                                if (!((reference36 != null))) {
                                    return;
                                } else {
                                    number6 = Math.min(number6, reference36.f49);
                                    number8 = Math.min(number8, reference36.f50);
                                    number10 = Math.max(number10, reference36.f49);
                                    number12 = Math.max(number12, reference36.f50);
                                    reference36 = ProjectionUtils.projectToScreen(number26, number30, number34, arg4);
                                    if (!((reference36 != null))) {
                                        return;
                                    } else {
                                        number6 = Math.min(number6, reference36.f49);
                                        number8 = Math.min(number8, reference36.f50);
                                        number10 = Math.max(number10, reference36.f49);
                                        number12 = Math.max(number12, reference36.f50);
                                        integer37 = ((int) number6);
                                        integer38 = ((int) number8);
                                        integer39 = ((int) number10);
                                        integer40 = ((int) number12);
                                        integer41 = 1;
                                        saved2 = this.value2D.getValue();
                                        if (saved2) {
                                            integer42 = 1;
                                            arg0.fill((integer37 - integer42), (integer38 - integer42), (integer39 + integer42), ((integer38 + integer42) + integer41), -16777216);
                                            arg0.fill((integer37 - integer42), ((integer40 - integer42) - integer41), (integer39 + integer42), (integer40 + integer42), -16777216);
                                            arg0.fill((integer37 - integer42), (integer38 - integer42), ((integer37 + integer42) + integer41), (integer40 + integer42), -16777216);
                                            arg0.fill(((integer39 - integer42) - integer41), (integer38 - integer42), (integer39 + integer42), (integer40 + integer42), -16777216);
                                            arg0.fill(integer37, integer38, integer39, (integer38 + integer41), arg2);
                                            arg0.fill(integer37, (integer40 - integer41), integer39, integer40, arg2);
                                            arg0.fill(integer37, integer38, (integer37 + integer41), integer40, arg2);
                                            arg0.fill((integer39 - integer41), integer38, integer39, integer40, arg2);
                                        }
                                        saved3 = this.healthBar.getValue();
                                        if (saved3) {
                                            number42 = Math.clamp(((double) (arg1.getHealth() / arg1.getMaxHealth())), 0.0, 1.0);
                                            integer44 = Recovered_eg.m30(((float) number42));
                                            integer45 = Math.max(1, (integer40 - integer38));
                                            saved4 = JvmSupport.fcmpl(arg1.getHealth(), 0.0f);
                                            integer46 = Math.max((!((saved4 <= 0)) ? 1 : 0), ((int) Math.ceil((((double) integer45) * number42))));
                                            integer47 = 4;
                                            integer48 = (integer37 - integer47);
                                            integer49 = (integer48 + 1);
                                            arg0.fill((integer48 - 1), (integer38 - 1), (integer49 + 1), ((integer38 + integer45) + 1), -16777216);
                                            arg0.fill(integer48, integer38, integer49, (integer38 + integer45), -11513776);
                                            if (!((integer46 <= 0))) {
                                                arg0.fill(integer48, ((integer38 + integer45) - integer46), integer49, (integer38 + integer45), integer44);
                                            }
                                        }
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    static {
        TEXT_PLAYERESP = new String("PlayerESP");
        TEXT_2D = new String("2D");
        TEXT_HEALTH_BAR = new String("Health bar");
        TEXT_OUTLINE = new String("Outline");
        TEXT_COLOR = new String("Color");
        TEXT_THEME = new String("Theme");
        TEXT_TEAM = new String("Team");
        TEXT_CUSTOM = new String("Custom");
        TEXT_RED = new String("Red");
        TEXT_GREEN = new String("Green");
        TEXT_BLUE = new String("Blue");
    }

    public void onEvent(Event event) {
        HudRenderEvent saved1 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        Object reference2 = null;
        float floating3 = 0.0f;
        boolean saved4 = false;
        int integer4 = 0;
        Iterator reference5 = null;
        boolean saved5 = false;
        Player reference6 = null;
        boolean saved6 = false;
        LocalPlayer saved7 = null;
        boolean saved8 = false;
        boolean saved9 = false;
        boolean saved10 = false;
        LocalPlayer saved11 = null;
        EntityColorEvent saved12 = null;
        boolean saved13 = false;
        boolean saved14 = false;
        LocalPlayer saved15 = null;
        boolean saved16 = false;
        boolean saved17 = false;
        int integer3 = 0;
        boolean saved18 = false;
        RotationEvent saved19 = null;
        RotationEvent saved20 = null;
        RotationEvent saved21 = null;
        saved1 = Events.hudRender;
        if (!((event != saved1))) {
            saved2 = this.value2D.getValue();
            if (!(saved2)) {
                saved3 = this.healthBar.getValue();
                if (saved3) {
                    reference2 = Events.hudRender.getGraphics();
                    floating3 = Events.hudRender.getPartialTick();
                    saved4 = this.f785;
                    if (saved4) {
                        integer4 = Recovered_eg.m31();
                    } else {
                        integer4 = this.pm$119();
                    }
                    reference5 = PlayerESP.mc.level.players().iterator();
                    loop31: while (true) {
                        saved5 = reference5.hasNext();
                        if (!(saved5)) {
                            break loop31;
                        }
                        reference6 = ((Player) reference5.next());
                        saved6 = ModuleManager.antiBot.m140(reference6);
                        if (saved6) {
                            continue loop31;
                        }
                        saved7 = PlayerESP.mc.player;
                        if (!((reference6 == saved7))) {
                            this.draw2DBox(((GuiGraphicsExtractor) reference2), reference6, integer4, floating3, this.f780);
                        }
                        continue loop31;
                    }
                }
            } else {
                reference2 = Events.hudRender.getGraphics();
                floating3 = Events.hudRender.getPartialTick();
                saved8 = this.f785;
                if (saved8) {
                    integer4 = Recovered_eg.m31();
                } else {
                    integer4 = this.pm$119();
                }
                reference5 = PlayerESP.mc.level.players().iterator();
                loop31: while (true) {
                    saved9 = reference5.hasNext();
                    if (!(saved9)) {
                        break loop31;
                    }
                    reference6 = ((Player) reference5.next());
                    saved10 = ModuleManager.antiBot.m140(reference6);
                    if (saved10) {
                        continue loop31;
                    }
                    saved11 = PlayerESP.mc.player;
                    if (!((reference6 == saved11))) {
                        this.draw2DBox(((GuiGraphicsExtractor) reference2), reference6, integer4, floating3, this.f780);
                    }
                    continue loop31;
                }
            }
        }
        saved12 = Events.entityColor;
        if (!((event != saved12))) {
            saved13 = this.outline.getValue();
            if (saved13) {
                reference2 = Events.entityColor.getEntity();
                saved14 = ModuleManager.antiBot.m140(Events.entityColor.getEntity());
                if (!(saved14)) {
                    saved15 = PlayerESP.mc.player;
                    if (!((reference2 == saved15))) {
                        saved16 = (reference2 instanceof Player);
                        if (!(saved16)) {
                            return;
                        } else {
                            saved17 = this.f785;
                            if (saved17) {
                                integer3 = Recovered_eg.m31();
                            } else {
                                saved18 = this.f786;
                                if (saved18) {
                                    integer3 = this.pm$118(((Player) reference2));
                                } else {
                                    integer3 = this.pm$119();
                                }
                            }
                            Events.entityColor.setColor(integer3);
                            saved19 = Events.rotation;
                            if (!((event != saved19))) {
                                this.f785 = this.color.is(PlayerESP.TEXT_THEME);
                                this.f786 = this.color.is(PlayerESP.TEXT_TEAM);
                            }
                            return;
                        }
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            } else {
                saved20 = Events.rotation;
                if (!((event != saved20))) {
                    this.f785 = this.color.is(PlayerESP.TEXT_THEME);
                    this.f786 = this.color.is(PlayerESP.TEXT_TEAM);
                }
                return;
            }
        } else {
            saved21 = Events.rotation;
            if (!((event != saved21))) {
                this.f785 = this.color.is(PlayerESP.TEXT_THEME);
                this.f786 = this.color.is(PlayerESP.TEXT_TEAM);
            }
            return;
        }
    }

    private int pm$119() {
        int integer1 = 0;
        int integer2 = 0;
        int integer3 = 0;
        int saved1 = 0;
        int saved2 = 0;
        int saved3 = 0;
        int integer0 = 0;
        integer1 = ((int) this.red.getValue());
        integer2 = ((int) this.green.getValue());
        integer3 = ((int) this.blue.getValue());
        saved1 = this.f782;
        if (!((integer1 != saved1))) {
            saved2 = this.f783;
            if (!((integer2 != saved2))) {
                saved3 = this.f784;
                if (!((integer3 == saved3))) {
                    this.f782 = integer1;
                    this.f783 = integer2;
                    this.f784 = integer3;
                    this.f781 = ((((integer1 << 16) | (integer2 << 8)) | integer3) | -16777216);
                }
            } else {
                this.f782 = integer1;
                this.f783 = integer2;
                this.f784 = integer3;
                this.f781 = ((((integer1 << 16) | (integer2 << 8)) | integer3) | -16777216);
            }
        } else {
            this.f782 = integer1;
            this.f783 = integer2;
            this.f784 = integer3;
            this.f781 = ((((integer1 << 16) | (integer2 << 8)) | integer3) | -16777216);
        }
        integer0 = this.f781;
        return integer0;
    }
}
