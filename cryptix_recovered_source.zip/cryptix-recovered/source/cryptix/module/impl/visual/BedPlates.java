package cryptix.module.impl.visual;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.HudRenderEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.render.ProjectionUtils;
import cryptix.setting.NumberSetting;
import cryptix.util.BedPlateEntry;
import cryptix.util.Recovered_dl;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.Property;

/**
 * Reconstructed from a/uk.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class BedPlates extends Module {
    private static final String TEXT_BEDPLATES;
    private static final String TEXT_RANGE;
    private NumberSetting range;
    private BlockPos.MutableBlockPos f696;
    private final List f697;

    public BedPlates() {
        super(BedPlates.TEXT_BEDPLATES, Category.VISUAL);
        this.range = new NumberSetting(BedPlates.TEXT_RANGE, this, 16.0, 8.0, 32.0, 1.0);
        this.f696 = new BlockPos.MutableBlockPos();
        this.f697 = new ArrayList();
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        Object reference2 = null;
        int integer3 = 0;
        int integer4 = 0;
        int integer5 = 0;
        int integer6 = 0;
        int integer7 = 0;
        int integer8 = 0;
        int saved2 = 0;
        int integer9 = 0;
        int integer10 = 0;
        int saved3 = 0;
        int integer11 = 0;
        int integer12 = 0;
        int integer13 = 0;
        BlockState reference14 = null;
        boolean saved4 = false;
        Comparable saved5 = null;
        BedPart saved6 = null;
        BlockState reference15 = null;
        boolean saved7 = false;
        ItemStack reference16 = null;
        boolean saved8 = false;
        HudRenderEvent saved9 = null;
        Recovered_dl reference3 = null;
        Iterator reference4 = null;
        boolean saved10 = false;
        BedPlateEntry reference5 = null;
        Recovered_dl reference6 = null;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            this.f697.clear();
            reference2 = BedPlates.mc.player.blockPosition();
            integer3 = ((BlockPos) reference2).getX();
            integer4 = ((BlockPos) reference2).getY();
            integer5 = ((BlockPos) reference2).getZ();
            integer6 = ((int) this.range.getValue());
            integer7 = (integer6 * integer6);
            integer8 = (-integer6);
            loop31: while (true) {
                if ((integer8 > integer6)) {
                    break loop31;
                }
                saved2 = (integer8 * integer8);
                if (!((saved2 <= integer7))) {
                } else {
                    integer9 = (integer3 + integer8);
                    integer10 = (-integer6);
                    loop47: while (true) {
                        if ((integer10 > integer6)) {
                            break loop47;
                        }
                        saved3 = ((integer8 * integer8) + (integer10 * integer10));
                        if (!((saved3 <= integer7))) {
                        } else {
                            integer11 = (integer5 + integer10);
                            integer12 = -4;
                            loop66: while (true) {
                                if ((integer12 > 4)) {
                                    break loop66;
                                }
                                integer13 = (integer4 + integer12);
                                this.f696.set(integer9, integer13, integer11);
                                reference14 = BedPlates.mc.level.getBlockState(((BlockPos) (Object) this.f696));
                                saved4 = (reference14.getBlock() instanceof BedBlock);
                                if (!(saved4)) {
                                } else {
                                    saved5 = reference14.getValue(((Property) (Object) BedBlock.PART));
                                    saved6 = BedPart.FOOT;
                                    if (!((saved5 == saved6))) {
                                    } else {
                                        this.f696.set(integer9, (integer13 + 1), integer11);
                                        reference15 = BedPlates.mc.level.getBlockState(((BlockPos) (Object) this.f696));
                                        saved7 = reference15.isAir();
                                        if (saved7) {
                                        } else {
                                            reference16 = new ItemStack(((ItemLike) (Object) reference15.getBlock().asItem()));
                                            saved8 = reference16.isEmpty();
                                            if (!(saved8)) {
                                                this.f697.add(new BedPlateEntry(integer9, integer13, integer11, reference16));
                                            }
                                        }
                                    }
                                }
                                integer12++;
                                continue loop66;
                            }
                        }
                        integer10++;
                        continue loop47;
                    }
                }
                integer8++;
                continue loop31;
            }
        }
        saved9 = Events.hudRender;
        if (!((event != saved9))) {
            reference2 = ((HudRenderEvent) (Object) event);
            reference3 = new Recovered_dl();
            reference4 = this.f697.iterator();
            loop157: while (true) {
                saved10 = reference4.hasNext();
                if (!(saved10)) {
                    break loop157;
                }
                reference5 = ((BedPlateEntry) reference4.next());
                reference6 = ProjectionUtils.projectToScreen((((double) reference5.x) + 0.5), (((double) reference5.y) + 1.5), (((double) reference5.z) + 0.5), reference3);
                if (!((reference6 != null))) {
                    continue loop157;
                }
                integer7 = ((int) reference6.f49);
                integer8 = ((int) reference6.f50);
                integer9 = 10;
                ((HudRenderEvent) reference2).getGraphics().fill((integer7 - integer9), (integer8 - integer9), (integer7 + integer9), (integer8 + integer9), -2147483648);
                ((HudRenderEvent) reference2).getGraphics().item(reference5.stack, ((integer7 - integer9) + 2), ((integer8 - integer9) + 2));
                continue loop157;
            }
        }
    }

    static {
        TEXT_BEDPLATES = new String("BedPlates");
        TEXT_RANGE = new String("Range");
    }
}
