package cryptix.module.impl.visual;

import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.NumberSetting;

/**
 * Reconstructed from a/bo.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Hotbar extends Module {
    private static final String TEXT_ANIMATION_TIME;
    private static final String TEXT_HOTBAR;
    public final NumberSetting animationTime;

    static {
        TEXT_HOTBAR = new String("Hotbar");
        TEXT_ANIMATION_TIME = new String("Animation Time");
    }

    public Hotbar() {
        super(Hotbar.TEXT_HOTBAR, Category.VISUAL);
        this.animationTime = new NumberSetting(Hotbar.TEXT_ANIMATION_TIME, this, 100.0, 50.0, 200.0, 25.0);
    }
}
