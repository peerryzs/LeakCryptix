package cryptix.module.impl.visual;

import cryptix.module.Category;
import cryptix.module.Module;

/**
 * Reconstructed from a/nz.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class AntiFire extends Module {
    private static final String TEXT_ANTIFIRE;

    static {
        TEXT_ANTIFIRE = new String("AntiFire");
    }

    public AntiFire() {
        super(AntiFire.TEXT_ANTIFIRE, Category.VISUAL);
    }
}
