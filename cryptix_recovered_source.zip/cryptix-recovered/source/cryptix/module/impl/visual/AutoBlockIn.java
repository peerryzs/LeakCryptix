package cryptix.module.impl.visual;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.NumberSetting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Reconstructed from a/vv.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class AutoBlockIn extends Module {
    private final Direction[] f478;
    private static final String TEXT_AUTOBLOCKIN;
    private int f479;
    private final BooleanSetting onlyWhileSneaking;
    private final NumberSetting delay;
    private static final String TEXT_ONLY_WHILE_SNEAKING;
    private static final String TEXT_DELAY;

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        BlockPos reference2 = null;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            saved2 = this.onlyWhileSneaking.getValue();
            if (saved2) {
                saved3 = AutoBlockIn.mc.options.keyShift.isDown();
                if (!(saved3)) {
                    this.f479 = 0;
                    return;
                } else {
                    this.f479 = (this.f479 + 1);
                    reference2 = AutoBlockIn.mc.player.blockPosition();
                    this.pm$89(reference2.relative(Direction.NORTH));
                    this.pm$89(reference2.relative(Direction.NORTH).relative(Direction.UP));
                    this.pm$89(reference2.relative(Direction.SOUTH));
                    this.pm$89(reference2.relative(Direction.SOUTH).relative(Direction.UP));
                    this.pm$89(reference2.relative(Direction.EAST));
                    this.pm$89(reference2.relative(Direction.EAST).relative(Direction.UP));
                    this.pm$89(reference2.relative(Direction.WEST));
                    this.pm$89(reference2.relative(Direction.WEST).relative(Direction.UP));
                    return;
                }
            } else {
                this.f479 = (this.f479 + 1);
                reference2 = AutoBlockIn.mc.player.blockPosition();
                this.pm$89(reference2.relative(Direction.NORTH));
                this.pm$89(reference2.relative(Direction.NORTH).relative(Direction.UP));
                this.pm$89(reference2.relative(Direction.SOUTH));
                this.pm$89(reference2.relative(Direction.SOUTH).relative(Direction.UP));
                this.pm$89(reference2.relative(Direction.EAST));
                this.pm$89(reference2.relative(Direction.EAST).relative(Direction.UP));
                this.pm$89(reference2.relative(Direction.WEST));
                this.pm$89(reference2.relative(Direction.WEST).relative(Direction.UP));
                return;
            }
        } else {
            return;
        }
    }

    private void pm$89(BlockPos arg0) {
        boolean saved1 = false;
        int saved2 = 0;
        Vec3 reference2 = null;
        Direction[] reference3 = null;
        int integer4 = 0;
        int integer5 = 0;
        Object reference6 = null;
        BlockPos reference7 = null;
        boolean saved3 = false;
        Vec3 reference8 = null;
        double number9 = 0.0;
        double number11 = 0.0;
        double number13 = 0.0;
        double number15 = 0.0;
        float floating17 = 0.0f;
        float floating18 = 0.0f;
        Vec3 reference19 = null;
        BlockHitResult reference20 = null;
        boolean saved4 = false;
        Direction saved5 = null;
        saved1 = AutoBlockIn.mc.level.getBlockState(arg0).canBeReplaced();
        if (!(saved1)) {
            return;
        } else {
            saved2 = JvmSupport.dcmpg(((double) this.f479), this.delay.getValue());
            if (!((saved2 >= 0))) {
                return;
            } else {
                reference2 = AutoBlockIn.mc.player.getEyePosition();
                reference3 = this.f478;
                integer4 = reference3.length;
                integer5 = 0;
                loop28: while (true) {
                    if ((integer5 >= integer4)) {
                        break loop28;
                    }
                    reference6 = reference3[integer5];
                    reference7 = arg0.relative(((Direction) reference6).getOpposite());
                    saved3 = AutoBlockIn.mc.level.getBlockState(reference7).isFaceSturdy(((BlockGetter) (Object) AutoBlockIn.mc.level), reference7, ((Direction) reference6));
                    if (!(saved3)) {
                        integer5++;
                        continue loop28;
                    }
                    reference8 = Vec3.atCenterOf(((Vec3i) (Object) reference7)).add((((double) ((Direction) reference6).getStepX()) * 0.499), (((double) ((Direction) reference6).getStepY()) * 0.499), (((double) ((Direction) reference6).getStepZ()) * 0.499));
                    number9 = (reference8.x - reference2.x);
                    number11 = (reference8.y - reference2.y);
                    number13 = (reference8.z - reference2.z);
                    number15 = Math.sqrt(((number9 * number9) + (number13 * number13)));
                    floating17 = (((float) Math.toDegrees(Math.atan2(number13, number9))) - 90.0f);
                    floating18 = ((float) (-Math.toDegrees(Math.atan2(number11, number15))));
                    reference19 = Vec3.directionFromRotation(floating18, floating17).scale(4.5);
                    reference20 = AutoBlockIn.mc.level.clip(new ClipContext(reference2, reference2.add(reference19), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, AutoBlockIn.mc.player));
                    saved4 = reference20.getBlockPos().equals(reference7);
                    if (!(saved4)) {
                        integer5++;
                        continue loop28;
                    }
                    saved5 = reference20.getDirection();
                    if (!((saved5 == reference6))) {
                        integer5++;
                        continue loop28;
                    }
                    AutoBlockIn.mc.player.setYRot(floating17);
                    AutoBlockIn.mc.player.setXRot(floating18);
                    AutoBlockIn.mc.gameMode.useItemOn(AutoBlockIn.mc.player, InteractionHand.MAIN_HAND, reference20);
                    this.f479 = 0;
                    return;
                }
                return;
            }
        }
    }

    static {
        TEXT_AUTOBLOCKIN = new String("AutoBlockIn");
        TEXT_DELAY = new String("Delay");
        TEXT_ONLY_WHILE_SNEAKING = new String("Only While Sneaking");
    }

    public AutoBlockIn() {
        super(AutoBlockIn.TEXT_AUTOBLOCKIN, Category.VISUAL);
        this.delay = new NumberSetting(AutoBlockIn.TEXT_DELAY, this, 1.0, 0.0, 4.0, 1.0);
        this.onlyWhileSneaking = new BooleanSetting(AutoBlockIn.TEXT_ONLY_WHILE_SNEAKING, this, false);
        this.f478 = new Direction[] {Direction.DOWN, Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};
    }
}
