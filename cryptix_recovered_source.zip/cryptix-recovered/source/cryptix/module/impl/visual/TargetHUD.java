package cryptix.module.impl.visual;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.HudRenderEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.gui.Recovered_sy;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.module.ModuleManager;
import cryptix.module.impl.combat.KillAura;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.util.Recovered_eg;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.PlayerSkin;

/**
 * Reconstructed from a/xz.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class TargetHUD extends Module {
    private int f865;
    private final BooleanSetting showWinOrLoss;
    private static final String TEXT_HP_7;
    private static final String TEXT_PLAYER;
    private static final String TEXT_HP_10;
    private static final String TEXT_HEALTH_ANIMATION;
    private static final String TEXT_HP_15;
    private static final String TEXT_HP_8;
    private int f863;
    private Player f861;
    private float f855;
    private int f866;
    private String f862;
    private static final String TEXT_HP_11;
    private Identifier f860;
    private static final String TEXT_CL;
    private static final String TEXT_HP_18;
    private static final String TEXT_HP_6;
    private float f854;
    private static final String TEXT_HP_3;
    private static final String TEXT_SHOW_WIN_OR_LOSS;
    private static final String TEXT_HP_16;
    private int f857;
    private static final String TEXT_HP_19;
    private float f856;
    private int f858;
    private static final String TEXT_HP_20;
    private final BooleanSetting editPosition;
    private static final String TEXT_AW;
    private final BooleanSetting healthAnimation;
    private static final String TEXT_TARGETHUD;
    private static final String TEXT_HP_9;
    private int f867;
    private static final String TEXT_HP_0;
    private final BooleanSetting themeColor;
    private static final String[] f869;
    private static final String TEXT_HP_1;
    private static final String TEXT_HP_14;
    private float f853;
    private static final String TEXT_HP_12;
    private static final String TEXT_THEME_COLOR;
    private static final String TEXT_EMPTY;
    private Recovered_sy f868;
    private static final String TEXT_HP_5;
    private static final String TEXT_EDIT_POSITION;
    private static final String TEXT_HP_4;
    private final BooleanSetting outline;
    private static final String TEXT_OUTLINE;
    private Player f859;
    private static final String TEXT_HP_13;
    private int f864;
    private static final String TEXT_HP_2;
    private static final String TEXT_HP_17;

    public void onEvent(Event event) {
        HudRenderEvent saved1 = null;
        Screen saved2 = null;
        Recovered_sy saved3 = null;
        RotationEvent saved4 = null;
        boolean saved5 = false;
        BooleanSetting saved6 = null;
        boolean saved7 = false;
        KillAura reference2 = null;
        boolean saved8 = false;
        int branchValue9 = 0;
        int integer3 = 0;
        float floating4 = 0.0f;
        Player reference5 = null;
        RotationEvent saved10 = null;
        boolean saved11 = false;
        BooleanSetting saved12 = null;
        boolean saved13 = false;
        boolean saved14 = false;
        int branchValue15 = 0;
        saved1 = Events.hudRender;
        if (!((event != saved1))) {
            saved2 = TargetHUD.mc.gui.screen();
            saved3 = this.f868;
            if (!((saved2 != saved3))) {
                return;
            } else {
                this.render(Events.hudRender);
                saved4 = Events.rotation;
                if (!((event != saved4))) {
                    saved5 = this.editPosition.getValue();
                    if (saved5) {
                        TargetHUD.mc.gui.setScreen(this.f868);
                        saved6 = this.editPosition;
                        saved7 = this.editPosition.getValue();
                        saved6.setValue(((!(saved7) ? 1 : 0) != 0));
                    }
                    reference2 = ModuleManager.killAura;
                    if (!((reference2 == null))) {
                        saved8 = (reference2.f18 instanceof Player);
                        branchValue9 = (saved8 ? 1 : 0);
                    } else {
                        branchValue9 = 0;
                    }
                    integer3 = branchValue9;
                    floating4 = (!((integer3 == 0)) ? 255.0f : 0.0f);
                    this.f858 = this.f857;
                    this.f857 = ((int) Mth.lerp(0.5f, ((float) this.f857), floating4));
                    if (!((integer3 != 0))) {
                        return;
                    } else {
                        reference5 = ((Player) (Object) reference2.f18);
                        this.f855 = this.f854;
                        this.f854 = this.f853;
                        this.f853 = this.f856;
                        this.f856 = reference5.getHealth();
                        return;
                    }
                } else {
                    return;
                }
            }
        } else {
            saved10 = Events.rotation;
            if (!((event != saved10))) {
                saved11 = this.editPosition.getValue();
                if (saved11) {
                    TargetHUD.mc.gui.setScreen(this.f868);
                    saved12 = this.editPosition;
                    saved13 = this.editPosition.getValue();
                    saved12.setValue(((!(saved13) ? 1 : 0) != 0));
                }
                reference2 = ModuleManager.killAura;
                if (!((reference2 == null))) {
                    saved14 = (reference2.f18 instanceof Player);
                    branchValue15 = (saved14 ? 1 : 0);
                } else {
                    branchValue15 = 0;
                }
                integer3 = branchValue15;
                floating4 = (!((integer3 == 0)) ? 255.0f : 0.0f);
                this.f858 = this.f857;
                this.f857 = ((int) Mth.lerp(0.5f, ((float) this.f857), floating4));
                if (!((integer3 != 0))) {
                    return;
                } else {
                    reference5 = ((Player) (Object) reference2.f18);
                    this.f855 = this.f854;
                    this.f854 = this.f853;
                    this.f853 = this.f856;
                    this.f856 = reference5.getHealth();
                    return;
                }
            } else {
                return;
            }
        }
    }

    private void render(HudRenderEvent arg0) {
        KillAura reference2 = null;
        boolean saved1 = false;
        Player saved2 = null;
        int saved3 = 0;
        int branchValue4 = 0;
        int branchValue5 = 0;
        int integer3 = 0;
        boolean saved6 = false;
        Player reference4 = null;
        Player saved7 = null;
        CompletableFuture saved9 = null;
        int integer5 = 0;
        int integer6 = 0;
        int integer7 = 0;
        int integer8 = 0;
        int integer9 = 0;
        float floating10 = 0.0f;
        float floating11 = 0.0f;
        float floating12 = 0.0f;
        float floating13 = 0.0f;
        float floating14 = 0.0f;
        GuiGraphicsExtractor reference15 = null;
        int integer16 = 0;
        int integer17 = 0;
        int integer18 = 0;
        int integer19 = 0;
        int integer20 = 0;
        int integer21 = 0;
        int integer22 = 0;
        Object reference23 = null;
        boolean saved10 = false;
        boolean saved11 = false;
        int saved12 = 0;
        boolean saved13 = false;
        int saved14 = 0;
        String reference24 = null;
        Identifier saved15 = null;
        reference2 = ModuleManager.killAura;
        if (!((reference2 != null))) {
            return;
        } else {
            saved1 = (reference2.f18 instanceof Player);
            if (!(saved1)) {
                saved2 = this.f859;
                if (!((saved2 == null))) {
                    saved3 = this.f857;
                    branchValue4 = (!((saved3 <= 10)) ? 1 : 0);
                } else {
                    branchValue4 = 0;
                }
                branchValue5 = branchValue4;
            } else {
                branchValue5 = 1;
            }
            integer3 = branchValue5;
            if (!((integer3 != 0))) {
                return;
            } else {
                saved6 = (reference2.f18 instanceof Player);
                reference4 = (saved6 ? ((Player) (Object) reference2.f18) : this.f859);
                saved7 = this.f861;
                if (!((saved7 == reference4))) {
                    this.f861 = reference4;
                    this.f860 = null;
                    this.f862 = reference4.getDisplayName().getString();
                    this.f863 = TargetHUD.mc.font.width(this.f862);
                    saved9 = TargetHUD.mc.getSkinManager().get(reference4.getGameProfile());
                    final TargetHUD captured8 = this;
                    saved9.thenAccept((lambdaArg0) -> captured8.renderCallback0(((Optional) lambdaArg0)));
                }
                integer5 = TargetHUD.mc.getWindow().getGuiScaledWidth();
                integer6 = TargetHUD.mc.getWindow().getGuiScaledHeight();
                integer7 = ((integer5 >> 1) + this.m213());
                integer8 = ((integer6 >> 1) + this.m214());
                integer9 = Math.max(80, (48 + this.f863));
                floating10 = Mth.lerp(arg0.getPartialTick(), this.f855, this.f854);
                floating11 = Mth.lerp(arg0.getPartialTick(), this.f853, this.f856);
                floating12 = reference4.getMaxHealth();
                floating13 = (floating11 / floating12);
                floating14 = (floating10 / floating12);
                reference15 = arg0.getGraphics();
                integer16 = Recovered_eg.m31();
                integer17 = (this.themeColor.getValue() ? 1 : 0);
                integer18 = (!((integer17 == 0)) ? integer16 : Recovered_eg.m30(floating13));
                integer19 = integer18;
                integer19 = ((integer19 & 16777215) | 1677721600);
                integer20 = ((int) (((float) this.f858) + (((float) (this.f857 - this.f858)) * arg0.getPartialTick())));
                integer18 = ((integer20 << 24) | (integer18 & 16777215));
                integer21 = (((integer20 * 128) / 254) << 24);
                integer22 = Math.round(floating11);
                if (!((integer22 >= 0))) {
                    integer22 = 0;
                } else {
                    if (!((integer22 <= 20))) {
                        integer22 = 20;
                    }
                }
                reference23 = TargetHUD.f869[integer22];
                reference15.fill(integer7, integer8, (integer7 + integer9), (integer8 + 42), integer21);
                saved10 = this.outline.getValue();
                if (saved10) {
                    reference15.fill(integer7, integer8, (integer7 + 1), (integer8 + 42), ((integer20 << 24) | (integer16 & 16777215)));
                    reference15.fill(((integer7 + integer9) - 1), integer8, (integer7 + integer9), (integer8 + 42), ((integer20 << 24) | (integer16 & 16777215)));
                    reference15.fill(integer7, integer8, (integer7 + integer9), (integer8 + 1), ((integer20 << 24) | (integer16 & 16777215)));
                    reference15.fill(integer7, (integer8 + 41), (integer7 + integer9), (integer8 + 42), ((integer20 << 24) | (integer16 & 16777215)));
                }
                saved11 = this.healthAnimation.getValue();
                if (saved11) {
                    saved12 = this.f857;
                    if (!((saved12 <= 200))) {
                        reference15.fill((integer7 + 4), (integer8 + 34), ((integer7 + 8) + ((int) (((float) (integer9 - 12)) * floating14))), (integer8 + 38), integer19);
                    }
                }
                reference15.fill((integer7 + 4), (integer8 + 34), ((integer7 + 8) + ((int) (((float) (integer9 - 12)) * floating13))), (integer8 + 38), integer18);
                saved13 = this.showWinOrLoss.getValue();
                if (saved13) {
                    saved14 = JvmSupport.fcmpg(reference4.getHealth(), TargetHUD.mc.player.getHealth());
                    reference24 = (!((saved14 > 0)) ? TargetHUD.TEXT_AW : TargetHUD.TEXT_CL);
                    reference15.text(TargetHUD.mc.font, reference24, ((integer7 + integer9) - 10), (integer8 + 5), ((integer20 << 24) | 16777215), false);
                }
                reference15.text(TargetHUD.mc.font, this.f862, (integer7 + 34), (integer8 + 5), ((integer20 << 24) | 16777215), false);
                reference15.text(TargetHUD.mc.font, ((String) reference23), ((integer7 + integer9) - 35), (integer8 + 22), integer18, false);
                saved15 = this.f860;
                if (!((saved15 == null))) {
                    reference15.blit(RenderPipelines.GUI_TEXTURED, this.f860, (integer7 + 4), (integer8 + 4), 8.0f, 8.0f, 26, 26, 8, 8, 64, 64, ((integer20 << 24) | 16777215));
                }
                this.f859 = reference4;
                return;
            }
        }
    }

    private void renderCallback0(Optional arg0) {
        final TargetHUD captured1 = this;
        arg0.ifPresent((lambdaArg0) -> captured1.renderCallback1(((PlayerSkin) lambdaArg0)));
    }

    public int m216() {
        return this.f867;
    }

    public int m213() {
        return this.f864;
    }

    public void m217(int arg0, int arg1) {
        this.f864 = arg0;
        this.f865 = arg1;
    }

    private void renderCallback1(PlayerSkin arg0) {
        this.f860 = arg0.body().id();
    }

    public int m215() {
        return this.f866;
    }

    public void m212(GuiGraphicsExtractor arg0, float arg1, Player arg2) {
        int integer4 = 0;
        int integer5 = 0;
        int integer6 = 0;
        int integer7 = 0;
        String reference8 = null;
        int integer9 = 0;
        int integer10 = 0;
        int integer11 = 0;
        integer4 = TargetHUD.mc.getWindow().getGuiScaledWidth();
        integer5 = TargetHUD.mc.getWindow().getGuiScaledHeight();
        integer6 = ((integer4 >> 1) + this.f864);
        integer7 = ((integer5 >> 1) + this.f865);
        reference8 = TargetHUD.TEXT_PLAYER;
        integer9 = TargetHUD.mc.font.width(reference8);
        integer10 = Math.max(80, (38 + integer9));
        this.f866 = integer10;
        this.f867 = 42;
        integer11 = -1;
        arg0.fill(integer6, integer7, (integer6 + integer10), (integer7 + 42), -1442840576);
        arg0.text(TargetHUD.mc.font, reference8, (integer6 + 34), (integer7 + 5), -1, false);
        arg0.text(TargetHUD.mc.font, TargetHUD.TEXT_HP_20, ((integer6 + integer10) - 35), (integer7 + 22), integer11, false);
        arg0.fill((integer6 + 4), (integer7 + 34), (((integer6 + 8) + integer10) - 12), (integer7 + 38), integer11);
    }

    static {
        TEXT_TARGETHUD = new String("TargetHUD");
        TEXT_THEME_COLOR = new String("Theme Color");
        TEXT_OUTLINE = new String("Outline");
        TEXT_EDIT_POSITION = new String("Edit Position");
        TEXT_SHOW_WIN_OR_LOSS = new String("Show Win or Loss");
        TEXT_HEALTH_ANIMATION = new String("Health Animation");
        TEXT_EMPTY = new String("");
        TEXT_AW = new String("\u00a7aW");
        TEXT_CL = new String("\u00a7cL");
        TEXT_PLAYER = new String("Player");
        TEXT_HP_20 = new String("HP: 20");
        TEXT_HP_0 = new String("HP: 0");
        TEXT_HP_1 = new String("HP: 1");
        TEXT_HP_2 = new String("HP: 2");
        TEXT_HP_3 = new String("HP: 3");
        TEXT_HP_4 = new String("HP: 4");
        TEXT_HP_5 = new String("HP: 5");
        TEXT_HP_6 = new String("HP: 6");
        TEXT_HP_7 = new String("HP: 7");
        TEXT_HP_8 = new String("HP: 8");
        TEXT_HP_9 = new String("HP: 9");
        TEXT_HP_10 = new String("HP: 10");
        TEXT_HP_11 = new String("HP: 11");
        TEXT_HP_12 = new String("HP: 12");
        TEXT_HP_13 = new String("HP: 13");
        TEXT_HP_14 = new String("HP: 14");
        TEXT_HP_15 = new String("HP: 15");
        TEXT_HP_16 = new String("HP: 16");
        TEXT_HP_17 = new String("HP: 17");
        TEXT_HP_18 = new String("HP: 18");
        TEXT_HP_19 = new String("HP: 19");
        f869 = new String[] {TargetHUD.TEXT_HP_0, TargetHUD.TEXT_HP_1, TargetHUD.TEXT_HP_2, TargetHUD.TEXT_HP_3, TargetHUD.TEXT_HP_4, TargetHUD.TEXT_HP_5, TargetHUD.TEXT_HP_6, TargetHUD.TEXT_HP_7, TargetHUD.TEXT_HP_8, TargetHUD.TEXT_HP_9, TargetHUD.TEXT_HP_10, TargetHUD.TEXT_HP_11, TargetHUD.TEXT_HP_12, TargetHUD.TEXT_HP_13, TargetHUD.TEXT_HP_14, TargetHUD.TEXT_HP_15, TargetHUD.TEXT_HP_16, TargetHUD.TEXT_HP_17, TargetHUD.TEXT_HP_18, TargetHUD.TEXT_HP_19, TargetHUD.TEXT_HP_20};
    }

    public int m214() {
        return this.f865;
    }

    public TargetHUD() {
        super(TargetHUD.TEXT_TARGETHUD, Category.VISUAL);
        this.themeColor = new BooleanSetting(TargetHUD.TEXT_THEME_COLOR, this, false);
        this.outline = new BooleanSetting(TargetHUD.TEXT_OUTLINE, this, false);
        this.editPosition = new BooleanSetting(TargetHUD.TEXT_EDIT_POSITION, this, false);
        this.showWinOrLoss = new BooleanSetting(TargetHUD.TEXT_SHOW_WIN_OR_LOSS, this, false);
        this.healthAnimation = new BooleanSetting(TargetHUD.TEXT_HEALTH_ANIMATION, this, false);
        this.f862 = TargetHUD.TEXT_EMPTY;
        this.f868 = new Recovered_sy(this);
    }
}
