package cryptix.module.impl.visual;

import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;

/**
 * Reconstructed from a/dq.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Theme extends Module {
    private static final String TEXT_THEME;
    private static final String TEXT_CHERRY;
    public final NumberSetting speed;
    private static final String TEXT_DEFAULT;
    private static final String TEXT_SPEED;
    private static final String TEXT_NOVA;
    private static final String TEXT_GOLD;
    private static final String TEXT_INFERNO;
    private static final String TEXT_RAINBOW;
    private static final String TEXT_OCEAN;
    private static final String TEXT_EMERALD;
    private static final String TEXT_SAKURA;
    private static final String TEXT_COTTON_CANDY;
    private static final String TEXT_FROST;
    public final ModeSetting theme;

    public Theme() {
        super(Theme.TEXT_THEME, Category.VISUAL);
        this.theme = new ModeSetting(Theme.TEXT_THEME, this, Theme.TEXT_DEFAULT, new String[] {Theme.TEXT_DEFAULT, Theme.TEXT_CHERRY, Theme.TEXT_COTTON_CANDY, Theme.TEXT_EMERALD, Theme.TEXT_FROST, Theme.TEXT_GOLD, Theme.TEXT_INFERNO, Theme.TEXT_NOVA, Theme.TEXT_OCEAN, Theme.TEXT_RAINBOW, Theme.TEXT_SAKURA});
        this.speed = new NumberSetting(Theme.TEXT_SPEED, this, 1.0, 0.5, 5.0, 0.25);
    }

    static {
        TEXT_THEME = new String("Theme");
        TEXT_DEFAULT = new String("Default");
        TEXT_CHERRY = new String("Cherry");
        TEXT_COTTON_CANDY = new String("Cotton Candy");
        TEXT_EMERALD = new String("Emerald");
        TEXT_FROST = new String("Frost");
        TEXT_GOLD = new String("Gold");
        TEXT_INFERNO = new String("Inferno");
        TEXT_NOVA = new String("Nova");
        TEXT_OCEAN = new String("Ocean");
        TEXT_RAINBOW = new String("Rainbow");
        TEXT_SAKURA = new String("Sakura");
        TEXT_SPEED = new String("Speed");
    }
}
