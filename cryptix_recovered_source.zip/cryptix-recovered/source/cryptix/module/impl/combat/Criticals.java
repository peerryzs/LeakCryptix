package cryptix.module.impl.combat;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.PacketSendEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.ModeSetting;
import cryptix.util.Recovered_hp;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;

/**
 * Reconstructed from a/jo.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Criticals extends Module {
    private static final String TEXT_TIMER;
    private long f275;
    private ModeSetting mode;
    private static final String TEXT_PACKET;
    private double f274;
    private static final String TEXT_CRITICALS;
    private static final String TEXT_MODE;

    public void onEvent(Event event) {
        PacketSendEvent saved1 = null;
        Packet reference3 = null;
        boolean saved2 = false;
        ServerboundAttackPacket reference2 = null;
        LocalPlayer saved3 = null;
        boolean saved4 = false;
        boolean saved5 = false;
        boolean saved6 = false;
        boolean saved7 = false;
        boolean saved8 = false;
        boolean saved9 = false;
        boolean saved10 = false;
        boolean saved11 = false;
        boolean saved12 = false;
        boolean saved13 = false;
        boolean saved14 = false;
        boolean saved15 = false;
        RotationEvent saved16 = null;
        int saved17 = 0;
        double number2 = 0.0;
        int saved18 = 0;
        int saved19 = 0;
        boolean saved20 = false;
        boolean saved21 = false;
        boolean saved22 = false;
        boolean saved23 = false;
        boolean saved24 = false;
        boolean saved25 = false;
        boolean saved26 = false;
        boolean saved27 = false;
        RotationEvent saved28 = null;
        int saved29 = 0;
        int saved30 = 0;
        int saved31 = 0;
        RotationEvent saved32 = null;
        int saved33 = 0;
        int saved34 = 0;
        int saved35 = 0;
        saved1 = Events.packetSend;
        if (!((event != saved1))) {
            reference3 = Events.packetSend.getPacket();
            saved2 = (reference3 instanceof ServerboundAttackPacket);
            if (saved2) {
                reference2 = ((ServerboundAttackPacket) (Object) reference3);
                saved3 = Criticals.mc.player;
                if (!((saved3 != null))) {
                    return;
                } else {
                    saved4 = Criticals.mc.player.onGround();
                    if (!(saved4)) {
                        return;
                    } else {
                        saved5 = Criticals.mc.player.isInWater();
                        if (!(saved5)) {
                            saved6 = Criticals.mc.player.isInLava();
                            if (saved6) {
                                return;
                            } else {
                                saved7 = this.mode.is(Criticals.TEXT_PACKET);
                                if (saved7) {
                                    this.pm$64();
                                }
                                saved8 = (Events.packetSend.getPacket() instanceof ServerboundMovePlayerPacket);
                                if (!(saved8)) {
                                    saved9 = (Events.packetSend.getPacket() instanceof ServerboundMovePlayerPacket.Pos);
                                    if (!(saved9)) {
                                        saved10 = (Events.packetSend.getPacket() instanceof ServerboundMovePlayerPacket.Rot);
                                        if (!(saved10)) {
                                            saved11 = (Events.packetSend.getPacket() instanceof ServerboundMovePlayerPacket.PosRot);
                                            if (saved11) {
                                                saved12 = event.isCancelled();
                                                if (!(saved12)) {
                                                    this.f274 = (this.f274 - 50.0);
                                                }
                                                this.f274 = (this.f274 + ((double) (System.currentTimeMillis() - this.f275)));
                                                this.f275 = System.currentTimeMillis();
                                            }
                                        } else {
                                            saved13 = event.isCancelled();
                                            if (!(saved13)) {
                                                this.f274 = (this.f274 - 50.0);
                                            }
                                            this.f274 = (this.f274 + ((double) (System.currentTimeMillis() - this.f275)));
                                            this.f275 = System.currentTimeMillis();
                                        }
                                    } else {
                                        saved14 = event.isCancelled();
                                        if (!(saved14)) {
                                            this.f274 = (this.f274 - 50.0);
                                        }
                                        this.f274 = (this.f274 + ((double) (System.currentTimeMillis() - this.f275)));
                                        this.f275 = System.currentTimeMillis();
                                    }
                                } else {
                                    saved15 = event.isCancelled();
                                    if (!(saved15)) {
                                        this.f274 = (this.f274 - 50.0);
                                    }
                                    this.f274 = (this.f274 + ((double) (System.currentTimeMillis() - this.f275)));
                                    this.f275 = System.currentTimeMillis();
                                }
                                saved16 = Events.rotation;
                                if (!((event != saved16))) {
                                    saved17 = JvmSupport.lcmp((System.currentTimeMillis() - this.f275), 200L);
                                    if (!((saved17 <= 0))) {
                                        this.f275 = System.currentTimeMillis();
                                        this.f274 = 0.0;
                                    }
                                    number2 = Criticals.mc.player.getDeltaMovement().y;
                                    saved18 = JvmSupport.dcmpl(number2, 0.0);
                                    if (!((saved18 <= 0))) {
                                        Recovered_hp.m59(2.5f);
                                    } else {
                                        saved19 = JvmSupport.dcmpg(this.f274, 0.0);
                                        if (!((saved19 >= 0))) {
                                            Recovered_hp.m59(0.5f);
                                        } else {
                                            Recovered_hp.m59(1.0f);
                                        }
                                    }
                                }
                                return;
                            }
                        } else {
                            return;
                        }
                    }
                }
            } else {
                saved20 = (Events.packetSend.getPacket() instanceof ServerboundMovePlayerPacket);
                if (!(saved20)) {
                    saved21 = (Events.packetSend.getPacket() instanceof ServerboundMovePlayerPacket.Pos);
                    if (!(saved21)) {
                        saved22 = (Events.packetSend.getPacket() instanceof ServerboundMovePlayerPacket.Rot);
                        if (!(saved22)) {
                            saved23 = (Events.packetSend.getPacket() instanceof ServerboundMovePlayerPacket.PosRot);
                            if (saved23) {
                                saved24 = event.isCancelled();
                                if (!(saved24)) {
                                    this.f274 = (this.f274 - 50.0);
                                }
                                this.f274 = (this.f274 + ((double) (System.currentTimeMillis() - this.f275)));
                                this.f275 = System.currentTimeMillis();
                            }
                        } else {
                            saved25 = event.isCancelled();
                            if (!(saved25)) {
                                this.f274 = (this.f274 - 50.0);
                            }
                            this.f274 = (this.f274 + ((double) (System.currentTimeMillis() - this.f275)));
                            this.f275 = System.currentTimeMillis();
                        }
                    } else {
                        saved26 = event.isCancelled();
                        if (!(saved26)) {
                            this.f274 = (this.f274 - 50.0);
                        }
                        this.f274 = (this.f274 + ((double) (System.currentTimeMillis() - this.f275)));
                        this.f275 = System.currentTimeMillis();
                    }
                } else {
                    saved27 = event.isCancelled();
                    if (!(saved27)) {
                        this.f274 = (this.f274 - 50.0);
                    }
                    this.f274 = (this.f274 + ((double) (System.currentTimeMillis() - this.f275)));
                    this.f275 = System.currentTimeMillis();
                }
                saved28 = Events.rotation;
                if (!((event != saved28))) {
                    saved29 = JvmSupport.lcmp((System.currentTimeMillis() - this.f275), 200L);
                    if (!((saved29 <= 0))) {
                        this.f275 = System.currentTimeMillis();
                        this.f274 = 0.0;
                    }
                    number2 = Criticals.mc.player.getDeltaMovement().y;
                    saved30 = JvmSupport.dcmpl(number2, 0.0);
                    if (!((saved30 <= 0))) {
                        Recovered_hp.m59(2.5f);
                    } else {
                        saved31 = JvmSupport.dcmpg(this.f274, 0.0);
                        if (!((saved31 >= 0))) {
                            Recovered_hp.m59(0.5f);
                        } else {
                            Recovered_hp.m59(1.0f);
                        }
                    }
                }
                return;
            }
        } else {
            saved32 = Events.rotation;
            if (!((event != saved32))) {
                saved33 = JvmSupport.lcmp((System.currentTimeMillis() - this.f275), 200L);
                if (!((saved33 <= 0))) {
                    this.f275 = System.currentTimeMillis();
                    this.f274 = 0.0;
                }
                number2 = Criticals.mc.player.getDeltaMovement().y;
                saved34 = JvmSupport.dcmpl(number2, 0.0);
                if (!((saved34 <= 0))) {
                    Recovered_hp.m59(2.5f);
                } else {
                    saved35 = JvmSupport.dcmpg(this.f274, 0.0);
                    if (!((saved35 >= 0))) {
                        Recovered_hp.m59(0.5f);
                    } else {
                        Recovered_hp.m59(1.0f);
                    }
                }
            }
            return;
        }
    }

    public Criticals() {
        super(Criticals.TEXT_CRITICALS, Category.COMBAT);
        this.mode = new ModeSetting(Criticals.TEXT_MODE, this, Criticals.TEXT_PACKET, new String[] {Criticals.TEXT_PACKET, Criticals.TEXT_TIMER});
    }

    private void pm$64() {
        double number1 = 0.0;
        double number3 = 0.0;
        double number5 = 0.0;
        number1 = Criticals.mc.player.getX();
        number3 = Criticals.mc.player.getY();
        number5 = Criticals.mc.player.getZ();
        Criticals.mc.getConnection().send(((Packet) (Object) new ServerboundMovePlayerPacket.Pos(number1, (number3 + 0.0625), number5, false, Criticals.mc.player.horizontalCollision)));
        Criticals.mc.getConnection().send(((Packet) (Object) new ServerboundMovePlayerPacket.Pos(number1, number3, number5, false, Criticals.mc.player.horizontalCollision)));
        Criticals.mc.getConnection().send(((Packet) (Object) new ServerboundMovePlayerPacket.Pos(number1, (number3 + 1e-06), number5, false, Criticals.mc.player.horizontalCollision)));
    }

    public void onEnable() {
        this.f275 = System.currentTimeMillis();
        this.f274 = 0.0;
    }

    static {
        TEXT_CRITICALS = new String("Criticals");
        TEXT_MODE = new String("Mode");
        TEXT_PACKET = new String("Packet");
        TEXT_TIMER = new String("Timer");
    }
}
