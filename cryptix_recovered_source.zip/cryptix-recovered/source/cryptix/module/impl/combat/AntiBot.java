package cryptix.module.impl.combat;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/**
 * Reconstructed from a/zs.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class AntiBot extends Module {
    private final Set f256;
    private static final String TEXT_ANTIBOT;
    private int f257;

    public AntiBot() {
        super(AntiBot.TEXT_ANTIBOT, Category.COMBAT);
        this.f256 = new HashSet();
        this.f257 = -1;
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        ClientPacketListener reference2 = null;
        Collection reference3 = null;
        int integer4 = 0;
        int saved2 = 0;
        Iterator reference5 = null;
        boolean saved3 = false;
        PlayerInfo reference6 = null;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            reference2 = AntiBot.mc.getConnection();
            if (!((reference2 != null))) {
                this.f256.clear();
                this.f257 = -1;
                return;
            } else {
                reference3 = reference2.getOnlinePlayers();
                integer4 = reference3.size();
                saved2 = this.f257;
                if (!((integer4 == saved2))) {
                    this.f257 = integer4;
                    this.f256.clear();
                    reference5 = reference3.iterator();
                    loop34: while (true) {
                        saved3 = reference5.hasNext();
                        if (!(saved3)) {
                            break loop34;
                        }
                        reference6 = ((PlayerInfo) reference5.next());
                        this.f256.add(reference6.getProfile().id());
                        continue loop34;
                    }
                }
                return;
            }
        } else {
            return;
        }
    }

    static {
        TEXT_ANTIBOT = new String("AntiBot");
    }

    public boolean m140(Entity arg0) {
        boolean saved1 = false;
        int integer0 = 0;
        boolean saved2 = false;
        Player reference2 = null;
        ClientPacketListener reference3 = null;
        boolean saved3 = false;
        saved1 = this.isEnabled();
        if (!(saved1)) {
            integer0 = 0;
            return (integer0 != 0);
        } else {
            saved2 = (arg0 instanceof Player);
            if (saved2) {
                reference2 = ((Player) (Object) arg0);
                reference3 = AntiBot.mc.getConnection();
                if (!((reference3 != null))) {
                    integer0 = 1;
                    return (integer0 != 0);
                } else {
                    saved3 = this.f256.contains(reference2.getUUID());
                    integer0 = (!(saved3) ? 1 : 0);
                    return (integer0 != 0);
                }
            } else {
                integer0 = 1;
                return (integer0 != 0);
            }
        }
    }
}
