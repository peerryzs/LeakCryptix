package cryptix.module.impl.combat;

import com.mojang.blaze3d.platform.InputConstants;
import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.NumberSetting;
import java.util.Random;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.phys.HitResult;

/**
 * Reconstructed from a/ql.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class AutoClicker extends Module {
    private static final String TEXT_MAX_CPS;
    private static final String TEXT_MIN_CPS;
    private static final String TEXT_BREAK_BLOCKS;
    private final NumberSetting minCPS;
    private static final String TEXT_RANDOMIZE;
    private final BooleanSetting breakBlocks;
    private static final String TEXT_AUTOCLICKER;
    private final BooleanSetting randomize;
    private long f268;
    private final Random f267;
    private final NumberSetting maxCPS;

    private long pm$63() {
        boolean saved1 = false;
        double number1 = 0.0;
        long local0 = 0L;
        saved1 = this.randomize.getValue();
        if (saved1) {
            number1 = (this.minCPS.getValue() + ((this.maxCPS.getValue() - this.minCPS.getValue()) * this.f267.nextDouble()));
        } else {
            number1 = this.minCPS.getValue();
        }
        local0 = ((long) (1000.0 / number1));
        return local0;
    }

    public AutoClicker() {
        super(AutoClicker.TEXT_AUTOCLICKER, Category.COMBAT);
        this.minCPS = new NumberSetting(AutoClicker.TEXT_MIN_CPS, this, 8.0, 1.0, 20.0, 1.0);
        this.maxCPS = new NumberSetting(AutoClicker.TEXT_MAX_CPS, this, 12.0, 1.0, 20.0, 1.0);
        this.randomize = new BooleanSetting(AutoClicker.TEXT_RANDOMIZE, this, true);
        this.breakBlocks = new BooleanSetting(AutoClicker.TEXT_BREAK_BLOCKS, this, false);
        this.f267 = new Random();
    }

    static {
        TEXT_AUTOCLICKER = new String("AutoClicker");
        TEXT_MIN_CPS = new String("Min CPS");
        TEXT_MAX_CPS = new String("Max CPS");
        TEXT_RANDOMIZE = new String("Randomize");
        TEXT_BREAK_BLOCKS = new String("Break Blocks");
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        Screen saved2 = null;
        boolean saved3 = false;
        boolean saved4 = false;
        HitResult saved5 = null;
        HitResult.Type saved6 = null;
        HitResult.Type saved7 = null;
        InputConstants.Key reference2 = null;
        long local2 = 0L;
        int saved8 = 0;
        InputConstants.Key reference4 = null;
        int saved9 = 0;
        int saved10 = 0;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            saved2 = AutoClicker.mc.gui.screen();
            if (!((saved2 == null))) {
                return;
            } else {
                saved3 = AutoClicker.mc.mouseHandler.isLeftPressed();
                if (!(saved3)) {
                    return;
                } else {
                    saved4 = this.breakBlocks.getValue();
                    if (saved4) {
                        saved5 = AutoClicker.mc.hitResult;
                        if (!((saved5 == null))) {
                            saved6 = AutoClicker.mc.hitResult.getType();
                            saved7 = HitResult.Type.BLOCK;
                            if (!((saved6 != saved7))) {
                                reference2 = InputConstants.Type.MOUSE.getOrCreate(0);
                                KeyMapping.set(reference2, true);
                                return;
                            } else {
                                local2 = this.pm$63();
                                saved8 = JvmSupport.lcmp((System.currentTimeMillis() - this.f268), local2);
                                if (!((saved8 < 0))) {
                                    reference4 = InputConstants.Type.MOUSE.getOrCreate(0);
                                    KeyMapping.set(reference4, true);
                                    KeyMapping.click(reference4);
                                    KeyMapping.set(reference4, false);
                                    this.f268 = System.currentTimeMillis();
                                }
                                return;
                            }
                        } else {
                            local2 = this.pm$63();
                            saved9 = JvmSupport.lcmp((System.currentTimeMillis() - this.f268), local2);
                            if (!((saved9 < 0))) {
                                reference4 = InputConstants.Type.MOUSE.getOrCreate(0);
                                KeyMapping.set(reference4, true);
                                KeyMapping.click(reference4);
                                KeyMapping.set(reference4, false);
                                this.f268 = System.currentTimeMillis();
                            }
                            return;
                        }
                    } else {
                        local2 = this.pm$63();
                        saved10 = JvmSupport.lcmp((System.currentTimeMillis() - this.f268), local2);
                        if (!((saved10 < 0))) {
                            reference4 = InputConstants.Type.MOUSE.getOrCreate(0);
                            KeyMapping.set(reference4, true);
                            KeyMapping.click(reference4);
                            KeyMapping.set(reference4, false);
                            this.f268 = System.currentTimeMillis();
                        }
                        return;
                    }
                }
            }
        } else {
            return;
        }
    }

    public void onEnable() {
        this.f268 = System.currentTimeMillis();
    }
}
