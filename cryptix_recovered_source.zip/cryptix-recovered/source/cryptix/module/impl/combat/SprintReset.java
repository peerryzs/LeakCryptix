package cryptix.module.impl.combat;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.PacketSendEvent;
import cryptix.event.impl.PostInputEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.mixin.ClientInputMixin;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;
import net.minecraft.client.player.ClientInput;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.Vec2;

/**
 * Reconstructed from a/rh.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class SprintReset extends Module {
    private static final String TEXT_RESET_DELAY;
    private static final String TEXT_MODE;
    private int f338;
    private int f339;
    private final ModeSetting mode;
    private final NumberSetting resetDelay;
    private static final String TEXT_STAP;
    private static final String TEXT_WTAP;
    private static final String TEXT_SPRINTRESET;
    private static final String TEXT_RELEASE_DELAY;
    private static final String TEXT_WTAP_2;
    private final NumberSetting releaseDelay;

    public SprintReset() {
        super(SprintReset.TEXT_SPRINTRESET, Category.COMBAT);
        this.releaseDelay = new NumberSetting(SprintReset.TEXT_RELEASE_DELAY, this, 2.0, 1.0, 5.0, 1.0);
        this.resetDelay = new NumberSetting(SprintReset.TEXT_RESET_DELAY, this, 0.0, 0.0, 10.0, 1.0);
        this.mode = new ModeSetting(SprintReset.TEXT_MODE, this, SprintReset.TEXT_WTAP, new String[] {SprintReset.TEXT_WTAP_2, SprintReset.TEXT_STAP});
    }

    static {
        TEXT_SPRINTRESET = new String("SprintReset");
        TEXT_RELEASE_DELAY = new String("Release Delay");
        TEXT_RESET_DELAY = new String("Reset Delay");
        TEXT_MODE = new String("Mode");
        TEXT_WTAP = new String("WTap");
        TEXT_WTAP_2 = new String("Wtap");
        TEXT_STAP = new String("STap");
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        PacketSendEvent saved2 = null;
        Object reference3 = null;
        boolean saved3 = false;
        Object reference2 = null;
        boolean saved4 = false;
        int saved5 = 0;
        PostInputEvent saved6 = null;
        int saved7 = 0;
        int saved8 = 0;
        int integer4 = 0;
        Vec2 reference5 = null;
        int saved9 = 0;
        ClientInput saved10 = null;
        int saved11 = 0;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            this.setSuffix(this.mode.getValue());
        }
        saved2 = Events.packetSend;
        if (!((event != saved2))) {
            reference3 = Events.packetSend.getPacket();
            saved3 = (reference3 instanceof ServerboundAttackPacket);
            if (saved3) {
                reference2 = ((ServerboundAttackPacket) reference3);
                reference3 = SprintReset.mc.level.getEntity(((ServerboundAttackPacket) reference2).entityId());
                if (!((reference3 == null))) {
                    saved4 = SprintReset.mc.player.isSprinting();
                    if (saved4) {
                        saved5 = this.f339;
                        if (!((saved5 > 0))) {
                            this.f338 = ((int) this.releaseDelay.getValue());
                            this.f339 = ((int) this.resetDelay.getValue());
                        }
                    }
                }
            }
        }
        saved6 = Events.postInput;
        if (!((event != saved6))) {
            saved7 = this.f339;
            if (!((saved7 <= 0))) {
                this.f339 = (this.f339 - 1);
            }
            saved8 = this.f338;
            if (!((saved8 <= 0))) {
                this.f338 = (this.f338 - 1);
                reference2 = SprintReset.mc.player.input.keyPresses;
                reference3 = ((ClientInputMixin) (Object) SprintReset.mc.player.input);
                integer4 = (this.mode.is(SprintReset.TEXT_STAP) ? 1 : 0);
                reference5 = new Vec2(0.0f, (!((integer4 == 0)) ? -1.0f : 0.0f));
                saved9 = JvmSupport.fcmpl(reference5.length(), 1.0f);
                if (!((saved9 <= 0))) {
                    reference5 = reference5.normalized();
                }
                ((ClientInputMixin) reference3).setMoveVector(reference5);
                saved10 = SprintReset.mc.player.input;
                saved10.keyPresses = new Input(false, ((!((integer4 == 0)) ? 1 : 0) != 0), false, false, ((Input) reference2).jump(), ((Input) reference2).shift(), ((Input) reference2).sprint());
            } else {
                saved11 = this.f338;
                if (!((saved11 != 0))) {
                    this.f338 = (this.f338 - 1);
                }
            }
        }
    }
}
