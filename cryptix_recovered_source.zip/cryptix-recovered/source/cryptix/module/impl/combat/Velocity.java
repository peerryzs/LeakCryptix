package cryptix.module.impl.combat;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.PacketReceiveEvent;
import cryptix.event.impl.PacketSendEvent;
import cryptix.event.impl.PostInputEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.module.ModuleManager;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;
import cryptix.util.TargetingUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.PacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ClientboundStartConfigurationPacket;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Reconstructed from a/na.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Velocity extends Module {
    private static final String TEXT_NORMAL;
    private int f372;
    private final NumberSetting delayRange;
    private boolean f370;
    private static final String TEXT_REVERSE;
    private static final String TEXT_HORIZONTAL;
    private final ModeSetting reduce;
    public final List f19;
    private static final String TEXT_DELAY_UNTIL_GROUND;
    private static final String TEXT_JUMP_RESET;
    private static final String TEXT_REDUCE;
    private int f369;
    private final BooleanSetting delayUntilGround;
    private boolean f371;
    private static final String TEXT_JUMP;
    private static final String TEXT_REDUCE_TICKS;
    private static final String TEXT_VELOCITY;
    private static final String TEXT_DELAY_TICKS;
    private final BooleanSetting delay;
    private final NumberSetting reduceMotion;
    private final NumberSetting reduceTicks;
    private static final String TEXT_DISABLED;
    private static final String TEXT_DELAY;
    private final NumberSetting delayTicks;
    private final BooleanSetting reverse;
    private static final String TEXT_AIRPUSH;
    private final NumberSetting vertical;
    private final BooleanSetting jumpReset;
    private int f368;
    private static final String TEXT_VERTICAL;
    private static final String TEXT_REDUCE_MOTION;
    private final NumberSetting horizontal;
    private static final String TEXT_DELAY_RANGE;

    public Velocity() {
        super(Velocity.TEXT_VELOCITY, Category.COMBAT);
        this.horizontal = new NumberSetting(Velocity.TEXT_HORIZONTAL, this, 100.0, 0.0, 100.0, 5.0);
        this.vertical = new NumberSetting(Velocity.TEXT_VERTICAL, this, 100.0, 0.0, 100.0, 5.0);
        this.reduceMotion = new NumberSetting(Velocity.TEXT_REDUCE_MOTION, this, 1.0, 0.0, 1.0, 0.1);
        this.reduceTicks = new NumberSetting(Velocity.TEXT_REDUCE_TICKS, this, 0.0, 0.0, 5.0, 1.0);
        this.reduce = new ModeSetting(Velocity.TEXT_REDUCE, this, Velocity.TEXT_DISABLED, new String[] {Velocity.TEXT_DISABLED, Velocity.TEXT_NORMAL, Velocity.TEXT_AIRPUSH});
        this.jumpReset = new BooleanSetting(Velocity.TEXT_JUMP_RESET, this, false);
        this.delay = new BooleanSetting(Velocity.TEXT_DELAY, this, false);
        this.delayTicks = new NumberSetting(Velocity.TEXT_DELAY_TICKS, this, 4.0, 1.0, 15.0, 1.0);
        this.delayRange = new NumberSetting(Velocity.TEXT_DELAY_RANGE, this, 3.0, 1.0, 4.0, 0.5);
        this.delayUntilGround = new BooleanSetting(Velocity.TEXT_DELAY_UNTIL_GROUND, this, false);
        this.reverse = new BooleanSetting(Velocity.TEXT_REVERSE, this, false);
        this.f19 = new ArrayList();
        this.f368 = -1;
    }

    private void pm$81(Entity arg0) {
        boolean saved1 = false;
        boolean saved2 = false;
        saved1 = ModuleManager.bedAura.isEnabled();
        if (saved1) {
            saved2 = ModuleManager.bedAura.f25;
            if (saved2) {
                return;
            } else {
                this.f371 = true;
                Velocity.mc.gameMode.attack(Velocity.mc.player, arg0);
                Velocity.mc.getConnection().send(((Packet) (Object) new ServerboundSwingPacket(InteractionHand.MAIN_HAND)));
                this.f371 = false;
                return;
            }
        } else {
            this.f371 = true;
            Velocity.mc.gameMode.attack(Velocity.mc.player, arg0);
            Velocity.mc.getConnection().send(((Packet) (Object) new ServerboundSwingPacket(InteractionHand.MAIN_HAND)));
            this.f371 = false;
            return;
        }
    }

    private static void releaseCallback0(Packet arg0) {
        arg0.handle(((PacketListener) (Object) Velocity.mc.getConnection()));
    }

    private void release() {
        boolean saved1 = false;
        List saved2 = null;
        List reference1 = null;
        Iterator reference2 = null;
        boolean saved3 = false;
        Packet reference3 = null;
        Minecraft saved5 = null;
        saved1 = this.f19.isEmpty();
        if (saved1) {
            return;
        } else {
            saved2 = this.f19;
            reference1 = saved2;
            synchronized (saved2) {
                reference2 = this.f19.iterator();
                loop14: while (true) {
                    saved3 = reference2.hasNext();
                    if (!(saved3)) {
                        break loop14;
                    }
                    reference3 = ((Packet) reference2.next());
                    saved5 = Velocity.mc;
                    final Packet captured4 = reference3;
                    saved5.execute(() -> Velocity.releaseCallback0(captured4));
                    continue loop14;
                }
                this.f19.clear();
            }
            this.f369 = 0;
            return;
        }
    }

    static {
        TEXT_VELOCITY = new String("Velocity");
        TEXT_HORIZONTAL = new String("Horizontal");
        TEXT_VERTICAL = new String("Vertical");
        TEXT_REDUCE_MOTION = new String("Reduce Motion");
        TEXT_REDUCE_TICKS = new String("Reduce Ticks");
        TEXT_REDUCE = new String("Reduce");
        TEXT_DISABLED = new String("Disabled");
        TEXT_NORMAL = new String("Normal");
        TEXT_AIRPUSH = new String("AirPush");
        TEXT_JUMP_RESET = new String("Jump Reset");
        TEXT_DELAY = new String("Delay");
        TEXT_DELAY_TICKS = new String("Delay Ticks");
        TEXT_DELAY_RANGE = new String("Delay Range");
        TEXT_DELAY_UNTIL_GROUND = new String("Delay Until Ground");
        TEXT_REVERSE = new String("Reverse");
        TEXT_JUMP = new String("Jump");
    }

    private boolean pm$82() {
        LivingEntity reference1 = null;
        LivingEntity reference2 = null;
        boolean saved1 = false;
        boolean saved2 = false;
        int saved3 = 0;
        boolean saved4 = false;
        boolean saved5 = false;
        int saved6 = 0;
        int branchValue7 = 0;
        int branchValue8 = 0;
        int branchValue9 = 0;
        int branchValue10 = 0;
        boolean saved11 = false;
        boolean saved12 = false;
        int saved13 = 0;
        int branchValue14 = 0;
        int branchValue15 = 0;
        int branchValue16 = 0;
        int branchValue17 = 0;
        int branchValue18 = 0;
        int saved19 = 0;
        boolean saved20 = false;
        boolean saved21 = false;
        int saved22 = 0;
        int branchValue23 = 0;
        int branchValue24 = 0;
        int branchValue25 = 0;
        int branchValue26 = 0;
        boolean saved27 = false;
        boolean saved28 = false;
        int saved29 = 0;
        int branchValue30 = 0;
        int branchValue31 = 0;
        int branchValue32 = 0;
        int branchValue33 = 0;
        int branchValue34 = 0;
        int integer0 = 0;
        reference1 = TargetingUtils.findTarget(6.0, false);
        reference2 = TargetingUtils.m55(false);
        saved1 = Velocity.mc.player.onGround();
        if (saved1) {
            saved2 = this.delayUntilGround.getValue();
            if (!(saved2)) {
                if (!((reference1 == null))) {
                    saved3 = JvmSupport.dcmpl(((double) Velocity.mc.player.distanceTo(reference1)), this.delayRange.getValue());
                    if (!((saved3 <= 0))) {
                        saved4 = this.reduce.is(Velocity.TEXT_AIRPUSH);
                        if (saved4) {
                            saved5 = Velocity.mc.player.isSprinting();
                            if (!(saved5)) {
                                if (!((reference2 == null))) {
                                    saved6 = JvmSupport.fcmpl(Velocity.mc.player.distanceTo(reference2), 11.0f);
                                    branchValue7 = (!((saved6 > 0)) ? 1 : 0);
                                } else {
                                    branchValue7 = 1;
                                }
                                branchValue8 = branchValue7;
                            } else {
                                branchValue8 = 0;
                            }
                            branchValue9 = branchValue8;
                        } else {
                            branchValue9 = 1;
                        }
                        branchValue10 = branchValue9;
                    } else {
                        branchValue10 = 0;
                    }
                    branchValue17 = branchValue10;
                } else {
                    saved11 = this.reduce.is(Velocity.TEXT_AIRPUSH);
                    if (saved11) {
                        saved12 = Velocity.mc.player.isSprinting();
                        if (!(saved12)) {
                            if (!((reference2 == null))) {
                                saved13 = JvmSupport.fcmpl(Velocity.mc.player.distanceTo(reference2), 11.0f);
                                branchValue14 = (!((saved13 > 0)) ? 1 : 0);
                            } else {
                                branchValue14 = 1;
                            }
                            branchValue15 = branchValue14;
                        } else {
                            branchValue15 = 0;
                        }
                        branchValue16 = branchValue15;
                    } else {
                        branchValue16 = 1;
                    }
                    branchValue17 = branchValue16;
                }
                branchValue18 = branchValue17;
            } else {
                branchValue18 = 0;
            }
            branchValue34 = branchValue18;
        } else {
            if (!((reference1 == null))) {
                saved19 = JvmSupport.dcmpl(((double) Velocity.mc.player.distanceTo(reference1)), this.delayRange.getValue());
                if (!((saved19 <= 0))) {
                    saved20 = this.reduce.is(Velocity.TEXT_AIRPUSH);
                    if (saved20) {
                        saved21 = Velocity.mc.player.isSprinting();
                        if (!(saved21)) {
                            if (!((reference2 == null))) {
                                saved22 = JvmSupport.fcmpl(Velocity.mc.player.distanceTo(reference2), 11.0f);
                                branchValue23 = (!((saved22 > 0)) ? 1 : 0);
                            } else {
                                branchValue23 = 1;
                            }
                            branchValue24 = branchValue23;
                        } else {
                            branchValue24 = 0;
                        }
                        branchValue25 = branchValue24;
                    } else {
                        branchValue25 = 1;
                    }
                    branchValue26 = branchValue25;
                } else {
                    branchValue26 = 0;
                }
                branchValue33 = branchValue26;
            } else {
                saved27 = this.reduce.is(Velocity.TEXT_AIRPUSH);
                if (saved27) {
                    saved28 = Velocity.mc.player.isSprinting();
                    if (!(saved28)) {
                        if (!((reference2 == null))) {
                            saved29 = JvmSupport.fcmpl(Velocity.mc.player.distanceTo(reference2), 11.0f);
                            branchValue30 = (!((saved29 > 0)) ? 1 : 0);
                        } else {
                            branchValue30 = 1;
                        }
                        branchValue31 = branchValue30;
                    } else {
                        branchValue31 = 0;
                    }
                    branchValue32 = branchValue31;
                } else {
                    branchValue32 = 1;
                }
                branchValue33 = branchValue32;
            }
            branchValue34 = branchValue33;
        }
        integer0 = branchValue34;
        return (integer0 != 0);
    }

    public void onEvent(Event event) {
        PostInputEvent saved1 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        RotationEvent saved4 = null;
        boolean saved5 = false;
        boolean saved6 = false;
        int saved7 = 0;
        boolean saved8 = false;
        boolean saved9 = false;
        int saved10 = 0;
        int saved11 = 0;
        Screen saved12 = null;
        Object reference2 = null;
        double number3 = 0.0;
        boolean saved13 = false;
        LivingEntity reference5 = null;
        boolean saved14 = false;
        int saved15 = 0;
        int saved16 = 0;
        boolean saved17 = false;
        boolean saved18 = false;
        Vec3 reference6 = null;
        Vec3 reference7 = null;
        double number8 = 0.0;
        double number10 = 0.0;
        double number12 = 0.0;
        double number14 = 0.0;
        float floating16 = 0.0f;
        float floating17 = 0.0f;
        boolean saved19 = false;
        int saved20 = 0;
        int saved21 = 0;
        boolean saved22 = false;
        boolean saved23 = false;
        boolean saved24 = false;
        int saved25 = 0;
        int saved26 = 0;
        boolean saved27 = false;
        boolean saved28 = false;
        boolean saved29 = false;
        int saved30 = 0;
        int saved31 = 0;
        boolean saved32 = false;
        boolean saved33 = false;
        boolean saved34 = false;
        int saved35 = 0;
        int saved36 = 0;
        boolean saved37 = false;
        boolean saved38 = false;
        boolean saved39 = false;
        int saved40 = 0;
        int saved41 = 0;
        boolean saved42 = false;
        boolean saved43 = false;
        PacketSendEvent saved44 = null;
        boolean saved45 = false;
        boolean saved46 = false;
        boolean saved47 = false;
        PacketReceiveEvent saved48 = null;
        boolean saved49 = false;
        ClientboundSetEntityMotionPacket reference3 = null;
        LocalPlayer saved50 = null;
        int saved51 = 0;
        int saved52 = 0;
        Object reference4 = null;
        int saved53 = 0;
        boolean saved54 = false;
        boolean saved55 = false;
        double number5 = 0.0;
        double number7 = 0.0;
        double number9 = 0.0;
        double number11 = 0.0;
        int saved56 = 0;
        boolean saved57 = false;
        int saved58 = 0;
        boolean saved59 = false;
        boolean saved60 = false;
        int saved61 = 0;
        boolean saved62 = false;
        boolean saved63 = false;
        boolean saved64 = false;
        boolean saved65 = false;
        int saved66 = 0;
        boolean saved67 = false;
        boolean saved68 = false;
        boolean saved69 = false;
        boolean saved70 = false;
        boolean saved71 = false;
        boolean saved72 = false;
        boolean saved73 = false;
        boolean saved74 = false;
        List saved75 = null;
        saved1 = Events.postInput;
        if (!((event != saved1))) {
            saved2 = Velocity.mc.player.onGround();
            if (saved2) {
                saved3 = this.f370;
                if (saved3) {
                    Velocity.mc.player.input.makeJump();
                    System.out.println(Velocity.TEXT_JUMP);
                    this.f370 = false;
                }
            }
        }
        saved4 = Events.rotation;
        if (!((event != saved4))) {
            saved5 = this.reduce.is(Velocity.TEXT_DISABLED);
            if (!(saved5)) {
                this.setSuffix(this.reduce.getValue());
            } else {
                this.setSuffix(null);
            }
            saved6 = this.f19.isEmpty();
            if (!(saved6)) {
                this.f369 = (this.f369 + 1);
                saved7 = JvmSupport.dcmpl(((double) this.f369), this.delayTicks.getValue());
                if (!((saved7 > 0))) {
                    saved8 = this.delayUntilGround.getValue();
                    if (saved8) {
                        saved9 = Velocity.mc.player.onGround();
                        if (saved9) {
                            this.release();
                        }
                    }
                } else {
                    this.release();
                }
            }
            saved10 = this.f368;
            if (!((saved10 < 0))) {
                saved11 = JvmSupport.dcmpg(((double) this.f368), this.reduceTicks.getValue());
                if (!((saved11 >= 0))) {
                    saved12 = Velocity.mc.gui.screen();
                    if (!((saved12 != null))) {
                        this.f368 = (this.f368 + 1);
                        reference2 = Velocity.mc.player.getDeltaMovement();
                        number3 = this.reduceMotion.getValue();
                        saved13 = this.reduce.is(Velocity.TEXT_NORMAL);
                        if (saved13) {
                            reference5 = TargetingUtils.findTarget(3.0, false);
                            if (!((reference5 == null))) {
                                saved14 = (reference5 instanceof Player);
                                if (saved14) {
                                    saved15 = this.f372;
                                    saved16 = Velocity.mc.player.tickCount;
                                    if (!((saved15 == saved16))) {
                                        saved17 = this.f19.isEmpty();
                                        if (saved17) {
                                            saved18 = reference5.isAlive();
                                            if (saved18) {
                                                reference6 = Velocity.mc.player.getEyePosition();
                                                reference7 = reference5.getEyePosition();
                                                number8 = (reference7.x - reference6.x);
                                                number10 = (reference7.y - reference6.y);
                                                number12 = (reference7.z - reference6.z);
                                                number14 = Math.sqrt(((number8 * number8) + (number12 * number12)));
                                                floating16 = ((float) (Math.toDegrees(Math.atan2(number12, number8)) - 90.0));
                                                floating17 = ((float) (-Math.toDegrees(Math.atan2(number10, number14))));
                                                Events.rotation.setYaw(floating16);
                                                Events.rotation.setPitch(floating17);
                                                this.pm$81(reference5);
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            saved19 = this.reduce.is(Velocity.TEXT_AIRPUSH);
                            if (saved19) {
                                reference5 = TargetingUtils.m55(false);
                                if (!((reference5 == null))) {
                                    saved20 = this.f372;
                                    saved21 = Velocity.mc.player.tickCount;
                                    if (!((saved20 == saved21))) {
                                        saved22 = this.f19.isEmpty();
                                        if (saved22) {
                                            saved23 = reference5.isAlive();
                                            if (saved23) {
                                                this.pm$81(reference5);
                                            } else {
                                                reference5 = TargetingUtils.findTarget(3.0, false);
                                                saved24 = (reference5 instanceof Player);
                                                if (saved24) {
                                                    saved25 = this.f372;
                                                    saved26 = Velocity.mc.player.tickCount;
                                                    if (!((saved25 == saved26))) {
                                                        saved27 = this.f19.isEmpty();
                                                        if (saved27) {
                                                            saved28 = reference5.isAlive();
                                                            if (saved28) {
                                                                reference6 = Velocity.mc.player.getEyePosition();
                                                                reference7 = reference5.getEyePosition();
                                                                number8 = (reference7.x - reference6.x);
                                                                number10 = (reference7.y - reference6.y);
                                                                number12 = (reference7.z - reference6.z);
                                                                number14 = Math.sqrt(((number8 * number8) + (number12 * number12)));
                                                                floating16 = ((float) (Math.toDegrees(Math.atan2(number12, number8)) - 90.0));
                                                                floating17 = ((float) (-Math.toDegrees(Math.atan2(number10, number14))));
                                                                Events.rotation.setYaw(floating16);
                                                                Events.rotation.setPitch(floating17);
                                                                this.pm$81(reference5);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } else {
                                            reference5 = TargetingUtils.findTarget(3.0, false);
                                            saved29 = (reference5 instanceof Player);
                                            if (saved29) {
                                                saved30 = this.f372;
                                                saved31 = Velocity.mc.player.tickCount;
                                                if (!((saved30 == saved31))) {
                                                    saved32 = this.f19.isEmpty();
                                                    if (saved32) {
                                                        saved33 = reference5.isAlive();
                                                        if (saved33) {
                                                            reference6 = Velocity.mc.player.getEyePosition();
                                                            reference7 = reference5.getEyePosition();
                                                            number8 = (reference7.x - reference6.x);
                                                            number10 = (reference7.y - reference6.y);
                                                            number12 = (reference7.z - reference6.z);
                                                            number14 = Math.sqrt(((number8 * number8) + (number12 * number12)));
                                                            floating16 = ((float) (Math.toDegrees(Math.atan2(number12, number8)) - 90.0));
                                                            floating17 = ((float) (-Math.toDegrees(Math.atan2(number10, number14))));
                                                            Events.rotation.setYaw(floating16);
                                                            Events.rotation.setPitch(floating17);
                                                            this.pm$81(reference5);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        reference5 = TargetingUtils.findTarget(3.0, false);
                                        saved34 = (reference5 instanceof Player);
                                        if (saved34) {
                                            saved35 = this.f372;
                                            saved36 = Velocity.mc.player.tickCount;
                                            if (!((saved35 == saved36))) {
                                                saved37 = this.f19.isEmpty();
                                                if (saved37) {
                                                    saved38 = reference5.isAlive();
                                                    if (saved38) {
                                                        reference6 = Velocity.mc.player.getEyePosition();
                                                        reference7 = reference5.getEyePosition();
                                                        number8 = (reference7.x - reference6.x);
                                                        number10 = (reference7.y - reference6.y);
                                                        number12 = (reference7.z - reference6.z);
                                                        number14 = Math.sqrt(((number8 * number8) + (number12 * number12)));
                                                        floating16 = ((float) (Math.toDegrees(Math.atan2(number12, number8)) - 90.0));
                                                        floating17 = ((float) (-Math.toDegrees(Math.atan2(number10, number14))));
                                                        Events.rotation.setYaw(floating16);
                                                        Events.rotation.setPitch(floating17);
                                                        this.pm$81(reference5);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    reference5 = TargetingUtils.findTarget(3.0, false);
                                    saved39 = (reference5 instanceof Player);
                                    if (saved39) {
                                        saved40 = this.f372;
                                        saved41 = Velocity.mc.player.tickCount;
                                        if (!((saved40 == saved41))) {
                                            saved42 = this.f19.isEmpty();
                                            if (saved42) {
                                                saved43 = reference5.isAlive();
                                                if (saved43) {
                                                    reference6 = Velocity.mc.player.getEyePosition();
                                                    reference7 = reference5.getEyePosition();
                                                    number8 = (reference7.x - reference6.x);
                                                    number10 = (reference7.y - reference6.y);
                                                    number12 = (reference7.z - reference6.z);
                                                    number14 = Math.sqrt(((number8 * number8) + (number12 * number12)));
                                                    floating16 = ((float) (Math.toDegrees(Math.atan2(number12, number8)) - 90.0));
                                                    floating17 = ((float) (-Math.toDegrees(Math.atan2(number10, number14))));
                                                    Events.rotation.setYaw(floating16);
                                                    Events.rotation.setPitch(floating17);
                                                    this.pm$81(reference5);
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                Velocity.mc.player.setDeltaMovement((((Vec3) reference2).x * number3), ((Vec3) reference2).y, (((Vec3) reference2).z * number3));
                            }
                        }
                    }
                }
            }
        }
        saved44 = Events.packetSend;
        if (!((event != saved44))) {
            saved45 = (Events.packetSend.getPacket() instanceof ServerboundAttackPacket);
            if (saved45) {
                this.f372 = Velocity.mc.player.tickCount;
            }
            saved46 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
            if (saved46) {
                saved47 = this.f371;
                if (saved47) {
                    event.setCancelled(true);
                }
            }
        }
        saved48 = Events.packetReceive;
        if (!((event != saved48))) {
            reference2 = Events.packetReceive.getPacket();
            saved49 = (reference2 instanceof ClientboundSetEntityMotionPacket);
            if (saved49) {
                reference3 = ((ClientboundSetEntityMotionPacket) reference2);
                saved50 = Velocity.mc.player;
                if (!((saved50 != null))) {
                    return;
                } else {
                    saved51 = reference3.id();
                    saved52 = Velocity.mc.player.getId();
                    if (!((saved51 != saved52))) {
                        reference4 = reference3.movement();
                        saved53 = JvmSupport.dcmpl(((Vec3) reference4).y, 0.0);
                        if (!((saved53 <= 0))) {
                            saved54 = ModuleManager.longJump.isEnabled();
                            if (!(saved54)) {
                                saved55 = this.reverse.getValue();
                                number5 = (saved55 ? ((-this.horizontal.getValue()) * 0.01) : (this.horizontal.getValue() * 0.01));
                                number7 = (((Vec3) reference4).x * number5);
                                number9 = (((Vec3) reference4).y * (this.vertical.getValue() * 0.01));
                                number11 = (((Vec3) reference4).z * number5);
                                saved56 = JvmSupport.dcmpl(this.horizontal.getValue(), 100.0);
                                if (!((saved56 != 0))) {
                                    saved57 = this.reverse.getValue();
                                    if (saved57) {
                                        event.setCancelled(true);
                                    }
                                } else {
                                    event.setCancelled(true);
                                }
                                saved58 = JvmSupport.dcmpl(this.reduceTicks.getValue(), 0.0);
                                if (!((saved58 == 0))) {
                                    this.f368 = 0;
                                }
                                saved59 = this.delay.getValue();
                                if (saved59) {
                                    saved60 = this.pm$82();
                                    if (saved60) {
                                        this.f19.add(reference3);
                                        event.setCancelled(true);
                                    } else {
                                        saved61 = JvmSupport.dcmpl(this.horizontal.getValue(), 100.0);
                                        if (!((saved61 != 0))) {
                                            saved62 = this.reverse.getValue();
                                            if (saved62) {
                                                Velocity.mc.player.setDeltaMovement(new Vec3(number7, number9, number11));
                                            }
                                        } else {
                                            Velocity.mc.player.setDeltaMovement(new Vec3(number7, number9, number11));
                                        }
                                        saved63 = this.jumpReset.getValue();
                                        if (saved63) {
                                            saved64 = Velocity.mc.player.onGround();
                                            if (saved64) {
                                                saved65 = Velocity.mc.player.isSprinting();
                                                if (saved65) {
                                                    this.f370 = true;
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    saved66 = JvmSupport.dcmpl(this.horizontal.getValue(), 100.0);
                                    if (!((saved66 != 0))) {
                                        saved67 = this.reverse.getValue();
                                        if (saved67) {
                                            Velocity.mc.player.setDeltaMovement(new Vec3(number7, number9, number11));
                                        }
                                    } else {
                                        Velocity.mc.player.setDeltaMovement(new Vec3(number7, number9, number11));
                                    }
                                    saved68 = this.jumpReset.getValue();
                                    if (saved68) {
                                        saved69 = Velocity.mc.player.onGround();
                                        if (saved69) {
                                            saved70 = Velocity.mc.player.isSprinting();
                                            if (saved70) {
                                                this.f370 = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    return;
                }
            } else {
                saved71 = this.delay.getValue();
                if (saved71) {
                    saved72 = this.f19.isEmpty();
                    if (!(saved72)) {
                        saved73 = (reference2 instanceof ClientboundStartConfigurationPacket);
                        if (!(saved73)) {
                            saved74 = (reference2 instanceof ClientboundDisconnectPacket);
                            if (saved74) {
                                this.release();
                                return;
                            } else {
                                saved75 = this.f19;
                                reference4 = saved75;
                                synchronized (saved75) {
                                    this.f19.add(reference2);
                                    event.setCancelled(true);
                                }
                                return;
                            }
                        } else {
                            this.release();
                            return;
                        }
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
        } else {
            return;
        }
    }
}
