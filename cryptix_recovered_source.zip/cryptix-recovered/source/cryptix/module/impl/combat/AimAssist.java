package cryptix.module.impl.combat;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.MotionEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.NumberSetting;
import cryptix.util.TargetingUtils;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

/**
 * Reconstructed from a/zb.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class AimAssist extends Module {
    private static final String TEXT_RANGE;
    private static final String TEXT_SPEED;
    private static final String TEXT_AIMASSIST;
    private NumberSetting range;
    private NumberSetting speed;

    private float quantizeRotation(float rotation, float previousRotation) {
        float floating3 = 0.0f;
        float floating4 = 0.0f;
        float floating0 = 0.0f;
        floating3 = this.getMouseSensitivityStep();
        floating4 = (rotation - previousRotation);
        floating4 = (floating4 - (floating4 % floating3));
        floating0 = (previousRotation + floating4);
        return floating0;
    }

    private float getMouseSensitivityStep() {
        float floating1 = 0.0f;
        float floating2 = 0.0f;
        float floating0 = 0.0f;
        floating1 = ((Double) AimAssist.mc.options.sensitivity().get()).floatValue();
        floating2 = ((floating1 * 0.6f) + 0.2f);
        floating0 = ((((floating2 * floating2) * floating2) * 8.0f) * 0.15f);
        return floating0;
    }

    public void onEvent(Event event) {
        MotionEvent saved1 = null;
        LivingEntity reference2 = null;
        AABB reference3 = null;
        double number4 = 0.0;
        double number6 = 0.0;
        double number8 = 0.0;
        double number10 = 0.0;
        float floating12 = 0.0f;
        float floating13 = 0.0f;
        float floating14 = 0.0f;
        float floating15 = 0.0f;
        float floating16 = 0.0f;
        float floating17 = 0.0f;
        float floating18 = 0.0f;
        float floating19 = 0.0f;
        saved1 = Events.motion;
        if (!((event != saved1))) {
            reference2 = TargetingUtils.findTarget(this.range.getValue(), true);
            if (!((reference2 == null))) {
                reference3 = reference2.getBoundingBox();
                number4 = (Mth.clamp(AimAssist.mc.player.getX(), reference3.minX, reference3.maxX) - AimAssist.mc.player.getX());
                number6 = (Mth.clamp(AimAssist.mc.player.getEyeY(), reference3.minY, reference3.maxY) - AimAssist.mc.player.getEyeY());
                number8 = (Mth.clamp(AimAssist.mc.player.getZ(), reference3.minZ, reference3.maxZ) - AimAssist.mc.player.getZ());
                number10 = Math.sqrt(((number4 * number4) + (number8 * number8)));
                floating12 = ((float) (Math.toDegrees(Math.atan2(number8, number4)) - 90.0));
                floating13 = ((float) (-Math.toDegrees(Math.atan2(number6, number10))));
                floating14 = Mth.wrapDegrees((floating12 - AimAssist.mc.player.getYRot()));
                floating15 = (floating13 - AimAssist.mc.player.getXRot());
                floating16 = ((float) Math.min(((double) Math.abs(floating14)), this.speed.getValue()));
                floating17 = ((float) Math.min(((double) Math.abs(floating15)), this.speed.getValue()));
                floating18 = this.quantizeRotation(Math.copySign(floating16, floating14), AimAssist.mc.player.getYRot());
                floating19 = this.quantizeRotation(Math.copySign(floating17, floating15), AimAssist.mc.player.getXRot());
                AimAssist.mc.player.setYRot((AimAssist.mc.player.getYRot() + floating18));
                AimAssist.mc.player.setXRot((AimAssist.mc.player.getXRot() + floating19));
            }
        }
    }

    static {
        TEXT_AIMASSIST = new String("AimAssist");
        TEXT_RANGE = new String("Range");
        TEXT_SPEED = new String("Speed");
    }

    public AimAssist() {
        super(AimAssist.TEXT_AIMASSIST, Category.COMBAT);
        this.range = new NumberSetting(AimAssist.TEXT_RANGE, this, 6.0, 3.0, 8.0, 0.5);
        this.speed = new NumberSetting(AimAssist.TEXT_SPEED, this, 5.0, 1.0, 10.0, 0.5);
    }
}
