package cryptix.module.impl.combat;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.MouseButtonEvent;
import cryptix.event.impl.PacketSendEvent;
import cryptix.event.impl.PostMotionEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.module.ModuleManager;
import cryptix.network.PacketBuffer;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.ModeSetting;
import cryptix.setting.NumberSetting;
import cryptix.util.Recovered_ee;
import cryptix.util.TargetingUtils;
import java.util.Iterator;
import java.util.Optional;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.hurtingprojectile.Fireball;
import net.minecraft.world.entity.projectile.hurtingprojectile.LargeFireball;
import net.minecraft.world.entity.projectile.hurtingprojectile.SmallFireball;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

/**
 * Reconstructed from a/wt.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class KillAura extends Module {
    private final NumberSetting rotationRange;
    private static final String TEXT_WATCHDOG2;
    private static final String TEXT_KILLAURA;
    private final BooleanSetting attackCrits;
    private static final String TEXT_SWAP2;
    private static final String TEXT_OPTIMAL;
    public boolean f16;
    private float f327;
    private boolean f323;
    private static final String TEXT_CYCLE;
    private boolean f316;
    private float f324;
    private final BooleanSetting attackTeammates;
    private static final String TEXT_AUTOBLOCK_RMB;
    private static final String TEXT_ATTACK_COOLDOWN;
    private int f319;
    private boolean f315;
    private boolean f313;
    private final NumberSetting attackDelay;
    private static final String TEXT_VANILLA;
    public Entity f18;
    private final BooleanSetting requireSword;
    private final NumberSetting attackDelay2;
    private static final String TEXT_ROTATION_RANGE;
    private static final String TEXT_SHIELD;
    private static final String TEXT_REQUIRE_SWORD;
    private int f312;
    public boolean f17;
    private static final String TEXT_DISABLED;
    private final ModeSetting autoBlock;
    private static final String TEXT_AUTOBLOCK;
    private final ModeSetting rotations;
    private int f318;
    private static final String TEXT_ATTACK_CRITS;
    private final BooleanSetting autoBlockRMB;
    private static final String TEXT_FAKE;
    private int f322;
    private final BooleanSetting attackCooldown;
    private static final String TEXT_ATTACK_DELAY;
    private static final String TEXT_ROTATIONS;
    private boolean f320;
    private float f325;
    private static final String TEXT_ATTACK_TEAMMATES;
    private static final String TEXT_SWAP;
    private static final String TEXT_WATCHDOG;
    private float f326;
    private boolean f314;
    private final BooleanSetting attackFireballs;
    private final BooleanSetting ignoreShield;
    private int f321;
    private boolean f317;
    private static final String TEXT_ATTACK_DELAY2;
    private static final String TEXT_IGNORE_SHIELD;
    private static final String TEXT_HEAD;
    private static final String TEXT_ATTACK_FIREBALLS;

    public void onEvent(Event event) {
        PostMotionEvent saved1 = null;
        boolean saved2 = false;
        Entity saved3 = null;
        boolean saved4 = false;
        MouseButtonEvent saved5 = null;
        Screen saved6 = null;
        Entity saved7 = null;
        RotationEvent saved8 = null;
        Screen saved9 = null;
        boolean saved10 = false;
        int saved11 = 0;
        int branchValue12 = 0;
        int integer2 = 0;
        boolean saved13 = false;
        Entity reference3 = null;
        double number3 = 0.0;
        boolean saved14 = false;
        boolean saved15 = false;
        boolean saved16 = false;
        Entity saved17 = null;
        int integer5 = 0;
        boolean saved18 = false;
        double number6 = 0.0;
        boolean saved19 = false;
        int saved20 = 0;
        boolean saved21 = false;
        Entity reference9 = null;
        boolean saved22 = false;
        Player reference8 = null;
        boolean saved23 = false;
        boolean saved24 = false;
        boolean saved25 = false;
        boolean saved26 = false;
        boolean saved27 = false;
        boolean saved28 = false;
        boolean saved29 = false;
        boolean saved30 = false;
        boolean saved31 = false;
        boolean saved32 = false;
        boolean saved33 = false;
        boolean saved34 = false;
        boolean saved35 = false;
        boolean saved36 = false;
        boolean saved37 = false;
        boolean saved38 = false;
        boolean saved39 = false;
        PacketSendEvent saved40 = null;
        boolean saved41 = false;
        boolean saved42 = false;
        Entity saved43 = null;
        Entity saved44 = null;
        boolean saved45 = false;
        boolean saved46 = false;
        boolean saved47 = false;
        boolean saved48 = false;
        boolean saved49 = false;
        boolean saved50 = false;
        boolean saved51 = false;
        boolean saved52 = false;
        boolean saved53 = false;
        boolean saved54 = false;
        boolean saved55 = false;
        boolean saved56 = false;
        boolean saved57 = false;
        boolean saved58 = false;
        boolean saved59 = false;
        PacketSendEvent saved60 = null;
        boolean saved61 = false;
        boolean saved62 = false;
        Entity saved63 = null;
        Entity saved64 = null;
        boolean saved65 = false;
        boolean saved66 = false;
        boolean saved67 = false;
        boolean saved68 = false;
        boolean saved69 = false;
        boolean saved70 = false;
        boolean saved71 = false;
        boolean saved72 = false;
        boolean saved73 = false;
        boolean saved74 = false;
        boolean saved75 = false;
        boolean saved76 = false;
        boolean saved77 = false;
        boolean saved78 = false;
        boolean saved79 = false;
        PacketSendEvent saved80 = null;
        boolean saved81 = false;
        boolean saved82 = false;
        Entity saved83 = null;
        Entity saved84 = null;
        boolean saved85 = false;
        boolean saved86 = false;
        boolean saved87 = false;
        boolean saved88 = false;
        boolean saved89 = false;
        boolean saved90 = false;
        boolean saved91 = false;
        boolean saved92 = false;
        boolean saved93 = false;
        boolean saved94 = false;
        boolean saved95 = false;
        boolean saved96 = false;
        boolean saved97 = false;
        boolean saved98 = false;
        boolean saved99 = false;
        PacketSendEvent saved100 = null;
        boolean saved101 = false;
        boolean saved102 = false;
        Entity saved103 = null;
        Entity saved104 = null;
        boolean saved105 = false;
        boolean saved106 = false;
        boolean saved107 = false;
        boolean saved108 = false;
        PacketSendEvent saved109 = null;
        boolean saved110 = false;
        boolean saved111 = false;
        Entity saved112 = null;
        Entity saved113 = null;
        boolean saved114 = false;
        boolean saved115 = false;
        boolean saved116 = false;
        boolean saved117 = false;
        PacketSendEvent saved118 = null;
        boolean saved119 = false;
        boolean saved120 = false;
        Entity saved121 = null;
        Entity saved122 = null;
        boolean saved123 = false;
        boolean saved124 = false;
        boolean saved125 = false;
        boolean saved126 = false;
        PacketSendEvent saved127 = null;
        boolean saved128 = false;
        boolean saved129 = false;
        Entity saved130 = null;
        Entity saved131 = null;
        PacketSendEvent saved132 = null;
        boolean saved133 = false;
        boolean saved134 = false;
        Entity saved135 = null;
        Entity saved136 = null;
        boolean saved137 = false;
        boolean saved138 = false;
        boolean saved139 = false;
        Entity saved140 = null;
        boolean saved141 = false;
        boolean saved142 = false;
        int saved143 = 0;
        boolean saved144 = false;
        boolean saved145 = false;
        boolean saved146 = false;
        boolean saved147 = false;
        boolean saved148 = false;
        boolean saved149 = false;
        boolean saved150 = false;
        boolean saved151 = false;
        boolean saved152 = false;
        boolean saved153 = false;
        boolean saved154 = false;
        boolean saved155 = false;
        boolean saved156 = false;
        boolean saved157 = false;
        boolean saved158 = false;
        boolean saved159 = false;
        boolean saved160 = false;
        boolean saved161 = false;
        boolean saved162 = false;
        PacketSendEvent saved163 = null;
        boolean saved164 = false;
        boolean saved165 = false;
        Entity saved166 = null;
        Entity saved167 = null;
        boolean saved168 = false;
        boolean saved169 = false;
        boolean saved170 = false;
        boolean saved171 = false;
        boolean saved172 = false;
        boolean saved173 = false;
        boolean saved174 = false;
        boolean saved175 = false;
        boolean saved176 = false;
        boolean saved177 = false;
        boolean saved178 = false;
        boolean saved179 = false;
        boolean saved180 = false;
        boolean saved181 = false;
        boolean saved182 = false;
        PacketSendEvent saved183 = null;
        boolean saved184 = false;
        boolean saved185 = false;
        Entity saved186 = null;
        Entity saved187 = null;
        boolean saved188 = false;
        boolean saved189 = false;
        boolean saved190 = false;
        boolean saved191 = false;
        boolean saved192 = false;
        boolean saved193 = false;
        boolean saved194 = false;
        boolean saved195 = false;
        boolean saved196 = false;
        boolean saved197 = false;
        boolean saved198 = false;
        boolean saved199 = false;
        boolean saved200 = false;
        boolean saved201 = false;
        boolean saved202 = false;
        PacketSendEvent saved203 = null;
        boolean saved204 = false;
        boolean saved205 = false;
        Entity saved206 = null;
        Entity saved207 = null;
        boolean saved208 = false;
        boolean saved209 = false;
        boolean saved210 = false;
        boolean saved211 = false;
        boolean saved212 = false;
        boolean saved213 = false;
        boolean saved214 = false;
        boolean saved215 = false;
        boolean saved216 = false;
        boolean saved217 = false;
        boolean saved218 = false;
        boolean saved219 = false;
        boolean saved220 = false;
        boolean saved221 = false;
        boolean saved222 = false;
        PacketSendEvent saved223 = null;
        boolean saved224 = false;
        boolean saved225 = false;
        Entity saved226 = null;
        Entity saved227 = null;
        boolean saved228 = false;
        boolean saved229 = false;
        boolean saved230 = false;
        boolean saved231 = false;
        PacketSendEvent saved232 = null;
        boolean saved233 = false;
        boolean saved234 = false;
        Entity saved235 = null;
        Entity saved236 = null;
        boolean saved237 = false;
        boolean saved238 = false;
        boolean saved239 = false;
        boolean saved240 = false;
        PacketSendEvent saved241 = null;
        boolean saved242 = false;
        boolean saved243 = false;
        Entity saved244 = null;
        Entity saved245 = null;
        boolean saved246 = false;
        boolean saved247 = false;
        boolean saved248 = false;
        boolean saved249 = false;
        PacketSendEvent saved250 = null;
        boolean saved251 = false;
        boolean saved252 = false;
        Entity saved253 = null;
        Entity saved254 = null;
        PacketSendEvent saved255 = null;
        boolean saved256 = false;
        boolean saved257 = false;
        Entity saved258 = null;
        Entity saved259 = null;
        PacketSendEvent saved260 = null;
        boolean saved261 = false;
        boolean saved262 = false;
        Entity saved263 = null;
        Entity saved264 = null;
        saved1 = Events.postMotion;
        if (!((event != saved1))) {
            saved2 = this.f317;
            if (saved2) {
                saved3 = this.f18;
                if (!((saved3 == null))) {
                    this.f317 = false;
                    saved4 = this.autoBlock.is(KillAura.TEXT_WATCHDOG2);
                    if (!(saved4)) {
                        this.pm$71();
                    } else {
                        this.pm$72();
                    }
                }
            }
        }
        saved5 = Events.mouseButton;
        if (!((event != saved5))) {
            saved6 = KillAura.mc.gui.screen();
            if (!((saved6 != null))) {
                saved7 = this.f18;
                if (!((saved7 == null))) {
                    event.setCancelled(true);
                }
            }
        }
        saved8 = Events.rotation;
        if (!((event != saved8))) {
            this.f16 = false;
            saved9 = KillAura.mc.gui.screen();
            if (!((saved9 == null))) {
                this.pm$79();
                return;
            } else {
                saved10 = this.attackCooldown.getValue();
                if (saved10) {
                    saved11 = JvmSupport.fcmpl(KillAura.mc.player.getAttackStrengthScale(0.0f), 1.0f);
                    branchValue12 = (!((saved11 < 0)) ? 1 : 0);
                } else {
                    branchValue12 = 1;
                }
                integer2 = branchValue12;
                if (!((integer2 == 0))) {
                    this.f312 = (this.f312 + 1);
                }
                saved13 = this.attackFireballs.getValue();
                if (saved13) {
                    reference3 = this.findFireballTarget(3.0);
                    if (!((reference3 == null))) {
                        this.pm$76(reference3);
                        Events.rotation.setYaw(this.f324);
                        Events.rotation.setPitch(this.f325);
                        this.pm$79();
                        KillAura.mc.gameMode.attack(KillAura.mc.player, reference3);
                        KillAura.mc.player.swing(InteractionHand.MAIN_HAND);
                        this.f18 = reference3;
                        return;
                    } else {
                        number3 = this.rotationRange.getValue();
                        saved14 = this.attackTeammates.getValue();
                        if (!(saved14)) {
                            this.f18 = TargetingUtils.m54(number3, true);
                        } else {
                            this.f18 = TargetingUtils.findTarget(number3, true);
                        }
                        saved15 = this.requireSword.getValue();
                        if (saved15) {
                            saved16 = Recovered_ee.m44();
                            if (!(saved16)) {
                                this.f18 = null;
                            }
                        }
                        saved17 = this.f18;
                        if (!((saved17 == null))) {
                            this.pm$76(this.f18);
                            Events.rotation.setYaw(this.f324);
                            Events.rotation.setPitch(this.f325);
                            integer5 = (this.pm$80() ? 1 : 0);
                            saved18 = this.f314;
                            number6 = (saved18 ? this.attackDelay2.getValue() : this.attackDelay.getValue());
                            saved19 = ModuleManager.velocity.f19.isEmpty();
                            if (saved19) {
                                saved20 = JvmSupport.dcmpl(((double) this.f312), number6);
                                if (!((saved20 <= 0))) {
                                    if (!((integer2 == 0))) {
                                        saved21 = this.ignoreShield.getValue();
                                        if (saved21) {
                                            reference9 = this.f18;
                                            saved22 = (reference9 instanceof Player);
                                            if (saved22) {
                                                reference8 = ((Player) (Object) reference9);
                                                saved23 = reference8.isUsingItem();
                                                if (saved23) {
                                                    saved24 = reference8.getUseItem().is(Items.SHIELD);
                                                    if (saved24) {
                                                        System.out.println(KillAura.TEXT_SHIELD);
                                                        return;
                                                    } else {
                                                        saved25 = this.autoBlock.is(KillAura.TEXT_WATCHDOG);
                                                        if (!(saved25)) {
                                                            saved26 = this.autoBlock.is(KillAura.TEXT_WATCHDOG2);
                                                            if (!(saved26)) {
                                                                saved27 = this.autoBlock.is(KillAura.TEXT_SWAP);
                                                                if (!(saved27)) {
                                                                    saved28 = this.autoBlock.is(KillAura.TEXT_SWAP2);
                                                                    if (!(saved28)) {
                                                                        saved29 = this.autoBlock.is(KillAura.TEXT_CYCLE);
                                                                        if (saved29) {
                                                                            if (!((integer5 != 0))) {
                                                                                saved30 = this.f17;
                                                                                if (!(saved30)) {
                                                                                    this.f312 = 0;
                                                                                    this.pm$70(this.f324, this.f325, false);
                                                                                }
                                                                            }
                                                                        } else {
                                                                            this.f312 = 0;
                                                                            this.pm$70(this.f324, this.f325, false);
                                                                        }
                                                                    } else {
                                                                        if (!((integer5 != 0))) {
                                                                            saved31 = this.f17;
                                                                            if (!(saved31)) {
                                                                                this.f312 = 0;
                                                                                this.pm$70(this.f324, this.f325, false);
                                                                            }
                                                                        }
                                                                    }
                                                                } else {
                                                                    if (!((integer5 != 0))) {
                                                                        saved32 = this.f17;
                                                                        if (!(saved32)) {
                                                                            this.f312 = 0;
                                                                            this.pm$70(this.f324, this.f325, false);
                                                                        }
                                                                    }
                                                                }
                                                            } else {
                                                                if (!((integer5 != 0))) {
                                                                    saved33 = this.f17;
                                                                    if (!(saved33)) {
                                                                        this.f312 = 0;
                                                                        this.pm$70(this.f324, this.f325, false);
                                                                    }
                                                                }
                                                            }
                                                        } else {
                                                            if (!((integer5 != 0))) {
                                                                saved34 = this.f17;
                                                                if (!(saved34)) {
                                                                    this.f312 = 0;
                                                                    this.pm$70(this.f324, this.f325, false);
                                                                }
                                                            }
                                                        }
                                                        saved35 = this.f314;
                                                        this.f314 = ((!(saved35) ? 1 : 0) != 0);
                                                        saved36 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                                        if (!(saved36)) {
                                                            saved37 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                                            if (saved37) {
                                                                if (!((integer5 == 0))) {
                                                                    KillAura.mc.options.keyUse.setDown(false);
                                                                    this.pm$65(this.f18, this.f324, this.f325);
                                                                } else {
                                                                    saved38 = this.f17;
                                                                    if (saved38) {
                                                                        this.pm$72();
                                                                    }
                                                                    saved39 = this.f320;
                                                                    if (saved39) {
                                                                        this.f320 = false;
                                                                        PacketBuffer.stopAndFlush();
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        saved40 = Events.packetSend;
                                                        if (!((event != saved40))) {
                                                            saved41 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                                            if (saved41) {
                                                                saved42 = this.f313;
                                                                if (saved42) {
                                                                    event.setCancelled(true);
                                                                } else {
                                                                    saved43 = this.f18;
                                                                    if (!((saved43 == null))) {
                                                                        this.f313 = true;
                                                                    }
                                                                }
                                                            } else {
                                                                saved44 = this.f18;
                                                                if (!((saved44 == null))) {
                                                                    this.f313 = true;
                                                                }
                                                            }
                                                        }
                                                        return;
                                                    }
                                                } else {
                                                    saved45 = this.autoBlock.is(KillAura.TEXT_WATCHDOG);
                                                    if (!(saved45)) {
                                                        saved46 = this.autoBlock.is(KillAura.TEXT_WATCHDOG2);
                                                        if (!(saved46)) {
                                                            saved47 = this.autoBlock.is(KillAura.TEXT_SWAP);
                                                            if (!(saved47)) {
                                                                saved48 = this.autoBlock.is(KillAura.TEXT_SWAP2);
                                                                if (!(saved48)) {
                                                                    saved49 = this.autoBlock.is(KillAura.TEXT_CYCLE);
                                                                    if (saved49) {
                                                                        if (!((integer5 != 0))) {
                                                                            saved50 = this.f17;
                                                                            if (!(saved50)) {
                                                                                this.f312 = 0;
                                                                                this.pm$70(this.f324, this.f325, false);
                                                                            }
                                                                        }
                                                                    } else {
                                                                        this.f312 = 0;
                                                                        this.pm$70(this.f324, this.f325, false);
                                                                    }
                                                                } else {
                                                                    if (!((integer5 != 0))) {
                                                                        saved51 = this.f17;
                                                                        if (!(saved51)) {
                                                                            this.f312 = 0;
                                                                            this.pm$70(this.f324, this.f325, false);
                                                                        }
                                                                    }
                                                                }
                                                            } else {
                                                                if (!((integer5 != 0))) {
                                                                    saved52 = this.f17;
                                                                    if (!(saved52)) {
                                                                        this.f312 = 0;
                                                                        this.pm$70(this.f324, this.f325, false);
                                                                    }
                                                                }
                                                            }
                                                        } else {
                                                            if (!((integer5 != 0))) {
                                                                saved53 = this.f17;
                                                                if (!(saved53)) {
                                                                    this.f312 = 0;
                                                                    this.pm$70(this.f324, this.f325, false);
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        if (!((integer5 != 0))) {
                                                            saved54 = this.f17;
                                                            if (!(saved54)) {
                                                                this.f312 = 0;
                                                                this.pm$70(this.f324, this.f325, false);
                                                            }
                                                        }
                                                    }
                                                    saved55 = this.f314;
                                                    this.f314 = ((!(saved55) ? 1 : 0) != 0);
                                                    saved56 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                                    if (!(saved56)) {
                                                        saved57 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                                        if (saved57) {
                                                            if (!((integer5 == 0))) {
                                                                KillAura.mc.options.keyUse.setDown(false);
                                                                this.pm$65(this.f18, this.f324, this.f325);
                                                            } else {
                                                                saved58 = this.f17;
                                                                if (saved58) {
                                                                    this.pm$72();
                                                                }
                                                                saved59 = this.f320;
                                                                if (saved59) {
                                                                    this.f320 = false;
                                                                    PacketBuffer.stopAndFlush();
                                                                }
                                                            }
                                                        }
                                                    }
                                                    saved60 = Events.packetSend;
                                                    if (!((event != saved60))) {
                                                        saved61 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                                        if (saved61) {
                                                            saved62 = this.f313;
                                                            if (saved62) {
                                                                event.setCancelled(true);
                                                            } else {
                                                                saved63 = this.f18;
                                                                if (!((saved63 == null))) {
                                                                    this.f313 = true;
                                                                }
                                                            }
                                                        } else {
                                                            saved64 = this.f18;
                                                            if (!((saved64 == null))) {
                                                                this.f313 = true;
                                                            }
                                                        }
                                                    }
                                                    return;
                                                }
                                            } else {
                                                saved65 = this.autoBlock.is(KillAura.TEXT_WATCHDOG);
                                                if (!(saved65)) {
                                                    saved66 = this.autoBlock.is(KillAura.TEXT_WATCHDOG2);
                                                    if (!(saved66)) {
                                                        saved67 = this.autoBlock.is(KillAura.TEXT_SWAP);
                                                        if (!(saved67)) {
                                                            saved68 = this.autoBlock.is(KillAura.TEXT_SWAP2);
                                                            if (!(saved68)) {
                                                                saved69 = this.autoBlock.is(KillAura.TEXT_CYCLE);
                                                                if (saved69) {
                                                                    if (!((integer5 != 0))) {
                                                                        saved70 = this.f17;
                                                                        if (!(saved70)) {
                                                                            this.f312 = 0;
                                                                            this.pm$70(this.f324, this.f325, false);
                                                                        }
                                                                    }
                                                                } else {
                                                                    this.f312 = 0;
                                                                    this.pm$70(this.f324, this.f325, false);
                                                                }
                                                            } else {
                                                                if (!((integer5 != 0))) {
                                                                    saved71 = this.f17;
                                                                    if (!(saved71)) {
                                                                        this.f312 = 0;
                                                                        this.pm$70(this.f324, this.f325, false);
                                                                    }
                                                                }
                                                            }
                                                        } else {
                                                            if (!((integer5 != 0))) {
                                                                saved72 = this.f17;
                                                                if (!(saved72)) {
                                                                    this.f312 = 0;
                                                                    this.pm$70(this.f324, this.f325, false);
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        if (!((integer5 != 0))) {
                                                            saved73 = this.f17;
                                                            if (!(saved73)) {
                                                                this.f312 = 0;
                                                                this.pm$70(this.f324, this.f325, false);
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if (!((integer5 != 0))) {
                                                        saved74 = this.f17;
                                                        if (!(saved74)) {
                                                            this.f312 = 0;
                                                            this.pm$70(this.f324, this.f325, false);
                                                        }
                                                    }
                                                }
                                                saved75 = this.f314;
                                                this.f314 = ((!(saved75) ? 1 : 0) != 0);
                                                saved76 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                                if (!(saved76)) {
                                                    saved77 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                                    if (saved77) {
                                                        if (!((integer5 == 0))) {
                                                            KillAura.mc.options.keyUse.setDown(false);
                                                            this.pm$65(this.f18, this.f324, this.f325);
                                                        } else {
                                                            saved78 = this.f17;
                                                            if (saved78) {
                                                                this.pm$72();
                                                            }
                                                            saved79 = this.f320;
                                                            if (saved79) {
                                                                this.f320 = false;
                                                                PacketBuffer.stopAndFlush();
                                                            }
                                                        }
                                                    }
                                                }
                                                saved80 = Events.packetSend;
                                                if (!((event != saved80))) {
                                                    saved81 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                                    if (saved81) {
                                                        saved82 = this.f313;
                                                        if (saved82) {
                                                            event.setCancelled(true);
                                                        } else {
                                                            saved83 = this.f18;
                                                            if (!((saved83 == null))) {
                                                                this.f313 = true;
                                                            }
                                                        }
                                                    } else {
                                                        saved84 = this.f18;
                                                        if (!((saved84 == null))) {
                                                            this.f313 = true;
                                                        }
                                                    }
                                                }
                                                return;
                                            }
                                        } else {
                                            saved85 = this.autoBlock.is(KillAura.TEXT_WATCHDOG);
                                            if (!(saved85)) {
                                                saved86 = this.autoBlock.is(KillAura.TEXT_WATCHDOG2);
                                                if (!(saved86)) {
                                                    saved87 = this.autoBlock.is(KillAura.TEXT_SWAP);
                                                    if (!(saved87)) {
                                                        saved88 = this.autoBlock.is(KillAura.TEXT_SWAP2);
                                                        if (!(saved88)) {
                                                            saved89 = this.autoBlock.is(KillAura.TEXT_CYCLE);
                                                            if (saved89) {
                                                                if (!((integer5 != 0))) {
                                                                    saved90 = this.f17;
                                                                    if (!(saved90)) {
                                                                        this.f312 = 0;
                                                                        this.pm$70(this.f324, this.f325, false);
                                                                    }
                                                                }
                                                            } else {
                                                                this.f312 = 0;
                                                                this.pm$70(this.f324, this.f325, false);
                                                            }
                                                        } else {
                                                            if (!((integer5 != 0))) {
                                                                saved91 = this.f17;
                                                                if (!(saved91)) {
                                                                    this.f312 = 0;
                                                                    this.pm$70(this.f324, this.f325, false);
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        if (!((integer5 != 0))) {
                                                            saved92 = this.f17;
                                                            if (!(saved92)) {
                                                                this.f312 = 0;
                                                                this.pm$70(this.f324, this.f325, false);
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if (!((integer5 != 0))) {
                                                        saved93 = this.f17;
                                                        if (!(saved93)) {
                                                            this.f312 = 0;
                                                            this.pm$70(this.f324, this.f325, false);
                                                        }
                                                    }
                                                }
                                            } else {
                                                if (!((integer5 != 0))) {
                                                    saved94 = this.f17;
                                                    if (!(saved94)) {
                                                        this.f312 = 0;
                                                        this.pm$70(this.f324, this.f325, false);
                                                    }
                                                }
                                            }
                                            saved95 = this.f314;
                                            this.f314 = ((!(saved95) ? 1 : 0) != 0);
                                            saved96 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                            if (!(saved96)) {
                                                saved97 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                                if (saved97) {
                                                    if (!((integer5 == 0))) {
                                                        KillAura.mc.options.keyUse.setDown(false);
                                                        this.pm$65(this.f18, this.f324, this.f325);
                                                    } else {
                                                        saved98 = this.f17;
                                                        if (saved98) {
                                                            this.pm$72();
                                                        }
                                                        saved99 = this.f320;
                                                        if (saved99) {
                                                            this.f320 = false;
                                                            PacketBuffer.stopAndFlush();
                                                        }
                                                    }
                                                }
                                            }
                                            saved100 = Events.packetSend;
                                            if (!((event != saved100))) {
                                                saved101 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                                if (saved101) {
                                                    saved102 = this.f313;
                                                    if (saved102) {
                                                        event.setCancelled(true);
                                                    } else {
                                                        saved103 = this.f18;
                                                        if (!((saved103 == null))) {
                                                            this.f313 = true;
                                                        }
                                                    }
                                                } else {
                                                    saved104 = this.f18;
                                                    if (!((saved104 == null))) {
                                                        this.f313 = true;
                                                    }
                                                }
                                            }
                                            return;
                                        }
                                    } else {
                                        saved105 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                        if (!(saved105)) {
                                            saved106 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                            if (saved106) {
                                                if (!((integer5 == 0))) {
                                                    KillAura.mc.options.keyUse.setDown(false);
                                                    this.pm$65(this.f18, this.f324, this.f325);
                                                } else {
                                                    saved107 = this.f17;
                                                    if (saved107) {
                                                        this.pm$72();
                                                    }
                                                    saved108 = this.f320;
                                                    if (saved108) {
                                                        this.f320 = false;
                                                        PacketBuffer.stopAndFlush();
                                                    }
                                                }
                                            }
                                        }
                                        saved109 = Events.packetSend;
                                        if (!((event != saved109))) {
                                            saved110 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                            if (saved110) {
                                                saved111 = this.f313;
                                                if (saved111) {
                                                    event.setCancelled(true);
                                                } else {
                                                    saved112 = this.f18;
                                                    if (!((saved112 == null))) {
                                                        this.f313 = true;
                                                    }
                                                }
                                            } else {
                                                saved113 = this.f18;
                                                if (!((saved113 == null))) {
                                                    this.f313 = true;
                                                }
                                            }
                                        }
                                        return;
                                    }
                                } else {
                                    saved114 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                    if (!(saved114)) {
                                        saved115 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                        if (saved115) {
                                            if (!((integer5 == 0))) {
                                                KillAura.mc.options.keyUse.setDown(false);
                                                this.pm$65(this.f18, this.f324, this.f325);
                                            } else {
                                                saved116 = this.f17;
                                                if (saved116) {
                                                    this.pm$72();
                                                }
                                                saved117 = this.f320;
                                                if (saved117) {
                                                    this.f320 = false;
                                                    PacketBuffer.stopAndFlush();
                                                }
                                            }
                                        }
                                    }
                                    saved118 = Events.packetSend;
                                    if (!((event != saved118))) {
                                        saved119 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                        if (saved119) {
                                            saved120 = this.f313;
                                            if (saved120) {
                                                event.setCancelled(true);
                                            } else {
                                                saved121 = this.f18;
                                                if (!((saved121 == null))) {
                                                    this.f313 = true;
                                                }
                                            }
                                        } else {
                                            saved122 = this.f18;
                                            if (!((saved122 == null))) {
                                                this.f313 = true;
                                            }
                                        }
                                    }
                                    return;
                                }
                            } else {
                                saved123 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                if (!(saved123)) {
                                    saved124 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                    if (saved124) {
                                        if (!((integer5 == 0))) {
                                            KillAura.mc.options.keyUse.setDown(false);
                                            this.pm$65(this.f18, this.f324, this.f325);
                                        } else {
                                            saved125 = this.f17;
                                            if (saved125) {
                                                this.pm$72();
                                            }
                                            saved126 = this.f320;
                                            if (saved126) {
                                                this.f320 = false;
                                                PacketBuffer.stopAndFlush();
                                            }
                                        }
                                    }
                                }
                                saved127 = Events.packetSend;
                                if (!((event != saved127))) {
                                    saved128 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                    if (saved128) {
                                        saved129 = this.f313;
                                        if (saved129) {
                                            event.setCancelled(true);
                                        } else {
                                            saved130 = this.f18;
                                            if (!((saved130 == null))) {
                                                this.f313 = true;
                                            }
                                        }
                                    } else {
                                        saved131 = this.f18;
                                        if (!((saved131 == null))) {
                                            this.f313 = true;
                                        }
                                    }
                                }
                                return;
                            }
                        } else {
                            this.pm$79();
                            saved132 = Events.packetSend;
                            if (!((event != saved132))) {
                                saved133 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                if (saved133) {
                                    saved134 = this.f313;
                                    if (saved134) {
                                        event.setCancelled(true);
                                    } else {
                                        saved135 = this.f18;
                                        if (!((saved135 == null))) {
                                            this.f313 = true;
                                        }
                                    }
                                } else {
                                    saved136 = this.f18;
                                    if (!((saved136 == null))) {
                                        this.f313 = true;
                                    }
                                }
                            }
                            return;
                        }
                    }
                } else {
                    number3 = this.rotationRange.getValue();
                    saved137 = this.attackTeammates.getValue();
                    if (!(saved137)) {
                        this.f18 = TargetingUtils.m54(number3, true);
                    } else {
                        this.f18 = TargetingUtils.findTarget(number3, true);
                    }
                    saved138 = this.requireSword.getValue();
                    if (saved138) {
                        saved139 = Recovered_ee.m44();
                        if (!(saved139)) {
                            this.f18 = null;
                        }
                    }
                    saved140 = this.f18;
                    if (!((saved140 == null))) {
                        this.pm$76(this.f18);
                        Events.rotation.setYaw(this.f324);
                        Events.rotation.setPitch(this.f325);
                        integer5 = (this.pm$80() ? 1 : 0);
                        saved141 = this.f314;
                        number6 = (saved141 ? this.attackDelay2.getValue() : this.attackDelay.getValue());
                        saved142 = ModuleManager.velocity.f19.isEmpty();
                        if (saved142) {
                            saved143 = JvmSupport.dcmpl(((double) this.f312), number6);
                            if (!((saved143 <= 0))) {
                                if (!((integer2 == 0))) {
                                    saved144 = this.ignoreShield.getValue();
                                    if (saved144) {
                                        reference9 = this.f18;
                                        saved145 = (reference9 instanceof Player);
                                        if (saved145) {
                                            reference8 = ((Player) (Object) reference9);
                                            saved146 = reference8.isUsingItem();
                                            if (saved146) {
                                                saved147 = reference8.getUseItem().is(Items.SHIELD);
                                                if (saved147) {
                                                    System.out.println(KillAura.TEXT_SHIELD);
                                                    return;
                                                } else {
                                                    saved148 = this.autoBlock.is(KillAura.TEXT_WATCHDOG);
                                                    if (!(saved148)) {
                                                        saved149 = this.autoBlock.is(KillAura.TEXT_WATCHDOG2);
                                                        if (!(saved149)) {
                                                            saved150 = this.autoBlock.is(KillAura.TEXT_SWAP);
                                                            if (!(saved150)) {
                                                                saved151 = this.autoBlock.is(KillAura.TEXT_SWAP2);
                                                                if (!(saved151)) {
                                                                    saved152 = this.autoBlock.is(KillAura.TEXT_CYCLE);
                                                                    if (saved152) {
                                                                        if (!((integer5 != 0))) {
                                                                            saved153 = this.f17;
                                                                            if (!(saved153)) {
                                                                                this.f312 = 0;
                                                                                this.pm$70(this.f324, this.f325, false);
                                                                            }
                                                                        }
                                                                    } else {
                                                                        this.f312 = 0;
                                                                        this.pm$70(this.f324, this.f325, false);
                                                                    }
                                                                } else {
                                                                    if (!((integer5 != 0))) {
                                                                        saved154 = this.f17;
                                                                        if (!(saved154)) {
                                                                            this.f312 = 0;
                                                                            this.pm$70(this.f324, this.f325, false);
                                                                        }
                                                                    }
                                                                }
                                                            } else {
                                                                if (!((integer5 != 0))) {
                                                                    saved155 = this.f17;
                                                                    if (!(saved155)) {
                                                                        this.f312 = 0;
                                                                        this.pm$70(this.f324, this.f325, false);
                                                                    }
                                                                }
                                                            }
                                                        } else {
                                                            if (!((integer5 != 0))) {
                                                                saved156 = this.f17;
                                                                if (!(saved156)) {
                                                                    this.f312 = 0;
                                                                    this.pm$70(this.f324, this.f325, false);
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        if (!((integer5 != 0))) {
                                                            saved157 = this.f17;
                                                            if (!(saved157)) {
                                                                this.f312 = 0;
                                                                this.pm$70(this.f324, this.f325, false);
                                                            }
                                                        }
                                                    }
                                                    saved158 = this.f314;
                                                    this.f314 = ((!(saved158) ? 1 : 0) != 0);
                                                    saved159 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                                    if (!(saved159)) {
                                                        saved160 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                                        if (saved160) {
                                                            if (!((integer5 == 0))) {
                                                                KillAura.mc.options.keyUse.setDown(false);
                                                                this.pm$65(this.f18, this.f324, this.f325);
                                                            } else {
                                                                saved161 = this.f17;
                                                                if (saved161) {
                                                                    this.pm$72();
                                                                }
                                                                saved162 = this.f320;
                                                                if (saved162) {
                                                                    this.f320 = false;
                                                                    PacketBuffer.stopAndFlush();
                                                                }
                                                            }
                                                        }
                                                    }
                                                    saved163 = Events.packetSend;
                                                    if (!((event != saved163))) {
                                                        saved164 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                                        if (saved164) {
                                                            saved165 = this.f313;
                                                            if (saved165) {
                                                                event.setCancelled(true);
                                                            } else {
                                                                saved166 = this.f18;
                                                                if (!((saved166 == null))) {
                                                                    this.f313 = true;
                                                                }
                                                            }
                                                        } else {
                                                            saved167 = this.f18;
                                                            if (!((saved167 == null))) {
                                                                this.f313 = true;
                                                            }
                                                        }
                                                    }
                                                    return;
                                                }
                                            } else {
                                                saved168 = this.autoBlock.is(KillAura.TEXT_WATCHDOG);
                                                if (!(saved168)) {
                                                    saved169 = this.autoBlock.is(KillAura.TEXT_WATCHDOG2);
                                                    if (!(saved169)) {
                                                        saved170 = this.autoBlock.is(KillAura.TEXT_SWAP);
                                                        if (!(saved170)) {
                                                            saved171 = this.autoBlock.is(KillAura.TEXT_SWAP2);
                                                            if (!(saved171)) {
                                                                saved172 = this.autoBlock.is(KillAura.TEXT_CYCLE);
                                                                if (saved172) {
                                                                    if (!((integer5 != 0))) {
                                                                        saved173 = this.f17;
                                                                        if (!(saved173)) {
                                                                            this.f312 = 0;
                                                                            this.pm$70(this.f324, this.f325, false);
                                                                        }
                                                                    }
                                                                } else {
                                                                    this.f312 = 0;
                                                                    this.pm$70(this.f324, this.f325, false);
                                                                }
                                                            } else {
                                                                if (!((integer5 != 0))) {
                                                                    saved174 = this.f17;
                                                                    if (!(saved174)) {
                                                                        this.f312 = 0;
                                                                        this.pm$70(this.f324, this.f325, false);
                                                                    }
                                                                }
                                                            }
                                                        } else {
                                                            if (!((integer5 != 0))) {
                                                                saved175 = this.f17;
                                                                if (!(saved175)) {
                                                                    this.f312 = 0;
                                                                    this.pm$70(this.f324, this.f325, false);
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        if (!((integer5 != 0))) {
                                                            saved176 = this.f17;
                                                            if (!(saved176)) {
                                                                this.f312 = 0;
                                                                this.pm$70(this.f324, this.f325, false);
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if (!((integer5 != 0))) {
                                                        saved177 = this.f17;
                                                        if (!(saved177)) {
                                                            this.f312 = 0;
                                                            this.pm$70(this.f324, this.f325, false);
                                                        }
                                                    }
                                                }
                                                saved178 = this.f314;
                                                this.f314 = ((!(saved178) ? 1 : 0) != 0);
                                                saved179 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                                if (!(saved179)) {
                                                    saved180 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                                    if (saved180) {
                                                        if (!((integer5 == 0))) {
                                                            KillAura.mc.options.keyUse.setDown(false);
                                                            this.pm$65(this.f18, this.f324, this.f325);
                                                        } else {
                                                            saved181 = this.f17;
                                                            if (saved181) {
                                                                this.pm$72();
                                                            }
                                                            saved182 = this.f320;
                                                            if (saved182) {
                                                                this.f320 = false;
                                                                PacketBuffer.stopAndFlush();
                                                            }
                                                        }
                                                    }
                                                }
                                                saved183 = Events.packetSend;
                                                if (!((event != saved183))) {
                                                    saved184 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                                    if (saved184) {
                                                        saved185 = this.f313;
                                                        if (saved185) {
                                                            event.setCancelled(true);
                                                        } else {
                                                            saved186 = this.f18;
                                                            if (!((saved186 == null))) {
                                                                this.f313 = true;
                                                            }
                                                        }
                                                    } else {
                                                        saved187 = this.f18;
                                                        if (!((saved187 == null))) {
                                                            this.f313 = true;
                                                        }
                                                    }
                                                }
                                                return;
                                            }
                                        } else {
                                            saved188 = this.autoBlock.is(KillAura.TEXT_WATCHDOG);
                                            if (!(saved188)) {
                                                saved189 = this.autoBlock.is(KillAura.TEXT_WATCHDOG2);
                                                if (!(saved189)) {
                                                    saved190 = this.autoBlock.is(KillAura.TEXT_SWAP);
                                                    if (!(saved190)) {
                                                        saved191 = this.autoBlock.is(KillAura.TEXT_SWAP2);
                                                        if (!(saved191)) {
                                                            saved192 = this.autoBlock.is(KillAura.TEXT_CYCLE);
                                                            if (saved192) {
                                                                if (!((integer5 != 0))) {
                                                                    saved193 = this.f17;
                                                                    if (!(saved193)) {
                                                                        this.f312 = 0;
                                                                        this.pm$70(this.f324, this.f325, false);
                                                                    }
                                                                }
                                                            } else {
                                                                this.f312 = 0;
                                                                this.pm$70(this.f324, this.f325, false);
                                                            }
                                                        } else {
                                                            if (!((integer5 != 0))) {
                                                                saved194 = this.f17;
                                                                if (!(saved194)) {
                                                                    this.f312 = 0;
                                                                    this.pm$70(this.f324, this.f325, false);
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        if (!((integer5 != 0))) {
                                                            saved195 = this.f17;
                                                            if (!(saved195)) {
                                                                this.f312 = 0;
                                                                this.pm$70(this.f324, this.f325, false);
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if (!((integer5 != 0))) {
                                                        saved196 = this.f17;
                                                        if (!(saved196)) {
                                                            this.f312 = 0;
                                                            this.pm$70(this.f324, this.f325, false);
                                                        }
                                                    }
                                                }
                                            } else {
                                                if (!((integer5 != 0))) {
                                                    saved197 = this.f17;
                                                    if (!(saved197)) {
                                                        this.f312 = 0;
                                                        this.pm$70(this.f324, this.f325, false);
                                                    }
                                                }
                                            }
                                            saved198 = this.f314;
                                            this.f314 = ((!(saved198) ? 1 : 0) != 0);
                                            saved199 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                            if (!(saved199)) {
                                                saved200 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                                if (saved200) {
                                                    if (!((integer5 == 0))) {
                                                        KillAura.mc.options.keyUse.setDown(false);
                                                        this.pm$65(this.f18, this.f324, this.f325);
                                                    } else {
                                                        saved201 = this.f17;
                                                        if (saved201) {
                                                            this.pm$72();
                                                        }
                                                        saved202 = this.f320;
                                                        if (saved202) {
                                                            this.f320 = false;
                                                            PacketBuffer.stopAndFlush();
                                                        }
                                                    }
                                                }
                                            }
                                            saved203 = Events.packetSend;
                                            if (!((event != saved203))) {
                                                saved204 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                                if (saved204) {
                                                    saved205 = this.f313;
                                                    if (saved205) {
                                                        event.setCancelled(true);
                                                    } else {
                                                        saved206 = this.f18;
                                                        if (!((saved206 == null))) {
                                                            this.f313 = true;
                                                        }
                                                    }
                                                } else {
                                                    saved207 = this.f18;
                                                    if (!((saved207 == null))) {
                                                        this.f313 = true;
                                                    }
                                                }
                                            }
                                            return;
                                        }
                                    } else {
                                        saved208 = this.autoBlock.is(KillAura.TEXT_WATCHDOG);
                                        if (!(saved208)) {
                                            saved209 = this.autoBlock.is(KillAura.TEXT_WATCHDOG2);
                                            if (!(saved209)) {
                                                saved210 = this.autoBlock.is(KillAura.TEXT_SWAP);
                                                if (!(saved210)) {
                                                    saved211 = this.autoBlock.is(KillAura.TEXT_SWAP2);
                                                    if (!(saved211)) {
                                                        saved212 = this.autoBlock.is(KillAura.TEXT_CYCLE);
                                                        if (saved212) {
                                                            if (!((integer5 != 0))) {
                                                                saved213 = this.f17;
                                                                if (!(saved213)) {
                                                                    this.f312 = 0;
                                                                    this.pm$70(this.f324, this.f325, false);
                                                                }
                                                            }
                                                        } else {
                                                            this.f312 = 0;
                                                            this.pm$70(this.f324, this.f325, false);
                                                        }
                                                    } else {
                                                        if (!((integer5 != 0))) {
                                                            saved214 = this.f17;
                                                            if (!(saved214)) {
                                                                this.f312 = 0;
                                                                this.pm$70(this.f324, this.f325, false);
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if (!((integer5 != 0))) {
                                                        saved215 = this.f17;
                                                        if (!(saved215)) {
                                                            this.f312 = 0;
                                                            this.pm$70(this.f324, this.f325, false);
                                                        }
                                                    }
                                                }
                                            } else {
                                                if (!((integer5 != 0))) {
                                                    saved216 = this.f17;
                                                    if (!(saved216)) {
                                                        this.f312 = 0;
                                                        this.pm$70(this.f324, this.f325, false);
                                                    }
                                                }
                                            }
                                        } else {
                                            if (!((integer5 != 0))) {
                                                saved217 = this.f17;
                                                if (!(saved217)) {
                                                    this.f312 = 0;
                                                    this.pm$70(this.f324, this.f325, false);
                                                }
                                            }
                                        }
                                        saved218 = this.f314;
                                        this.f314 = ((!(saved218) ? 1 : 0) != 0);
                                        saved219 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                        if (!(saved219)) {
                                            saved220 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                            if (saved220) {
                                                if (!((integer5 == 0))) {
                                                    KillAura.mc.options.keyUse.setDown(false);
                                                    this.pm$65(this.f18, this.f324, this.f325);
                                                } else {
                                                    saved221 = this.f17;
                                                    if (saved221) {
                                                        this.pm$72();
                                                    }
                                                    saved222 = this.f320;
                                                    if (saved222) {
                                                        this.f320 = false;
                                                        PacketBuffer.stopAndFlush();
                                                    }
                                                }
                                            }
                                        }
                                        saved223 = Events.packetSend;
                                        if (!((event != saved223))) {
                                            saved224 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                            if (saved224) {
                                                saved225 = this.f313;
                                                if (saved225) {
                                                    event.setCancelled(true);
                                                } else {
                                                    saved226 = this.f18;
                                                    if (!((saved226 == null))) {
                                                        this.f313 = true;
                                                    }
                                                }
                                            } else {
                                                saved227 = this.f18;
                                                if (!((saved227 == null))) {
                                                    this.f313 = true;
                                                }
                                            }
                                        }
                                        return;
                                    }
                                } else {
                                    saved228 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                    if (!(saved228)) {
                                        saved229 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                        if (saved229) {
                                            if (!((integer5 == 0))) {
                                                KillAura.mc.options.keyUse.setDown(false);
                                                this.pm$65(this.f18, this.f324, this.f325);
                                            } else {
                                                saved230 = this.f17;
                                                if (saved230) {
                                                    this.pm$72();
                                                }
                                                saved231 = this.f320;
                                                if (saved231) {
                                                    this.f320 = false;
                                                    PacketBuffer.stopAndFlush();
                                                }
                                            }
                                        }
                                    }
                                    saved232 = Events.packetSend;
                                    if (!((event != saved232))) {
                                        saved233 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                        if (saved233) {
                                            saved234 = this.f313;
                                            if (saved234) {
                                                event.setCancelled(true);
                                            } else {
                                                saved235 = this.f18;
                                                if (!((saved235 == null))) {
                                                    this.f313 = true;
                                                }
                                            }
                                        } else {
                                            saved236 = this.f18;
                                            if (!((saved236 == null))) {
                                                this.f313 = true;
                                            }
                                        }
                                    }
                                    return;
                                }
                            } else {
                                saved237 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                                if (!(saved237)) {
                                    saved238 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                    if (saved238) {
                                        if (!((integer5 == 0))) {
                                            KillAura.mc.options.keyUse.setDown(false);
                                            this.pm$65(this.f18, this.f324, this.f325);
                                        } else {
                                            saved239 = this.f17;
                                            if (saved239) {
                                                this.pm$72();
                                            }
                                            saved240 = this.f320;
                                            if (saved240) {
                                                this.f320 = false;
                                                PacketBuffer.stopAndFlush();
                                            }
                                        }
                                    }
                                }
                                saved241 = Events.packetSend;
                                if (!((event != saved241))) {
                                    saved242 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                    if (saved242) {
                                        saved243 = this.f313;
                                        if (saved243) {
                                            event.setCancelled(true);
                                        } else {
                                            saved244 = this.f18;
                                            if (!((saved244 == null))) {
                                                this.f313 = true;
                                            }
                                        }
                                    } else {
                                        saved245 = this.f18;
                                        if (!((saved245 == null))) {
                                            this.f313 = true;
                                        }
                                    }
                                }
                                return;
                            }
                        } else {
                            saved246 = this.autoBlock.is(KillAura.TEXT_DISABLED);
                            if (!(saved246)) {
                                saved247 = KillAura.mc.player.getMainHandItem().is(ItemTags.SWORDS);
                                if (saved247) {
                                    if (!((integer5 == 0))) {
                                        KillAura.mc.options.keyUse.setDown(false);
                                        this.pm$65(this.f18, this.f324, this.f325);
                                    } else {
                                        saved248 = this.f17;
                                        if (saved248) {
                                            this.pm$72();
                                        }
                                        saved249 = this.f320;
                                        if (saved249) {
                                            this.f320 = false;
                                            PacketBuffer.stopAndFlush();
                                        }
                                    }
                                }
                            }
                            saved250 = Events.packetSend;
                            if (!((event != saved250))) {
                                saved251 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                                if (saved251) {
                                    saved252 = this.f313;
                                    if (saved252) {
                                        event.setCancelled(true);
                                    } else {
                                        saved253 = this.f18;
                                        if (!((saved253 == null))) {
                                            this.f313 = true;
                                        }
                                    }
                                } else {
                                    saved254 = this.f18;
                                    if (!((saved254 == null))) {
                                        this.f313 = true;
                                    }
                                }
                            }
                            return;
                        }
                    } else {
                        this.pm$79();
                        saved255 = Events.packetSend;
                        if (!((event != saved255))) {
                            saved256 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                            if (saved256) {
                                saved257 = this.f313;
                                if (saved257) {
                                    event.setCancelled(true);
                                } else {
                                    saved258 = this.f18;
                                    if (!((saved258 == null))) {
                                        this.f313 = true;
                                    }
                                }
                            } else {
                                saved259 = this.f18;
                                if (!((saved259 == null))) {
                                    this.f313 = true;
                                }
                            }
                        }
                        return;
                    }
                }
            }
        } else {
            saved260 = Events.packetSend;
            if (!((event != saved260))) {
                saved261 = (Events.packetSend.getPacket() instanceof ServerboundPlayerActionPacket);
                if (saved261) {
                    saved262 = this.f313;
                    if (saved262) {
                        event.setCancelled(true);
                    } else {
                        saved263 = this.f18;
                        if (!((saved263 == null))) {
                            this.f313 = true;
                        }
                    }
                } else {
                    saved264 = this.f18;
                    if (!((saved264 == null))) {
                        this.f313 = true;
                    }
                }
            }
            return;
        }
    }

    private float getMouseSensitivityStep() {
        float floating1 = 0.0f;
        int saved1 = 0;
        float floating2 = 0.0f;
        float floating0 = 0.0f;
        floating1 = ((Double) KillAura.mc.options.sensitivity().get()).floatValue();
        saved1 = JvmSupport.fcmpl(floating1, this.f327);
        if (!((saved1 == 0))) {
            floating2 = ((floating1 * 0.6f) + 0.2f);
            this.f327 = floating1;
            this.f326 = ((((floating2 * floating2) * floating2) * 8.0f) * 0.15f);
        }
        floating0 = this.f326;
        return floating0;
    }

    static {
        TEXT_KILLAURA = new String("KillAura");
        TEXT_ROTATIONS = new String("Rotations");
        TEXT_HEAD = new String("Head");
        TEXT_OPTIMAL = new String("Optimal");
        TEXT_AUTOBLOCK = new String("AutoBlock");
        TEXT_DISABLED = new String("Disabled");
        TEXT_FAKE = new String("Fake");
        TEXT_VANILLA = new String("Vanilla");
        TEXT_WATCHDOG = new String("Watchdog");
        TEXT_WATCHDOG2 = new String("Watchdog2");
        TEXT_SWAP = new String("Swap");
        TEXT_SWAP2 = new String("Swap2");
        TEXT_CYCLE = new String("Cycle");
        TEXT_ATTACK_DELAY = new String("Attack Delay");
        TEXT_ATTACK_DELAY2 = new String("Attack Delay2");
        TEXT_ROTATION_RANGE = new String("Rotation Range");
        TEXT_ATTACK_CRITS = new String("Attack Crits");
        TEXT_ATTACK_COOLDOWN = new String("Attack Cooldown");
        TEXT_IGNORE_SHIELD = new String("Ignore Shield");
        TEXT_REQUIRE_SWORD = new String("Require Sword");
        TEXT_AUTOBLOCK_RMB = new String("AutoBlock RMB");
        TEXT_ATTACK_TEAMMATES = new String("Attack Teammates");
        TEXT_ATTACK_FIREBALLS = new String("Attack Fireballs");
        TEXT_SHIELD = new String("shield");
    }

    private void pm$70(float arg0, float arg1, boolean arg2) {
        boolean saved1 = false;
        boolean saved2 = false;
        int saved3 = 0;
        double number4 = 0.0;
        int saved4 = 0;
        int saved5 = 0;
        Vec3 reference6 = null;
        float floating7 = 0.0f;
        float floating8 = 0.0f;
        double number9 = 0.0;
        double number11 = 0.0;
        double number13 = 0.0;
        Vec3 reference15 = null;
        Vec3 reference16 = null;
        EntityHitResult reference17 = null;
        Vec3 reference18 = null;
        int saved6 = 0;
        int saved7 = 0;
        saved1 = ModuleManager.bedAura.f25;
        if (saved1) {
            return;
        } else {
            saved2 = this.attackCrits.getValue();
            if (saved2) {
                saved3 = JvmSupport.dcmpl(KillAura.mc.player.getDeltaMovement().y, 0.0);
                if (!((saved3 <= 0))) {
                    return;
                } else {
                    number4 = this.rayIntersectionDistance(this.f18, arg0, arg1, 10.0);
                    saved4 = JvmSupport.dcmpg(number4, 3.0);
                    if (!((saved4 > 0))) {
                        saved5 = JvmSupport.dcmpl(number4, 0.0);
                        if (!((saved5 < 0))) {
                            KillAura.mc.gameMode.attack(KillAura.mc.player, this.f18);
                            KillAura.mc.player.swing(InteractionHand.MAIN_HAND);
                            if (arg2) {
                                reference6 = KillAura.mc.player.getEyePosition();
                                floating7 = (arg0 * 0.017453292f);
                                floating8 = (arg1 * 0.017453292f);
                                number9 = ((-Math.sin(((double) floating7))) * Math.cos(((double) floating8)));
                                number11 = (-Math.sin(((double) floating8)));
                                number13 = (Math.cos(((double) floating7)) * Math.cos(((double) floating8)));
                                reference15 = new Vec3(number9, number11, number13);
                                reference16 = reference6.add(reference15.scale(number4));
                                reference17 = new EntityHitResult(this.f18, reference16);
                                reference18 = reference17.getLocation().subtract(this.f18.getX(), this.f18.getY(), this.f18.getZ());
                                KillAura.mc.getConnection().send(((Packet) (Object) new ServerboundInteractPacket(this.f18.getId(), InteractionHand.MAIN_HAND, reference18, KillAura.mc.player.isShiftKeyDown())));
                            }
                        }
                    }
                    return;
                }
            } else {
                number4 = this.rayIntersectionDistance(this.f18, arg0, arg1, 10.0);
                saved6 = JvmSupport.dcmpg(number4, 3.0);
                if (!((saved6 > 0))) {
                    saved7 = JvmSupport.dcmpl(number4, 0.0);
                    if (!((saved7 < 0))) {
                        KillAura.mc.gameMode.attack(KillAura.mc.player, this.f18);
                        KillAura.mc.player.swing(InteractionHand.MAIN_HAND);
                        if (arg2) {
                            reference6 = KillAura.mc.player.getEyePosition();
                            floating7 = (arg0 * 0.017453292f);
                            floating8 = (arg1 * 0.017453292f);
                            number9 = ((-Math.sin(((double) floating7))) * Math.cos(((double) floating8)));
                            number11 = (-Math.sin(((double) floating8)));
                            number13 = (Math.cos(((double) floating7)) * Math.cos(((double) floating8)));
                            reference15 = new Vec3(number9, number11, number13);
                            reference16 = reference6.add(reference15.scale(number4));
                            reference17 = new EntityHitResult(this.f18, reference16);
                            reference18 = reference17.getLocation().subtract(this.f18.getX(), this.f18.getY(), this.f18.getZ());
                            KillAura.mc.getConnection().send(((Packet) (Object) new ServerboundInteractPacket(this.f18.getId(), InteractionHand.MAIN_HAND, reference18, KillAura.mc.player.isShiftKeyDown())));
                        }
                    }
                }
                return;
            }
        }
    }

    private void pm$67() {
        int integer1 = 0;
        boolean saved1 = false;
        int saved2 = 0;
        this.f321 = -1;
        this.f322 = -1;
        integer1 = 0;
        loop8: while (true) {
            if ((integer1 >= 9)) {
                break loop8;
            }
            saved1 = KillAura.mc.player.getInventory().getItem(integer1).is(ItemTags.SWORDS);
            if (saved1) {
                saved2 = this.f321;
                if (!((saved2 != -1))) {
                    this.f321 = integer1;
                    integer1++;
                    continue loop8;
                } else {
                    this.f322 = integer1;
                    break loop8;
                }
            } else {
                integer1++;
                continue loop8;
            }
        }
    }

    private void pm$72() {
        this.f313 = false;
        KillAura.mc.getConnection().send(((Packet) (Object) new ServerboundPlayerActionPacket(ServerboundPlayerActionPacket.Action.RELEASE_USE_ITEM, BlockPos.ZERO, Direction.DOWN)));
        this.f17 = false;
    }

    private void pm$68(int arg0) {
        int saved1 = 0;
        KillAura.mc.getConnection().send(((Packet) (Object) new ServerboundSetCarriedItemPacket(arg0)));
        this.f315 = true;
        saved1 = KillAura.mc.player.getInventory().getSelectedSlot();
        if (!((arg0 != saved1))) {
            this.f315 = false;
        }
    }

    private double rayIntersectionDistance(Entity arg0, float arg1, float arg2, double arg3) {
        Vec3 reference6 = null;
        AABB reference7 = null;
        boolean saved1 = false;
        double number0 = 0.0;
        Vec3 reference8 = null;
        Vec3 reference9 = null;
        Optional reference10 = null;
        boolean saved2 = false;
        reference6 = KillAura.mc.player.getEyePosition(1.0f);
        reference7 = arg0.getBoundingBox();
        saved1 = reference7.contains(reference6);
        if (saved1) {
            number0 = 0.0;
            return number0;
        } else {
            reference8 = this.getLookVector(arg2, arg1);
            reference9 = new Vec3((reference6.x + (reference8.x * arg3)), (reference6.y + (reference8.y * arg3)), (reference6.z + (reference8.z * arg3)));
            reference10 = reference7.clip(reference6, reference9);
            saved2 = reference10.isPresent();
            number0 = (saved2 ? reference6.distanceTo(((Vec3) reference10.get())) : -0.1);
            return number0;
        }
    }

    private boolean pm$66(Entity arg0, double arg1) {
        Vec3 reference4 = null;
        Vec3 reference5 = null;
        Vec3 reference6 = null;
        double number7 = 0.0;
        int saved1 = 0;
        int integer0 = 0;
        reference4 = arg0.getEyePosition(1.0f);
        reference5 = arg0.getViewVector(1.0f).normalize();
        reference6 = KillAura.mc.player.getEyePosition(1.0f).subtract(reference4).normalize();
        number7 = reference5.dot(reference6);
        saved1 = JvmSupport.dcmpl(number7, Math.cos(Math.toRadians(arg1)));
        integer0 = (!((saved1 < 0)) ? 1 : 0);
        return (integer0 != 0);
    }

    private Vec3 getLookVector(float arg0, float arg1) {
        float floating3 = 0.0f;
        float floating4 = 0.0f;
        float floating5 = 0.0f;
        float floating6 = 0.0f;
        Vec3 reference0 = null;
        floating3 = Mth.cos(((double) (((-arg1) * 0.017453292f) - 3.1415927f)));
        floating4 = Mth.sin(((double) (((-arg1) * 0.017453292f) - 3.1415927f)));
        floating5 = (-Mth.cos(((double) ((-arg0) * 0.017453292f))));
        floating6 = Mth.sin(((double) ((-arg0) * 0.017453292f)));
        reference0 = new Vec3(((double) (floating4 * floating5)), ((double) floating6), ((double) (floating3 * floating5)));
        return reference0;
    }

    private Entity findFireballTarget(double arg0) {
        AABB reference3 = null;
        Entity reference4 = null;
        double number5 = 0.0;
        Iterator reference7 = null;
        boolean saved1 = false;
        Entity reference8 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        boolean saved4 = false;
        Entity saved5 = null;
        LocalPlayer saved6 = null;
        Object reference0 = this;
        double number9 = 0.0;
        int saved7 = 0;
        int saved8 = 0;
        reference3 = KillAura.mc.player.getBoundingBox().inflate(arg0);
        reference4 = null;
        number5 = 1.7976931348623157e+308;
        reference7 = KillAura.mc.level.getEntities(KillAura.mc.player, reference3).iterator();
        loop18: while (true) {
            saved1 = reference7.hasNext();
            if (!(saved1)) {
                break loop18;
            }
            reference8 = ((Entity) reference7.next());
            saved2 = (reference8 instanceof Fireball);
            if (!(saved2)) {
                saved3 = (reference8 instanceof SmallFireball);
                if (!(saved3)) {
                    saved4 = (reference8 instanceof LargeFireball);
                    if (!(saved4)) {
                        continue loop18;
                    }
                }
            }
            saved5 = ((Fireball) (Object) reference8).getOwner();
            saved6 = KillAura.mc.player;
            if (!((saved5 != saved6))) {
                continue loop18;
            }
            number9 = ((KillAura) reference0).rayIntersectionDistance(reference8, ((KillAura) reference0).f324, ((KillAura) reference0).f325, 10.0);
            saved7 = JvmSupport.dcmpg(number9, arg0);
            if (!((saved7 > 0))) {
                saved8 = JvmSupport.dcmpg(number9, number5);
                if (!((saved8 >= 0))) {
                    reference4 = reference8;
                    number5 = number9;
                }
            }
            continue loop18;
        }
        reference0 = reference4;
        return ((Entity) reference0);
    }

    public KillAura() {
        super(KillAura.TEXT_KILLAURA, Category.COMBAT);
        this.rotations = new ModeSetting(KillAura.TEXT_ROTATIONS, this, KillAura.TEXT_HEAD, new String[] {KillAura.TEXT_HEAD, KillAura.TEXT_OPTIMAL});
        this.autoBlock = new ModeSetting(KillAura.TEXT_AUTOBLOCK, this, KillAura.TEXT_DISABLED, new String[] {KillAura.TEXT_DISABLED, KillAura.TEXT_FAKE, KillAura.TEXT_VANILLA, KillAura.TEXT_WATCHDOG, KillAura.TEXT_WATCHDOG2, KillAura.TEXT_SWAP, KillAura.TEXT_SWAP2, KillAura.TEXT_CYCLE});
        this.attackDelay = new NumberSetting(KillAura.TEXT_ATTACK_DELAY, this, 3.0, 0.0, 10.0, 1.0);
        this.attackDelay2 = new NumberSetting(KillAura.TEXT_ATTACK_DELAY2, this, 3.0, 0.0, 10.0, 1.0);
        this.rotationRange = new NumberSetting(KillAura.TEXT_ROTATION_RANGE, this, 5.0, 3.0, 10.0, 0.5);
        this.attackCrits = new BooleanSetting(KillAura.TEXT_ATTACK_CRITS, this, true);
        this.attackCooldown = new BooleanSetting(KillAura.TEXT_ATTACK_COOLDOWN, this, true);
        this.ignoreShield = new BooleanSetting(KillAura.TEXT_IGNORE_SHIELD, this, false);
        this.requireSword = new BooleanSetting(KillAura.TEXT_REQUIRE_SWORD, this, false);
        this.autoBlockRMB = new BooleanSetting(KillAura.TEXT_AUTOBLOCK_RMB, this, false);
        this.attackTeammates = new BooleanSetting(KillAura.TEXT_ATTACK_TEAMMATES, this, true);
        this.attackFireballs = new BooleanSetting(KillAura.TEXT_ATTACK_FIREBALLS, this, false);
        this.f321 = -1;
        this.f322 = -1;
    }

    private void pm$69() {
        boolean saved1 = false;
        saved1 = this.f315;
        if (saved1) {
            KillAura.mc.getConnection().send(((Packet) (Object) new ServerboundSetCarriedItemPacket(KillAura.mc.player.getInventory().getSelectedSlot())));
            this.f315 = false;
        }
    }

    private void pm$76(Entity arg0) {
        boolean saved1 = false;
        AABB reference8 = null;
        double number2 = 0.0;
        double number4 = 0.0;
        double number6 = 0.0;
        double number8 = 0.0;
        double number10 = 0.0;
        double number12 = 0.0;
        double number14 = 0.0;
        float floating16 = 0.0f;
        float floating17 = 0.0f;
        float floating18 = 0.0f;
        saved1 = this.rotations.is(KillAura.TEXT_OPTIMAL);
        if (saved1) {
            reference8 = arg0.getBoundingBox();
            number2 = Mth.clamp(KillAura.mc.player.getX(), reference8.minX, reference8.maxX);
            number4 = Mth.clamp(KillAura.mc.player.getEyeY(), reference8.minY, reference8.maxY);
            number6 = Mth.clamp(KillAura.mc.player.getZ(), reference8.minZ, reference8.maxZ);
        } else {
            number2 = arg0.getX();
            number4 = arg0.getEyeY();
            number6 = arg0.getZ();
        }
        number8 = (number2 - KillAura.mc.player.getX());
        number10 = (number4 - KillAura.mc.player.getEyeY());
        number12 = (number6 - KillAura.mc.player.getZ());
        number14 = Math.sqrt(((number8 * number8) + (number12 * number12)));
        floating16 = (((float) Math.toDegrees(Math.atan2(number12, number8))) - 90.0f);
        floating17 = ((float) (-Math.toDegrees(Math.atan2(number10, number14))));
        floating16 = (KillAura.mc.player.getYRot() + Mth.wrapDegrees((floating16 - KillAura.mc.player.getYRot())));
        floating18 = this.getMouseSensitivityStep();
        this.f324 = this.pm$78(floating16, KillAura.mc.player.getYRot(), floating18);
        this.f325 = this.pm$78(floating17, KillAura.mc.player.getXRot(), floating18);
    }

    public int getEventPriority(Event arg0) {
        RotationEvent saved1 = null;
        int integer0 = 0;
        saved1 = Events.rotation;
        if (!((arg0 != saved1))) {
            integer0 = -2;
            return integer0;
        } else {
            integer0 = 0;
            return integer0;
        }
    }

    private void pm$71() {
        KillAura.mc.getConnection().send(((Packet) (Object) new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, 0, Events.rotation.getYaw(), Events.rotation.getPitch())));
        this.f17 = true;
    }

    private void pm$79() {
        boolean saved1 = false;
        boolean saved2 = false;
        boolean saved3 = false;
        this.f16 = false;
        this.f313 = false;
        this.f18 = null;
        saved1 = this.f315;
        if (saved1) {
            this.pm$69();
        }
        saved2 = this.f17;
        if (saved2) {
            this.pm$72();
        }
        saved3 = this.f320;
        if (saved3) {
            PacketBuffer.stopAndFlush();
            this.f320 = false;
        }
        this.f318 = 0;
        this.f319 = 0;
    }

    private void pm$65(Entity arg0, float arg1, float arg2) {
        String reference4 = null;
        int integer5 = 0;
        String reference7 = null;
        int saved1 = 0;
        boolean saved2 = false;
        boolean saved3 = false;
        boolean saved4 = false;
        boolean saved5 = false;
        boolean saved6 = false;
        boolean saved7 = false;
        boolean saved8 = false;
        int saved9 = 0;
        boolean saved10 = false;
        int saved11 = 0;
        boolean saved12 = false;
        int saved13 = 0;
        boolean saved14 = false;
        boolean saved15 = false;
        boolean saved16 = false;
        int saved17 = 0;
        int saved18 = 0;
        boolean saved19 = false;
        int saved20 = 0;
        int saved21 = 0;
        int saved22 = 0;
        boolean saved23 = false;
        int saved24 = 0;
        int saved25 = 0;
        boolean saved26 = false;
        boolean saved27 = false;
        int integer6 = 0;
        boolean saved28 = false;
        boolean saved29 = false;
        boolean saved30 = false;
        boolean saved31 = false;
        boolean saved32 = false;
        boolean saved33 = false;
        int saved34 = 0;
        boolean saved35 = false;
        int saved36 = 0;
        boolean saved37 = false;
        boolean saved38 = false;
        boolean saved39 = false;
        int saved40 = 0;
        boolean saved41 = false;
        int saved42 = 0;
        boolean saved43 = false;
        boolean saved44 = false;
        boolean saved45 = false;
        this.f313 = false;
        this.f16 = true;
        reference4 = this.autoBlock.getValue();
        integer5 = -1;
        reference7 = reference4;
        saved1 = reference4.hashCode();
        if (!((saved1 != 2182005))) {
            saved2 = reference4.equals(KillAura.TEXT_FAKE);
            if (saved2) {
                integer5 = 1;
            }
        } else {
            if (!((saved1 != 2590131))) {
                saved3 = reference4.equals(KillAura.TEXT_SWAP);
                if (saved3) {
                    integer5 = 5;
                }
            } else {
                if (!((saved1 != 65579206))) {
                    saved4 = reference4.equals(KillAura.TEXT_CYCLE);
                    if (saved4) {
                        integer5 = 2;
                    }
                } else {
                    if (!((saved1 != 80294111))) {
                        saved5 = reference4.equals(KillAura.TEXT_SWAP2);
                        if (saved5) {
                            integer5 = 6;
                        }
                    } else {
                        if (!((saved1 != 609795629))) {
                            saved6 = reference4.equals(KillAura.TEXT_WATCHDOG);
                            if (saved6) {
                                integer5 = 3;
                            }
                        } else {
                            if (!((saved1 != 1723795365))) {
                                saved7 = reference4.equals(KillAura.TEXT_WATCHDOG2);
                                if (saved7) {
                                    integer5 = 4;
                                }
                            } else {
                                if (!((saved1 != 1897755483))) {
                                    saved8 = reference4.equals(KillAura.TEXT_VANILLA);
                                    if (saved8) {
                                        integer5 = 0;
                                    }
                                } else {
                                }
                            }
                        }
                    }
                }
            }
        }
        switch (integer5) {
            case 0:
            {
                KillAura.mc.getConnection().send(((Packet) (Object) new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, 0, KillAura.mc.player.getYRot(), KillAura.mc.player.getXRot())));
                return;
            }
            case 1:
            {
                return;
            }
            case 2:
            {
                this.f313 = true;
                this.f318 = (this.f318 + 1);
                saved9 = this.f318;
                if (!((saved9 >= 3))) {
                    saved10 = this.f17;
                    if (saved10) {
                        this.f320 = true;
                        PacketBuffer.startBuffering();
                        this.pm$72();
                    }
                    return;
                } else {
                    this.pm$70(this.f324, this.f325, true);
                    this.pm$71();
                    KillAura.mc.player.startUsingItem(InteractionHand.MAIN_HAND);
                    this.f313 = false;
                    PacketBuffer.stopAndFlush();
                    this.f318 = 0;
                    return;
                }
            }
            case 3:
            {
                this.f313 = true;
                this.f318 = (this.f318 + 1);
                saved11 = this.f318;
                if (!((saved11 >= 3))) {
                    saved12 = this.f17;
                    if (saved12) {
                        saved13 = this.f318;
                        if (!((saved13 <= 1))) {
                            this.pm$72();
                            return;
                        } else {
                            saved14 = this.f17;
                            if (saved14) {
                                KillAura.mc.player.startUsingItem(InteractionHand.MAIN_HAND);
                            }
                            return;
                        }
                    } else {
                        saved15 = this.f17;
                        if (saved15) {
                            KillAura.mc.player.startUsingItem(InteractionHand.MAIN_HAND);
                        }
                        return;
                    }
                } else {
                    saved16 = this.f17;
                    if (saved16) {
                        this.pm$72();
                        return;
                    } else {
                        saved17 = JvmSupport.dcmpg(((double) KillAura.mc.player.distanceTo(arg0)), 3.0);
                        if (!((saved17 >= 0))) {
                            saved18 = KillAura.mc.player.hurtTime;
                            if (!((saved18 >= 3))) {
                                saved19 = this.pm$66(arg0, 30.0);
                                if (saved19) {
                                    this.pm$70(this.f324, this.f325, true);
                                    this.pm$71();
                                    KillAura.mc.player.startUsingItem(InteractionHand.MAIN_HAND);
                                } else {
                                    this.pm$70(this.f324, this.f325, false);
                                }
                            } else {
                                this.pm$70(this.f324, this.f325, false);
                            }
                        } else {
                            this.pm$70(this.f324, this.f325, false);
                        }
                        this.f318 = 0;
                        return;
                    }
                }
            }
            case 4:
            {
                this.f313 = true;
                this.f318 = (this.f318 + 1);
                saved20 = this.f318;
                if (!((saved20 >= 3))) {
                    return;
                } else {
                    this.pm$70(this.f324, this.f325, true);
                    this.pm$71();
                    this.f313 = false;
                    PacketBuffer.stopAndFlush();
                    PacketBuffer.startBuffering();
                    this.pm$72();
                    this.f320 = true;
                    this.f318 = 0;
                    return;
                }
            }
            case 5:
            {
                this.f313 = true;
                this.f318 = (this.f318 + 1);
                saved21 = this.f318;
                if (!((saved21 >= 3))) {
                    saved22 = this.f318;
                    if (!((saved22 == 2))) {
                        saved23 = this.f17;
                        if (saved23) {
                            KillAura.mc.player.startUsingItem(InteractionHand.MAIN_HAND);
                        }
                    }
                    return;
                } else {
                    this.pm$67();
                    saved24 = this.f321;
                    if (!((saved24 == -1))) {
                        saved25 = this.f322;
                        if (!((saved25 != -1))) {
                            saved26 = KillAura.mc.player.getInventory().getItem(KillAura.mc.player.getInventory().getSelectedSlot()).is(ItemTags.SWORDS);
                            if (saved26) {
                                this.pm$70(this.f324, this.f325, false);
                            }
                        } else {
                            saved27 = this.f323;
                            integer6 = (saved27 ? this.f322 : this.f321);
                            saved28 = this.f323;
                            this.f323 = ((!(saved28) ? 1 : 0) != 0);
                            this.pm$68(integer6);
                            saved29 = KillAura.mc.player.getInventory().getItem(integer6).is(ItemTags.SWORDS);
                            if (saved29) {
                                this.pm$70(this.f324, this.f325, true);
                                this.pm$71();
                                KillAura.mc.player.startUsingItem(InteractionHand.MAIN_HAND);
                            }
                            this.f318 = 0;
                        }
                    } else {
                        saved30 = KillAura.mc.player.getInventory().getItem(KillAura.mc.player.getInventory().getSelectedSlot()).is(ItemTags.SWORDS);
                        if (saved30) {
                            this.pm$70(this.f324, this.f325, false);
                        }
                    }
                    return;
                }
            }
            case 6:
            {
                this.f318 = (this.f318 + 1);
                this.f313 = true;
                saved31 = this.f17;
                if (saved31) {
                    this.pm$72();
                }
                saved32 = this.f315;
                if (!(saved32)) {
                    saved33 = this.f316;
                    if (saved33) {
                        this.pm$68(((KillAura.mc.player.getInventory().getSelectedSlot() % 8) + 1));
                        return;
                    } else {
                        saved34 = this.f318;
                        if (!((saved34 >= 3))) {
                            return;
                        } else {
                            saved35 = this.f315;
                            if (saved35) {
                                this.pm$68(KillAura.mc.player.getInventory().getSelectedSlot());
                                this.pm$70(this.f324, this.f325, false);
                            }
                            this.f319 = (this.f319 + 1);
                            saved36 = this.f319;
                            if (!((saved36 >= 3))) {
                                this.f316 = true;
                                saved37 = this.f323;
                                this.f323 = ((!(saved37) ? 1 : 0) != 0);
                                this.pm$70(this.f324, this.f325, true);
                                this.pm$71();
                            } else {
                                this.f316 = false;
                                saved38 = this.f323;
                                this.f323 = ((!(saved38) ? 1 : 0) != 0);
                                saved39 = this.f323;
                                if (saved39) {
                                    this.pm$70(this.f324, this.f325, true);
                                    this.f317 = true;
                                } else {
                                    this.pm$70(this.f324, this.f325, false);
                                }
                                this.f319 = 0;
                            }
                            this.f318 = 0;
                            return;
                        }
                    }
                } else {
                    saved40 = this.f318;
                    if (!((saved40 >= 3))) {
                        return;
                    } else {
                        saved41 = this.f315;
                        if (saved41) {
                            this.pm$68(KillAura.mc.player.getInventory().getSelectedSlot());
                            this.pm$70(this.f324, this.f325, false);
                        }
                        this.f319 = (this.f319 + 1);
                        saved42 = this.f319;
                        if (!((saved42 >= 3))) {
                            this.f316 = true;
                            saved43 = this.f323;
                            this.f323 = ((!(saved43) ? 1 : 0) != 0);
                            this.pm$70(this.f324, this.f325, true);
                            this.pm$71();
                        } else {
                            this.f316 = false;
                            saved44 = this.f323;
                            this.f323 = ((!(saved44) ? 1 : 0) != 0);
                            saved45 = this.f323;
                            if (saved45) {
                                this.pm$70(this.f324, this.f325, true);
                                this.f317 = true;
                            } else {
                                this.pm$70(this.f324, this.f325, false);
                            }
                            this.f319 = 0;
                        }
                        this.f318 = 0;
                        return;
                    }
                }
            }
            default:
            {
                return;
            }
        }
    }

    private float pm$78(float arg0, float arg1, float arg2) {
        float floating4 = 0.0f;
        float floating0 = 0.0f;
        floating4 = (arg0 - arg1);
        floating4 = (floating4 - (floating4 % arg2));
        floating0 = (arg1 + floating4);
        return floating0;
    }

    private boolean pm$80() {
        long local1 = 0L;
        int saved1 = 0;
        int integer3 = 0;
        boolean saved2 = false;
        int integer0 = 0;
        local1 = KillAura.mc.getWindow().handle();
        saved1 = GLFW.glfwGetMouseButton(local1, 1);
        integer3 = (!((saved1 != 1)) ? 1 : 0);
        saved2 = this.autoBlockRMB.getValue();
        integer0 = (saved2 ? (!((integer3 == 0)) ? 1 : 0) : 1);
        return (integer0 != 0);
    }

    public void onDisable() {
        this.pm$79();
    }
}
