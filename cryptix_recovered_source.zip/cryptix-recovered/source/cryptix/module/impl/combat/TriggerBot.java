package cryptix.module.impl.combat;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.RotationEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;

/**
 * Reconstructed from a/wh.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class TriggerBot extends Module {
    private static final String TEXT_TRIGGERBOT;

    public TriggerBot() {
        super(TriggerBot.TEXT_TRIGGERBOT, Category.COMBAT);
    }

    public void onEvent(Event event) {
        RotationEvent saved1 = null;
        Entity reference3 = null;
        boolean saved2 = false;
        Entity reference2 = null;
        LocalPlayer saved3 = null;
        boolean saved4 = false;
        int saved5 = 0;
        saved1 = Events.rotation;
        if (!((event != saved1))) {
            reference3 = TriggerBot.mc.crosshairPickEntity;
            saved2 = (reference3 instanceof Entity);
            if (saved2) {
                reference2 = reference3;
                saved3 = TriggerBot.mc.player;
                if (!((saved3 == null))) {
                    saved4 = TriggerBot.mc.player.isAlive();
                    if (saved4) {
                        saved5 = JvmSupport.fcmpl(TriggerBot.mc.player.getAttackStrengthScale(0.0f), 1.0f);
                        if (!((saved5 < 0))) {
                            TriggerBot.mc.gameMode.attack(TriggerBot.mc.player, reference2);
                            TriggerBot.mc.player.swing(InteractionHand.MAIN_HAND);
                        }
                    }
                }
            }
        }
    }

    static {
        TEXT_TRIGGERBOT = new String("TriggerBot");
    }
}
