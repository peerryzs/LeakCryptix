package cryptix.module.impl.misc;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.PacketReceiveEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;

/**
 * Reconstructed from a/aw.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class AutoGG extends Module {
    private static final String TEXT_AUTOGG;
    private static final String TEXT_EMPTY;
    private static final String TEXT_EMPTY_2;
    private static final String TEXT_GAME_OVER;
    private static final String TEXT_VICTORY;
    private static final String TEXT_GG;
    private static final String TEXT_DEFEAT;
    private static final String TEXT_CRYPTIX_ON_TOP;

    public void onEvent(Event event) {
        PacketReceiveEvent saved1 = null;
        Packet reference2 = null;
        boolean saved2 = false;
        ClientboundSetTitleTextPacket reference3 = null;
        String reference4 = null;
        boolean saved3 = false;
        boolean saved4 = false;
        boolean saved5 = false;
        saved1 = Events.packetReceive;
        if (!((event != saved1))) {
            reference2 = Events.packetReceive.getPacket();
            saved2 = (reference2 instanceof ClientboundSetTitleTextPacket);
            if (saved2) {
                reference3 = ((ClientboundSetTitleTextPacket) (Object) reference2);
                reference4 = reference3.text().getString().replace(AutoGG.TEXT_EMPTY_2, AutoGG.TEXT_EMPTY).toLowerCase();
                saved3 = reference4.contains(AutoGG.TEXT_DEFEAT);
                if (!(saved3)) {
                    saved4 = reference4.contains(AutoGG.TEXT_GAME_OVER);
                    if (saved4) {
                        AutoGG.mc.getConnection().sendChat(AutoGG.TEXT_GG);
                    } else {
                        saved5 = reference4.contains(AutoGG.TEXT_VICTORY);
                        if (saved5) {
                            AutoGG.mc.getConnection().sendChat(AutoGG.TEXT_CRYPTIX_ON_TOP);
                        }
                    }
                } else {
                    AutoGG.mc.getConnection().sendChat(AutoGG.TEXT_GG);
                }
            }
        }
    }

    static {
        TEXT_AUTOGG = new String("AutoGG");
        TEXT_EMPTY_2 = new String("!");
        TEXT_EMPTY = new String("");
        TEXT_DEFEAT = new String("defeat");
        TEXT_GAME_OVER = new String("game over");
        TEXT_GG = new String("gg");
        TEXT_VICTORY = new String("victory");
        TEXT_CRYPTIX_ON_TOP = new String("cryptix on top");
    }

    public AutoGG() {
        super(AutoGG.TEXT_AUTOGG, Category.MISC);
    }
}
