package cryptix.module.impl.misc;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.PostInputEvent;
import cryptix.event.impl.RotationEvent;
import cryptix.mixin.MultiPlayerGameModeMixin;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.recovery.JvmSupport;
import cryptix.setting.BooleanSetting;
import cryptix.setting.NumberSetting;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

/**
 * Reconstructed from a/ek.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class WindCharge extends Module {
    private int f398;
    private float f397;
    private boolean f399;
    private static final String TEXT_ROTATIONSPEED;
    private static final String TEXT_WINDCHARGE;
    private final NumberSetting rotationSpeed;
    private static final String TEXT_JUMP;
    private final BooleanSetting jump;

    private static Packet onEventCallback0(int arg0) {
        ServerboundUseItemPacket reference0 = null;
        reference0 = new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, arg0, Events.rotation.getYaw(), Events.rotation.getPitch());
        return ((Packet) (Object) reference0);
    }

    public WindCharge() {
        super(WindCharge.TEXT_WINDCHARGE, Category.MISC);
        this.rotationSpeed = new NumberSetting(WindCharge.TEXT_ROTATIONSPEED, this, 5.0, 1.0, 10.0, 0.1);
        this.jump = new BooleanSetting(WindCharge.TEXT_JUMP, this, true);
        this.f398 = -1;
    }

    public void onEnable() {
        this.f397 = WindCharge.mc.player.getXRot();
        this.f397 = -1.0f;
    }

    static {
        TEXT_WINDCHARGE = new String("WindCharge");
        TEXT_ROTATIONSPEED = new String("RotationSpeed");
        TEXT_JUMP = new String("Jump");
    }

    public void onEvent(Event event) {
        PostInputEvent saved1 = null;
        boolean saved2 = false;
        RotationEvent saved3 = null;
        int integer2 = 0;
        int integer3 = 0;
        boolean saved4 = false;
        int saved5 = 0;
        float floating3 = 0.0f;
        float floating4 = 0.0f;
        int saved6 = 0;
        boolean saved7 = false;
        saved1 = Events.postInput;
        if (!((event != saved1))) {
            saved2 = this.f399;
            if (saved2) {
                WindCharge.mc.player.input.makeJump();
                this.f399 = false;
                this.toggle();
            }
        }
        saved3 = Events.rotation;
        if (!((event != saved3))) {
            integer2 = 0;
            integer3 = 0;
            loop22: while (true) {
                if ((integer3 >= 9)) {
                    break loop22;
                }
                saved4 = WindCharge.mc.player.getInventory().getItem(integer3).is(Items.WIND_CHARGE);
                if (saved4) {
                    saved5 = this.f398;
                    if (!((saved5 != -1))) {
                        this.f398 = WindCharge.mc.player.getInventory().getSelectedSlot();
                        WindCharge.mc.player.getInventory().setSelectedSlot(integer3);
                    }
                    integer2 = 1;
                    break loop22;
                } else {
                    integer3++;
                    continue loop22;
                }
            }
            if (!((integer2 != 0))) {
                return;
            } else {
                floating3 = (((float) this.rotationSpeed.getValue()) * 10.0f);
                floating4 = (90.0f - this.f397);
                this.f397 = (this.f397 + Math.copySign(Math.min(Math.abs(floating4), floating3), floating4));
                Events.rotation.setPitch(this.f397);
                saved6 = JvmSupport.fcmpl(this.f397, 90.0f);
                if (!((saved6 < 0))) {
                    saved7 = WindCharge.mc.player.getMainHandItem().is(Items.WIND_CHARGE);
                    if (saved7) {
                        ((MultiPlayerGameModeMixin) (Object) WindCharge.mc.gameMode).invokeStartPrediction(WindCharge.mc.level, (lambdaArg0) -> WindCharge.onEventCallback0(lambdaArg0));
                        this.f399 = true;
                    }
                }
                return;
            }
        } else {
            return;
        }
    }

    public void onDisable() {
        int saved1 = 0;
        saved1 = this.f398;
        if (!((saved1 == -1))) {
            WindCharge.mc.player.getInventory().setSelectedSlot(this.f398);
            this.f398 = -1;
        }
    }
}
