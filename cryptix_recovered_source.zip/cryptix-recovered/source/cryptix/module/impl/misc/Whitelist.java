package cryptix.module.impl.misc;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.PacketReceiveEvent;
import cryptix.module.Category;
import cryptix.module.Module;
import net.minecraft.network.protocol.common.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.world.phys.Vec3;

/**
 * Reconstructed from a/tc.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Whitelist extends Module {
    private static final String TEXT_PROTECT_YOUR_BED_AND_DESTROY_THE_ENEMY_BEDS;
    private static final String TEXT_WHITELIST;
    public Vec3 f21;
    private static final String TEXT_WHITELIST_2;
    public boolean f20;
    private boolean f391;

    public void onEvent(Event event) {
        PacketReceiveEvent saved1 = null;
        boolean saved2 = false;
        Object reference3 = null;
        boolean saved3 = false;
        Object reference2 = null;
        boolean saved4 = false;
        boolean saved5 = false;
        boolean saved6 = false;
        saved1 = Events.packetReceive;
        if (!((event != saved1))) {
            saved2 = (Events.packetReceive.getPacket() instanceof ClientboundDisconnectPacket);
            if (saved2) {
                this.f20 = false;
                this.f21 = null;
            }
            reference3 = Events.packetReceive.getPacket();
            saved3 = (reference3 instanceof ClientboundSystemChatPacket);
            if (saved3) {
                reference2 = ((ClientboundSystemChatPacket) reference3);
                reference3 = ((ClientboundSystemChatPacket) reference2).content().getString();
                saved4 = ((String) reference3).contains(Whitelist.TEXT_PROTECT_YOUR_BED_AND_DESTROY_THE_ENEMY_BEDS);
                if (saved4) {
                    this.f391 = true;
                }
            }
            reference3 = Events.packetReceive.getPacket();
            saved5 = (reference3 instanceof ClientboundPlayerPositionPacket);
            if (saved5) {
                reference2 = ((ClientboundPlayerPositionPacket) reference3);
                saved6 = this.f391;
                if (saved6) {
                    this.f20 = true;
                    this.f391 = false;
                    System.out.println(Whitelist.TEXT_WHITELIST);
                    this.f21 = ((ClientboundPlayerPositionPacket) reference2).change().position();
                }
            }
        }
    }

    static {
        TEXT_WHITELIST_2 = new String("Whitelist");
        TEXT_PROTECT_YOUR_BED_AND_DESTROY_THE_ENEMY_BEDS = new String("Protect your bed and destroy the enemy beds.");
        TEXT_WHITELIST = new String("whitelist");
    }

    public Whitelist() {
        super(Whitelist.TEXT_WHITELIST_2, Category.MISC);
    }
}
