package cryptix.module.impl.misc;

import cryptix.event.Event;
import cryptix.event.Events;
import cryptix.event.impl.PacketSendEvent;
import cryptix.event.impl.PostInputEvent;
import cryptix.mixin.ClientInputMixin;
import cryptix.module.Category;
import cryptix.module.Module;
import cryptix.setting.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.common.ServerboundKeepAlivePacket;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.phys.Vec2;

/**
 * Reconstructed from a/oj.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Disabler extends Module {
    private static final String TEXT_WATCHDOG_INVMOVE;
     int ticks;
    private static final String TEXT_KEEPALIVE_PACKET;
    private final BooleanSetting sprintPacket;
    private static final String TEXT_DISABLER;
    private final BooleanSetting watchdogInvMove;
    private final BooleanSetting keepAlivePacket;
    private static final String TEXT_SPRINT_PACKET;

    public void onEvent(Event event) {
        PostInputEvent saved1 = null;
        int saved2 = 0;
        Object reference2 = null;
        PacketSendEvent saved3 = null;
        boolean saved4 = false;
        boolean saved5 = false;
        boolean saved6 = false;
        boolean saved7 = false;
        Object reference3 = null;
        ServerboundPlayerCommandPacket.Action saved8 = null;
        ServerboundPlayerCommandPacket.Action saved9 = null;
        ServerboundPlayerCommandPacket.Action saved10 = null;
        ServerboundPlayerCommandPacket.Action saved11 = null;
        boolean saved12 = false;
        Object reference4 = null;
        boolean saved13 = false;
        ServerboundPlayerCommandPacket.Action saved14 = null;
        ServerboundPlayerCommandPacket.Action saved15 = null;
        boolean saved16 = false;
        boolean saved17 = false;
        ContainerInput saved18 = null;
        ContainerInput saved19 = null;
        ClientPacketListener saved20 = null;
        boolean saved21 = false;
        saved1 = Events.postInput;
        if (!((event != saved1))) {
            saved2 = this.ticks;
            if (!((saved2 <= 0))) {
                Disabler.mc.player.input.keyPresses = new Input(false, false, false, false, false, false, false);
                reference2 = ((ClientInputMixin) (Object) Disabler.mc.player.input);
                ((ClientInputMixin) reference2).setMoveVector(new Vec2(0.0f, 0.0f));
                this.ticks = (this.ticks - 1);
            }
        }
        saved3 = Events.packetSend;
        if (!((event != saved3))) {
            reference2 = Events.packetSend.getPacket();
            saved4 = this.keepAlivePacket.getValue();
            if (saved4) {
                saved5 = (reference2 instanceof ServerboundKeepAlivePacket);
                if (saved5) {
                    event.setCancelled(true);
                }
            }
            saved6 = this.sprintPacket.getValue();
            if (saved6) {
                saved7 = (reference2 instanceof ServerboundPlayerCommandPacket);
                if (saved7) {
                    reference3 = ((ServerboundPlayerCommandPacket) reference2);
                    saved8 = ((ServerboundPlayerCommandPacket) reference3).getAction();
                    saved9 = ServerboundPlayerCommandPacket.Action.START_SPRINTING;
                    if (!((saved8 == saved9))) {
                        saved10 = ((ServerboundPlayerCommandPacket) reference3).getAction();
                        saved11 = ServerboundPlayerCommandPacket.Action.STOP_SPRINTING;
                        if (!((saved10 != saved11))) {
                            event.setCancelled(true);
                        }
                    } else {
                        event.setCancelled(true);
                    }
                }
            }
            saved12 = this.watchdogInvMove.getValue();
            if (saved12) {
                reference4 = Events.packetSend.getPacket();
                saved13 = (reference4 instanceof ServerboundPlayerCommandPacket);
                if (saved13) {
                    reference3 = ((ServerboundPlayerCommandPacket) reference4);
                    saved14 = ((ServerboundPlayerCommandPacket) reference3).getAction();
                    saved15 = ServerboundPlayerCommandPacket.Action.OPEN_INVENTORY;
                    if (!((saved14 != saved15))) {
                        event.setCancelled(true);
                    }
                }
            }
            saved16 = this.watchdogInvMove.getValue();
            if (saved16) {
                saved17 = (reference2 instanceof ServerboundContainerClickPacket);
                if (saved17) {
                    reference3 = ((ServerboundContainerClickPacket) reference2);
                    reference4 = Minecraft.getInstance();
                    saved18 = ((ServerboundContainerClickPacket) reference3).containerInput();
                    saved19 = ContainerInput.PICKUP;
                    if (!((saved18 != saved19))) {
                        saved20 = ((Minecraft) reference4).getConnection();
                        if (!((saved20 == null))) {
                            saved21 = (((Minecraft) reference4).player.containerMenu instanceof InventoryMenu);
                            if (saved21) {
                                this.ticks = 5;
                            }
                        }
                    }
                }
            }
        }
    }

    public Disabler() {
        super(Disabler.TEXT_DISABLER, Category.MISC);
        this.keepAlivePacket = new BooleanSetting(Disabler.TEXT_KEEPALIVE_PACKET, this, false);
        this.sprintPacket = new BooleanSetting(Disabler.TEXT_SPRINT_PACKET, this, false);
        this.watchdogInvMove = new BooleanSetting(Disabler.TEXT_WATCHDOG_INVMOVE, this, false);
        this.ticks = -1;
    }

    static {
        TEXT_DISABLER = new String("Disabler");
        TEXT_KEEPALIVE_PACKET = new String("KeepAlive Packet");
        TEXT_SPRINT_PACKET = new String("Sprint Packet");
        TEXT_WATCHDOG_INVMOVE = new String("Watchdog InvMove");
    }
}
