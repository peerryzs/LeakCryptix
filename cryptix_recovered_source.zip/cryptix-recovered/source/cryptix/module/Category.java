package cryptix.module;

/**
 * Reconstructed from a/ll.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public enum Category {
    COMBAT, MOVEMENT, PLAYER, VISUAL, MISC;
    private static final String TEXT_MISC = new String("MISC");
    private static final String TEXT_VISUAL = new String("VISUAL");
    private static final String TEXT_MOVEMENT = new String("MOVEMENT");
    private static final String TEXT_PLAYER = new String("PLAYER");
    private static final String TEXT_COMBAT = new String("COMBAT");
}
