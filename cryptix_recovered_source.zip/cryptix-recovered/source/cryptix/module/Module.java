package cryptix.module;

import cryptix.event.Event;
import cryptix.event.Events;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.Minecraft;

/**
 * Reconstructed from a/le.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public abstract class Module {
    private int defaultKeybind;
    private String suffix;
    private int keybind;
    public List settings;
    private static final String TEXT_EMPTY;
    private boolean hidden;
    private String displayName;
    private final String name;
    private boolean enabled;
    private long toggleTime;
    private int cachedWidth;
    private final Category category;
    public static final Minecraft mc;

    public void toggle() {
        boolean saved1 = false;
        boolean saved2 = false;
        saved1 = this.enabled;
        this.enabled = ((!(saved1) ? 1 : 0) != 0);
        saved2 = this.enabled;
        if (saved2) {
            this.onEnable();
        } else {
            this.onDisable();
        }
        this.toggleTime = System.nanoTime();
        ModuleManager.playToggleSound();
        Events.refreshAllListeners();
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public Module(String name, int arg1, Category arg2) {
        this.settings = new ArrayList();
        this.cachedWidth = -1;
        this.defaultKeybind = 0;
        this.category = arg2;
        this.name = name;
        this.displayName = name;
        this.suffix = Module.TEXT_EMPTY;
        this.keybind = arg1;
        this.defaultKeybind = arg1;
        this.enabled = false;
    }

    public void onDisable() {
    }

    public void setSuffix(String arg0) {
        boolean saved1 = false;
        saved1 = Objects.equals(this.suffix, arg0);
        if (saved1) {
            return;
        } else {
            this.suffix = arg0;
            this.displayName = (!((arg0 != null)) ? this.name : ("" + this.name + "\u00a77 " + arg0));
            this.cachedWidth = Module.mc.font.width(this.displayName);
            ModuleManager.sortModulesByWidth();
            return;
        }
    }

    public String getName() {
        return this.name;
    }

    public void setHidden(boolean arg0) {
        this.hidden = arg0;
    }

    public boolean isHidden() {
        return this.hidden;
    }

    public long getToggleTime() {
        return this.toggleTime;
    }

    public void setKeybind(int arg0) {
        this.keybind = arg0;
    }

    public int getDefaultKeybind() {
        return this.defaultKeybind;
    }

    public String getSuffix() {
        return this.suffix;
    }

    public Category getCategory() {
        return this.category;
    }

    public void onEnable() {
    }

    public void onEvent(Event event) {
    }

    public int getKeybind() {
        return this.keybind;
    }

    public Module(String name, Category arg1) {
        this.settings = new ArrayList();
        this.cachedWidth = -1;
        this.defaultKeybind = 0;
        this.category = arg1;
        this.name = name;
        this.displayName = name;
        this.suffix = Module.TEXT_EMPTY;
        this.keybind = 0;
        this.enabled = false;
    }

    static {
        TEXT_EMPTY = new String("");
        mc = Minecraft.getInstance();
    }

    public int getDisplayWidth() {
        int saved1 = 0;
        int integer0 = 0;
        saved1 = this.cachedWidth;
        if (!((saved1 != -1))) {
            this.cachedWidth = Module.mc.font.width(this.displayName);
        }
        integer0 = this.cachedWidth;
        return integer0;
    }

    public void setEnabled(boolean arg0) {
        boolean saved1 = false;
        saved1 = this.enabled;
        if (!((saved1 == arg0))) {
            this.toggle();
        }
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public int getEventPriority(Event arg0) {
        int integer0 = 0;
        integer0 = 0;
        return integer0;
    }
}
