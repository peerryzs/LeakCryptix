package cryptix.render;

import cryptix.event.impl.HudRenderEvent;
import cryptix.recovery.JvmSupport;
import cryptix.util.MinecraftAccess;
import cryptix.util.Recovered_dl;
import net.minecraft.client.Camera;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector4f;

/**
 * Reconstructed from a/nf.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class ProjectionUtils implements MinecraftAccess {
    private static double f925;
    private static int f928;
    private static double f927;
    private static final Matrix4f f923;
    private static double f926;
    private static final Vector4f f924;
    private static int f929;

    static {
        f923 = new Matrix4f();
        f924 = new Vector4f();
    }

    public static Recovered_dl projectToScreen(double arg0, double arg1, double arg2, Recovered_dl arg3) {
        int saved1 = 0;
        Recovered_dl reference0 = null;
        float floating7 = 0.0f;
        double number8 = 0.0;
        double number10 = 0.0;
        double number12 = 0.0;
        ProjectionUtils.f924.set(((float) (arg0 - ProjectionUtils.f925)), ((float) (arg1 - ProjectionUtils.f926)), ((float) (arg2 - ProjectionUtils.f927)), 1.0f);
        ProjectionUtils.f924.mul(((Matrix4fc) (Object) ProjectionUtils.f923));
        saved1 = JvmSupport.fcmpg(ProjectionUtils.f924.w, 0.0f);
        if (!((saved1 > 0))) {
            reference0 = null;
            return reference0;
        } else {
            floating7 = (1.0f / ProjectionUtils.f924.w);
            number8 = ((double) (ProjectionUtils.f924.x * floating7));
            number10 = ((double) (ProjectionUtils.f924.y * floating7));
            number12 = ((double) (ProjectionUtils.f924.z * floating7));
            arg3.m246((((number8 * 0.5) + 0.5) * ((double) ProjectionUtils.f928)), ((0.5 - (number10 * 0.5)) * ((double) ProjectionUtils.f929)), number12);
            reference0 = arg3;
            return reference0;
        }
    }

    public ProjectionUtils() {
    }

    public static void m47() {
        Camera reference0 = null;
        Vec3 reference1 = null;
        reference0 = MinecraftAccess.mc.gameRenderer.mainCamera();
        reference1 = reference0.position();
        ProjectionUtils.f925 = reference1.x;
        ProjectionUtils.f926 = reference1.y;
        ProjectionUtils.f927 = reference1.z;
        ProjectionUtils.f923.set(((Matrix4fc) (Object) reference0.getViewRotationProjectionMatrix(ProjectionUtils.f923)));
        ProjectionUtils.f928 = MinecraftAccess.mc.getWindow().getGuiScaledWidth();
        ProjectionUtils.f929 = MinecraftAccess.mc.getWindow().getGuiScaledHeight();
    }

    public static void m49(HudRenderEvent arg0, int arg1, int arg2, int arg3, int arg4, double arg5, int arg6, int arg7, int arg8) {
        arg0.getGraphics().fill((arg1 - 1), (arg2 - 1), ((arg1 + arg3) + 1), ((arg2 + arg4) + 1), arg6);
        arg0.getGraphics().fill(arg1, arg2, (arg1 + arg3), (arg2 + arg4), arg7);
        arg0.getGraphics().fill(arg1, arg2, ((int) (((double) arg1) + (((double) arg3) * arg5))), (arg2 + arg4), arg8);
    }
}
