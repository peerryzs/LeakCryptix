package cryptix.gui;

import cryptix.module.impl.visual.TargetHUD;
import cryptix.recovery.JvmSupport;
import cryptix.util.MinecraftAccess;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/**
 * Reconstructed from a/sy.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_sy extends Screen implements MinecraftAccess {
    private double f196;
    private final TargetHUD f194;
    private static final String TEXT_TARGETHUD_POSITION;
    private double f197;
    private boolean f195;
    private static final String TEXT_RESET_POSITION;
    private static final String TEXT_EDIT_THE_TARGETHUD_POSITION_BY_DRAGGING;

    public void extractRenderState(GuiGraphicsExtractor arg0, int arg1, int arg2, float arg3) {
        int integer5 = 0;
        int integer6 = 0;
        boolean saved1 = false;
        int integer7 = 0;
        int integer8 = 0;
        int integer9 = 0;
        int integer10 = 0;
        int integer11 = 0;
        int integer12 = 0;
        String reference7 = null;
        GuiEventListener saved2 = null;
        arg0.fill(0, 0, this.width, this.height, -2147483648);
        this.f194.m212(arg0, arg3, MinecraftAccess.mc.player);
        integer5 = MinecraftAccess.mc.getWindow().getGuiScaledWidth();
        integer6 = MinecraftAccess.mc.getWindow().getGuiScaledHeight();
        saved1 = this.pm$13(((double) arg1), ((double) arg2));
        if (saved1) {
            integer7 = MinecraftAccess.mc.getWindow().getGuiScaledWidth();
            integer8 = MinecraftAccess.mc.getWindow().getGuiScaledHeight();
            integer9 = (this.f194.m213() + (integer7 / 2));
            integer10 = (this.f194.m214() + (integer8 / 2));
            integer11 = this.f194.m215();
            integer12 = this.f194.m216();
            arg0.outline(integer9, integer10, integer11, integer12, -1);
        }
        reference7 = Recovered_sy.TEXT_EDIT_THE_TARGETHUD_POSITION_BY_DRAGGING;
        arg0.text(MinecraftAccess.mc.font, reference7, ((integer5 / 2) - (MinecraftAccess.mc.font.width(reference7) / 2)), ((integer6 / 2) - 25), -1);
        saved2 = this.getFocused();
        if (!((saved2 == null))) {
            this.setFocused(null);
        }
        super.extractRenderState(arg0, arg1, arg2, arg3);
    }

    public void init() {
        MutableComponent saved2 = null;
        Button reference1 = null;
        saved2 = Component.literal(Recovered_sy.TEXT_RESET_POSITION);
        final Recovered_sy captured1 = this;
        reference1 = Button.builder(((Component) (Object) saved2), (lambdaArg0) -> captured1.initCallback0(((Button) lambdaArg0))).bounds((this.width - 90), (this.height - 25), 85, 20).build();
        this.addRenderableWidget(((GuiEventListener) (Object) reference1));
    }

    public boolean mouseReleased(MouseButtonEvent arg0) {
        int saved1 = 0;
        boolean saved2 = false;
        int integer0 = 0;
        saved1 = arg0.button();
        if (!((saved1 != 0))) {
            saved2 = this.f195;
            if (saved2) {
                this.f195 = false;
                this.f194.m217(this.f194.m213(), this.f194.m214());
                integer0 = 1;
                return (integer0 != 0);
            } else {
                integer0 = (super.mouseReleased(arg0) ? 1 : 0);
                return (integer0 != 0);
            }
        } else {
            integer0 = (super.mouseReleased(arg0) ? 1 : 0);
            return (integer0 != 0);
        }
    }

    static {
        TEXT_TARGETHUD_POSITION = new String("TargetHUD Position");
        TEXT_RESET_POSITION = new String("Reset Position");
        TEXT_EDIT_THE_TARGETHUD_POSITION_BY_DRAGGING = new String("Edit the TargetHUD position by dragging.");
    }

    public Recovered_sy(TargetHUD arg0) {
        super(((Component) (Object) Component.literal(Recovered_sy.TEXT_TARGETHUD_POSITION)));
        this.f194 = arg0;
    }

    public boolean isPauseScreen() {
        int integer0 = 0;
        integer0 = 0;
        return (integer0 != 0);
    }

    private boolean pm$13(double arg0, double arg1) {
        int integer5 = 0;
        int integer6 = 0;
        int integer7 = 0;
        int integer8 = 0;
        int integer9 = 0;
        int integer10 = 0;
        int saved1 = 0;
        int saved2 = 0;
        int saved3 = 0;
        int saved4 = 0;
        int branchValue5 = 0;
        int branchValue6 = 0;
        int branchValue7 = 0;
        int integer0 = 0;
        integer5 = MinecraftAccess.mc.getWindow().getGuiScaledWidth();
        integer6 = MinecraftAccess.mc.getWindow().getGuiScaledHeight();
        integer7 = (this.f194.m213() + (integer5 / 2));
        integer8 = (this.f194.m214() + (integer6 / 2));
        integer9 = this.f194.m215();
        integer10 = this.f194.m216();
        saved1 = JvmSupport.dcmpl(arg0, ((double) integer7));
        if (!((saved1 < 0))) {
            saved2 = JvmSupport.dcmpg(arg0, ((double) (integer7 + integer9)));
            if (!((saved2 > 0))) {
                saved3 = JvmSupport.dcmpl(arg1, ((double) integer8));
                if (!((saved3 < 0))) {
                    saved4 = JvmSupport.dcmpg(arg1, ((double) (integer8 + integer10)));
                    branchValue5 = (!((saved4 > 0)) ? 1 : 0);
                } else {
                    branchValue5 = 0;
                }
                branchValue6 = branchValue5;
            } else {
                branchValue6 = 0;
            }
            branchValue7 = branchValue6;
        } else {
            branchValue7 = 0;
        }
        integer0 = branchValue7;
        return (integer0 != 0);
    }

    public boolean mouseClicked(MouseButtonEvent arg0, boolean arg1) {
        double number3 = 0.0;
        double number5 = 0.0;
        int integer7 = 0;
        boolean saved1 = false;
        int integer8 = 0;
        int integer9 = 0;
        double number10 = 0.0;
        int integer0 = 0;
        number3 = arg0.x();
        number5 = arg0.y();
        integer7 = arg0.button();
        if (!((integer7 != 0))) {
            saved1 = this.pm$13(number3, number5);
            if (saved1) {
                this.f195 = true;
                integer8 = MinecraftAccess.mc.getWindow().getGuiScaledWidth();
                integer9 = 150;
                number10 = ((double) ((integer8 + this.f194.m213()) - integer9));
                this.f196 = (arg0.x() - number10);
                this.f197 = (arg0.y() - ((double) this.f194.m214()));
                integer0 = 1;
                return (integer0 != 0);
            } else {
                integer0 = (super.mouseClicked(arg0, arg1) ? 1 : 0);
                return (integer0 != 0);
            }
        } else {
            integer0 = (super.mouseClicked(arg0, arg1) ? 1 : 0);
            return (integer0 != 0);
        }
    }

    public boolean mouseDragged(MouseButtonEvent arg0, double arg1, double arg2) {
        double number6 = 0.0;
        double number8 = 0.0;
        int integer10 = 0;
        boolean saved1 = false;
        int integer11 = 0;
        int integer12 = 0;
        double number13 = 0.0;
        double number15 = 0.0;
        int integer17 = 0;
        int integer18 = 0;
        int integer0 = 0;
        number6 = arg0.x();
        number8 = arg0.y();
        integer10 = arg0.button();
        saved1 = this.f195;
        if (saved1) {
            if (!((integer10 != 0))) {
                integer11 = MinecraftAccess.mc.getWindow().getGuiScaledWidth();
                integer12 = 150;
                number13 = (number6 - this.f196);
                number15 = (number8 - this.f197);
                integer17 = ((int) ((number13 + ((double) integer12)) - ((double) integer11)));
                integer18 = ((int) number15);
                this.f194.m217(integer17, integer18);
                integer0 = 1;
                return (integer0 != 0);
            } else {
                integer0 = (super.mouseDragged(arg0, arg1, arg2) ? 1 : 0);
                return (integer0 != 0);
            }
        } else {
            integer0 = (super.mouseDragged(arg0, arg1, arg2) ? 1 : 0);
            return (integer0 != 0);
        }
    }

    private void initCallback0(Button arg0) {
        this.f194.m217(0, 0);
    }
}
