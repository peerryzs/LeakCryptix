package cryptix.gui;

import cryptix.module.Category;
import cryptix.module.ModuleManager;
import cryptix.util.Recovered_gm;
import cryptix.util.Recovered_mw;
import cryptix.util.Recovered_qj;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * Reconstructed from a/ej.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class Recovered_ej extends Screen {
    private static final String TEXT_MISC;
    private Recovered_gm f158;
    private static final String TEXT_VISUAL;
    private static final String TEXT_CLICKGUI;
    private int f160;
    private List f157;
    private static final String TEXT_COMBAT;
    private static final String TEXT_PLAYER;
    private static final String TEXT_MOVEMENT;
    private int f159;
    private static final String TEXT_CONFIGS;

    public boolean keyPressed(KeyEvent arg0) {
        Iterator reference2 = null;
        boolean saved1 = false;
        Recovered_gm reference3 = null;
        int integer4 = 0;
        Iterator reference5 = null;
        boolean saved2 = false;
        Recovered_mw reference6 = null;
        boolean saved3 = false;
        int integer0 = 0;
        reference2 = this.f157.iterator();
        loop4: while (true) {
            saved1 = reference2.hasNext();
            if (!(saved1)) {
                break loop4;
            }
            reference3 = ((Recovered_gm) reference2.next());
            integer4 = 0;
            reference5 = reference3.m108().iterator();
            loop17: while (true) {
                saved2 = reference5.hasNext();
                if (!(saved2)) {
                    break loop17;
                }
                reference6 = ((Recovered_mw) reference5.next());
                saved3 = reference6.f13;
                if (saved3) {
                    integer4 = 1;
                }
                continue loop17;
            }
            reference3.m105(arg0.key());
            if (!((integer4 == 0))) {
                integer0 = 0;
                return (integer0 != 0);
            }
            continue loop4;
        }
        integer0 = (super.keyPressed(arg0) ? 1 : 0);
        return (integer0 != 0);
    }

    public void extractRenderState(GuiGraphicsExtractor arg0, int arg1, int arg2, float arg3) {
        Recovered_gm saved1 = null;
        int saved2 = 0;
        Iterator reference5 = null;
        boolean saved3 = false;
        Recovered_gm reference6 = null;
        super.extractRenderState(arg0, arg1, arg2, arg3);
        saved1 = this.f158;
        if (!((saved1 == null))) {
            saved2 = GLFW.glfwGetMouseButton(this.minecraft.getWindow().handle(), 0);
            if (!((saved2 != 1))) {
                this.f158.f4 = (arg1 - this.f159);
                this.f158.f5 = (arg2 - this.f160);
            } else {
                this.f158 = null;
            }
        }
        reference5 = this.f157.iterator();
        loop39: while (true) {
            saved3 = reference5.hasNext();
            if (!(saved3)) {
                break loop39;
            }
            reference6 = ((Recovered_gm) reference5.next());
            reference6.m101(arg0);
            continue loop39;
        }
    }

    public boolean mouseClicked(MouseButtonEvent arg0, boolean arg1) {
        double number3 = 0.0;
        double number5 = 0.0;
        int integer7 = 0;
        Iterator reference8 = null;
        boolean saved1 = false;
        Recovered_gm reference9 = null;
        boolean saved2 = false;
        boolean saved3 = false;
        int integer0 = 0;
        number3 = arg0.x();
        number5 = arg0.y();
        integer7 = arg0.button();
        if (!((integer7 != 0))) {
            reference8 = this.f157.iterator();
            loop15: while (true) {
                saved1 = reference8.hasNext();
                if (!(saved1)) {
                    break loop15;
                }
                reference9 = ((Recovered_gm) reference8.next());
                saved2 = reference9.m102(number3, number5);
                if (saved2) {
                    this.startDrag(reference9, number3, number5);
                }
                continue loop15;
            }
        }
        reference8 = this.f157.iterator();
        loop37: while (true) {
            saved3 = reference8.hasNext();
            if (!(saved3)) {
                break loop37;
            }
            reference9 = ((Recovered_gm) reference8.next());
            reference9.m104(number3, number5, integer7);
            continue loop37;
        }
        integer0 = (super.mouseClicked(arg0, arg1) ? 1 : 0);
        return (integer0 != 0);
    }

    private void startDrag(Recovered_gm arg0, double arg1, double arg2) {
        this.f158 = arg0;
        this.f159 = (((int) arg1) - arg0.f4);
        this.f160 = (((int) arg2) - arg0.f5);
    }

    public Recovered_ej() {
        super(((Component) (Object) Component.literal(Recovered_ej.TEXT_CLICKGUI)));
        this.f157 = new ArrayList();
        this.f157.add(new Recovered_gm(Recovered_ej.TEXT_COMBAT, 50, 50, ModuleManager.getModulesInCategory(Category.COMBAT)));
        this.f157.add(new Recovered_gm(Recovered_ej.TEXT_MOVEMENT, 160, 50, ModuleManager.getModulesInCategory(Category.MOVEMENT)));
        this.f157.add(new Recovered_gm(Recovered_ej.TEXT_PLAYER, 270, 50, ModuleManager.getModulesInCategory(Category.PLAYER)));
        this.f157.add(new Recovered_gm(Recovered_ej.TEXT_VISUAL, 380, 50, ModuleManager.getModulesInCategory(Category.VISUAL)));
        this.f157.add(new Recovered_gm(Recovered_ej.TEXT_MISC, 490, 50, ModuleManager.getModulesInCategory(Category.MISC)));
        this.f157.add(new Recovered_qj(Recovered_ej.TEXT_CONFIGS, 600, 50));
    }

    public boolean mouseReleased(MouseButtonEvent arg0) {
        int saved1 = 0;
        Iterator reference2 = null;
        boolean saved2 = false;
        Recovered_gm reference3 = null;
        int integer0 = 0;
        saved1 = arg0.button();
        if (!((saved1 != 0))) {
            this.f158 = null;
            reference2 = this.f157.iterator();
            loop10: while (true) {
                saved2 = reference2.hasNext();
                if (!(saved2)) {
                    break loop10;
                }
                reference3 = ((Recovered_gm) reference2.next());
                reference3.m107();
                continue loop10;
            }
        }
        integer0 = (super.mouseReleased(arg0) ? 1 : 0);
        return (integer0 != 0);
    }

    public boolean mouseDragged(MouseButtonEvent arg0, double arg1, double arg2) {
        double number6 = 0.0;
        double number8 = 0.0;
        Iterator reference10 = null;
        boolean saved1 = false;
        Recovered_gm reference11 = null;
        Recovered_gm saved2 = null;
        int integer0 = 0;
        number6 = arg0.x();
        number8 = arg0.y();
        reference10 = this.f157.iterator();
        loop10: while (true) {
            saved1 = reference10.hasNext();
            if (!(saved1)) {
                break loop10;
            }
            reference11 = ((Recovered_gm) reference10.next());
            reference11.m106(number6, number8);
            continue loop10;
        }
        saved2 = this.f158;
        if (!((saved2 == null))) {
            this.f158.f4 = (((int) number6) - this.f159);
            this.f158.f5 = (((int) number8) - this.f160);
        }
        integer0 = (super.mouseDragged(arg0, arg1, arg2) ? 1 : 0);
        return (integer0 != 0);
    }

    static {
        TEXT_CLICKGUI = new String("ClickGUI");
        TEXT_COMBAT = new String("Combat");
        TEXT_MOVEMENT = new String("Movement");
        TEXT_PLAYER = new String("Player");
        TEXT_VISUAL = new String("Visual");
        TEXT_MISC = new String("Misc");
        TEXT_CONFIGS = new String("Configs");
    }
}
