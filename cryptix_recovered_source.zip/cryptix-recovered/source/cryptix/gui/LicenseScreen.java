package cryptix.gui;

import a.b;
import a.i;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/**
 * Reconstructed from a/qf.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class LicenseScreen extends Screen {
    private static final String TEXT_CRYPTIX_LICENSE_TXT;
    private static final String TEXT_CRYPTIX_LOGIN;
    private static final String TEXT_LOGIN;
    private static final String TEXT_CRYPTIX_LICENSE_KEY;
    private EditBox f133;
    private final File f134;
    private static final String TEXT_LICENSE;
    public static String f21;
    private static final String TEXT_COPY_HWID;

    private void loginCallback0() {
        int integer1 = 0;
        Minecraft saved2 = null;
        integer1 = (i.m0(("" + LicenseScreen.f21 + "|" + b.m1())) ? 1 : 0);
        saved2 = Minecraft.getInstance();
        final LicenseScreen captured1 = this;
        final boolean captured3 = (integer1 != 0);
        saved2.execute(() -> captured1.loginCallback1(captured3));
    }

    private void loginCallback1(boolean arg0) {
        IOException reference2 = null;
        if (arg0) {
            try {
                this.f134.getParentFile().mkdirs();
                Files.writeString(this.f134.toPath(), LicenseScreen.f21, new OpenOption[] {});
            } catch (IOException caught1) {
                reference2 = caught1;
            }
            Minecraft.getInstance().gui.setScreen(null);
        } else {
            System.exit(0);
        }
    }

    private void initCallback1(Button arg0) {
        this.pm$6();
    }

    static {
        TEXT_CRYPTIX_LOGIN = new String("Cryptix Login");
        TEXT_CRYPTIX_LICENSE_TXT = new String("cryptix/license.txt");
        TEXT_LICENSE = new String("License");
        TEXT_LOGIN = new String("Login");
        TEXT_COPY_HWID = new String("Copy HWID");
        TEXT_CRYPTIX_LICENSE_KEY = new String("Cryptix License Key");
    }

    public LicenseScreen() {
        super(((Component) (Object) Component.literal(LicenseScreen.TEXT_CRYPTIX_LOGIN)));
        this.f134 = new File(Minecraft.getInstance().gameDirectory, LicenseScreen.TEXT_CRYPTIX_LICENSE_TXT);
    }

    public void extractRenderState(GuiGraphicsExtractor arg0, int arg1, int arg2, float arg3) {
        String reference5 = null;
        super.extractRenderState(arg0, arg1, arg2, arg3);
        reference5 = LicenseScreen.TEXT_CRYPTIX_LICENSE_KEY;
        arg0.text(this.font, ((Component) (Object) Component.literal(reference5)), ((this.width / 2) - (this.font.width(reference5) / 2)), ((this.height / 2) - 60), -1);
    }

    private void pm$6() {
        String reference1 = null;
        reference1 = b.m1();
        Minecraft.getInstance().keyboardHandler.setClipboard(reference1);
    }

    private void initCallback0(Button arg0) {
        this.login();
    }

    public boolean shouldCloseOnEsc() {
        int integer0 = 0;
        integer0 = 0;
        return (integer0 != 0);
    }

    protected void init() {
        boolean saved1 = false;
        IOException reference1 = null;
        MutableComponent saved4 = null;
        MutableComponent saved6 = null;
        this.f133 = new EditBox(this.font, ((this.width / 2) - 100), ((this.height / 2) - 20), 200, 20, ((Component) (Object) Component.literal(LicenseScreen.TEXT_LICENSE)));
        this.f133.setMaxLength(64);
        saved1 = this.f134.exists();
        if (saved1) {
            try {
                this.f133.setValue(Files.readString(this.f134.toPath()));
            } catch (IOException caught2) {
                reference1 = caught2;
            }
        }
        this.addRenderableWidget(((GuiEventListener) (Object) this.f133));
        saved4 = Component.literal(LicenseScreen.TEXT_LOGIN);
        final LicenseScreen captured3 = this;
        this.addRenderableWidget(((GuiEventListener) (Object) Button.builder(((Component) (Object) saved4), (lambdaArg0) -> captured3.initCallback0(((Button) lambdaArg0))).bounds(((this.width / 2) - 50), ((this.height / 2) + 20), 100, 20).build()));
        saved6 = Component.literal(LicenseScreen.TEXT_COPY_HWID);
        final LicenseScreen captured5 = this;
        this.addRenderableWidget(((GuiEventListener) (Object) Button.builder(((Component) (Object) saved6), (lambdaArg0) -> captured5.initCallback1(((Button) lambdaArg0))).bounds(((this.width / 2) - 50), ((this.height / 2) + 50), 100, 20).build()));
        this.setInitialFocus(((GuiEventListener) (Object) this.f133));
    }

    private void login() {
        boolean saved1 = false;
        LicenseScreen.f21 = this.f133.getValue();
        saved1 = LicenseScreen.f21.isEmpty();
        if (saved1) {
            return;
        } else {
            final LicenseScreen captured2 = this;
            new Thread(() -> captured2.loginCallback0()).start();
            return;
        }
    }
}
