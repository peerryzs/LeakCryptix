package cryptix.gui;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import cryptix.mixin.MinecraftMixin_nz;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/**
 * Reconstructed from a/ak.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class TokenLoginScreen extends Screen {
    private EditBox f145;
    private static final String TEXT_1_2_3_4_5;
    private static final String TEXT_NAME;
    private static final String TEXT_TOKEN_LOGIN;
    private static final String TEXT_AUTHORIZATION;
    private static final String TEXT_LOGIN;
    private static final String TEXT_W_8_W_4_W_4_W_4_W_12;
    private static final String TEXT_HTTPS_API_MINECRAFTSERVICES_COM_MINECRAFT_PROFILE;
    private static final String TEXT_BACK;
    private static final String TEXT_ID;
    private static final String TEXT_TOKEN;

    private void pm$8() {
        String reference1 = null;
        reference1 = this.f145.getValue();
        this.loginWithToken(reference1);
    }

    public void extractRenderState(GuiGraphicsExtractor arg0, int arg1, int arg2, float arg3) {
        String reference5 = null;
        super.extractRenderState(arg0, arg1, arg2, arg3);
        reference5 = ("\u00a7aLogged in as: " + ((MinecraftMixin_nz) (Object) Minecraft.getInstance()).getUser().getName());
        arg0.text(this.font, ((Component) (Object) Component.literal(reference5)), ((this.width / 2) - (this.font.width(reference5) / 2)), ((this.height / 2) - 50), -1);
    }

    public void loginWithToken(String arg0) {
        final TokenLoginScreen captured1 = this;
        final String captured2 = arg0;
        new Thread(() -> captured1.loginWithTokenCallback0(captured2)).start();
    }

    private void loginWithTokenCallback0(String arg0) {
        Object reference2 = null;
        Minecraft reference3 = null;
        UUID reference4 = null;
        User reference5 = null;
        try {
            reference2 = this.pm$9(arg0);
            reference3 = Minecraft.getInstance();
            reference4 = UUID.fromString(((String[]) reference2)[1].replaceFirst(TokenLoginScreen.TEXT_W_8_W_4_W_4_W_4_W_12, TokenLoginScreen.TEXT_1_2_3_4_5));
            reference5 = new User(((String[]) reference2)[0], reference4, arg0, Optional.empty(), Optional.empty());
            ((MinecraftMixin_nz) (Object) Minecraft.getInstance()).setUser(reference5);
            System.out.println(("Logged in as " + reference5.getName()));
        } catch (Exception caught1) {
            reference2 = caught1;
            ((Exception) reference2).printStackTrace();
        }
    }

    public TokenLoginScreen() {
        super(((Component) (Object) Component.literal(TokenLoginScreen.TEXT_TOKEN_LOGIN)));
    }

    static {
        TEXT_TOKEN_LOGIN = new String("Token Login");
        TEXT_TOKEN = new String("Token");
        TEXT_LOGIN = new String("Login");
        TEXT_BACK = new String("Back");
        TEXT_HTTPS_API_MINECRAFTSERVICES_COM_MINECRAFT_PROFILE = new String("https://api.minecraftservices.com/minecraft/profile");
        TEXT_AUTHORIZATION = new String("Authorization");
        TEXT_NAME = new String("name");
        TEXT_ID = new String("id");
        TEXT_W_8_W_4_W_4_W_4_W_12 = new String("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})");
        TEXT_1_2_3_4_5 = new String("$1-$2-$3-$4-$5");
    }

    protected void init() {
        MutableComponent saved2 = null;
        MutableComponent saved4 = null;
        this.f145 = new EditBox(this.font, ((this.width / 2) - 100), ((this.height / 2) - 20), 200, 20, ((Component) (Object) Component.literal(TokenLoginScreen.TEXT_TOKEN)));
        this.f145.setMaxLength(32767);
        this.addRenderableWidget(((GuiEventListener) (Object) this.f145));
        saved2 = Component.literal(TokenLoginScreen.TEXT_LOGIN);
        final TokenLoginScreen captured1 = this;
        this.addRenderableWidget(((GuiEventListener) (Object) Button.builder(((Component) (Object) saved2), (lambdaArg0) -> captured1.initCallback0(((Button) lambdaArg0))).bounds(((this.width / 2) - 50), ((this.height / 2) + 20), 100, 20).build()));
        saved4 = Component.literal(TokenLoginScreen.TEXT_BACK);
        final TokenLoginScreen captured3 = this;
        this.addRenderableWidget(((GuiEventListener) (Object) Button.builder(((Component) (Object) saved4), (lambdaArg0) -> captured3.initCallback1(((Button) lambdaArg0))).bounds(((this.width / 2) - 50), ((this.height / 2) + 50), 100, 20).build()));
        this.setInitialFocus(((GuiEventListener) (Object) this.f145));
    }

    private void initCallback1(Button arg0) {
        this.onClose();
    }

    private void initCallback0(Button arg0) {
        this.pm$8();
    }

    private String[] pm$9(String arg0) throws IOException, InterruptedException {
        HttpClient reference2 = null;
        HttpRequest reference3 = null;
        HttpResponse reference4 = null;
        JsonObject reference5 = null;
        String[] reference0 = null;
        reference2 = HttpClient.newHttpClient();
        reference3 = HttpRequest.newBuilder().uri(URI.create(TokenLoginScreen.TEXT_HTTPS_API_MINECRAFTSERVICES_COM_MINECRAFT_PROFILE)).header(TokenLoginScreen.TEXT_AUTHORIZATION, ("Bearer " + arg0)).GET().build();
        reference4 = reference2.send(reference3, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        reference5 = JsonParser.parseString(((String) reference4.body())).getAsJsonObject();
        reference0 = new String[] {reference5.get(TokenLoginScreen.TEXT_NAME).getAsString(), reference5.get(TokenLoginScreen.TEXT_ID).getAsString()};
        return reference0;
    }
}
