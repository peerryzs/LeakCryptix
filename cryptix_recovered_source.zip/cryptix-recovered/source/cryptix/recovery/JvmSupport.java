package cryptix.recovery;

/** JVM operations whose corner-case behavior must not be replaced by Java approximations. */
public final class JvmSupport {
    private JvmSupport() {}
    public static int lcmp(long a, long b) { return a < b ? -1 : a > b ? 1 : 0; }
    public static int fcmpl(float a, float b) { return a < b ? -1 : a > b ? 1 : a == b ? 0 : -1; }
    public static int fcmpg(float a, float b) { return a < b ? -1 : a > b ? 1 : a == b ? 0 : 1; }
    public static int dcmpl(double a, double b) { return a < b ? -1 : a > b ? 1 : a == b ? 0 : -1; }
    public static int dcmpg(double a, double b) { return a < b ? -1 : a > b ? 1 : a == b ? 0 : 1; }
    /** Rethrow the exact exception object; bytecode has no checked-exception restriction. */
    public static RuntimeException rethrow(Throwable throwable) {
        JvmSupport.<RuntimeException>throwUnchecked(throwable);
        throw new AssertionError("unreachable");
    }
    @SuppressWarnings("unchecked")
    private static <T extends Throwable> void throwUnchecked(Throwable throwable) throws T {
        throw (T) throwable;
    }
}
