package cryptix.input;

import cryptix.module.Module;
import cryptix.module.ModuleManager;
import cryptix.util.MinecraftAccess;
import java.util.Iterator;
import net.minecraft.client.gui.screens.Screen;
import org.lwjgl.glfw.GLFW;

/**
 * Reconstructed from a/u.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class KeybindManager implements MinecraftAccess {
    private static final boolean[] f53;

    static {
        f53 = new boolean[349];
    }

    public KeybindManager() {
    }

    public static void pollKeybinds() {
        Screen saved1 = null;
        long local0 = 0L;
        int integer2 = 0;
        Iterator reference3 = null;
        boolean saved2 = false;
        Module reference4 = null;
        int integer5 = 0;
        int saved3 = 0;
        int integer6 = 0;
        boolean saved4 = false;
        Iterator reference7 = null;
        boolean saved5 = false;
        Module reference8 = null;
        int saved6 = 0;
        saved1 = MinecraftAccess.mc.gui.screen();
        if (!((saved1 == null))) {
            return;
        } else {
            local0 = MinecraftAccess.mc.getWindow().handle();
            integer2 = 1;
            reference3 = ModuleManager.getModules().iterator();
            loop14: while (true) {
                saved2 = reference3.hasNext();
                if (!(saved2)) {
                    break loop14;
                }
                reference4 = ((Module) reference3.next());
                integer5 = reference4.getKeybind();
                if ((integer5 == -1)) {
                    continue loop14;
                }
                if (!((integer5 != 0))) {
                    continue loop14;
                }
                saved3 = GLFW.glfwGetKey(local0, integer5);
                integer6 = (!((saved3 != integer2)) ? 1 : 0);
                if (!((integer6 == 0))) {
                    saved4 = KeybindManager.f53[integer5];
                    if (!(saved4)) {
                        reference7 = ModuleManager.getModules().iterator();
                        loop48: while (true) {
                            saved5 = reference7.hasNext();
                            if (!(saved5)) {
                                break loop48;
                            }
                            reference8 = ((Module) reference7.next());
                            saved6 = reference8.getKeybind();
                            if (!((saved6 != integer5))) {
                                reference8.toggle();
                            }
                            continue loop48;
                        }
                        KeybindManager.f53[integer5] = true;
                    }
                } else {
                    KeybindManager.f53[integer5] = false;
                }
                continue loop14;
            }
            return;
        }
    }
}
