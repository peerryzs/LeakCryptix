package cryptix.setting;

import cryptix.module.Module;

/**
 * Reconstructed from a/xc.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class BooleanSetting extends Setting {
    private boolean value;
    private boolean defaultValue;

    public BooleanSetting(String name, Module module, boolean arg2) {
        super(name, module);
        this.defaultValue = arg2;
        this.value = arg2;
    }

    public boolean getDefaultValue() {
        return this.defaultValue;
    }

    public boolean getValue() {
        return this.value;
    }

    public void setValue(boolean arg0) {
        this.value = arg0;
    }
}
