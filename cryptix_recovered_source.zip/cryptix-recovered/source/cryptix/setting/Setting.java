package cryptix.setting;

import cryptix.module.Module;

/**
 * Reconstructed from a/rg.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public abstract class Setting {
    private final String name;
    private final Module module;

    public Module getModule() {
        return this.module;
    }

    public String getName() {
        return this.name;
    }

    public Setting(String name, Module module) {
        this.name = name;
        this.module = module;
        this.module.settings.add(this);
    }
}
