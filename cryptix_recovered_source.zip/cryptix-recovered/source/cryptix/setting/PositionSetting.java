package cryptix.setting;

import cryptix.gui.Recovered_zg;
import cryptix.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

/**
 * Reconstructed from a/se.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class PositionSetting extends Setting {
    private Screen editorScreen;
    private int width;
    private int y;
    private int height;
    private int x;

    public int getX() {
        return this.x;
    }

    public PositionSetting(String name, Module module, int arg2, int arg3, int arg4, int arg5, Screen arg6) {
        super(name, module);
        boolean saved1 = false;
        Recovered_zg reference8 = null;
        this.x = arg2;
        this.y = arg3;
        this.width = arg4;
        this.height = arg5;
        this.editorScreen = arg6;
        saved1 = (arg6 instanceof Recovered_zg);
        if (saved1) {
            reference8 = ((Recovered_zg) (Object) arg6);
            reference8.setting = this;
        }
    }

    public int getWidth() {
        return this.width;
    }

    public int getY() {
        return this.y;
    }

    public void setHeight(int arg0) {
        this.height = arg0;
    }

    public void openEditor() {
        Minecraft.getInstance().gui.setScreen(this.editorScreen);
    }

    public void setY(int arg0) {
        this.y = arg0;
    }

    public int getHeight() {
        return this.height;
    }

    public void setPosition(int arg0, int arg1) {
        this.x = arg0;
        this.y = arg1;
    }

    public Screen getEditorScreen() {
        return this.editorScreen;
    }

    public void setWidth(int arg0) {
        this.width = arg0;
    }

    public void setX(int arg0) {
        this.x = arg0;
    }
}
