package cryptix.setting;

import cryptix.module.Module;

/**
 * Reconstructed from a/lm.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class NumberSetting extends Setting {
    private final double increment;
    private double defaultValue;
    private final double maximum;
    private final double minimum;
    private static final String TEXT_EMPTY;
    private double value;

    static {
        TEXT_EMPTY = new String("\\.");
    }

    public double getMinimum() {
        return this.minimum;
    }

    public NumberSetting(String name, Module module, double arg2, double arg3, double arg4, double arg5) {
        super(name, module);
        this.defaultValue = this.value;
        this.value = arg2;
        this.minimum = arg3;
        this.maximum = arg4;
        this.increment = arg5;
    }

    public void setValue(double arg0) {
        int integer3 = 0;
        arg0 = Math.max(this.minimum, Math.min(this.maximum, arg0));
        arg0 = (((double) Math.round((arg0 / this.increment))) * this.increment);
        integer3 = String.valueOf(this.increment).split(NumberSetting.TEXT_EMPTY)[1].length();
        arg0 = (((double) Math.round((arg0 * Math.pow(10.0, ((double) integer3))))) / Math.pow(10.0, ((double) integer3)));
        this.value = arg0;
    }

    public double getDefaultValue() {
        return this.defaultValue;
    }

    public double getMaximum() {
        return this.maximum;
    }

    public double getIncrement() {
        return this.increment;
    }

    public double getValue() {
        return this.value;
    }
}
