package cryptix.setting;

import cryptix.module.Module;

/**
 * Reconstructed from a/ju.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class ModeSetting extends Setting {
    private String defaultValue;
    private final String[] modes;
    private String value;

    public String getValue() {
        return this.value;
    }

    public String getDefaultValue() {
        return this.defaultValue;
    }

    public boolean is(String arg0) {
        int integer0 = 0;
        integer0 = (this.value.equals(arg0) ? 1 : 0);
        return (integer0 != 0);
    }

    public void setValue(String arg0) {
        this.value = arg0;
    }

    public String[] getModes() {
        return this.modes;
    }

    public ModeSetting(String name, Module module, String arg2, String[] arg3) {
        super(name, module);
        this.value = arg2;
        this.defaultValue = this.value;
        this.modes = arg3;
    }
}
