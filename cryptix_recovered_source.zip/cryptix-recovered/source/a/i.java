package a;

import native0.Loader;
import native0.hidden.Hidden0;

/**
 * Reconstructed from a/i.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class i {
    private static final String f32 = null;
    private static final String f17 = null;
    private static final String f8 = null;
    private static final String f2 = null;
    private static final String f21 = null;
    private static final String f26 = null;
    private static final String f13 = null;
    private static final String f20 = null;
    private static final String f25 = null;
    private static final String f31 = null;
    private static final String f14 = null;
    private static final String f5 = null;
    private static final String f30 = null;
    private static final String f0String = null;
    private static final String f29 = null;
    private static final String f10 = null;
    private static final String f22 = null;
    private static final String f12 = null;
    private static final String f16 = null;
    private static final String f28 = null;
    private static final String f15 = null;
    private static final String f18 = null;
    private static final String f24 = null;
    private static final String f9 = null;
    private static final String f19 = null;
    private static final String f3 = null;
    private static final String f4 = null;
    private static final String f23 = null;
    private static final String f6 = null;
    private static final String f11 = null;
    private static final String f7 = null;
    private static final String f1 = null;
    public static boolean f0;
    private static final String f27 = null;

    static {
        Loader.registerNativesForClass(0, i.class);
        Hidden0.special_clinit_0_00(i.class);
    }

    private static native boolean pm$1(String arg0);

    public static native boolean m0(String arg0);

    public i() {
    }

    private static native void pm$3();

    private static native boolean pm$2();

    private static native boolean pm$0(String arg0);

    private static native void lambda$failClosed$0();
}
