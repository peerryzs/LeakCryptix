package a;

import native0.Loader;
import native0.hidden.Hidden0;

/**
 * Reconstructed from a/b.class; descriptive names are inferred.
 * See recovery-manifest.json for method-level validation and unresolved regions.
 */
public class b {
    private static final String f33 = null;
    private static final String f41 = null;
    private static final String f48 = null;
    private static final String f47 = null;
    private static final String f46 = null;
    private static final String f49 = null;
    private static final String f44 = null;
    private static final String f45 = null;
    private static final String f34 = null;
    private static final String f37 = null;
    private static final String f35 = null;
    private static final String f36 = null;
    private static final String f42 = null;
    private static final String f43 = null;
    private static final String f39 = null;
    private static final String f38 = null;
    private static final String f40 = null;

    public static native void m2();

    public static native String m1();

    public static native void m3(String arg0);

    static {
        Loader.registerNativesForClass(1, b.class);
        Hidden0.special_clinit_1_30(b.class);
    }

    public b() {
    }
}
