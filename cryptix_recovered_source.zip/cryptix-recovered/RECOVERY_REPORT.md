# Cryptix Java recovery report

## Result and scope

The source tree covers all **151 classes** in the supplied JAR, including **55 modules** and **32 mixins**. It contains **152 Java files**: one per original class plus the small `JvmSupport` compatibility helper. There are 24,455 source lines including imports, comments, and whitespace.

Of the original **765 methods**, **720** have explicit reconstructed Java bodies, **5** enum methods are represented by a Java enum declaration, **30** were abstract declarations, and **10** remain native declarations. The 55 module classes contain **264 methods**, including constructors and static initializers. Every one of these module methods has a reconstructed body. No module is represented only by a signature or an `UnsupportedOperationException` placeholder.

This is an editable reconstruction, **not the author's recovered repository, not byte-for-byte original source, and not a verified functionally identical or drop-in client rebuild**. Original comments, local-variable names, layout, generic source information, and some original names were unavailable. Numerous descriptive names are inferred from strings, call sites, field use, event hooks, and surviving lambda implementation names. Less certain names remain numeric or prefixed `Recovered_` instead of being invented with false confidence.

## Input identity

- File: `cryptix.jar`
- Size: 72,062,102 bytes
- SHA-256: `4549e6578f0762adfad4c67e3e791b5c9ecad606986863ff74b47b13c9c4716d`
- Embedded native payload: `native0/x64-windows.dll`, 71,825,920 bytes
- Native SHA-256: `a979fc1b26a6e5a8a9868b20f56fbb8173840dd85f6147c106aab1bd41652142`

The supplied manifest reports Minecraft **26.2**, official mappings, Fabric Loader **0.19.3**, Loom **1.17.20**, Mixin **0.17.3+mixin.0.8.7**, and Gradle **9.7.0**. The class major version is **69**, and the supplied Fabric metadata requires **Java 25 or later**. These are statements about the uploaded artifact, not independent confirmation that an external dependency distribution is available or compatible.

## Static reconstruction work

No uploaded class or native library was executed. The pipeline used a classfile reader and the installed JDK's internal ASM implementation, followed by a custom typed-stack source reconstructor. Attempts to retrieve third-party decompilers were blocked by this environment's outbound download restrictions; CFR or Vineflower output is not being claimed as the provenance of this source.

The normalizer performed:

- **25,261** arithmetic constant folds.
- **9,766** replacements of reads of private static integer fields with no Java writes.
- **456** statically decoded UTF-8 string initializers.
- **388** removed no-op instructions.

String allocations are retained as `new String(...)` rather than indiscriminately converting all original strings into interned literals. Field reads remain field reads in generated source. Control flow was reconstructed into Java conditionals, loops, switches, exception handlers, and synchronized blocks. Return-slot shuffles were simplified for direct accessors. Additional work addressed slot reuse, long arithmetic, duplicate evaluation, lambda captures, native-name collisions, and loop exits.

No claim is made that bytecode normalization is transparent to every possible reflective, native, timing-sensitive, or identity-sensitive observation. In particular, the zero-field transformation assumes that JNI, reflection, or another transformer does not mutate those fields. The JAR itself contains no ordinary Java writes to them.

## Validation actually performed

1. **Typed-stack analysis:** all 725 bytecode-bearing methods in the normalized original classes were accepted by the static ASM analysis. This is not a full JVM verifier or a runtime test.
2. **Java parsing:** all 152 delivered Java files parsed with zero diagnostics.
3. **Compilation against API-signature fixtures:** the complete source compiled successfully with annotation processing disabled. The external fixtures are nonfunctional and inferred; this checks internal Java consistency, not an actual Minecraft/Fabric build. Generic/unchecked warnings remain.
4. **Synthetic differential tests:** 5,574 comparisons passed between independently authored original and reconstructed test code. These exercise loops and loop exits, switches/fallthrough, short-circuit conditions, lambda capture, compound assignment, strings, array initialization, exception paths, 64-bit operations, NaN, infinities, and signed zero. They do **not** execute or certify the uploaded client.
5. **Optional symbol-restoration audit:** after compiling against fixtures and restoring known JVM names, all **151 original class names**, **1,221 field name/descriptor pairs**, and **765 method name/descriptor pairs** were present. This proves symbol presence only, not identical implementations, access flags, metadata, native ABI behavior, or a working client.

The supporting logs and fixtures are under `validation/`. They are separate from `source/` so that test scaffolding cannot be mistaken for recovered module implementations.

## Native code and runtime dependencies

Nine application methods in `a/i` and `a/b` are native; `native0/Loader.registerNativesForClass` is a tenth native declaration. Their native implementations have **not** been reconstructed into Java. They remain explicit native declarations, not no-op substitutes or unconditional-success replacements. The Java native-loading code is included.

The Java bytecode also refers to `native0/hidden/Hidden0.special_clinit_0_00` and `special_clinit_1_30`; a corresponding class definition is not supplied as a normal class entry in the input JAR. These are unresolved runtime bridge dependencies. No replacement behavior is fabricated for them in the product source. A compile-only signature fixture exists exclusively under `validation/`.

The Windows DLL was inspected as a binary artifact, not run or unpacked into a complete native source tree. Its absence from the source ZIP is intentional: the original copy remains in the user's input JAR. `tools/extract_original_resources.py` can copy the exact original resources, including that DLL, without executing them.

Nothing in this result is a safety attestation for the original client or DLL. Native checks and failure paths were not intentionally bypassed.

## Known reconstruction differences and qualifications

### Names, packages, access, and compiler artifacts

Modules, settings, events, and utilities have descriptive names and packages. Reflection, literal class names, serialized lambdas, mixin configuration, and JNI can depend on JVM names. The `symbols.tsv` map and `RestoreSymbols.java` utility provide an optional static post-compilation restoration of known class/member names, including the native bridge's two different fields originally named `f0`. The utility also reinstates omitted opaque-zero field declarations.

The readable tree broadens a small set of cross-class member accesses and makes flattened classes public, because independently emitted Java files cannot use the original private/package access arrangement as-is. Generic signatures are not fully restored. New Java compilation creates its own synthetic methods and implementation details. Symbol restoration does not erase these differences.

### Record and enum handling

The category is represented as a Java enum. Its compiler-generated helpers are not hand-written copies of the original shuffled bytecode. Original decoded enum-string fields are retained, but allocation/initialization details of compiler-generated enum names are not promised identical.

`a/uz`, now `BedPlateEntry`, was a record. Its original ObjectMethods bootstrap handles refer to field names `x`, `y`, `z`, and `stack`, while the physical fields in the uploaded bytecode are renamed `f689` through `f692`. The source reconstructs intended structural equality, hashing, and string representation over the actual fields instead of deliberately reproducing a suspected broken bootstrap linkage. It is emitted as an ordinary final class, not an exact record-metadata restoration. Record reflection and a possible original linkage failure therefore are **not preserved**. This is a documented intentional reconstruction choice.

### Behavior that looks like a bug is not automatically corrected

For example, the number-setting constructor copies its current value into the default-value field before assigning the supplied value. The reconstructed constructor retains that ordering rather than silently changing the default. Module categories also follow the original data: `AutoBlockIn` is placed in Visual because that is the category in its constructor.

### Build and execution limits

No real Minecraft 26.2 runtime, Fabric environment, native authentication flow, or Windows integration was run. No loadable replacement client JAR is supplied. Real dependency overloads, generics, annotation processing, runtime mixin application, and DLL interaction require separate validation with the actual matching environment. The API-signature fixtures must never be used as runtime dependencies or shipped with a mod.

## Where to start

Read `MODULE_INDEX.md`, then open `source/cryptix/module/impl/`. `source/cryptix/module/Module.java`, `ModuleManager.java`, `source/cryptix/event/`, and `source/cryptix/setting/` contain the shared behavior.

Use `mappings.json` and `recovery-manifest.json` to trace descriptive names and recovered methods back to original signatures. `normalized/normalized.json` contains the normalized instructions and frames for independent inspection. `audit/original-java-classes.jar` preserves the original Java class bytes as the reference, without the native library or resources.

The original supplied metadata says `All Rights Reserved`. This reconstruction does not grant a new license or imply that the client's code is open source.
